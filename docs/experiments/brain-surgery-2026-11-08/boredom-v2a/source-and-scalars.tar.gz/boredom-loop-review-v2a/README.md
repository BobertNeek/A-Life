# Frozen boredom-loop research review

Research candidate only. No promotion, GPU qualification or autonomous-life
claim. Start with source/docs/experiments/boredom-loop-candidate-2026-11-08/
results.md, source-lineage.md and fatigue-diagnosis.md.

The 60 controlled episodes are two sampling streams on one fixed inherited
candidate, not 60 independent genetic replications. Original run counts were
48 × 24 ticks, 8 × 96 ticks and 4 × 24 ticks. No allocation was rerun.

Apply patches to baseline 2da9dd323ad6f074556a851174a2edbc9e34e216 in order:
1. biological-drive-audit-v1-source.patch
2. rest-motion-world-candidate-v1.patch
3. boredom-loop-candidate-v2a-source.patch

ALLOWLIST.json lists exact payload files and hashes. MANIFEST.sha256 additionally
binds this README and the allowlist. The source-only patch is separate from
receipt projections. The compiled binary is represented by its digest only.
No checkpoints, acquired banks, executables or whole learned arrays are present.
