//! Bounded sparse biochemical graphs and typed neural coupling.

use serde::{Deserialize, Serialize};
use std::sync::Arc;

use crate::{
    BodyEventDelta, BodyState, DriveSnapshot, EndocrineProfile, EndocrineSnapshot,
    HomeostaticSnapshot, ScaffoldContractError, Tick, Validate, MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
};

pub const BIOCHEMICAL_GRAPH_SCHEMA_VERSION: u16 = 3;
pub const MAX_ACTIVE_CHEMICAL_SPECIES: usize = 32;
pub const MAX_ACTIVE_REACTIONS: usize = 128;
pub const MAX_ACTIVE_EMITTERS: usize = 64;
pub const MAX_ACTIVE_RECEPTORS: usize = 64;
pub const MAX_ACTIVE_NEUROEMITTERS: usize = 32;
pub const MAX_NEURAL_RECEPTOR_ACTIVATIONS: usize = 32;
pub const MAX_NEURAL_EMISSIONS: usize = 16;

const CONCENTRATION_ROUNDING_TOLERANCE: f64 = 1.0e-6;

#[repr(transparent)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct ChemicalSpeciesId(pub u16);

impl ChemicalSpeciesId {
    pub fn validate(self) -> Result<(), ScaffoldContractError> {
        if self.0 == 0 {
            Err(ScaffoldContractError::InvalidId)
        } else {
            Ok(())
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChemicalSpeciesKind {
    Material,
    Regulatory,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChemicalCompartment {
    Circulation,
    Neural,
    Gut,
    Organ(u8),
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct ChemicalSpecies {
    pub id: ChemicalSpeciesId,
    pub kind: ChemicalSpeciesKind,
    pub compartment: ChemicalCompartment,
    pub baseline: f32,
    pub decay_retention: f32,
    pub minimum: f32,
    pub maximum: f32,
}

impl ChemicalSpecies {
    fn expressed_baseline(self, developmental_expression: f32) -> f32 {
        match self.kind {
            ChemicalSpeciesKind::Material => self.baseline,
            ChemicalSpeciesKind::Regulatory => {
                self.minimum + (self.baseline - self.minimum) * developmental_expression
            }
        }
    }
}

impl Validate for ChemicalSpecies {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.id.validate()?;
        validate_finite_values(&[
            self.baseline,
            self.decay_retention,
            self.minimum,
            self.maximum,
        ])?;
        if !(0.0..=1.0).contains(&self.decay_retention)
            || self.minimum < 0.0
            || self.minimum >= self.maximum
            || !(self.minimum..=self.maximum).contains(&self.baseline)
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct StoichiometricTerm {
    pub species: ChemicalSpeciesId,
    pub amount: f32,
}

impl Validate for StoichiometricTerm {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.species.validate()?;
        validate_finite_values(&[self.amount])?;
        if self.amount <= 0.0 {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SparseReaction {
    pub reactants: Vec<StoichiometricTerm>,
    pub products: Vec<StoichiometricTerm>,
    pub rate: f32,
    pub rate_control: Option<ChemicalSpeciesId>,
}

impl Validate for SparseReaction {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        if self.reactants.is_empty()
            || self.reactants.len() > 2
            || self.products.is_empty()
            || self.products.len() > 2
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        validate_finite_values(&[self.rate])?;
        if !(0.0..=1.0).contains(&self.rate) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        for term in self.reactants.iter().chain(self.products.iter()) {
            term.validate_contract()?;
        }
        if let Some(control) = self.rate_control {
            control.validate()?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BiochemicalSourceLocus {
    Basal,
    EnergyDeficit,
    Damage,
    TemperatureStress,
    Nutrition,
    SocialContact,
    SleepRecovery,
    MatingOpportunity,
    Awake,
    Sleeping,
    PlayerReward,
    PlayStimulation,
    PerceivedNovelty,
    Investigation,
    /// Persistent loss of viability, distinct from the one-shot damage event.
    HealthDeficit,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum EmitterResponse {
    Analogue,
    Digital,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct BiochemicalEmitter {
    pub source: BiochemicalSourceLocus,
    pub target: ChemicalSpeciesId,
    pub cadence_ticks: u32,
    pub threshold: f32,
    pub gain: f32,
    pub response: EmitterResponse,
    pub inverted: bool,
    /// Inherited basal expression for this emitter while other chemistry matures.
    #[serde(default, skip_serializing_if = "zero_expression_floor")]
    pub developmental_expression_floor: f32,
}

fn zero_expression_floor(value: &f32) -> bool {
    *value == 0.0
}

impl Validate for BiochemicalEmitter {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.target.validate()?;
        validate_finite_values(&[
            self.threshold,
            self.gain,
            self.developmental_expression_floor,
        ])?;
        if self.cadence_ticks == 0
            || !(0.0..=1.0).contains(&self.threshold)
            || !(-1.0..=1.0).contains(&self.gain)
            || !(0.0..=1.0).contains(&self.developmental_expression_floor)
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DriveChannel {
    Hunger,
    Fatigue,
    Fear,
    Pain,
    Loneliness,
    Curiosity,
    BrainAtp,
    TemperatureStress,
    Reproductive,
    Extension0,
    Extension1,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum EndocrineChannel {
    Adrenaline,
    Cortisol,
    Dopamine,
    Oxytocin,
    Serotonin,
    Acetylcholine,
    LearningModulator,
    DevelopmentalHormone,
    SleepPressure,
    Extension0,
    Extension1,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum NeuralReceptorClass {
    InteroceptiveInput,
    RegionalExcitability,
    ProjectionGain,
    LocalThreshold,
    AttentionGate,
    PlasticityAppetitive,
    PlasticityAversive,
    StructuralGrowth,
    Sleep,
    Consolidation,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BiochemicalTargetLocus {
    Drive(DriveChannel),
    Endocrine(EndocrineChannel),
    Neural(NeuralReceptorClass),
    Development(u8),
    Autonomic(u8),
    OrganEnergyUse,
    OrganRepair,
    LocomotorCapacity,
    SleepMetabolicRate,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct BiochemicalReceptor {
    pub source: ChemicalSpeciesId,
    pub target: BiochemicalTargetLocus,
    pub threshold: f32,
    pub gain: f32,
    #[serde(default, skip_serializing_if = "zero_expression_floor")]
    pub nominal: f32,
    #[serde(default, skip_serializing_if = "is_false")]
    pub digital: bool,
}

fn is_false(value: &bool) -> bool {
    !*value
}

impl Validate for BiochemicalReceptor {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.source.validate()?;
        validate_finite_values(&[self.threshold, self.gain, self.nominal])?;
        if !(0.0..=1.0).contains(&self.nominal) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        if !(0.0..=1.0).contains(&self.threshold) || !(-2.0..=2.0).contains(&self.gain) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NeuralEmissionClass {
    RegionalArousal,
    PredictionResidual,
    MotorCommitment,
    UnresolvedGap,
    SocialState,
    ExecutiveSustain,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Neuroemitter {
    pub source: NeuralEmissionClass,
    pub target: ChemicalSpeciesId,
    pub threshold: f32,
    pub gain: f32,
}

impl Validate for Neuroemitter {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.target.validate()?;
        validate_finite_values(&[self.threshold, self.gain])?;
        if !(0.0..=1.0).contains(&self.threshold) || !(-1.0..=1.0).contains(&self.gain) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct NeuralEmission {
    pub class: NeuralEmissionClass,
    pub activity: f32,
    pub confidence: f32,
}

impl NeuralEmission {
    pub fn new(
        class: NeuralEmissionClass,
        activity: f32,
        confidence: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let value = Self {
            class,
            activity,
            confidence,
        };
        value.validate_contract()?;
        Ok(value)
    }
}

impl Validate for NeuralEmission {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        validate_unit_values(&[self.activity, self.confidence])
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct NeuralEmissionFrame {
    pub schema_version: u16,
    pub source_tick: Tick,
    pub graph_epoch: u64,
    pub emissions: Vec<NeuralEmission>,
}

impl NeuralEmissionFrame {
    pub fn new(
        source_tick: Tick,
        graph_epoch: u64,
        emissions: Vec<NeuralEmission>,
    ) -> Result<Self, ScaffoldContractError> {
        let frame = Self {
            schema_version: BIOCHEMICAL_GRAPH_SCHEMA_VERSION,
            source_tick,
            graph_epoch,
            emissions,
        };
        frame.validate_contract()?;
        Ok(frame)
    }
}

impl Validate for NeuralEmissionFrame {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        if self.schema_version != BIOCHEMICAL_GRAPH_SCHEMA_VERSION
            || self.graph_epoch == 0
            || self.emissions.len() > MAX_NEURAL_EMISSIONS
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        for emission in &self.emissions {
            emission.validate_contract()?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct NeuralReceptorActivation {
    pub class: NeuralReceptorClass,
    pub signal: f32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct NeuralReceptorFrame {
    pub schema_version: u16,
    pub source_chemistry_version: u16,
    pub source_tick: Tick,
    pub activations: Vec<NeuralReceptorActivation>,
}

impl NeuralReceptorFrame {
    pub fn activation_for(&self, class: NeuralReceptorClass) -> f32 {
        self.activations
            .iter()
            .find(|activation| activation.class == class)
            .map_or(0.0, |activation| activation.signal)
    }
}

impl Validate for NeuralReceptorFrame {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        if self.schema_version != BIOCHEMICAL_GRAPH_SCHEMA_VERSION
            || self.source_chemistry_version != BIOCHEMICAL_GRAPH_SCHEMA_VERSION
            || self.activations.len() > MAX_NEURAL_RECEPTOR_ACTIVATIONS
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        let mut classes = self
            .activations
            .iter()
            .map(|activation| activation.class)
            .collect::<Vec<_>>();
        classes.sort();
        if classes.windows(2).any(|pair| pair[0] == pair[1]) {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        validate_unit_values(
            &self
                .activations
                .iter()
                .map(|activation| activation.signal)
                .collect::<Vec<_>>(),
        )
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(try_from = "BiochemicalPhenotypeWire")]
pub struct BiochemicalPhenotype {
    #[serde(
        default,
        skip_serializing_if = "crate::chemistry::BiologicalValueProfile::is_default"
    )]
    value_profile: crate::chemistry::BiologicalValueProfile,
    schema_version: u16,
    species_budget: usize,
    reaction_budget: usize,
    species: Vec<ChemicalSpecies>,
    reactions: Vec<SparseReaction>,
    emitters: Vec<BiochemicalEmitter>,
    receptors: Vec<BiochemicalReceptor>,
    neuroemitters: Vec<Neuroemitter>,
    #[serde(skip)]
    compiled: Arc<CompiledBiochemistry>,
}

// Only genetic source data crosses persistence boundaries. Rebuild derived indexes
// once on load; private source fields cannot invalidate them during simulation.
#[derive(Deserialize)]
struct BiochemicalPhenotypeWire {
    #[serde(default)]
    value_profile: crate::chemistry::BiologicalValueProfile,
    schema_version: u16,
    species_budget: usize,
    reaction_budget: usize,
    species: Vec<ChemicalSpecies>,
    reactions: Vec<SparseReaction>,
    emitters: Vec<BiochemicalEmitter>,
    receptors: Vec<BiochemicalReceptor>,
    neuroemitters: Vec<Neuroemitter>,
}

impl TryFrom<BiochemicalPhenotypeWire> for BiochemicalPhenotype {
    type Error = ScaffoldContractError;
    fn try_from(wire: BiochemicalPhenotypeWire) -> Result<Self, Self::Error> {
        let mut value = Self {
            value_profile: wire.value_profile,
            schema_version: wire.schema_version,
            species_budget: wire.species_budget,
            reaction_budget: wire.reaction_budget,
            species: wire.species,
            reactions: wire.reactions,
            emitters: wire.emitters,
            receptors: wire.receptors,
            neuroemitters: wire.neuroemitters,
            compiled: Arc::default(),
        };
        value.compile()?;
        Ok(value)
    }
}

#[derive(Debug, Clone, Default, PartialEq)]
struct CompiledBiochemistry {
    reactions: Vec<Vec<ReactionParticipant>>,
    rate_controls: Vec<Option<usize>>,
    emitter_targets: Vec<usize>,
    neuroemitter_targets: Vec<usize>,
    receptor_groups: Vec<ReceptorGroup>,
    organ_energy_group: Option<usize>,
    organ_repair_group: Option<usize>,
    locomotor_capacity_group: Option<usize>,
    sleep_metabolic_group: Option<usize>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct ReactionParticipant {
    index: usize,
    gross: f64,
    net: f64,
}

#[derive(Debug, Clone, PartialEq)]
struct ReceptorGroup {
    target: BiochemicalTargetLocus,
    // receptor index and resolved concentration index
    inputs: Vec<(usize, usize)>,
}

impl BiochemicalPhenotype {
    /// Recombine only homologous parameters. Wiring, species bounds, and budgets
    /// remain a coherent inherited graph; no runtime concentrations are involved.
    pub(crate) fn map_homologous_parameters(
        &self,
        other: &Self,
        mut map: impl FnMut(f32, f32, f32, f32) -> Result<f32, ScaffoldContractError>,
    ) -> Result<Self, ScaffoldContractError> {
        self.validate_contract()?;
        other.validate_contract()?;
        let homologous = self.species.len() == other.species.len()
            && self.species.iter().zip(&other.species).all(|(a, b)| {
                a.id == b.id
                    && a.kind == b.kind
                    && a.compartment == b.compartment
                    && a.minimum == b.minimum
                    && a.maximum == b.maximum
            })
            && self.reactions.len() == other.reactions.len()
            && self.reactions.iter().zip(&other.reactions).all(|(a, b)| {
                a.rate_control == b.rate_control
                    && a.reactants == b.reactants
                    && a.products == b.products
            })
            && self.emitters.len() == other.emitters.len()
            && self.emitters.iter().zip(&other.emitters).all(|(a, b)| {
                a.source == b.source
                    && a.target == b.target
                    && a.cadence_ticks == b.cadence_ticks
                    && a.response == b.response
                    && a.inverted == b.inverted
            })
            && self.receptors.len() == other.receptors.len()
            && self.receptors.iter().zip(&other.receptors).all(|(a, b)| {
                a.source == b.source && a.target == b.target && a.digital == b.digital
            })
            && self.neuroemitters.len() == other.neuroemitters.len()
            && self
                .neuroemitters
                .iter()
                .zip(&other.neuroemitters)
                .all(|(a, b)| a.source == b.source && a.target == b.target);
        // Unmatched topology is an intact structural allele, not a half-built organ.
        let other = if homologous { other } else { self };
        let mut child = self.clone();
        for (a, b) in child.species.iter_mut().zip(&other.species) {
            a.baseline = map(a.baseline, b.baseline, a.minimum, a.maximum)?;
            a.decay_retention = map(a.decay_retention, b.decay_retention, 0.0, 1.0)?;
        }
        for (a, b) in child.reactions.iter_mut().zip(&other.reactions) {
            a.rate = map(a.rate, b.rate, 0.0, 1.0)?;
        }
        for (a, b) in child.emitters.iter_mut().zip(&other.emitters) {
            a.threshold = map(a.threshold, b.threshold, 0.0, 1.0)?;
            a.gain = map(a.gain, b.gain, -1.0, 1.0)?;
            a.developmental_expression_floor = map(
                a.developmental_expression_floor,
                b.developmental_expression_floor,
                0.0,
                1.0,
            )?;
        }
        for (a, b) in child.receptors.iter_mut().zip(&other.receptors) {
            a.threshold = map(a.threshold, b.threshold, 0.0, 1.0)?;
            a.gain = map(a.gain, b.gain, -2.0, 2.0)?;
            a.nominal = map(a.nominal, b.nominal, 0.0, 1.0)?;
        }
        for (a, b) in child.neuroemitters.iter_mut().zip(&other.neuroemitters) {
            a.threshold = map(a.threshold, b.threshold, 0.0, 1.0)?;
            a.gain = map(a.gain, b.gain, -1.0, 1.0)?;
        }
        for (a, b) in child
            .value_profile
            .drives
            .iter_mut()
            .zip(other.value_profile.drives)
        {
            *a = map(*a, b, -2.0, 2.0)?;
        }
        for (a, b) in child
            .value_profile
            .hormones
            .iter_mut()
            .zip(other.value_profile.hormones)
        {
            *a = map(*a, b, -2.0, 2.0)?;
        }
        child.value_profile.energy = map(
            child.value_profile.energy,
            other.value_profile.energy,
            -2.0,
            2.0,
        )?;
        child.value_profile.injury = map(
            child.value_profile.injury,
            other.value_profile.injury,
            0.0,
            2.0,
        )?;
        child.value_profile.disappointment = map(
            child.value_profile.disappointment,
            other.value_profile.disappointment,
            0.0,
            1.0,
        )?;
        child.compile()?;
        Ok(child)
    }

    /// Default-centered modifiers compile chromosome traits into the same graph
    /// that owns physiology. They do not create a second endocrine simulation.
    pub(crate) fn with_chromosome_traits(
        &self,
        chemistry: &crate::ChemistryPhenotype,
        temperament: &crate::PredispositionPhenotype,
    ) -> Result<Self, ScaffoldContractError> {
        use ids::*;
        let center = crate::ContinuousLocus::midpoint_value;
        let scale = |value: f32, reference: f32| (value - reference).exp2();
        let stress = scale(chemistry.stress_baseline, center(0.18, 0.24));
        let reward = scale(chemistry.reward_sensitivity, center(0.50, 0.58));
        let bond = scale(chemistry.bonding_sensitivity, center(0.46, 0.54));
        let production = scale(chemistry.hormone_production, center(0.45, 0.52));
        let decay = scale(chemistry.hormone_decay, center(0.50, 0.57));
        let is_hormone = |id| {
            matches!(
                id,
                ADRENALINE
                    | CORTISOL
                    | DOPAMINE
                    | OXYTOCIN
                    | SEROTONIN
                    | ACETYLCHOLINE
                    | LEARNING_SIGNAL
                    | DEVELOPMENT_SIGNAL
                    | SLEEP_PRESSURE
            )
        };
        let mut result = self.clone();
        for chemical in &mut result.species {
            // Metabolic material reserves are not hormone production.
            if chemical.kind == ChemicalSpeciesKind::Regulatory {
                let gain = match chemical.id {
                    FEAR | ADRENALINE | CORTISOL => stress,
                    LONELINESS | OXYTOCIN | SEROTONIN => bond,
                    CURIOSITY => scale(temperament.novelty_bias, center(0.45, 0.53)),
                    _ => 1.0,
                };
                let gain = gain
                    * if is_hormone(chemical.id) {
                        production
                    } else {
                        1.0
                    };
                chemical.baseline =
                    (chemical.baseline * gain).clamp(chemical.minimum, chemical.maximum);
                chemical.decay_retention = chemical.decay_retention.powf(decay);
            }
        }
        for emitter in &mut result.emitters {
            let mut gain = if is_hormone(emitter.target) {
                production
            } else {
                1.0
            };
            if matches!(emitter.target, ADRENALINE | CORTISOL | FEAR) {
                gain *= stress;
            }
            if emitter.source == BiochemicalSourceLocus::SocialContact {
                gain *= bond * scale(temperament.social_attention, center(0.42, 0.50));
            }
            if emitter.target == FEAR {
                gain *= scale(temperament.hazard_aversion, center(0.58, 0.66));
            }
            emitter.gain = (emitter.gain * gain).clamp(-1.0, 1.0);
        }
        for emitter in &mut result.neuroemitters {
            if is_hormone(emitter.target) {
                emitter.gain = (emitter.gain * production).clamp(-1.0, 1.0);
            }
        }
        for receptor in &mut result.receptors {
            match receptor.target {
                BiochemicalTargetLocus::Drive(DriveChannel::Hunger) => {
                    receptor.threshold = (receptor.threshold
                        + (chemistry.hunger_threshold - center(0.38, 0.44)))
                    .clamp(0.0, 1.0);
                    receptor.gain = (receptor.gain
                        * scale(temperament.food_attraction, center(0.54, 0.62)))
                    .clamp(-2.0, 2.0);
                }
                BiochemicalTargetLocus::Drive(DriveChannel::Fatigue) => {
                    receptor.threshold = (receptor.threshold
                        + (chemistry.fatigue_threshold - center(0.66, 0.72)))
                    .clamp(0.0, 1.0);
                }
                BiochemicalTargetLocus::Drive(DriveChannel::Fear) => {
                    receptor.gain = (receptor.gain
                        * scale(temperament.hazard_aversion, center(0.58, 0.66)))
                    .clamp(-2.0, 2.0);
                }
                BiochemicalTargetLocus::Neural(NeuralReceptorClass::PlasticityAppetitive) => {
                    receptor.gain = (receptor.gain * reward).clamp(-2.0, 2.0);
                }
                _ => {}
            }
        }
        result.compile()?;
        Ok(result)
    }

    pub const fn value_profile(&self) -> crate::chemistry::BiologicalValueProfile {
        self.value_profile
    }

    pub(crate) fn with_value_profile(
        &self,
        profile: crate::chemistry::BiologicalValueProfile,
    ) -> Result<Self, ScaffoldContractError> {
        let mut value = self.clone();
        value.value_profile = profile;
        value.compile()?;
        Ok(value)
    }

    fn compile(&mut self) -> Result<(), ScaffoldContractError> {
        self.validate_contract()?;
        let mut compiled = CompiledBiochemistry::default();
        for reaction in &self.reactions {
            let mut participants: Vec<ReactionParticipant> = Vec::with_capacity(4);
            for (terms, sign) in [(&reaction.reactants, -1.0), (&reaction.products, 1.0)] {
                for term in terms {
                    let index = self
                        .species_index(term.species)
                        .ok_or(ScaffoldContractError::InvalidId)?;
                    let slot = match participants.iter().position(|row| row.index == index) {
                        Some(slot) => slot,
                        None => {
                            participants.push(ReactionParticipant {
                                index,
                                gross: 0.0,
                                net: 0.0,
                            });
                            participants.len() - 1
                        }
                    };
                    participants[slot].net += sign * f64::from(term.amount);
                    if sign < 0.0 {
                        participants[slot].gross += f64::from(term.amount);
                    }
                }
            }
            participants.sort_by_key(|row| row.index);
            compiled.reactions.push(participants);
            compiled.rate_controls.push(
                reaction
                    .rate_control
                    .map(|id| self.species_index(id).unwrap()),
            );
        }
        compiled.emitter_targets = self
            .emitters
            .iter()
            .map(|row| self.species_index(row.target).unwrap())
            .collect();
        compiled.neuroemitter_targets = self
            .neuroemitters
            .iter()
            .map(|row| self.species_index(row.target).unwrap())
            .collect();
        for (index, receptor) in self.receptors.iter().enumerate() {
            let slot = match compiled
                .receptor_groups
                .iter()
                .position(|group| group.target == receptor.target)
            {
                Some(slot) => slot,
                None => {
                    compiled.receptor_groups.push(ReceptorGroup {
                        target: receptor.target,
                        inputs: Vec::new(),
                    });
                    compiled.receptor_groups.len() - 1
                }
            };
            compiled.receptor_groups[slot]
                .inputs
                .push((index, self.species_index(receptor.source).unwrap()));
            match receptor.target {
                BiochemicalTargetLocus::OrganEnergyUse => compiled.organ_energy_group = Some(slot),
                BiochemicalTargetLocus::OrganRepair => compiled.organ_repair_group = Some(slot),
                BiochemicalTargetLocus::LocomotorCapacity => {
                    compiled.locomotor_capacity_group = Some(slot)
                }
                BiochemicalTargetLocus::SleepMetabolicRate => {
                    compiled.sleep_metabolic_group = Some(slot)
                }
                _ => {}
            }
        }
        self.compiled = Arc::new(compiled);
        Ok(())
    }
    pub fn species(&self) -> &[ChemicalSpecies] {
        &self.species
    }

    pub fn reactions(&self) -> &[SparseReaction] {
        &self.reactions
    }

    pub fn emitters(&self) -> &[BiochemicalEmitter] {
        &self.emitters
    }

    pub fn receptors(&self) -> &[BiochemicalReceptor] {
        &self.receptors
    }

    pub fn neuroemitters(&self) -> &[Neuroemitter] {
        &self.neuroemitters
    }

    pub const fn species_budget(&self) -> usize {
        self.species_budget
    }

    pub const fn reaction_budget(&self) -> usize {
        self.reaction_budget
    }

    pub(crate) fn with_reaction_rate(
        &self,
        reaction_index: usize,
        rate: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let mut value = self.clone();
        let reaction = value
            .reactions
            .get_mut(reaction_index)
            .ok_or(ScaffoldContractError::InvalidGeneticBounds)?;
        reaction.rate = rate;
        value.compile()?;
        Ok(value)
    }

    pub(crate) fn with_emitter_expression_floor(
        &self,
        emitter_index: usize,
        floor: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let mut value = self.clone();
        let emitter = value
            .emitters
            .get_mut(emitter_index)
            .ok_or(ScaffoldContractError::InvalidGeneticBounds)?;
        emitter.developmental_expression_floor = floor;
        value.compile()?;
        Ok(value)
    }

    pub(crate) fn with_emitter_gain(
        &self,
        emitter_index: usize,
        gain: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let mut value = self.clone();
        value
            .emitters
            .get_mut(emitter_index)
            .ok_or(ScaffoldContractError::InvalidGeneticBounds)?
            .gain = gain;
        value.compile()?;
        Ok(value)
    }

    pub(crate) fn with_receptor_nominal(
        &self,
        receptor_index: usize,
        nominal: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let mut value = self.clone();
        value
            .receptors
            .get_mut(receptor_index)
            .ok_or(ScaffoldContractError::InvalidGeneticBounds)?
            .nominal = nominal;
        value.compile()?;
        Ok(value)
    }

    /// Install an explicit inherited waking/recovery circuit. Legacy reference
    /// recipes and loaded concentrations remain unchanged until callers opt in.
    pub(crate) fn with_waking_recovery(mut self) -> Result<Self, ScaffoldContractError> {
        use ids::*;
        self.emitters.retain(|row| {
            row.target != SLEEP_STATE
                && !((row.target == FATIGUE && row.source == BiochemicalSourceLocus::EnergyDeficit)
                    || (row.source == BiochemicalSourceLocus::SleepRecovery
                        && row.target == BRAIN_ATP)
                    || (row.source == BiochemicalSourceLocus::Awake
                        && matches!(row.target, FATIGUE | SLEEP_PRESSURE)))
        });
        // Availability must not collapse at ordinary reserves merely because
        // sleeping no longer supplies a direct ATP boost. This sensitivity is
        // an inherited emitter parameter; actual neural work still pays reserve.
        for row in &mut self.emitters {
            if row.source == BiochemicalSourceLocus::EnergyDeficit && row.target == BRAIN_ATP {
                row.gain = -0.02;
            }
        }
        self.species.retain(|row| row.id != SLEEP_STATE);
        self.species.push(regulatory(SLEEP_STATE, 0.0, 0.0));
        self.species.sort_by_key(|row| row.id);
        let mut sleeping = emitter(BiochemicalSourceLocus::Sleeping, SLEEP_STATE, 1.0);
        sleeping.developmental_expression_floor = 1.0;
        self.emitters.push(sleeping);
        for id in [FATIGUE, SLEEP_PRESSURE] {
            let row = self
                .species
                .iter_mut()
                .find(|row| row.id == id)
                .ok_or(ScaffoldContractError::InvalidGeneticBounds)?;
            row.decay_retention = 0.99995;
            self.emitters
                .push(emitter(BiochemicalSourceLocus::Awake, id, 0.00007));
        }
        self.receptors.retain(|row| {
            !matches!(
                row.target,
                BiochemicalTargetLocus::LocomotorCapacity
                    | BiochemicalTargetLocus::SleepMetabolicRate
            )
        });
        self.receptors.push(BiochemicalReceptor {
            source: FATIGUE,
            target: BiochemicalTargetLocus::LocomotorCapacity,
            threshold: 0.0,
            gain: -1.0,
            nominal: 1.0,
            digital: false,
        });
        self.receptors.push(BiochemicalReceptor {
            source: SLEEP_STATE,
            target: BiochemicalTargetLocus::SleepMetabolicRate,
            threshold: 0.0,
            gain: -0.9,
            nominal: 1.0,
            digital: false,
        });
        self.receptors
            .sort_by_key(|row| (target_order(row.target), row.source));
        self.compile()?;
        Ok(self)
    }

    /// Keep injury salient while health remains low. The emitter lives in the
    /// inherited graph; an old saved graph is never rewritten on load.
    pub(crate) fn with_health_distress(mut self) -> Result<Self, ScaffoldContractError> {
        self.emitters.retain(|row| {
            !(row.source == BiochemicalSourceLocus::HealthDeficit && row.target == ids::PAIN)
        });
        let mut distress = emitter(BiochemicalSourceLocus::HealthDeficit, ids::PAIN, 0.1);
        // A mild scratch does not become a constant emergency through repeated
        // release. Acute damage still supplies the immediate pain spike.
        distress.threshold = 0.4;
        distress.developmental_expression_floor = 1.0;
        self.emitters.push(distress);
        self.compile()?;
        Ok(self)
    }

    /// Inherited boredom circuit, separate from exploratory curiosity. Toy
    /// use can relieve an existing need; it cannot manufacture praise or food.
    pub(crate) fn with_play_stimulation(mut self) -> Result<Self, ScaffoldContractError> {
        let boredom = ChemicalSpeciesId(22);
        self.species.retain(|row| row.id != boredom);
        self.species.push(regulatory(boredom, 0.0, 1.0));
        self.species.sort_by_key(|row| row.id);
        self.emitters.retain(|row| row.target != boredom);
        for (source, gain) in [
            (BiochemicalSourceLocus::Awake, 0.0002),
            (BiochemicalSourceLocus::PlayStimulation, -0.2),
        ] {
            let mut release = emitter(source, boredom, gain);
            release.developmental_expression_floor = 1.0;
            self.emitters.push(release);
        }
        self.receptors
            .retain(|row| row.target != BiochemicalTargetLocus::Drive(DriveChannel::Extension0));
        self.receptors.push(BiochemicalReceptor {
            source: boredom,
            target: BiochemicalTargetLocus::Drive(DriveChannel::Extension0),
            threshold: 0.0,
            gain: 1.0,
            nominal: 0.0,
            digital: false,
        });
        self.value_profile.drives[9] = -0.08;
        self.emitters.retain(|row| {
            !matches!(
                row.source,
                BiochemicalSourceLocus::PerceivedNovelty | BiochemicalSourceLocus::Investigation
            )
        });
        for (source, gain) in [
            (BiochemicalSourceLocus::PerceivedNovelty, 0.04),
            (BiochemicalSourceLocus::Investigation, -0.08),
        ] {
            let mut release = emitter(source, ids::CURIOSITY, gain);
            release.developmental_expression_floor = 1.0;
            self.emitters.push(release);
        }
        self.receptors
            .sort_by_key(|row| (target_order(row.target), row.source));
        self.compile()?;
        Ok(self)
    }

    pub(crate) fn with_player_reward(mut self) -> Result<Self, ScaffoldContractError> {
        // Newborns can receive care before mature regulatory expression.
        for row in &mut self.emitters {
            if row.source == BiochemicalSourceLocus::SocialContact {
                row.developmental_expression_floor = 1.0;
            }
        }
        let praise = ChemicalSpeciesId(21);
        self.species.retain(|row| row.id != praise);
        self.species.push(regulatory(praise, 0.0, 0.25));
        self.species.sort_by_key(|row| row.id);
        self.emitters.retain(|row| {
            row.source != BiochemicalSourceLocus::PlayerReward || row.target != praise
        });
        let mut release = emitter(BiochemicalSourceLocus::PlayerReward, praise, 0.6);
        release.developmental_expression_floor = 1.0;
        self.emitters.push(release);
        self.receptors.retain(|row| {
            row.target != BiochemicalTargetLocus::Endocrine(EndocrineChannel::Extension0)
        });
        self.receptors.push(BiochemicalReceptor {
            source: praise,
            target: BiochemicalTargetLocus::Endocrine(EndocrineChannel::Extension0),
            threshold: 0.0,
            gain: 1.0,
            nominal: 0.0,
            digital: false,
        });
        self.value_profile.hormones[9] = 0.3;
        self.receptors
            .sort_by_key(|row| (target_order(row.target), row.source));
        self.compile()?;
        Ok(self)
    }

    pub(crate) fn early_mammal_reference(
        endocrine: EndocrineProfile,
        brain_atp_baseline: f32,
    ) -> Result<Self, ScaffoldContractError> {
        use ids::*;
        let drives = DriveSnapshot {
            brain_atp: brain_atp_baseline,
            ..DriveSnapshot::baseline()
        };
        let hormones = endocrine.baseline;
        let drive_decay = 1.0 - endocrine.parameters.drive_decay_per_update;
        let hormone_decay = 1.0 - endocrine.parameters.hormone_decay_per_update;
        let mut species = vec![
            regulatory(HUNGER, drives.hunger, drive_decay),
            regulatory(FATIGUE, drives.fatigue, drive_decay),
            regulatory(FEAR, drives.fear, drive_decay),
            regulatory(PAIN, drives.pain, drive_decay),
            regulatory(LONELINESS, drives.loneliness, drive_decay),
            regulatory(CURIOSITY, drives.curiosity, drive_decay),
            material(BRAIN_ATP, drives.brain_atp, drive_decay),
            regulatory(TEMPERATURE, drives.temperature_stress, drive_decay),
            regulatory(REPRODUCTIVE, drives.reproductive_drive, drive_decay),
            regulatory(ADRENALINE, hormones.adrenaline, hormone_decay),
            regulatory(CORTISOL, hormones.cortisol, hormone_decay),
            regulatory(DOPAMINE, hormones.dopamine, hormone_decay),
            regulatory(OXYTOCIN, hormones.oxytocin, hormone_decay),
            regulatory(SEROTONIN, hormones.serotonin, hormone_decay),
            regulatory(ACETYLCHOLINE, hormones.acetylcholine, hormone_decay),
            regulatory(LEARNING_SIGNAL, hormones.learning_modulator, hormone_decay),
            regulatory(
                DEVELOPMENT_SIGNAL,
                hormones.developmental_hormone,
                hormone_decay,
            ),
            regulatory(SLEEP_PRESSURE, hormones.sleep_pressure, hormone_decay),
            material(NUTRIENT, 0.0, 0.5),
        ];
        species.sort_by_key(|row| row.id);
        let reactions = vec![SparseReaction {
            reactants: vec![term(NUTRIENT, 1.0)],
            products: vec![term(BRAIN_ATP, 1.0)],
            rate: 0.5,
            rate_control: None,
        }];
        let emitters = vec![
            emitter(BiochemicalSourceLocus::EnergyDeficit, HUNGER, 0.18),
            emitter(BiochemicalSourceLocus::EnergyDeficit, FATIGUE, 0.12),
            emitter(BiochemicalSourceLocus::EnergyDeficit, BRAIN_ATP, -0.12),
            emitter(BiochemicalSourceLocus::Damage, PAIN, 0.80),
            emitter(BiochemicalSourceLocus::Damage, FEAR, 0.35),
            emitter(BiochemicalSourceLocus::Damage, ADRENALINE, 0.55),
            emitter(BiochemicalSourceLocus::Damage, CORTISOL, 0.65),
            emitter(BiochemicalSourceLocus::Nutrition, NUTRIENT, 0.80),
            emitter(BiochemicalSourceLocus::Nutrition, HUNGER, -0.30),
            emitter(BiochemicalSourceLocus::Nutrition, DOPAMINE, 0.12),
            emitter(BiochemicalSourceLocus::Nutrition, DEVELOPMENT_SIGNAL, 0.08),
            emitter(BiochemicalSourceLocus::PlayerReward, DOPAMINE, 0.18),
            emitter(BiochemicalSourceLocus::SocialContact, LONELINESS, -0.60),
            emitter(BiochemicalSourceLocus::SocialContact, OXYTOCIN, 0.45),
            emitter(BiochemicalSourceLocus::SocialContact, SEROTONIN, 0.12),
            emitter(BiochemicalSourceLocus::SleepRecovery, FATIGUE, -0.70),
            emitter(BiochemicalSourceLocus::SleepRecovery, PAIN, -0.45),
            emitter(BiochemicalSourceLocus::SleepRecovery, SLEEP_PRESSURE, -0.75),
            emitter(BiochemicalSourceLocus::SleepRecovery, BRAIN_ATP, 0.30),
            emitter(BiochemicalSourceLocus::TemperatureStress, TEMPERATURE, 0.30),
            emitter(BiochemicalSourceLocus::TemperatureStress, CORTISOL, 0.20),
            emitter(
                BiochemicalSourceLocus::MatingOpportunity,
                REPRODUCTIVE,
                0.85,
            ),
        ];
        let mut receptors = vec![
            drive_receptor(HUNGER, DriveChannel::Hunger),
            drive_receptor(FATIGUE, DriveChannel::Fatigue),
            drive_receptor(FEAR, DriveChannel::Fear),
            drive_receptor(PAIN, DriveChannel::Pain),
            drive_receptor(LONELINESS, DriveChannel::Loneliness),
            drive_receptor(CURIOSITY, DriveChannel::Curiosity),
            drive_receptor(BRAIN_ATP, DriveChannel::BrainAtp),
            drive_receptor(TEMPERATURE, DriveChannel::TemperatureStress),
            drive_receptor(REPRODUCTIVE, DriveChannel::Reproductive),
            endocrine_receptor(ADRENALINE, EndocrineChannel::Adrenaline),
            endocrine_receptor(CORTISOL, EndocrineChannel::Cortisol),
            endocrine_receptor(DOPAMINE, EndocrineChannel::Dopamine),
            endocrine_receptor(OXYTOCIN, EndocrineChannel::Oxytocin),
            endocrine_receptor(SEROTONIN, EndocrineChannel::Serotonin),
            endocrine_receptor(ACETYLCHOLINE, EndocrineChannel::Acetylcholine),
            endocrine_receptor(LEARNING_SIGNAL, EndocrineChannel::LearningModulator),
            endocrine_receptor(DEVELOPMENT_SIGNAL, EndocrineChannel::DevelopmentalHormone),
            endocrine_receptor(SLEEP_PRESSURE, EndocrineChannel::SleepPressure),
            neural_receptor(ADRENALINE, NeuralReceptorClass::RegionalExcitability, 1.0),
            neural_receptor(CORTISOL, NeuralReceptorClass::PlasticityAversive, 1.0),
            neural_receptor(DOPAMINE, NeuralReceptorClass::PlasticityAppetitive, 1.0),
            neural_receptor(ACETYLCHOLINE, NeuralReceptorClass::AttentionGate, 1.0),
            neural_receptor(SLEEP_PRESSURE, NeuralReceptorClass::Sleep, 1.0),
            neural_receptor(SEROTONIN, NeuralReceptorClass::Consolidation, 1.0),
            BiochemicalReceptor {
                source: BRAIN_ATP,
                target: BiochemicalTargetLocus::OrganEnergyUse,
                threshold: 0.0,
                gain: 0.75,
                nominal: 0.25,
                digital: false,
            },
            BiochemicalReceptor {
                source: PAIN,
                target: BiochemicalTargetLocus::OrganRepair,
                threshold: 0.0,
                gain: 0.02,
                nominal: 0.0,
                digital: false,
            },
        ];
        receptors.sort_by_key(|row| (target_order(row.target), row.source));
        let neuroemitters = vec![
            Neuroemitter {
                source: NeuralEmissionClass::RegionalArousal,
                target: ADRENALINE,
                threshold: 0.0,
                gain: 0.15,
            },
            Neuroemitter {
                source: NeuralEmissionClass::PredictionResidual,
                target: ADRENALINE,
                threshold: 0.0,
                gain: 0.25,
            },
            Neuroemitter {
                source: NeuralEmissionClass::PredictionResidual,
                target: LEARNING_SIGNAL,
                threshold: 0.0,
                gain: 0.20,
            },
            Neuroemitter {
                source: NeuralEmissionClass::MotorCommitment,
                target: ACETYLCHOLINE,
                threshold: 0.0,
                gain: 0.10,
            },
            Neuroemitter {
                source: NeuralEmissionClass::SocialState,
                target: OXYTOCIN,
                threshold: 0.0,
                gain: 0.20,
            },
            Neuroemitter {
                source: NeuralEmissionClass::ExecutiveSustain,
                target: ACETYLCHOLINE,
                threshold: 0.0,
                gain: 0.15,
            },
        ];
        let mut value = Self {
            schema_version: BIOCHEMICAL_GRAPH_SCHEMA_VERSION,
            species_budget: MAX_ACTIVE_CHEMICAL_SPECIES,
            reaction_budget: MAX_ACTIVE_REACTIONS,
            species,
            reactions,
            emitters,
            receptors,
            neuroemitters,
            value_profile: crate::chemistry::BiologicalValueProfile::default(),
            compiled: Arc::default(),
        };
        value.compile()?;
        Ok(value)
    }

    fn species_index(&self, id: ChemicalSpeciesId) -> Option<usize> {
        self.species.binary_search_by_key(&id, |row| row.id).ok()
    }
}

impl Validate for BiochemicalPhenotype {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.value_profile.validate_contract()?;
        if self.schema_version != BIOCHEMICAL_GRAPH_SCHEMA_VERSION
            || self.species.is_empty()
            || self.species.len() > self.species_budget
            || self.species_budget > MAX_ACTIVE_CHEMICAL_SPECIES
            || self.reactions.len() > self.reaction_budget
            || self.reaction_budget > MAX_ACTIVE_REACTIONS
            || self.emitters.len() > MAX_ACTIVE_EMITTERS
            || self.receptors.len() > MAX_ACTIVE_RECEPTORS
            || self.neuroemitters.len() > MAX_ACTIVE_NEUROEMITTERS
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        for row in &self.species {
            row.validate_contract()?;
        }
        if self.species.windows(2).any(|pair| pair[0].id >= pair[1].id) {
            return Err(ScaffoldContractError::InvalidId);
        }
        for reaction in &self.reactions {
            reaction.validate_contract()?;
            validate_reaction_species(self, reaction)?;
        }
        for emitter in &self.emitters {
            emitter.validate_contract()?;
            require_species(self, emitter.target)?;
        }
        for receptor in &self.receptors {
            receptor.validate_contract()?;
            require_species(self, receptor.source)?;
        }
        for neuroemitter in &self.neuroemitters {
            neuroemitter.validate_contract()?;
            require_species(self, neuroemitter.target)?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct BiochemicalWorkReceipt {
    pub species_updates: u32,
    pub reaction_evaluations: u32,
    pub emitter_evaluations: u32,
    pub receptor_evaluations: u32,
    pub neural_emitter_evaluations: u32,
}

impl BiochemicalWorkReceipt {
    pub const fn total(self) -> u64 {
        self.species_updates as u64
            + self.reaction_evaluations as u64
            + self.emitter_evaluations as u64
            + self.receptor_evaluations as u64
            + self.neural_emitter_evaluations as u64
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct BiochemicalGraphState {
    schema_version: u16,
    tick: Tick,
    active_species: u16,
    concentrations: [f32; MAX_ACTIVE_CHEMICAL_SPECIES],
}

impl BiochemicalGraphState {
    pub fn new(
        phenotype: &BiochemicalPhenotype,
        tick: Tick,
        developmental_expression: f32,
    ) -> Result<Self, ScaffoldContractError> {
        phenotype.validate_contract()?;
        validate_developmental_expression(developmental_expression)?;
        let mut concentrations = [0.0; MAX_ACTIVE_CHEMICAL_SPECIES];
        for (index, species) in phenotype.species.iter().enumerate() {
            concentrations[index] = species.expressed_baseline(developmental_expression);
        }
        Ok(Self {
            schema_version: BIOCHEMICAL_GRAPH_SCHEMA_VERSION,
            tick,
            active_species: phenotype.species.len() as u16,
            concentrations,
        })
    }

    pub const fn tick(&self) -> Tick {
        self.tick
    }

    pub fn concentration(
        &self,
        phenotype: &BiochemicalPhenotype,
        species: ChemicalSpeciesId,
    ) -> Result<f32, ScaffoldContractError> {
        let index = phenotype
            .species_index(species)
            .ok_or(ScaffoldContractError::InvalidId)?;
        Ok(self.concentrations[index])
    }

    /// Decay and emitters publish into a staged state, then reactions execute
    /// sequentially in inherited declaration order. Each reaction consumes the
    /// preceding reaction's output. This bounded solver is order-dependent;
    /// sorting or deduplicating reaction genes changes organism dynamics.
    pub fn advance(
        &self,
        next_tick: Tick,
        body: BodyState,
        event: BodyEventDelta,
        neural: Option<&NeuralEmissionFrame>,
        phenotype: &BiochemicalPhenotype,
        developmental_expression: f32,
    ) -> Result<(Self, BiochemicalWorkReceipt), ScaffoldContractError> {
        self.validate_against(phenotype)?;
        validate_developmental_expression(developmental_expression)?;
        Tick::validate_monotonic(self.tick, next_tick)?;
        if let Some(frame) = neural {
            frame.validate_contract()?;
            if frame.source_tick != self.tick {
                return Err(ScaffoldContractError::NonMonotonicTick);
            }
        }
        let elapsed = next_tick.raw().saturating_sub(self.tick.raw()).min(64) as f32;
        let mut next = *self;
        next.tick = next_tick;
        for (index, species) in phenotype.species.iter().enumerate() {
            let expressed_baseline = species.expressed_baseline(developmental_expression);
            next.concentrations[index] = (expressed_baseline
                + (self.concentrations[index] - expressed_baseline)
                    * if elapsed == 1.0 {
                        species.decay_retention
                    } else {
                        species.decay_retention.powf(elapsed)
                    })
            .clamp(species.minimum, species.maximum);
        }
        for (emitter, target_index) in phenotype
            .emitters
            .iter()
            .zip(&phenotype.compiled.emitter_targets)
        {
            let cadence_crossings = crossed_cadence(self.tick, next_tick, emitter.cadence_ticks);
            if cadence_crossings > 0 {
                let source = source_value(emitter.source, body, event);
                let source = if emitter.inverted {
                    1.0 - source
                } else {
                    source
                };
                let response = match emitter.response {
                    EmitterResponse::Analogue => (source - emitter.threshold).max(0.0),
                    EmitterResponse::Digital => {
                        if source >= emitter.threshold {
                            1.0
                        } else {
                            0.0
                        }
                    }
                };
                let release_count = emitter_release_count(emitter.source, cadence_crossings);
                apply_delta(
                    phenotype,
                    &mut next,
                    *target_index,
                    response
                        * emitter.gain
                        * developmental_expression.max(emitter.developmental_expression_floor)
                        * release_count as f32,
                );
            }
        }
        let neural_evaluations = if let Some(frame) = neural {
            for (neuroemitter, target_index) in phenotype
                .neuroemitters
                .iter()
                .zip(&phenotype.compiled.neuroemitter_targets)
            {
                let activity = frame
                    .emissions
                    .iter()
                    .filter(|emission| emission.class == neuroemitter.source)
                    .map(|emission| emission.activity * emission.confidence)
                    .fold(0.0, f32::max);
                let response = (activity - neuroemitter.threshold).max(0.0);
                apply_delta(
                    phenotype,
                    &mut next,
                    *target_index,
                    response * neuroemitter.gain * developmental_expression,
                );
            }
            phenotype.neuroemitters.len() as u32
        } else {
            0
        };
        for (index, reaction) in phenotype.reactions.iter().enumerate() {
            apply_reaction(
                phenotype,
                &mut next,
                reaction,
                &phenotype.compiled.reactions[index],
                phenotype.compiled.rate_controls[index],
                elapsed * developmental_expression,
            )?;
        }
        next.validate_against(phenotype)?;
        Ok((
            next,
            BiochemicalWorkReceipt {
                species_updates: phenotype.species.len() as u32,
                reaction_evaluations: phenotype.reactions.len() as u32,
                emitter_evaluations: phenotype.emitters.len() as u32,
                receptor_evaluations: phenotype.receptors.len() as u32,
                neural_emitter_evaluations: neural_evaluations,
            },
        ))
    }

    pub fn derive_homeostasis(
        &self,
        phenotype: &BiochemicalPhenotype,
    ) -> Result<HomeostaticSnapshot, ScaffoldContractError> {
        self.validate_against(phenotype)?;
        let mut drives = DriveSnapshot {
            hunger: 0.0,
            fatigue: 0.0,
            fear: 0.0,
            pain: 0.0,
            loneliness: 0.0,
            curiosity: 0.0,
            brain_atp: 0.0,
            temperature_stress: 0.0,
            reproductive_drive: 0.0,
            extension: [0.0; crate::DRIVE_EXTENSION_SLOTS],
        };
        let mut hormones = EndocrineSnapshot {
            adrenaline: 0.0,
            cortisol: 0.0,
            dopamine: 0.0,
            oxytocin: 0.0,
            serotonin: 0.0,
            acetylcholine: 0.0,
            learning_modulator: 0.0,
            developmental_hormone: 0.0,
            sleep_pressure: 0.0,
            extension: [0.0; crate::ENDOCRINE_EXTENSION_SLOTS],
        };
        for group in &phenotype.compiled.receptor_groups {
            if !matches!(
                group.target,
                BiochemicalTargetLocus::Drive(_) | BiochemicalTargetLocus::Endocrine(_)
            ) {
                continue;
            }
            let signal = receptor_group_signal(self, phenotype, group);
            match group.target {
                BiochemicalTargetLocus::Drive(channel) => set_drive(&mut drives, channel, signal),
                BiochemicalTargetLocus::Endocrine(channel) => {
                    set_endocrine(&mut hormones, channel, signal)
                }
                _ => {}
            }
        }
        HomeostaticSnapshot::new(self.tick, drives, hormones)
    }

    pub fn organ_regulation(
        &self,
        phenotype: &BiochemicalPhenotype,
    ) -> Result<(Option<f32>, Option<f32>), ScaffoldContractError> {
        self.validate_against(phenotype)?;
        let evaluate = |index: Option<usize>| {
            index.map(|index| {
                receptor_group_signal(self, phenotype, &phenotype.compiled.receptor_groups[index])
            })
        };
        Ok((
            evaluate(phenotype.compiled.organ_energy_group),
            evaluate(phenotype.compiled.organ_repair_group),
        ))
    }

    /// None preserves exact legacy motor behavior. A present receptor supplies
    /// capacity only; it cannot select or replace the organism's movement intent.
    pub fn locomotor_capacity(
        &self,
        phenotype: &BiochemicalPhenotype,
    ) -> Result<Option<f32>, ScaffoldContractError> {
        self.validate_against(phenotype)?;
        Ok(phenotype.compiled.locomotor_capacity_group.map(|index| {
            receptor_group_signal(self, phenotype, &phenotype.compiled.receptor_groups[index])
        }))
    }

    pub fn sleep_metabolic_rate(
        &self,
        phenotype: &BiochemicalPhenotype,
    ) -> Result<Option<f32>, ScaffoldContractError> {
        self.validate_against(phenotype)?;
        Ok(phenotype.compiled.sleep_metabolic_group.map(|index| {
            receptor_group_signal(self, phenotype, &phenotype.compiled.receptor_groups[index])
        }))
    }

    pub fn neural_receptor_frame(
        &self,
        phenotype: &BiochemicalPhenotype,
    ) -> Result<NeuralReceptorFrame, ScaffoldContractError> {
        self.validate_against(phenotype)?;
        let mut activations = Vec::<NeuralReceptorActivation>::new();
        for group in &phenotype.compiled.receptor_groups {
            let BiochemicalTargetLocus::Neural(class) = group.target else {
                continue;
            };
            activations.push(NeuralReceptorActivation {
                class,
                signal: receptor_group_signal(self, phenotype, group),
            });
        }
        activations.sort_by_key(|row| row.class);
        let frame = NeuralReceptorFrame {
            schema_version: BIOCHEMICAL_GRAPH_SCHEMA_VERSION,
            source_chemistry_version: phenotype.schema_version,
            source_tick: self.tick,
            activations,
        };
        frame.validate_contract()?;
        Ok(frame)
    }

    pub fn validate_against(
        &self,
        phenotype: &BiochemicalPhenotype,
    ) -> Result<(), ScaffoldContractError> {
        if self.schema_version != BIOCHEMICAL_GRAPH_SCHEMA_VERSION
            || usize::from(self.active_species) != phenotype.species.len()
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        for (index, species) in phenotype.species.iter().enumerate() {
            let value = self.concentrations[index];
            if !value.is_finite() || !(species.minimum..=species.maximum).contains(&value) {
                return Err(ScaffoldContractError::ScalarOutOfRange);
            }
        }
        Ok(())
    }
}

fn validate_developmental_expression(value: f32) -> Result<(), ScaffoldContractError> {
    if !value.is_finite() || !(0.0..=1.0).contains(&value) {
        return Err(ScaffoldContractError::ScalarOutOfRange);
    }
    Ok(())
}

impl Validate for BiochemicalGraphState {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        if self.schema_version != BIOCHEMICAL_GRAPH_SCHEMA_VERSION
            || self.active_species == 0
            || usize::from(self.active_species) > MAX_ACTIVE_CHEMICAL_SPECIES
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        validate_nonnegative_values(&self.concentrations[..usize::from(self.active_species)])
    }
}

fn validate_reaction_species(
    phenotype: &BiochemicalPhenotype,
    reaction: &SparseReaction,
) -> Result<(), ScaffoldContractError> {
    for term in reaction.reactants.iter().chain(reaction.products.iter()) {
        require_species(phenotype, term.species)?;
    }
    if let Some(control) = reaction.rate_control {
        require_species(phenotype, control)?;
    }
    let material_reactant_total = reaction
        .reactants
        .iter()
        .filter(|term| {
            species(phenotype, term.species)
                .is_some_and(|row| row.kind == ChemicalSpeciesKind::Material)
        })
        .map(|term| f64::from(term.amount))
        .sum::<f64>();
    let material_product_total = reaction
        .products
        .iter()
        .filter(|term| {
            species(phenotype, term.species)
                .is_some_and(|row| row.kind == ChemicalSpeciesKind::Material)
        })
        .map(|term| f64::from(term.amount))
        .sum::<f64>();
    if (material_reactant_total - material_product_total).abs() > CONCENTRATION_ROUNDING_TOLERANCE {
        return Err(ScaffoldContractError::ScalarOutOfRange);
    }
    Ok(())
}

fn apply_reaction(
    phenotype: &BiochemicalPhenotype,
    state: &mut BiochemicalGraphState,
    reaction: &SparseReaction,
    participants: &[ReactionParticipant],
    rate_control: Option<usize>,
    elapsed: f32,
) -> Result<(), ScaffoldContractError> {
    if participants.iter().all(|row| row.net == 0.0) {
        return Ok(());
    }
    let mut available = f64::INFINITY;
    for participant in participants.iter().filter(|row| row.gross > 0.0) {
        let row = phenotype.species[participant.index];
        let concentration = f64::from(state.concentrations[participant.index]);
        let resource = if participant.net < 0.0 {
            concentration - f64::from(row.minimum)
        } else {
            concentration
        };
        if !resource.is_finite() {
            return Err(ScaffoldContractError::NonFiniteFloat);
        }
        if resource < 0.0 {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        available = available.min(resource / participant.gross);
    }
    let control = rate_control
        .map(|index| state.concentrations[index])
        .unwrap_or(1.0);
    let mut extent = f64::from(reaction.rate) * f64::from(elapsed) * f64::from(control) * available;
    if !extent.is_finite() {
        return Err(ScaffoldContractError::NonFiniteFloat);
    }
    extent = extent.max(0.0);
    if extent == 0.0 {
        return Ok(());
    }
    for participant in participants {
        let index = participant.index;
        let row = phenotype.species[index];
        let (room, divisor) = if participant.net < 0.0 {
            (
                f64::from(state.concentrations[index]) - f64::from(row.minimum),
                -participant.net,
            )
        } else if participant.net > 0.0 {
            (
                f64::from(row.maximum) - f64::from(state.concentrations[index]),
                participant.net,
            )
        } else {
            continue;
        };
        if room < 0.0 {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        let candidate = room / divisor;
        if !candidate.is_finite() {
            return Err(ScaffoldContractError::NonFiniteFloat);
        }
        extent = extent.min(candidate);
    }
    if extent == 0.0 {
        return Ok(());
    }
    // At most four participants. Validate all results before publishing any of them.
    let mut updates = [(0usize, 0.0f32); 4];
    let mut count = 0;
    for participant in participants.iter().filter(|row| row.net != 0.0) {
        let index = participant.index;
        let row = phenotype.species[index];
        let candidate = f64::from(state.concentrations[index]) + extent * participant.net;
        if !candidate.is_finite() {
            return Err(ScaffoldContractError::NonFiniteFloat);
        }
        if candidate < f64::from(row.minimum) - CONCENTRATION_ROUNDING_TOLERANCE
            || candidate > f64::from(row.maximum) + CONCENTRATION_ROUNDING_TOLERANCE
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        let value = candidate as f32;
        if !value.is_finite() {
            return Err(ScaffoldContractError::NonFiniteFloat);
        }
        updates[count] = (index, value.clamp(row.minimum, row.maximum));
        count += 1;
    }
    for &(index, value) in &updates[..count] {
        state.concentrations[index] = value;
    }
    Ok(())
}

fn apply_delta(
    phenotype: &BiochemicalPhenotype,
    state: &mut BiochemicalGraphState,
    index: usize,
    delta: f32,
) {
    let row = phenotype.species[index];
    state.concentrations[index] =
        (state.concentrations[index] + delta).clamp(row.minimum, row.maximum);
}

fn receptor_group_signal(
    state: &BiochemicalGraphState,
    phenotype: &BiochemicalPhenotype,
    group: &ReceptorGroup,
) -> f32 {
    let (mut nominal, mut positive, mut negative) = (0.0, 0.0, 0.0);
    let (mut positives, mut negatives) = (0, 0);
    for &(receptor_index, species_index) in &group.inputs {
        let receptor = phenotype.receptors[receptor_index];
        nominal += receptor.nominal;
        let excess = (state.concentrations[species_index] - receptor.threshold).max(0.0);
        let response = if receptor.digital {
            if excess > 0.0 {
                receptor.gain.abs()
            } else {
                0.0
            }
        } else {
            excess * receptor.gain.abs()
        };
        if receptor.gain.is_sign_negative() {
            negative += response;
            negatives += 1;
        } else {
            positive += response;
            positives += 1;
        }
    }
    let mut result = nominal / group.inputs.len() as f32;
    if positives > 0 {
        result = (result + positive / positives as f32).clamp(0.0, 1.0);
    }
    if negatives > 0 {
        result = (result - negative / negatives as f32).clamp(0.0, 1.0);
    }
    result
}

fn source_value(source: BiochemicalSourceLocus, body: BodyState, event: BodyEventDelta) -> f32 {
    match source {
        BiochemicalSourceLocus::Basal => 1.0,
        BiochemicalSourceLocus::EnergyDeficit => 1.0 - body.energy,
        BiochemicalSourceLocus::Damage => event.damage,
        BiochemicalSourceLocus::HealthDeficit => 1.0 - body.health,
        BiochemicalSourceLocus::TemperatureStress => body.temperature_stress,
        BiochemicalSourceLocus::Nutrition => event.nutrition,
        BiochemicalSourceLocus::SocialContact => event.social_contact,
        BiochemicalSourceLocus::SleepRecovery => event.sleep_recovery,
        BiochemicalSourceLocus::MatingOpportunity => event.mating_opportunity,
        BiochemicalSourceLocus::Awake => f32::from(!body.sleeping),
        BiochemicalSourceLocus::Sleeping => f32::from(body.sleeping),
        BiochemicalSourceLocus::PlayerReward => event.player_reward,
        BiochemicalSourceLocus::PlayStimulation => event.play_stimulation,
        BiochemicalSourceLocus::PerceivedNovelty => event.perceived_novelty,
        BiochemicalSourceLocus::Investigation => event.investigation,
    }
    .clamp(0.0, 1.0)
}

fn crossed_cadence(from: Tick, to: Tick, cadence: u32) -> u32 {
    let cadence = u64::from(cadence);
    let crossed = to.raw() / cadence - from.raw() / cadence;
    u32::try_from(crossed.min(u64::from(MAX_BIOCHEMISTRY_CATCH_UP_STEPS)))
        .unwrap_or(MAX_BIOCHEMISTRY_CATCH_UP_STEPS)
}

// Event-backed loci are one-shot/source-reset inputs for this advance. Basal
// and persistent body-state loci can be replayed for each missed boundary.
fn emitter_release_count(source: BiochemicalSourceLocus, cadence_crossings: u32) -> u32 {
    match source {
        BiochemicalSourceLocus::Damage
        | BiochemicalSourceLocus::Nutrition
        | BiochemicalSourceLocus::SocialContact
        | BiochemicalSourceLocus::SleepRecovery
        | BiochemicalSourceLocus::MatingOpportunity
        | BiochemicalSourceLocus::PlayerReward
        | BiochemicalSourceLocus::PlayStimulation
        | BiochemicalSourceLocus::PerceivedNovelty
        | BiochemicalSourceLocus::Investigation => 1,
        BiochemicalSourceLocus::Basal
        | BiochemicalSourceLocus::Awake
        | BiochemicalSourceLocus::Sleeping
        | BiochemicalSourceLocus::EnergyDeficit
        | BiochemicalSourceLocus::HealthDeficit
        | BiochemicalSourceLocus::TemperatureStress => cadence_crossings,
    }
}

fn set_drive(drives: &mut DriveSnapshot, channel: DriveChannel, signal: f32) {
    match channel {
        DriveChannel::Hunger => drives.hunger = signal,
        DriveChannel::Fatigue => drives.fatigue = signal,
        DriveChannel::Fear => drives.fear = signal,
        DriveChannel::Pain => drives.pain = signal,
        DriveChannel::Loneliness => drives.loneliness = signal,
        DriveChannel::Curiosity => drives.curiosity = signal,
        DriveChannel::BrainAtp => drives.brain_atp = signal,
        DriveChannel::TemperatureStress => drives.temperature_stress = signal,
        DriveChannel::Reproductive => drives.reproductive_drive = signal,
        DriveChannel::Extension0 => drives.extension[0] = signal,
        DriveChannel::Extension1 => drives.extension[1] = signal,
    }
}

fn set_endocrine(hormones: &mut EndocrineSnapshot, channel: EndocrineChannel, signal: f32) {
    match channel {
        EndocrineChannel::Adrenaline => hormones.adrenaline = signal,
        EndocrineChannel::Cortisol => hormones.cortisol = signal,
        EndocrineChannel::Dopamine => hormones.dopamine = signal,
        EndocrineChannel::Oxytocin => hormones.oxytocin = signal,
        EndocrineChannel::Serotonin => hormones.serotonin = signal,
        EndocrineChannel::Acetylcholine => hormones.acetylcholine = signal,
        EndocrineChannel::LearningModulator => hormones.learning_modulator = signal,
        EndocrineChannel::DevelopmentalHormone => hormones.developmental_hormone = signal,
        EndocrineChannel::SleepPressure => hormones.sleep_pressure = signal,
        EndocrineChannel::Extension0 => hormones.extension[0] = signal,
        EndocrineChannel::Extension1 => hormones.extension[1] = signal,
    }
}

fn species(phenotype: &BiochemicalPhenotype, id: ChemicalSpeciesId) -> Option<&ChemicalSpecies> {
    phenotype
        .species_index(id)
        .map(|index| &phenotype.species[index])
}

fn require_species(
    phenotype: &BiochemicalPhenotype,
    id: ChemicalSpeciesId,
) -> Result<(), ScaffoldContractError> {
    species(phenotype, id)
        .map(|_| ())
        .ok_or(ScaffoldContractError::InvalidId)
}

fn validate_finite_values(values: &[f32]) -> Result<(), ScaffoldContractError> {
    if values.iter().any(|value| !value.is_finite()) {
        Err(ScaffoldContractError::NonFiniteFloat)
    } else {
        Ok(())
    }
}

fn validate_unit_values(values: &[f32]) -> Result<(), ScaffoldContractError> {
    validate_finite_values(values)?;
    if values.iter().any(|value| !(0.0..=1.0).contains(value)) {
        Err(ScaffoldContractError::ScalarOutOfRange)
    } else {
        Ok(())
    }
}

fn validate_nonnegative_values(values: &[f32]) -> Result<(), ScaffoldContractError> {
    validate_finite_values(values)?;
    if values.iter().any(|value| *value < 0.0) {
        Err(ScaffoldContractError::ScalarOutOfRange)
    } else {
        Ok(())
    }
}

fn regulatory(id: ChemicalSpeciesId, baseline: f32, decay: f32) -> ChemicalSpecies {
    ChemicalSpecies {
        id,
        kind: ChemicalSpeciesKind::Regulatory,
        compartment: ChemicalCompartment::Circulation,
        baseline,
        decay_retention: decay.clamp(0.0, 1.0),
        minimum: 0.0,
        maximum: 1.0,
    }
}

fn material(id: ChemicalSpeciesId, baseline: f32, decay: f32) -> ChemicalSpecies {
    ChemicalSpecies {
        kind: ChemicalSpeciesKind::Material,
        ..regulatory(id, baseline, decay)
    }
}

const fn term(species: ChemicalSpeciesId, amount: f32) -> StoichiometricTerm {
    StoichiometricTerm { species, amount }
}

const fn emitter(
    source: BiochemicalSourceLocus,
    target: ChemicalSpeciesId,
    gain: f32,
) -> BiochemicalEmitter {
    BiochemicalEmitter {
        source,
        target,
        cadence_ticks: 1,
        threshold: 0.0,
        gain,
        response: EmitterResponse::Analogue,
        inverted: false,
        developmental_expression_floor: 0.0,
    }
}

const fn drive_receptor(source: ChemicalSpeciesId, channel: DriveChannel) -> BiochemicalReceptor {
    BiochemicalReceptor {
        source,
        target: BiochemicalTargetLocus::Drive(channel),
        threshold: 0.0,
        gain: 1.0,
        nominal: 0.0,
        digital: false,
    }
}

const fn endocrine_receptor(
    source: ChemicalSpeciesId,
    channel: EndocrineChannel,
) -> BiochemicalReceptor {
    BiochemicalReceptor {
        source,
        target: BiochemicalTargetLocus::Endocrine(channel),
        threshold: 0.0,
        gain: 1.0,
        nominal: 0.0,
        digital: false,
    }
}

const fn neural_receptor(
    source: ChemicalSpeciesId,
    class: NeuralReceptorClass,
    gain: f32,
) -> BiochemicalReceptor {
    BiochemicalReceptor {
        source,
        target: BiochemicalTargetLocus::Neural(class),
        threshold: 0.0,
        gain,
        nominal: 0.0,
        digital: false,
    }
}

const fn target_order(target: BiochemicalTargetLocus) -> u8 {
    match target {
        BiochemicalTargetLocus::Drive(_) => 0,
        BiochemicalTargetLocus::Endocrine(_) => 1,
        BiochemicalTargetLocus::Neural(_) => 2,
        BiochemicalTargetLocus::Development(_) => 3,
        BiochemicalTargetLocus::Autonomic(_) => 4,
        BiochemicalTargetLocus::OrganEnergyUse => 5,
        BiochemicalTargetLocus::OrganRepair => 6,
        BiochemicalTargetLocus::LocomotorCapacity => 7,
        BiochemicalTargetLocus::SleepMetabolicRate => 8,
    }
}

mod ids {
    use super::ChemicalSpeciesId;

    pub const HUNGER: ChemicalSpeciesId = ChemicalSpeciesId(1);
    pub const FATIGUE: ChemicalSpeciesId = ChemicalSpeciesId(2);
    pub const FEAR: ChemicalSpeciesId = ChemicalSpeciesId(3);
    pub const PAIN: ChemicalSpeciesId = ChemicalSpeciesId(4);
    pub const LONELINESS: ChemicalSpeciesId = ChemicalSpeciesId(5);
    pub const CURIOSITY: ChemicalSpeciesId = ChemicalSpeciesId(6);
    pub const BRAIN_ATP: ChemicalSpeciesId = ChemicalSpeciesId(7);
    pub const TEMPERATURE: ChemicalSpeciesId = ChemicalSpeciesId(8);
    pub const REPRODUCTIVE: ChemicalSpeciesId = ChemicalSpeciesId(9);
    pub const ADRENALINE: ChemicalSpeciesId = ChemicalSpeciesId(10);
    pub const CORTISOL: ChemicalSpeciesId = ChemicalSpeciesId(11);
    pub const DOPAMINE: ChemicalSpeciesId = ChemicalSpeciesId(12);
    pub const OXYTOCIN: ChemicalSpeciesId = ChemicalSpeciesId(13);
    pub const SEROTONIN: ChemicalSpeciesId = ChemicalSpeciesId(14);
    pub const ACETYLCHOLINE: ChemicalSpeciesId = ChemicalSpeciesId(15);
    pub const LEARNING_SIGNAL: ChemicalSpeciesId = ChemicalSpeciesId(16);
    pub const DEVELOPMENT_SIGNAL: ChemicalSpeciesId = ChemicalSpeciesId(17);
    pub const SLEEP_PRESSURE: ChemicalSpeciesId = ChemicalSpeciesId(18);
    pub const NUTRIENT: ChemicalSpeciesId = ChemicalSpeciesId(19);
    pub const SLEEP_STATE: ChemicalSpeciesId = ChemicalSpeciesId(20);
}

#[cfg(test)]
mod health_distress_tests {
    use super::BiochemicalGraphState;
    use crate::{
        AlleleSide, BiochemistryState, BodyEventDelta, BrainCapacityClass, CreatureGenome,
        FoundationCompatibilityFamilyId, FoundationGeneticIdentity, FoundationId, Tick,
    };

    #[test]
    fn inherited_low_health_keeps_pain_active_without_new_damage() {
        let mut genome = CreatureGenome::early_mammal_founder(
            0xD157_1255,
            FoundationGeneticIdentity::new(
                FoundationId::N512_V1.raw(),
                1,
                FoundationCompatibilityFamilyId::N512_FOUNDATION.raw(),
                BrainCapacityClass::N512_ID,
            )
            .unwrap(),
        )
        .unwrap();
        for side in [AlleleSide::Maternal, AlleleSide::Paternal] {
            genome.chemistry.graph = genome
                .chemistry
                .graph
                .clone()
                .with_health_distress(side)
                .unwrap();
        }
        let phenotype = genome.express().unwrap();
        let graph = &phenotype.chemistry.biochemical;
        let baseline = BiochemistryState::new(&phenotype, Tick::ZERO).unwrap();
        let mut mild_body = baseline.body;
        mild_body.set_health(0.8).unwrap();
        let mut critical_body = baseline.body;
        critical_body.set_health(0.1).unwrap();
        let initial = BiochemicalGraphState::new(graph, Tick::ZERO, 0.0).unwrap();
        let mut mild = initial;
        let mut critical = initial;
        for tick in 1..=64 {
            mild = mild
                .advance(
                    Tick(tick),
                    mild_body,
                    BodyEventDelta::zero(),
                    None,
                    graph,
                    0.0,
                )
                .unwrap()
                .0;
            critical = critical
                .advance(
                    Tick(tick),
                    critical_body,
                    BodyEventDelta::zero(),
                    None,
                    graph,
                    0.0,
                )
                .unwrap()
                .0;
        }
        let mild_pain = mild.derive_homeostasis(graph).unwrap().drives.pain;
        let critical_pain = critical.derive_homeostasis(graph).unwrap().drives.pain;
        assert!(
            mild_pain < 0.55,
            "mild injury should remain below emergency: {mild_pain}"
        );
        assert!(
            critical_pain > 0.55,
            "near-terminal health must cross the inherited emergency threshold: {critical_pain}"
        );
    }
}
