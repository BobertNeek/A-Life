//! Bounded multi-rate body, chemistry, development, and reproduction integration.

use serde::{Deserialize, Serialize};

use crate::{
    validate_finite, BiochemicalGraphState, BiochemicalWorkReceipt, CreaturePhenotype,
    ExperienceSequenceId, GenomeId, HomeostaticSnapshot, NeuralEmission, NeuralEmissionClass,
    NeuralEmissionFrame, NeuralReceptorFrame, ScaffoldContractError, Tick, Validate,
};

pub const MAX_BIOCHEMISTRY_CATCH_UP_STEPS: u32 = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct BiochemistryCadence {
    pub fast_hormone_ticks: u32,
    pub metabolism_ticks: u32,
    pub development_ticks: u32,
    pub reproduction_ticks: u32,
    pub max_catch_up_steps: u32,
}

impl BiochemistryCadence {
    pub const fn early_mammal() -> Self {
        Self {
            fast_hormone_ticks: 1,
            metabolism_ticks: 6,
            development_ticks: 60,
            reproduction_ticks: 120,
            max_catch_up_steps: MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
        }
    }
}

impl Validate for BiochemistryCadence {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        if self.fast_hormone_ticks == 0
            || self.metabolism_ticks < self.fast_hormone_ticks
            || self.development_ticks < self.metabolism_ticks
            || self.reproduction_ticks < self.development_ticks
            || self.max_catch_up_steps == 0
            || self.max_catch_up_steps > MAX_BIOCHEMISTRY_CATCH_UP_STEPS
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct BodyState {
    organs: [OrganPhysiology; ORGAN_KIND_COUNT],
    pub energy: f32,
    pub health: f32,
    pub injury: f32,
    pub temperature_stress: f32,
    pub sleeping: bool,
}

pub const ORGAN_KIND_COUNT: usize = 6;

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum OrganKind {
    MetabolicReserve,
    Circulatory,
    NeuralSupport,
    Thermoregulatory,
    Locomotor,
    Digestive,
}

impl OrganKind {
    pub const ALL: [Self; ORGAN_KIND_COUNT] = [
        Self::MetabolicReserve,
        Self::Circulatory,
        Self::NeuralSupport,
        Self::Thermoregulatory,
        Self::Locomotor,
        Self::Digestive,
    ];
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct OrganPhysiology {
    pub kind: OrganKind,
    pub energy: f32,
    pub integrity: f32,
    pub damage: f32,
    pub temperature_stress: f32,
    pub repair_capacity: f32,
    pub cadence_ticks: u32,
    pub energetic_cost: f32,
    pub exposed_locus: u16,
}

impl Validate for OrganPhysiology {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        validate_unit_values(&[
            self.energy,
            self.integrity,
            self.damage,
            self.temperature_stress,
            self.repair_capacity,
            self.energetic_cost,
        ])?;
        if self.cadence_ticks == 0 || self.exposed_locus == 0 {
            return Err(ScaffoldContractError::InvalidGeneticBounds);
        }
        Ok(())
    }
}

impl BodyState {
    fn baseline(phenotype: &CreaturePhenotype) -> Self {
        let energy = clamp01(0.50 + 0.50 * phenotype.body.metabolic_efficiency);
        let organs = OrganKind::ALL.map(|kind| OrganPhysiology {
            kind,
            energy,
            integrity: 1.0,
            damage: 0.0,
            temperature_stress: 0.0,
            repair_capacity: clamp01(0.35 + 0.55 * phenotype.body.injury_resistance),
            cadence_ticks: match kind {
                OrganKind::NeuralSupport | OrganKind::Circulatory => 1,
                OrganKind::Locomotor | OrganKind::Thermoregulatory => 6,
                OrganKind::MetabolicReserve | OrganKind::Digestive => 12,
            },
            energetic_cost: match kind {
                OrganKind::NeuralSupport => 0.18,
                OrganKind::Circulatory => 0.14,
                OrganKind::Locomotor => 0.12,
                _ => 0.08,
            },
            exposed_locus: kind as u16 + 1,
        });
        let mut value = Self {
            organs,
            energy,
            health: 1.0,
            injury: 0.0,
            temperature_stress: 0.0,
            sleeping: false,
        };
        value.refresh_compatibility_projections();
        value
    }

    #[expect(
        clippy::too_many_arguments,
        reason = "explicit prior state and genetic physiology parameters at the body-event boundary"
    )]
    fn apply_event(
        self,
        previous_tick: Tick,
        next_tick: Tick,
        event: BodyEventDelta,
        phenotype: &CreaturePhenotype,
        max_catch_up_steps: u32,
        energy_use: Option<f32>,
        repair_signal: Option<f32>,
        sleep_metabolic_rate: f32,
    ) -> Self {
        let injury_gain = event.damage * (1.0 - phenotype.body.injury_resistance);
        let turnover = phenotype.body.metabolic_turnover;
        let recovery = event.sleep_recovery * turnover;
        let temperature_stress = clamp01(
            self.temperature_stress
                + event.temperature_stress * (1.0 - phenotype.body.temperature_tolerance)
                - recovery * 0.20,
        );
        let mut organs = self.organs;
        for organ in &mut organs {
            let local_damage = match organ.kind {
                OrganKind::Circulatory | OrganKind::Locomotor => injury_gain,
                OrganKind::NeuralSupport => injury_gain * 0.35,
                _ => injury_gain * 0.15,
            };
            organ.damage = clamp01(organ.damage + local_damage);
            organ.integrity = clamp01(organ.integrity - local_damage);
        }
        // Ordinary repair cannot revive a globally terminal body before the
        // world checks death. A locally exhausted organ can still recover when
        // another organ retains integrity.
        let can_repair = organs.iter().any(|organ| organ.integrity > 0.0);
        for organ in &mut organs {
            let cadence_steps = crossed_boundaries(
                previous_tick,
                next_tick,
                organ.cadence_ticks,
                max_catch_up_steps,
            );
            let event_share = match organ.kind {
                OrganKind::Locomotor => event.energy * 0.35,
                OrganKind::NeuralSupport => event.energy * 0.25,
                OrganKind::Circulatory => event.energy * 0.20,
                _ => event.energy * 0.10,
            };
            let nutrition_gain = match organ.kind {
                OrganKind::Digestive => event.nutrition * phenotype.body.metabolic_efficiency,
                OrganKind::MetabolicReserve => {
                    event.nutrition * phenotype.body.metabolic_efficiency * 0.75
                }
                _ => event.nutrition * phenotype.body.metabolic_efficiency * 0.15,
            };
            let periodic_upkeep = organ.energetic_cost
                * 0.01
                * cadence_steps as f32
                * energy_use.unwrap_or(1.0)
                * match organ.kind {
                    OrganKind::NeuralSupport => {
                        (crate::ContinuousLocus::midpoint_value(0.52, 0.60)
                            - phenotype.chemistry.brain_atp_efficiency)
                            .exp2()
                    }
                    OrganKind::Locomotor => (crate::ContinuousLocus::midpoint_value(0.50, 0.57)
                        - phenotype.body.movement_efficiency)
                        .exp2(),
                    _ => 1.0,
                }
                * turnover
                * sleep_metabolic_rate;
            // Sleep is not nutrition, including for genomes without repair receptors.
            organ.energy = clamp01(organ.energy + event_share + nutrition_gain - periodic_upkeep);
            if can_repair {
                // Both chemical and legacy repair pay from local reserve.
                let repair = repair_signal.map_or(recovery * organ.repair_capacity, |signal| {
                    signal * organ.repair_capacity * cadence_steps as f32 * turnover
                });
                let repair = repair
                    .min(organ.damage.max(1.0 - organ.integrity))
                    .min(organ.energy);
                organ.damage = clamp01(organ.damage - repair);
                organ.integrity = clamp01(organ.integrity + repair);
                organ.energy -= repair;
            }
            organ.temperature_stress = if organ.kind == OrganKind::Thermoregulatory {
                temperature_stress
            } else {
                clamp01(temperature_stress * 0.25)
            };
        }
        let mut value = Self {
            organs,
            energy: self.energy,
            health: self.health,
            injury: self.injury,
            temperature_stress,
            sleeping: recovery > 0.0,
        };
        value.refresh_compatibility_projections();
        value
    }

    pub const fn organs(&self) -> &[OrganPhysiology; ORGAN_KIND_COUNT] {
        &self.organs
    }

    pub fn organ(&self, kind: OrganKind) -> &OrganPhysiology {
        &self.organs[kind as usize]
    }

    pub fn set_energy(&mut self, energy: f32) -> Result<(), ScaffoldContractError> {
        if !energy.is_finite() || !(0.0..=1.0).contains(&energy) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        for organ in &mut self.organs {
            organ.energy = energy;
        }
        self.refresh_compatibility_projections();
        Ok(())
    }

    /// Debit the current body-energy projection from local organ reserves in
    /// proportion to each organ's reserve. This preserves local heterogeneity
    /// while reducing the compatibility mean by the applied debit.
    pub fn debit_energy_pro_rata(
        &mut self,
        requested_debit: f32,
    ) -> Result<f32, ScaffoldContractError> {
        validate_finite(requested_debit)?;
        if requested_debit < 0.0 {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        self.validate_contract()?;

        let applied_debit = requested_debit.min(self.energy);
        if applied_debit == 0.0 {
            return Ok(0.0);
        }

        let total_energy = self.organs.iter().map(|organ| organ.energy).sum::<f32>();
        let total_debit = applied_debit * ORGAN_KIND_COUNT as f32;
        let scale = (1.0 - total_debit / total_energy).max(0.0);
        for organ in &mut self.organs {
            organ.energy = clamp01(organ.energy * scale);
        }
        self.refresh_compatibility_projections();
        Ok(applied_debit)
    }

    pub fn set_health(&mut self, health: f32) -> Result<(), ScaffoldContractError> {
        if !health.is_finite() || !(0.0..=1.0).contains(&health) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        for organ in &mut self.organs {
            organ.integrity = health;
            organ.damage = 1.0 - health;
        }
        self.refresh_compatibility_projections();
        Ok(())
    }

    fn projected_values(&self) -> (f32, f32, f32, f32) {
        let divisor = ORGAN_KIND_COUNT as f32;
        let energy = self.organs.iter().map(|organ| organ.energy).sum::<f32>() / divisor;
        let health = self.organs.iter().map(|organ| organ.integrity).sum::<f32>() / divisor;
        let injury = self.organs.iter().map(|organ| organ.damage).sum::<f32>() / divisor;
        let temperature_stress = self
            .organs
            .iter()
            .map(|organ| organ.temperature_stress)
            .fold(0.0, f32::max);
        (energy, health, injury, temperature_stress)
    }

    fn refresh_compatibility_projections(&mut self) {
        let (energy, health, injury, temperature_stress) = self.projected_values();
        self.energy = energy;
        self.health = health;
        self.injury = injury;
        self.temperature_stress = temperature_stress;
    }

    pub fn migrate_legacy_v1(
        energy: f32,
        health: f32,
        injury: f32,
        temperature_stress: f32,
        sleeping: bool,
    ) -> Result<Self, ScaffoldContractError> {
        validate_unit_values(&[energy, health, injury, temperature_stress])?;
        let organs = OrganKind::ALL.map(|kind| OrganPhysiology {
            kind,
            energy,
            integrity: health,
            damage: injury,
            temperature_stress,
            repair_capacity: 0.5,
            cadence_ticks: 1,
            energetic_cost: 0.1,
            exposed_locus: kind as u16 + 1,
        });
        let mut value = Self {
            organs,
            energy,
            health,
            injury,
            temperature_stress,
            sleeping,
        };
        value.refresh_compatibility_projections();
        value.validate_contract()?;
        Ok(value)
    }
}

impl Validate for BodyState {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        validate_unit_values(&[
            self.energy,
            self.health,
            self.injury,
            self.temperature_stress,
        ])?;
        for (index, organ) in self.organs.iter().enumerate() {
            organ.validate_contract()?;
            if organ.kind != OrganKind::ALL[index] {
                return Err(ScaffoldContractError::InvalidGeneticBounds);
            }
        }
        let projected = self.projected_values();
        if self.energy.to_bits() != projected.0.to_bits()
            || self.health.to_bits() != projected.1.to_bits()
            || self.injury.to_bits() != projected.2.to_bits()
            || self.temperature_stress.to_bits() != projected.3.to_bits()
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct BodyEventDelta {
    pub energy: f32,
    pub damage: f32,
    pub temperature_stress: f32,
    pub nutrition: f32,
    pub social_contact: f32,
    #[serde(default, skip_serializing_if = "is_zero_player_reward")]
    pub player_reward: f32,
    #[serde(default, skip_serializing_if = "is_zero_player_reward")]
    pub play_stimulation: f32,
    #[serde(default, skip_serializing_if = "is_zero_player_reward")]
    pub perceived_novelty: f32,
    #[serde(default, skip_serializing_if = "is_zero_player_reward")]
    pub investigation: f32,
    pub sleep_recovery: f32,
    pub mating_opportunity: f32,
}

impl BodyEventDelta {
    pub const fn zero() -> Self {
        Self {
            energy: 0.0,
            damage: 0.0,
            temperature_stress: 0.0,
            nutrition: 0.0,
            social_contact: 0.0,
            player_reward: 0.0,
            play_stimulation: 0.0,
            perceived_novelty: 0.0,
            investigation: 0.0,
            sleep_recovery: 0.0,
            mating_opportunity: 0.0,
        }
    }
}

impl Validate for BodyEventDelta {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        validate_signed_unit_values(&[self.energy])?;
        validate_unit_values(&[
            self.damage,
            self.temperature_stress,
            self.nutrition,
            self.social_contact,
            self.player_reward,
            self.play_stimulation,
            self.perceived_novelty,
            self.investigation,
            self.sleep_recovery,
            self.mating_opportunity,
        ])
    }
}

fn is_zero_player_reward(value: &f32) -> bool {
    *value == 0.0
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PassiveBodyUpkeepPolicy;

impl PassiveBodyUpkeepPolicy {
    pub const REFERENCE_LIFETIME_TICKS: u32 = 1_824;
    pub const ADULT_LIFETIME_BASE_MULTIPLIER: f32 = 2.0;
    pub const NO_FOOD_RESERVE_FRACTION: f32 = 0.55;
    pub const MATURATION_RESERVE_BUFFER: f32 = 1.25;
    pub const BODY_SIZE_LOAD_BASE: f32 = 0.90;
    pub const BODY_SIZE_LOAD_SPAN: f32 = 0.20;
    pub const EFFICIENCY_LOAD_BASE: f32 = 1.10;
    pub const EFFICIENCY_LOAD_SPAN: f32 = 0.20;

    pub fn maximum_lifespan_ticks(phenotype: &CreaturePhenotype) -> u64 {
        rounded_ticks(
            f64::from(Self::REFERENCE_LIFETIME_TICKS)
                * f64::from(Self::ADULT_LIFETIME_BASE_MULTIPLIER + phenotype.body.lifespan_scale),
        )
    }

    pub fn is_terminal(body: &BodyState, age_ticks: u64, phenotype: &CreaturePhenotype) -> bool {
        Self::is_terminal_with_age_death(body, age_ticks, phenotype, true)
    }

    /// The development override affects only the age threshold, never physiology.
    pub fn is_terminal_with_age_death(
        body: &BodyState,
        age_ticks: u64,
        phenotype: &CreaturePhenotype,
        age_death_enabled: bool,
    ) -> bool {
        body.health <= 0.0
            || body.energy <= 0.0
            || (age_death_enabled && age_ticks >= Self::maximum_lifespan_ticks(phenotype))
    }

    pub fn body_load(phenotype: &CreaturePhenotype) -> f32 {
        (Self::BODY_SIZE_LOAD_BASE + Self::BODY_SIZE_LOAD_SPAN * phenotype.body.size_scale)
            * (Self::EFFICIENCY_LOAD_BASE
                - Self::EFFICIENCY_LOAD_SPAN * phenotype.body.metabolic_efficiency)
    }

    pub fn reserve_horizon_ticks(phenotype: &CreaturePhenotype) -> u64 {
        let reference_ticks = f64::from(Self::REFERENCE_LIFETIME_TICKS);
        let maximum_lifespan_ticks = Self::maximum_lifespan_ticks(phenotype) as f64;
        let body_load = f64::from(Self::body_load(phenotype).max(f32::EPSILON));
        rounded_ticks(
            (f64::from(Self::MATURATION_RESERVE_BUFFER) * reference_ticks).max(
                f64::from(Self::NO_FOOD_RESERVE_FRACTION) * maximum_lifespan_ticks / body_load,
            ),
        )
    }

    pub fn upkeep_event(
        phenotype: &CreaturePhenotype,
        cadence: BiochemistryCadence,
        crossed_metabolism_steps: u32,
    ) -> BodyEventDelta {
        if crossed_metabolism_steps == 0 {
            return BodyEventDelta::zero();
        }
        let reserve_horizon_ticks = Self::reserve_horizon_ticks(phenotype).max(1) as f32;
        let baseline_energy = 0.50 + 0.50 * phenotype.body.metabolic_efficiency;
        let cost = baseline_energy * cadence.metabolism_ticks as f32 / reserve_horizon_ticks
            * crossed_metabolism_steps as f32;
        BodyEventDelta {
            energy: -cost.clamp(0.0, 1.0),
            ..BodyEventDelta::zero()
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct DevelopmentReadiness {
    pub last_update_tick: Tick,
    pub age_ticks: Tick,
    pub maturation: f32,
    pub puberty_reached: bool,
    pub critical_period_active: bool,
    pub critical_period_plasticity_bias: f32,
    pub biochemical_expression: f32,
    pub sleep_maturation_ready: bool,
    pub migration_ready: bool,
}

impl DevelopmentReadiness {
    fn derive(
        phenotype: &CreaturePhenotype,
        age: Tick,
        last_update_tick: Tick,
    ) -> Result<Self, ScaffoldContractError> {
        let state = phenotype.development_state_at(age)?;
        let critical_period_active = !state.open_critical_periods.is_empty();
        let critical_period_plasticity_bias = state
            .open_critical_periods
            .first()
            .map_or(0.0, |period| period.plasticity_bias.raw());
        let maturation = state.maturation.raw();
        let biochemical_gate = phenotype
            .development
            .biochemical_activation_maturation
            .raw();
        let biochemical_expression = if biochemical_gate == 0.0 {
            1.0
        } else {
            (maturation / biochemical_gate).clamp(0.0, 1.0)
        };
        let value = Self {
            last_update_tick,
            age_ticks: age,
            maturation,
            puberty_reached: age >= phenotype.development.puberty_tick,
            critical_period_active,
            critical_period_plasticity_bias,
            biochemical_expression,
            sleep_maturation_ready: maturation
                >= phenotype
                    .brain_genome
                    .developmental_schedule
                    .sleep_pressure_maturation_gate
                    .raw(),
            migration_ready: maturation >= phenotype.development.migration_checkpoint.raw(),
        };
        value.validate_contract()?;
        Ok(value)
    }
}

impl Validate for DevelopmentReadiness {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        Tick::validate_monotonic(self.last_update_tick, self.age_ticks)?;
        validate_unit_values(&[
            self.maturation,
            self.critical_period_plasticity_bias,
            self.biochemical_expression,
        ])
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct ReproductionReadiness {
    pub last_update_tick: Tick,
    pub puberty_reached: bool,
    pub healthy_enough: bool,
    pub energy_sufficient: bool,
    pub hormone_ready: bool,
    pub mating_opportunity: f32,
    pub ready: bool,
}

impl ReproductionReadiness {
    fn physiological_flags(
        body: BodyState,
        homeostasis: &HomeostaticSnapshot,
        phenotype: &CreaturePhenotype,
    ) -> (bool, bool, bool) {
        let healthy_enough = body.health >= 0.55 && body.injury <= 0.45;
        let energy_sufficient = body.energy >= 0.35 && homeostasis.drives.brain_atp >= 0.25;
        let hormone_ready = homeostasis.drives.reproductive_drive
            >= phenotype.chemistry.reproductive_threshold
            && homeostasis.hormones.developmental_hormone >= 0.20;
        (healthy_enough, energy_sufficient, hormone_ready)
    }

    fn is_fresh_at_age(&self, age: Tick, reproduction_ticks: u32) -> bool {
        reproduction_ticks > 0
            && age.raw() >= self.last_update_tick.raw()
            && age.raw() - self.last_update_tick.raw() < u64::from(reproduction_ticks)
    }

    fn derive(
        last_update_tick: Tick,
        body: BodyState,
        homeostasis: &HomeostaticSnapshot,
        development: DevelopmentReadiness,
        mating_opportunity: f32,
        phenotype: &CreaturePhenotype,
    ) -> Result<Self, ScaffoldContractError> {
        let (healthy_enough, energy_sufficient, hormone_ready) =
            Self::physiological_flags(body, homeostasis, phenotype);
        let ready = development.puberty_reached
            && healthy_enough
            && energy_sufficient
            && hormone_ready
            && mating_opportunity >= 0.50
            && phenotype.reproduction.fertility > 0.0;
        let value = Self {
            last_update_tick,
            puberty_reached: development.puberty_reached,
            healthy_enough,
            energy_sufficient,
            hormone_ready,
            mating_opportunity,
            ready,
        };
        value.validate_contract()?;
        Ok(value)
    }
}

impl Validate for ReproductionReadiness {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        validate_unit_values(&[self.mating_opportunity])
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
struct PendingPredictionResidualV1 {
    schema_version: u16,
    source_tick: Tick,
    source_sequence_id: ExperienceSequenceId,
    graph_epoch: u64,
    activity: f32,
    confidence: f32,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct BiochemistryState {
    // A snapshot of inherited valuation makes sealed credit reproducible without
    // a registry lookup. It cannot drift independently of the phenotype.
    #[serde(
        default,
        skip_serializing_if = "crate::chemistry::BiologicalValueProfile::is_default"
    )]
    value_profile: crate::chemistry::BiologicalValueProfile,
    pub source_genome_id: GenomeId,
    pub tick: Tick,
    pub body: BodyState,
    pub homeostasis: HomeostaticSnapshot,
    graph_state: BiochemicalGraphState,
    biochemical_work: BiochemicalWorkReceipt,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pending_prediction_residual: Option<PendingPredictionResidualV1>,
    pub development: DevelopmentReadiness,
    pub reproduction: ReproductionReadiness,
    pub cadence: BiochemistryCadence,
}

impl BiochemistryState {
    pub fn new(phenotype: &CreaturePhenotype, tick: Tick) -> Result<Self, ScaffoldContractError> {
        Self::new_with_age(phenotype, tick, tick)
    }

    pub fn new_with_age(
        phenotype: &CreaturePhenotype,
        tick: Tick,
        age: Tick,
    ) -> Result<Self, ScaffoldContractError> {
        phenotype.brain_genome.validate_contract()?;
        phenotype.chemistry.endocrine.validate_contract()?;
        let cadence = BiochemistryCadence::early_mammal();
        cadence.validate_contract()?;
        let body = BodyState::baseline(phenotype);
        let development_tick = cadence_boundary(age, cadence.development_ticks);
        let development = DevelopmentReadiness::derive(phenotype, age, development_tick)?;
        let biochemical_expression = development.biochemical_expression;
        let graph_state = BiochemicalGraphState::new(
            &phenotype.chemistry.biochemical,
            tick,
            biochemical_expression,
        )?;
        let homeostasis = graph_state.derive_homeostasis(&phenotype.chemistry.biochemical)?;
        let reproduction_tick = cadence_boundary(age, cadence.reproduction_ticks);
        let reproduction = ReproductionReadiness::derive(
            reproduction_tick,
            body,
            &homeostasis,
            development,
            0.0,
            phenotype,
        )?;
        let value = Self {
            source_genome_id: phenotype.source_genome_id,
            value_profile: phenotype.chemistry.biochemical.value_profile(),
            tick,
            body,
            homeostasis,
            graph_state,
            biochemical_work: BiochemicalWorkReceipt::default(),
            pending_prediction_residual: None,
            development,
            reproduction,
            cadence,
        };
        value.validate_against(phenotype)?;
        Ok(value)
    }

    pub fn advance(
        &self,
        next_tick: Tick,
        event: BodyEventDelta,
        phenotype: &CreaturePhenotype,
    ) -> Result<Self, ScaffoldContractError> {
        self.advance_with_age(next_tick, next_tick, event, phenotype)
    }

    /// Stage measured successor error for the next successful biology update.
    /// The enclosing world transaction seals the source experience or rolls back.
    pub fn with_prediction_residual_pulse(
        &self,
        source_sequence_id: ExperienceSequenceId,
        graph_epoch: u64,
        activity: f32,
        confidence: f32,
    ) -> Result<Self, ScaffoldContractError> {
        self.validate_contract()?;
        if self.pending_prediction_residual.is_some() {
            return Err(ScaffoldContractError::LearningEvidenceMismatch);
        }
        let value = Self {
            pending_prediction_residual: Some(PendingPredictionResidualV1 {
                schema_version: 1,
                source_tick: self.tick,
                source_sequence_id,
                graph_epoch,
                activity,
                confidence,
            }),
            ..*self
        };
        value.validate_contract()?;
        Ok(value)
    }

    pub fn advance_with_age(
        &self,
        next_tick: Tick,
        next_age: Tick,
        event: BodyEventDelta,
        phenotype: &CreaturePhenotype,
    ) -> Result<Self, ScaffoldContractError> {
        self.advance_with_neural_emission(next_tick, next_age, event, None, phenotype)
    }

    pub fn advance_with_neural_emission(
        &self,
        next_tick: Tick,
        next_age: Tick,
        event: BodyEventDelta,
        neural: Option<&NeuralEmissionFrame>,
        phenotype: &CreaturePhenotype,
    ) -> Result<Self, ScaffoldContractError> {
        self.validate_against(phenotype)?;
        event.validate_contract()?;
        phenotype.brain_genome.validate_contract()?;
        if phenotype.source_genome_id != self.source_genome_id {
            return Err(ScaffoldContractError::InvalidId);
        }
        Tick::validate_monotonic(self.tick, next_tick)?;
        Tick::validate_monotonic(self.development.age_ticks, next_age)?;
        Tick::validate_monotonic(next_age, next_tick)?;

        let metabolic_steps = crossed_boundaries(
            self.tick,
            next_tick,
            self.cadence.metabolism_ticks,
            self.cadence.max_catch_up_steps,
        );
        let development_steps = crossed_boundaries(
            self.development.age_ticks,
            next_age,
            self.cadence.development_ticks,
            self.cadence.max_catch_up_steps,
        );
        let reproduction_steps = crossed_boundaries(
            self.development.age_ticks,
            next_age,
            self.cadence.reproduction_ticks,
            self.cadence.max_catch_up_steps,
        );
        // Read the previous chemical state once. Body events feed the next chemistry
        // update below, closing the feedback loop without another simulation pass.
        let (energy_use, repair_signal) = self
            .graph_state
            .organ_regulation(&phenotype.chemistry.biochemical)?;
        let upkeep =
            PassiveBodyUpkeepPolicy::upkeep_event(phenotype, self.cadence, metabolic_steps);
        // Chemical state from the preceding interval regulates basal/organ
        // expenditure. Wake resumes normal expenditure immediately. Actual
        // measured cognitive work is debited separately, never discounted here.
        let sleep_metabolic_rate = if event.sleep_recovery > 0.0 {
            self.graph_state
                .sleep_metabolic_rate(&phenotype.chemistry.biochemical)?
                .unwrap_or(1.0)
        } else {
            1.0
        };
        // Nutrition is the material food input (applied independently per organ).
        // Signed energy is metabolic effort/recovery, including composite world
        // events, and follows the same inherited clock as upkeep and repair.
        let turnover = phenotype.body.metabolic_turnover;
        let event = BodyEventDelta {
            energy: signed_clamp(
                (event.energy + upkeep.energy * energy_use.unwrap_or(1.0) * sleep_metabolic_rate)
                    * turnover,
            ),
            ..event
        };
        let body = self.body.apply_event(
            self.tick,
            next_tick,
            event,
            phenotype,
            self.cadence.max_catch_up_steps,
            energy_use,
            repair_signal,
            sleep_metabolic_rate,
        );
        body.validate_contract()?;
        let development = if development_steps > 0 {
            DevelopmentReadiness::derive(
                phenotype,
                next_age,
                cadence_boundary(next_age, self.cadence.development_ticks),
            )?
        } else {
            DevelopmentReadiness {
                age_ticks: next_age,
                ..self.development
            }
        };
        let biochemical_expression = development.biochemical_expression;
        let pending_frame = self
            .pending_prediction_residual
            .map(|pulse| {
                if let Some(frame) = neural {
                    frame.validate_contract()?;
                }
                let mut emissions = neural.map_or_else(Vec::new, |frame| frame.emissions.clone());
                emissions.push(NeuralEmission::new(
                    NeuralEmissionClass::PredictionResidual,
                    pulse.activity,
                    pulse.confidence,
                )?);
                NeuralEmissionFrame::new(
                    neural.map_or(self.tick, |frame| frame.source_tick),
                    neural.map_or(pulse.graph_epoch, |frame| frame.graph_epoch),
                    emissions,
                )
            })
            .transpose()?;
        let (graph_state, biochemical_work) = self.graph_state.advance(
            next_tick,
            body,
            event,
            pending_frame.as_ref().or(neural),
            &phenotype.chemistry.biochemical,
            biochemical_expression,
        )?;
        let homeostasis = graph_state.derive_homeostasis(&phenotype.chemistry.biochemical)?;
        let reproduction = if reproduction_steps > 0 {
            ReproductionReadiness::derive(
                cadence_boundary(next_age, self.cadence.reproduction_ticks),
                body,
                &homeostasis,
                development,
                event.mating_opportunity,
                phenotype,
            )?
        } else if event.mating_opportunity > 0.0 || self.reproduction.mating_opportunity > 0.0 {
            // A mate encountered between cadence boundaries must not be
            // discarded: partners born on different ticks never share a
            // boundary. Keep the strongest opportunity for this window, but
            // recheck changing physiology without moving the freshness tick.
            ReproductionReadiness::derive(
                self.reproduction.last_update_tick,
                body,
                &homeostasis,
                development,
                event
                    .mating_opportunity
                    .max(self.reproduction.mating_opportunity),
                phenotype,
            )?
        } else {
            self.reproduction
        };
        let value = Self {
            source_genome_id: self.source_genome_id,
            value_profile: self.value_profile,
            tick: next_tick,
            body,
            homeostasis,
            graph_state,
            biochemical_work,
            pending_prediction_residual: None,
            development,
            reproduction,
            cadence: self.cadence,
        };
        value.validate_against(phenotype)?;
        Ok(value)
    }

    /// Checks cached readiness against the current biology and its bounded
    /// reproduction-cadence interval.
    pub fn is_reproduction_ready_at(
        &self,
        current_tick: Tick,
        current_age: Tick,
        phenotype: &CreaturePhenotype,
    ) -> bool {
        let (healthy_enough, energy_sufficient, hormone_ready) =
            ReproductionReadiness::physiological_flags(self.body, &self.homeostasis, phenotype);
        self.tick == current_tick
            && self.homeostasis.tick == current_tick
            && self.development.age_ticks == current_age
            && self
                .reproduction
                .is_fresh_at_age(current_age, self.cadence.reproduction_ticks)
            && self.reproduction.ready
            && self.reproduction.mating_opportunity >= 0.50
            && self.development.puberty_reached
            && healthy_enough
            && energy_sufficient
            && hormone_ready
            && phenotype.reproduction.fertility > 0.0
    }

    pub fn validate_against(
        &self,
        phenotype: &CreaturePhenotype,
    ) -> Result<(), ScaffoldContractError> {
        self.validate_contract()?;
        if self.source_genome_id != phenotype.source_genome_id
            || self.value_profile != phenotype.chemistry.biochemical.value_profile()
        {
            return Err(ScaffoldContractError::InvalidId);
        }
        self.graph_state
            .validate_against(&phenotype.chemistry.biochemical)
    }

    pub const fn graph_state(&self) -> &BiochemicalGraphState {
        &self.graph_state
    }

    pub const fn value_profile(&self) -> crate::chemistry::BiologicalValueProfile {
        self.value_profile
    }

    pub const fn biochemical_work(&self) -> BiochemicalWorkReceipt {
        self.biochemical_work
    }

    pub fn neural_receptor_frame(
        &self,
        phenotype: &CreaturePhenotype,
    ) -> Result<NeuralReceptorFrame, ScaffoldContractError> {
        self.graph_state
            .neural_receptor_frame(&phenotype.chemistry.biochemical)
    }
}

impl Validate for BiochemistryState {
    fn validate_contract(&self) -> Result<(), ScaffoldContractError> {
        self.value_profile.validate_contract()?;
        self.source_genome_id.validate()?;
        self.body.validate_contract()?;
        self.homeostasis.validate_contract()?;
        self.graph_state.validate_contract()?;
        self.development.validate_contract()?;
        self.reproduction.validate_contract()?;
        self.cadence.validate_contract()?;
        if let Some(pulse) = self.pending_prediction_residual {
            if pulse.schema_version != 1 || pulse.graph_epoch == 0 {
                return Err(ScaffoldContractError::InvalidDecisionEvidence);
            }
            pulse.source_sequence_id.validate()?;
            NeuralEmission::new(
                NeuralEmissionClass::PredictionResidual,
                pulse.activity,
                pulse.confidence,
            )?;
            if pulse.source_tick != self.tick {
                return Err(ScaffoldContractError::NonMonotonicTick);
            }
        }
        if self.homeostasis.tick != self.tick
            || self.graph_state.tick() != self.tick
            || self.development.age_ticks.raw() > self.tick.raw()
            || self.development.last_update_tick.raw() > self.tick.raw()
            || self.reproduction.last_update_tick.raw() > self.development.age_ticks.raw()
            || self.reproduction.last_update_tick.raw() > self.tick.raw()
        {
            return Err(ScaffoldContractError::NonMonotonicTick);
        }
        Ok(())
    }
}

fn crossed_boundaries(from: Tick, to: Tick, period: u32, cap: u32) -> u32 {
    let period = u64::from(period);
    let crossed = to.raw() / period - from.raw() / period;
    u32::try_from(crossed.min(u64::from(cap))).unwrap_or(cap)
}

fn rounded_ticks(value: f64) -> u64 {
    let rounded = value.round();
    if !rounded.is_finite() || rounded <= 0.0 {
        0
    } else if rounded >= u64::MAX as f64 {
        u64::MAX
    } else {
        rounded as u64
    }
}

fn cadence_boundary(tick: Tick, period: u32) -> Tick {
    let period = u64::from(period);
    Tick(tick.raw() / period * period)
}

fn validate_unit_values(values: &[f32]) -> Result<(), ScaffoldContractError> {
    for value in values {
        validate_finite(*value)?;
        if !(0.0..=1.0).contains(value) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
    }
    Ok(())
}

fn validate_signed_unit_values(values: &[f32]) -> Result<(), ScaffoldContractError> {
    for value in values {
        validate_finite(*value)?;
        if !(-1.0..=1.0).contains(value) {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
    }
    Ok(())
}

fn clamp01(value: f32) -> f32 {
    value.clamp(0.0, 1.0)
}

fn signed_clamp(value: f32) -> f32 {
    value.clamp(-1.0, 1.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        BrainCapacityClass, CreatureGenome, FoundationGeneticIdentity, MeasuredPhysiologyTransition,
    };

    #[test]
    fn food_relief_is_greater_when_biology_is_hungry_than_when_sated() {
        let genome = CreatureGenome::early_mammal_founder(
            0xE10_3201,
            FoundationGeneticIdentity::new(10, 1, 7, BrainCapacityClass::N2048_ID).unwrap(),
        )
        .unwrap();
        let phenotype = genome.express().unwrap();
        let initial = BiochemistryState::new(&phenotype, Tick(600)).unwrap();
        let food = BodyEventDelta {
            energy: 0.3,
            nutrition: 0.6,
            ..BodyEventDelta::zero()
        };

        // Both states emerge through the ordinary chemistry and metabolism.
        // The same food is then compared with doing nothing from each state.
        let mut sated = initial;
        let mut hungry = initial;
        hungry.body.set_energy(0.1).unwrap();
        for tick in 601..=603 {
            sated = sated.advance(Tick(tick), food, &phenotype).unwrap();
            hungry = hungry
                .advance(Tick(tick), BodyEventDelta::zero(), &phenotype)
                .unwrap();
        }
        assert!(hungry.homeostasis.drives.hunger > 0.5);
        assert!(sated.homeostasis.drives.hunger <= 0.05);

        let reward = |before: BiochemistryState, event: BodyEventDelta| {
            let after = before.advance(Tick(604), event, &phenotype).unwrap();
            MeasuredPhysiologyTransition::new(before, after)
                .unwrap()
                .homeostatic_improvement()
        };
        let sated_food_relief = reward(sated, food) - reward(sated, BodyEventDelta::zero());
        let hungry_food_relief = reward(hungry, food) - reward(hungry, BodyEventDelta::zero());
        assert!(
            hungry_food_relief > sated_food_relief + 0.02,
            "hungry relief {hungry_food_relief} should exceed sated relief {sated_food_relief}"
        );
        assert!(reward(hungry, food) > reward(sated, food));
    }

    #[test]
    fn inherited_chemical_controls_change_upkeep_and_pay_for_repair() {
        let genome = CreatureGenome::early_mammal_founder(
            0xE10_3200,
            FoundationGeneticIdentity::new(10, 1, 7, BrainCapacityClass::N512_ID).unwrap(),
        )
        .unwrap();
        let phenotype = genome.express().unwrap();
        // Alter the inherited response, not acquired hormone concentrations.
        let mut wire = serde_json::to_value(&genome).unwrap();
        for side in ["maternal", "paternal"] {
            let receptors = wire["chemistry"]["graph"][side]["receptors"]
                .as_array_mut()
                .unwrap();
            for receptor in receptors {
                if receptor["target"] == "OrganRepair" {
                    receptor["gain"] = serde_json::json!(0.0);
                }
            }
        }
        let no_repair: CreatureGenome = serde_json::from_value(wire).unwrap();
        let no_repair = no_repair.express().unwrap();
        let mut state = BiochemistryState::new(&phenotype, Tick(600)).unwrap();
        state.body.set_health(0.5).unwrap();
        state.body.set_energy(0.8).unwrap();
        // Injury first enters chemistry, then affects the following body update.
        let injury = BodyEventDelta {
            damage: 0.1,
            ..BodyEventDelta::zero()
        };
        let state = state.advance(Tick(601), injury, &phenotype).unwrap();
        let repaired = state
            .advance(Tick(613), BodyEventDelta::zero(), &phenotype)
            .unwrap();
        let unrepaired = state
            .advance(Tick(613), BodyEventDelta::zero(), &no_repair)
            .unwrap();
        assert!(repaired.body.health > unrepaired.body.health);
        assert!(repaired.body.energy < unrepaired.body.energy);
        repaired.validate_against(&phenotype).unwrap();

        let body = state.body;
        let run = |energy, repair| {
            body.apply_event(
                Tick(601),
                Tick(613),
                BodyEventDelta::zero(),
                &phenotype,
                MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
                Some(energy),
                Some(repair),
                1.0,
            )
        };
        assert!(run(0.25, 0.0).energy > run(1.0, 0.0).energy);
        let mut exhausted = body;
        exhausted.set_energy(0.0).unwrap();
        let after = exhausted.apply_event(
            Tick(601),
            Tick(613),
            BodyEventDelta::zero(),
            &phenotype,
            MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
            Some(1.0),
            Some(1.0),
            1.0,
        );
        assert_eq!(after.health, exhausted.health);
        assert_eq!(after.energy, 0.0);

        // No-receptor legacy bodies cannot turn sleep into food or free tissue.
        let sleeping = |body: BodyState| {
            body.apply_event(
                Tick(601),
                Tick(613),
                BodyEventDelta {
                    sleep_recovery: 1.0,
                    ..BodyEventDelta::zero()
                },
                &phenotype,
                MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
                Some(0.0),
                None,
                1.0,
            )
        };
        let recovered = sleeping(body);
        assert!(recovered.health > body.health);
        assert!(recovered.energy < body.energy);
        let recovered = sleeping(exhausted);
        assert_eq!(recovered.health, exhausted.health);
        assert_eq!(recovered.energy, 0.0);
    }

    #[test]
    fn globally_fatal_damage_cannot_be_repaired_before_terminal_check() {
        let phenotype = CreatureGenome::early_mammal_founder(
            0xE10_3202,
            FoundationGeneticIdentity::new(10, 1, 7, BrainCapacityClass::N512_ID).unwrap(),
        )
        .unwrap()
        .express()
        .unwrap();
        let mut body = BodyState::baseline(&phenotype);
        body.set_health(0.01).unwrap();
        body.set_energy(0.8).unwrap();
        let event = BodyEventDelta {
            damage: 1.0,
            sleep_recovery: 1.0,
            ..BodyEventDelta::zero()
        };
        let run = |body: BodyState, event, repair| {
            body.apply_event(
                Tick(0),
                Tick(12),
                event,
                &phenotype,
                MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
                Some(0.0),
                repair,
                1.0,
            )
        };
        let without_repair = run(body, event, Some(0.0));
        assert_eq!(without_repair.health, 0.0);
        assert!(without_repair.energy > 0.0);
        for repair in [Some(1.0), None] {
            let after = run(body, event, repair);
            assert_eq!(after, without_repair);
            assert!(PassiveBodyUpkeepPolicy::is_terminal(&after, 12, &phenotype));

            // Loading or advancing an already terminal body cannot revive it.
            let after = run(
                without_repair,
                BodyEventDelta {
                    sleep_recovery: 1.0,
                    ..BodyEventDelta::zero()
                },
                repair,
            );
            assert_eq!(after.health, 0.0);
        }
    }

    #[test]
    fn surviving_body_can_repair_a_zero_integrity_organ_from_its_reserve() {
        let phenotype = CreatureGenome::early_mammal_founder(
            0xE10_3202,
            FoundationGeneticIdentity::new(10, 1, 7, BrainCapacityClass::N512_ID).unwrap(),
        )
        .unwrap()
        .express()
        .unwrap();
        let mut body = BodyState::baseline(&phenotype);
        body.set_energy(0.8).unwrap();
        let organ = &mut body.organs[OrganKind::Circulatory as usize];
        organ.integrity = 0.0;
        organ.damage = 1.0;
        body.refresh_compatibility_projections();
        assert!(body.health > 0.0);
        for repair in [Some(1.0), None] {
            let after = body.apply_event(
                Tick(0),
                Tick(12),
                BodyEventDelta {
                    sleep_recovery: 1.0,
                    ..BodyEventDelta::zero()
                },
                &phenotype,
                MAX_BIOCHEMISTRY_CATCH_UP_STEPS,
                Some(0.0),
                repair,
                1.0,
            );
            let before_organ = body.organ(OrganKind::Circulatory);
            let after_organ = after.organ(OrganKind::Circulatory);
            assert!(after_organ.integrity > 0.0);
            let repaired = after_organ.integrity - before_organ.integrity;
            let spent = before_organ.energy - after_organ.energy;
            assert!((repaired - spent).abs() < 1e-6);
        }
    }

    #[test]
    fn newborn_at_late_world_tick_starts_development_at_biological_age_zero() {
        let genome = CreatureGenome::early_mammal_founder(
            0xE10_31FF,
            FoundationGeneticIdentity::new(10, 1, 7, BrainCapacityClass::N512_ID).unwrap(),
        )
        .unwrap();
        let mut phenotype = genome.express().unwrap();
        phenotype.development.puberty_tick = Tick(1);

        let state = BiochemistryState::new_with_age(&phenotype, Tick(10_000), Tick(0)).unwrap();

        assert_eq!(state.development.age_ticks, Tick(0));
        assert!(!state.development.puberty_reached);
    }
}
