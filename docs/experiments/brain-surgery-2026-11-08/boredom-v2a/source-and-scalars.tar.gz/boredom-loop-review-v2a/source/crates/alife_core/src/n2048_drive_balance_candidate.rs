//! Explicit fresh research identity for a a provisional native dendrite operating point.
use crate::{
    BrainCapacityClass, CanonicalDigestBuilder, FoundationWeightAsset, FoundationWeightAssetRef,
    ScaffoldContractError, SensorProfile,
};
use serde::{Deserialize, Serialize};
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct N2048DriveBalanceCandidateV1 {
    schema_version: u16,
    sensor_profile: SensorProfile,
    recipe_digest: [u64; 4],
    foundation_bytes: Option<Vec<u8>>,
}
impl N2048DriveBalanceCandidateV1 {
    // Frozen for this research identity; further tuning needs a new recipe/identity.
    pub const BIRTH_DENDRITE_OUTPUT_GAIN: f32 = 0.5;
    pub const BIRTH_DENDRITE_THRESHOLD: f32 = -1.0;
    pub const MAX_CANDIDATE_GAIN: f32 = 12.0;
    pub fn fresh(sensor_profile: SensorProfile) -> Result<Self, ScaffoldContractError> {
        SensorProfile::try_from_raw(sensor_profile.raw())?;
        Ok(Self {
            schema_version: 1,
            sensor_profile,
            recipe_digest: Self::recipe_digest(),
            foundation_bytes: None,
        })
    }
    pub fn for_asset(asset: &FoundationWeightAsset) -> Result<Self, ScaffoldContractError> {
        if !asset.is_n2048_drive_balance_candidate() {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        let mut value = Self::fresh(asset.manifest().sensor_profile())?;
        value.foundation_bytes = Some(asset.encode_canonical()?);
        Ok(value)
    }
    pub fn recipe_digest() -> [u64; 4] {
        let mut d = CanonicalDigestBuilder::new(b"alife.n2048.drive-balance-candidate.v1");
        for word in crate::N2048MemoryGainCandidateV1::recipe_digest() {
            d.write_u64(word);
        }
        d.write_u16(2);
        d.write_f32(Self::MAX_CANDIDATE_GAIN)
            .expect("fixed finite gain");
        // Bind the complete native birth recipe, not just its output amplitude.
        d.write_bytes(b"native-motor-birth-dendrites.v1");
        d.write_u16(64); // min(branch capacity, motor width, 64)
        d.write_bytes(b"motor-start-plus-index;neighbor-plus-one-else-minus-one");
        d.write_f32(1.0).expect("finite self input");
        d.write_f32(1.0).expect("finite neighbor input");
        d.write_f32(Self::BIRTH_DENDRITE_THRESHOLD)
            .expect("finite threshold");
        d.write_f32(Self::BIRTH_DENDRITE_OUTPUT_GAIN)
            .expect("finite gain");
        d.finish256()
    }
    pub const fn sensor_profile(&self) -> SensorProfile {
        self.sensor_profile
    }
    pub fn asset(&self) -> Result<Option<FoundationWeightAsset>, ScaffoldContractError> {
        self.foundation_bytes
            .as_deref()
            .map(FoundationWeightAsset::decode_canonical)
            .transpose()
    }
    pub fn asset_ref(&self) -> Option<FoundationWeightAssetRef> {
        self.asset().ok().flatten().map(|asset| asset.asset_ref())
    }
    pub(crate) fn validate_against(
        &self,
        capacity: &BrainCapacityClass,
        profile: SensorProfile,
    ) -> Result<(), ScaffoldContractError> {
        if self.schema_version != 1
            || capacity.id() != BrainCapacityClass::N2048_ID
            || self.sensor_profile != profile
            || self.recipe_digest != Self::recipe_digest()
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        SensorProfile::try_from_raw(profile.raw())?;
        if let Some(asset) = self.asset()? {
            if !asset.is_n2048_drive_balance_candidate()
                || asset.manifest().sensor_profile() != profile
            {
                return Err(ScaffoldContractError::PhenotypeCompile);
            }
        }
        Ok(())
    }
    pub(crate) fn write_canonical(&self, d: &mut CanonicalDigestBuilder) {
        d.write_u16(self.schema_version);
        d.write_u16(self.sensor_profile.raw());
        for word in self.recipe_digest {
            d.write_u64(word);
        }
        match &self.foundation_bytes {
            Some(bytes) => {
                d.write_some();
                d.write_sequence_len(bytes.len());
                d.write_bytes(bytes);
            }
            None => d.write_none(),
        }
    }
}
