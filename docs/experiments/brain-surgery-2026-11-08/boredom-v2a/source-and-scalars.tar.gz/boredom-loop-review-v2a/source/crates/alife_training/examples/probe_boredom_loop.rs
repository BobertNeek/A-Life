//! Disposable matched fixtures; native CPU semantics, not an autonomous cohort.
#[allow(dead_code)] // Some constructors are exercised only by guards.
#[path = "support/boredom_candidate.rs"]
mod boredom_candidate;
#[path = "support/care_candidate.rs"]
mod care_candidate;
#[allow(dead_code)] // Reuse the full inherited constructor module.
#[path = "support/drive_balance_candidate.rs"]
mod drive_balance_candidate;
#[path = "support/world_swap_legacy_v12.rs"]
mod world_swap_legacy_v12;
use alife_core::*;
use alife_training::{AdamWConfig, StageTrainableMask, TrainingSequence, cpu::*};
use alife_world::*;
use serde_json::{Value, json};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
const SEED: u64 = 2026110901;

#[cfg(test)]
fn biology(record: &WorldOrganismRecord, boredom: f32, fatigue: f32) -> Result<BiochemistryState> {
    biology_with_hunger(record, boredom, fatigue, 0.1)
}
fn biology_with_hunger(
    record: &WorldOrganismRecord,
    boredom: f32,
    fatigue: f32,
    hunger: f32,
) -> Result<BiochemistryState> {
    let graph = &record.phenotype().chemistry.biochemical;
    let mut wire = serde_json::to_value(record.biochemistry())?;
    for (channel, value) in [
        (BiochemicalDriveChannel::Extension0, boredom),
        (BiochemicalDriveChannel::Fatigue, fatigue),
        (BiochemicalDriveChannel::Curiosity, 0.1),
        (BiochemicalDriveChannel::Hunger, hunger),
    ] {
        let r = graph
            .receptors()
            .iter()
            .find(|r| r.target == BiochemicalTargetLocus::Drive(channel))
            .unwrap();
        let i = graph
            .species()
            .iter()
            .position(|s| s.id == r.source)
            .unwrap();
        wire["graph_state"]["concentrations"][i] = json!(
            (r.threshold + (value - r.nominal) / r.gain)
                .clamp(graph.species()[i].minimum, graph.species()[i].maximum)
        );
    }
    let state: BiochemicalGraphState = serde_json::from_value(wire["graph_state"].clone())?;
    wire["homeostasis"] = serde_json::to_value(state.derive_homeostasis(graph)?)?;
    let state: BiochemistryState = serde_json::from_value(wire)?;
    state.validate_against(record.phenotype())?;
    Ok(state)
}
fn physical_fixture(
    record: &WorldOrganismRecord,
    bio: BiochemistryState,
    toy: bool,
    distance: f32,
) -> Result<(HeadlessWorld, WorldEntityId)> {
    let own = record.organism_id();
    let mut world = HeadlessScenarioBuilder::new(SEED)
        .agent("fixture", own, Vec3f::ZERO)
        .build()?;
    let target = world.spawn_toy("physical sample", Vec3f::new(distance, 0., 0.), false)?;
    if !toy {
        let props = world.entity(target).unwrap().grounded_physical;
        // Same ordinary observations but a distinct physically non-activating
        // object. Never feed this fixture label to the brain.
        world.editor_remove_object(target)?;
        let replacement = world.editor_spawn_object(WorldEditorSpawnSpec {
            label: "physical sample".into(),
            kind: WorldObjectKind::Hazard,
            organism_id: None,
            position: Vec3f::new(distance, 0., 0.),
            nutrition: 0.,
            hazard_pain: 0.,
            radius: 0.5,
            token_id: None,
        })?;
        world.set_grounded_physical_properties(replacement, props)?;
    }
    let target = world.entity_id("physical sample").unwrap();
    world.register_organism_record(WorldOrganismRecord::new(
        own,
        world.entity_id("fixture").unwrap(),
        record.genome().clone(),
        record.phenotype().clone(),
        bio,
        record.birth_tick(),
    )?)?;
    Ok((world, target))
}
fn main() -> Result<()> {
    let out = std::env::args().nth(1).ok_or("output required")?;
    let ticks: usize = std::env::args().nth(2).map_or(Ok(24), |s| s.parse())?;
    let variant = std::env::args().nth(3).unwrap_or_else(|| "full".into());
    let (bridge, memory) = match variant.as_str() {
        "full" => (true, true),
        "no-memory" => (true, false),
        "no-drive" => (false, true),
        "baseline" => (false, false),
        _ => return Err("invalid variant".into()),
    };
    let signal = std::env::args()
        .nth(4)
        .map_or(Ok(4.), |x| x.parse::<f32>())?;
    let reference = std::env::args()
        .nth(5)
        .map_or(Ok(2.), |x| x.parse::<f32>())?;
    let tonic = std::env::args()
        .nth(6)
        .map_or(Ok(-3.), |x| x.parse::<f32>())?;
    let sampling_seed = std::env::args()
        .nth(7)
        .map_or(Ok(SEED as u32), |x| x.parse::<u32>())?;
    let only = std::env::args().nth(8);
    let (asset, p, recipe) =
        boredom_candidate::construct_parameters(bridge, memory, signal, reference, tonic)?;
    let mut trainer = CpuFoundationTrainer::new(
        p.clone(),
        asset.clone(),
        StageTrainableMask::recurrent_only(&p)?,
        AdamWConfig::default(),
    )?;
    // Nonzero optimizer sentinels: a frozen evaluation must preserve all of it.
    let mut ck = trainer.checkpoint();
    ck.optimizer_step = 7;
    ck.first_moment[0] = 0.125;
    ck.second_moment[0] = 0.25;
    ck.update_ages[0] = 7;
    trainer.restore_checkpoint(ck)?;
    let unchanged = serde_json::to_vec(&trainer.checkpoint())?;
    let (config, _, _) = care_candidate::source_memory_gain(SEED)?;
    let mut results = vec![];
    for (name, boredom, fatigue, toy, distance) in [
        ("toy-low", 0.1, 0.1, true, 0.25),
        ("toy-mid", 0.45, 0.1, true, 0.25),
        ("toy-high", 0.8, 0.1, true, 0.25),
        ("matched-nonplayable-high", 0.8, 0.1, false, 0.25),
        ("toy-high-tired", 0.8, 0.8, true, 0.25),
        ("toy-unreachable-high", 0.8, 0.1, true, 3.),
        ("hungry-toy-and-food", 0.8, 0.1, true, 0.25),
    ] {
        if (name == "hungry-toy-and-food" && only.is_none())
            || only.as_ref().is_some_and(|selected| selected != name)
        {
            continue;
        }
        let mut game =
            create_canonical_new_game_with_n2048_drive_balance_candidate(&config, &asset)?;
        let record = game
            .world
            .organism_registry()
            .iter()
            .next()
            .unwrap()
            .clone();
        let own = record.organism_id();
        let bio = biology_with_hunger(
            &record,
            boredom,
            fatigue,
            if name == "hungry-toy-and-food" {
                0.8
            } else {
                0.1
            },
        )?;
        let (mut world, target) = physical_fixture(&record, bio, toy, distance)?;
        let food = if name == "hungry-toy-and-food" {
            let id = world.editor_spawn_object(WorldEditorSpawnSpec {
                label: "edible sample".into(),
                kind: WorldObjectKind::Food,
                organism_id: None,
                position: Vec3f::new(0., 0., 0.25),
                nutrition: 0.35,
                hazard_pain: 0.,
                radius: 0.3,
                token_id: None,
            })?;
            let mut props = world.entity(id).unwrap().grounded_physical;
            props.chemical[0] = 0.85;
            world.set_grounded_physical_properties(id, props)?;
            Some(id)
        } else {
            None
        };
        let play = ActionCommand::structured(
            own,
            HeadlessActionIds::PLAY,
            ActionKind::Interact,
            ActionTarget::new(Some(target), None),
            Intensity::new(1.)?,
            DurationTicks::new(1),
            Confidence::new(1.)?,
            0,
            None,
            None,
            None,
        )?;
        let mut physical = world.clone();
        let direct = physical.apply_command(&play)?;
        let physical_probe = json!({"succeeded":direct.execution.succeeded,"phase":format!("{:?}",direct.phase),
            "body_event":direct.body_event,"before":bio.homeostasis,"after":physical.organism_registry().get(own).unwrap().biochemistry().homeostasis});
        assert_eq!(direct.body_event.nutrition, 0.);
        assert_eq!(direct.body_event.social_contact, 0.);
        assert_eq!(direct.body_event.player_reward, 0.);
        if !toy || distance > 1.25 {
            assert_eq!(direct.body_event.play_stimulation, 0.);
        }
        game.world = world;
        let mut host = CpuCanonicalHost::new_cohort(game, &trainer, sampling_seed)?;
        let mut rows = vec![];
        let mut pressure_probe = Vec::new();
        let effects = NeuralReceptorEffects::from_frame(
            &bio.neural_receptor_frame(record.phenotype())?,
            &NeuralReceptorPhenotype::compile(&p)?,
        )?;
        let mut roundtrip = false;
        let mut sleeping_ticks = 0;
        for n in 0..ticks {
            let step = host.step(&trainer, 0.2)?;
            sleeping_ticks += step.sleeping_organisms;
            for row in step.decisions {
                let frame = row.patch.pre_action().perception();
                let evaluation = trainer.evaluate_replay(&TrainingSequence {
                    phenotype_hash: p.phenotype_hash(),
                    initial: row.initial.clone(),
                    ticks: vec![row.replay_tick.clone()],
                    burn_in_ticks: 0,
                    memory_candidate_gain: 12.,
                })?;
                let encoded_for_audit = rows
                    .is_empty()
                    .then(|| row.replay_tick.encoded_inputs.clone());
                if rows.is_empty() {
                    for level in [0.0f32, 0.1, 0.3, 0.5, 0.7, 0.9] {
                        let mut tick = row.replay_tick.clone();
                        for a in p.sensor_encoder().assignments().iter().filter(|a| {
                            a.source_group() == SensorEncoderSourceGroup::Homeostasis
                                && a.source_index() == 9
                        }) {
                            let (lo, hi) = a.clamp_range();
                            let before = frame.homeostasis().drives.extension[0];
                            let delta = ((level * effects.interoceptive_gain * a.scale()
                                + a.bias())
                            .clamp(lo, hi)
                                - (before * effects.interoceptive_gain * a.scale() + a.bias())
                                    .clamp(lo, hi))
                                * effects.regional_excitability;
                            tick.encoded_inputs[a.target_neuron() as usize] =
                                (tick.encoded_inputs[a.target_neuron() as usize] + delta)
                                    .clamp(-1., 1.);
                        }
                        let eval = trainer.evaluate_replay(&TrainingSequence {
                            phenotype_hash: p.phenotype_hash(),
                            initial: row.initial.clone(),
                            ticks: vec![tick; 12],
                            burn_in_ticks: 0,
                            memory_candidate_gain: 12.,
                        })?;
                        pressure_probe.push(json!({"level":level,"logits":eval.candidate_logits}));
                    }
                }
                let candidates:Vec<Value>=frame.candidates().iter().enumerate().map(|(i,c)|json!({"index":i,"id":c.action_id.raw(),"kind":c.kind,
                    "family":c.family,"target":c.target,"features":c.features,"logit":evaluation.candidate_logits[0][i],
                    "memory":row.replay_tick.candidates[i].decoder_inputs[24..36],"port53":row.replay_tick.candidates[i].decoder_inputs[53],
                    "selected":row.action.motor_candidates.iter().any(|x|*x==Some(i as u16))})).collect();
                let motor = recipe["motor"].as_u64().unwrap() as usize;
                let reference = recipe["reference"].as_u64().unwrap() as usize;
                rows.push(json!({"tick":step.tick_before.raw(),"first_frame_encoded_inputs":encoded_for_audit,"drives":frame.homeostasis().drives,"candidates":candidates,
                    "bundle":row.patch.decision().selected_bundle,"representative":row.patch.decision().selected_action,
                    "outcome":row.patch.outcome(),"reward":row.biological_reward,
                    "bridge_activations":recipe["bridge"].as_array().unwrap().iter().map(|v| {let syn=&p.synapses()[v.as_u64().unwrap() as usize];json!({"source":syn.source(),"target":syn.target(),"source_activity":evaluation.final_activations[0][syn.source() as usize],"target_activity":evaluation.final_activations[0][syn.target() as usize]})}).collect::<Vec<_>>(),
                    "motor_activation":evaluation.final_activations[0][motor],"reference_activation":evaluation.final_activations[0][reference],
                    "boredom_activation":evaluation.final_activations[0][recipe["input_neuron"].as_u64().unwrap() as usize]}));
            }
            if n == ticks / 2 {
                let snapshot = host.checkpoint(&trainer)?;
                let bytes = serde_json::to_vec(&snapshot)?;
                let restored =
                    CpuCanonicalHost::from_checkpoint(serde_json::from_slice(&bytes)?, &trainer)?;
                assert_eq!(serde_json::to_vec(&restored.checkpoint(&trainer)?)?, bytes);
                host = restored;
                roundtrip = true;
            }
        }
        let checkpoint = host.checkpoint(&trainer)?;
        let r = &checkpoint.residents[0];
        results.push(json!({"name":name,"fixture_target":target,"food_target":food,"initial":bio,"physical_control":physical_probe,"rows":rows,
            "final":host.world().organism_registry().get(own).unwrap().biochemistry(),"food_consumed":food.map(|id|host.world().entity(id).unwrap().consumed),
            "sleeping_ticks":sleeping_ticks,"detached_pressure_replay":pressure_probe,"checkpoint_roundtrip":roundtrip,"acquired_nonzero_fast":r.neural.fast.iter().filter(|v|**v!=0.).count(),
            "acquired_nonzero_lifetime":r.neural.lifetime.iter().filter(|v|**v!=0.).count(),"memory":r.memory,"staged_memory":r.staged_memory}));
        use std::io::Write as _;
        std::fs::OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(format!("{out}.{name}.json"))?
            .write_all(&serde_json::to_vec_pretty(results.last().unwrap())?)?;
        eprintln!("completed {name}");
    }
    assert_eq!(serde_json::to_vec(&trainer.checkpoint())?, unchanged);
    use std::io::Write;
    std::fs::OpenOptions::new().create_new(true).write(true).open(out)?.write_all(&serde_json::to_vec_pretty(&json!({
        "scope":"Fixed disposable CPU fixtures; actual native neural, memory, world and biochemical steps; no optimizer training, no retained checkpoint inputs, no autonomous cohort",
        "temperature":0.2,"sampling_seed":sampling_seed,"variant":variant,"ticks":ticks,"recipe":recipe,"asset_digest":asset.digest(),"phenotype_hash":p.phenotype_hash(),"optimizer_preserved":true,"results":results}))?)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn changes_are_fresh_profile_bound_and_local_to_declared_boredom_edges() {
        let old = drive_balance_candidate::construct_with_reference(true).unwrap();
        let before = old.encode_canonical().unwrap();
        let (asset, p, report) = boredom_candidate::construct().unwrap();
        assert_ne!(asset.digest(), old.digest());
        assert_eq!(p.sensor_profile(), SensorProfile::GroundedObjectSlotsV1);
        let allowed: std::collections::BTreeSet<usize> = report["bridge"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_u64().unwrap() as usize)
            .collect();
        for (i, ((a, b), s)) in old
            .weights()
            .iter()
            .zip(asset.weights())
            .zip(p.synapses())
            .enumerate()
        {
            if a.to_bits() == b.to_bits() {
                continue;
            }
            assert!(
                allowed.contains(&i)
                    || matches!(s.kind(),CompiledSynapseKind::Decoder(c)
                if c.family()==CandidateActionFamily::Other && matches!(c.head(),DecoderHeadKind::ActionCandidate|DecoderHeadKind::MemoryContext))
            );
        }
        let g = BrainGenome::scaffold(SEED, BrainCapacityClass::N2048_ID);
        let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
        for profile in [
            SensorProfile::PrivilegedAffordanceV1,
            SensorProfile::GroundedTerrainVisionV1,
            SensorProfile::GroundedGripObjectSlotsV1,
        ] {
            assert!(boredom_candidate::validate_profile(profile).is_err());
            if let Ok((other, _)) =
                PhenotypeCompiler::compile_n2048_drive_balance_graph(g.clone(), d.clone(), profile)
            {
                assert!(
                    boredom_candidate::patch(&other, &vec![0.; other.synapses().len()]).is_err()
                );
            }
        }
        assert_eq!(
            before,
            drive_balance_candidate::construct_with_reference(true)
                .unwrap()
                .encode_canonical()
                .unwrap()
        );
        assert_eq!(
            FoundationWeightAsset::decode_canonical(&asset.encode_canonical().unwrap()).unwrap(),
            asset
        );
    }
    #[test]
    fn contact_reader_does_not_alias_targetless_other_or_operation_lane() {
        let (asset, p, report) = boredom_candidate::construct().unwrap();
        let motor = report["motor"].as_u64().unwrap() as u32;
        for kind in [ActionKind::Vocalize, ActionKind::Hold] {
            let f = CandidateFeatureVector::zero().with_intrinsic_action_basis(kind);
            let contribution: f32 = p
                .synapses()
                .iter()
                .zip(asset.weights())
                .filter_map(|(s, w)| match s.kind() {
                    CompiledSynapseKind::Decoder(c)
                        if c.family() == CandidateActionFamily::Other
                            && c.head() == DecoderHeadKind::ActionCandidate
                            && s.source() == motor =>
                    {
                        Some(f.0[c.input_lane() as usize] * w)
                    }
                    _ => None,
                })
                .sum();
            assert_eq!(contribution, 0.);
        }
        assert!(
            p.synapses()
                .iter()
                .zip(asset.weights())
                .all(|(s, w)| !matches!(s.kind(),CompiledSynapseKind::Decoder(c)
            if c.family()==CandidateActionFamily::Other && c.input_lane()==53 && *w!=0.))
        );
    }
    #[test]
    fn play_relief_is_not_food_praise_or_investigation() {
        let (asset, _, _) = boredom_candidate::construct().unwrap();
        let (config, _, _) = care_candidate::source_memory_gain(SEED).unwrap();
        let game =
            create_canonical_new_game_with_n2048_drive_balance_candidate(&config, &asset).unwrap();
        let record = game.world.organism_registry().iter().next().unwrap();
        let bio = biology(record, 0.8, 0.1).unwrap();
        let graph = &record.phenotype().chemistry.biochemical;
        let state: BiochemicalGraphState =
            serde_json::from_value(serde_json::to_value(bio).unwrap()["graph_state"].clone())
                .unwrap();
        let advance = |event| {
            state
                .advance(Tick(1), bio.body, event, None, graph, 1.)
                .unwrap()
                .0
                .derive_homeostasis(graph)
                .unwrap()
                .drives
                .extension[0]
        };
        let baseline = advance(BodyEventDelta::zero());
        let play = advance(BodyEventDelta {
            play_stimulation: 1.,
            ..BodyEventDelta::zero()
        });
        assert!(play < baseline - 0.1);
        for event in [
            BodyEventDelta {
                nutrition: 1.,
                ..BodyEventDelta::zero()
            },
            BodyEventDelta {
                player_reward: 1.,
                ..BodyEventDelta::zero()
            },
            BodyEventDelta {
                social_contact: 1.,
                ..BodyEventDelta::zero()
            },
            BodyEventDelta {
                investigation: 1.,
                ..BodyEventDelta::zero()
            },
        ] {
            assert_eq!(advance(event).to_bits(), baseline.to_bits());
        }
    }
    #[test]
    fn candidate_optimizer_cannot_be_restored_into_source_identity() {
        let (candidate, cp, _) = boredom_candidate::construct().unwrap();
        let (baseline, bp, _) = boredom_candidate::construct_variant(false, false).unwrap();
        let mut a = CpuFoundationTrainer::new(
            cp.clone(),
            candidate,
            StageTrainableMask::recurrent_only(&cp).unwrap(),
            AdamWConfig::default(),
        )
        .unwrap();
        let b = CpuFoundationTrainer::new(
            bp.clone(),
            baseline,
            StageTrainableMask::recurrent_only(&bp).unwrap(),
            AdamWConfig::default(),
        )
        .unwrap();
        assert_ne!(cp.phenotype_hash(), bp.phenotype_hash());
        let before = serde_json::to_vec(&a.checkpoint()).unwrap();
        assert!(a.restore_checkpoint(b.checkpoint()).is_err());
        assert_eq!(before, serde_json::to_vec(&a.checkpoint()).unwrap());
    }
    #[test]
    fn playable_and_failed_control_match_senses_and_contact_without_a_toy_oracle() {
        let (asset, _, _) = boredom_candidate::construct().unwrap();
        let (config, _, _) = care_candidate::source_memory_gain(SEED).unwrap();
        let game =
            create_canonical_new_game_with_n2048_drive_balance_candidate(&config, &asset).unwrap();
        let record = game.world.organism_registry().iter().next().unwrap();
        let bio = biology(record, 0.8, 0.1).unwrap();
        let own = record.organism_id();
        let (mut playable, pt) = physical_fixture(record, bio, true, 0.25).unwrap();
        let (mut failed, ft) = physical_fixture(record, bio, false, 0.25).unwrap();
        let pf = playable
            .perception_frame_draft(
                own,
                Tick::ZERO,
                SensorProfile::GroundedObjectSlotsV1,
                bio.homeostasis,
            )
            .unwrap();
        let ff = failed
            .perception_frame_draft(
                own,
                Tick::ZERO,
                SensorProfile::GroundedObjectSlotsV1,
                bio.homeostasis,
            )
            .unwrap();
        assert_eq!(
            pf.sensory().channels.as_flat_array(),
            ff.sensory().channels.as_flat_array()
        );
        assert_eq!(pf.body(), ff.body());
        assert_eq!(pf.homeostasis(), ff.homeostasis());
        assert_eq!(
            pf.candidates()
                .iter()
                .map(|c| (c.action_id, c.kind, c.family, c.features))
                .collect::<Vec<_>>(),
            ff.candidates()
                .iter()
                .map(|c| (c.action_id, c.kind, c.family, c.features))
                .collect::<Vec<_>>()
        );
        for frame in [&pf, &ff] {
            assert_eq!(
                frame
                    .candidates()
                    .iter()
                    .find(|c| c.action_id == HeadlessActionIds::PLAY)
                    .unwrap()
                    .features
                    .0[18],
                1.
            );
        }
        for (world, target, success) in [(&mut playable, pt, true), (&mut failed, ft, false)] {
            let command = ActionCommand::structured(
                own,
                HeadlessActionIds::PLAY,
                ActionKind::Interact,
                ActionTarget::new(Some(target), None),
                Intensity::new(1.).unwrap(),
                DurationTicks::new(1),
                Confidence::new(1.).unwrap(),
                0,
                None,
                None,
                None,
            )
            .unwrap();
            let result = world.apply_command(&command).unwrap();
            assert_eq!(result.execution.succeeded, success);
            assert_eq!(
                result.body_event.play_stimulation,
                if success { 1. } else { 0. }
            );
            assert_eq!(result.body_event.damage, 0.);
            assert_eq!(result.body_event.nutrition, 0.);
            assert_eq!(result.body_event.player_reward, 0.);
        }
    }
    #[test]
    fn movable_toy_preparation_is_not_play_relief() {
        let (asset, _, _) = boredom_candidate::construct().unwrap();
        let (config, _, _) = care_candidate::source_memory_gain(SEED).unwrap();
        let game =
            create_canonical_new_game_with_n2048_drive_balance_candidate(&config, &asset).unwrap();
        let record = game.world.organism_registry().iter().next().unwrap();
        let bio = biology(record, 0.8, 0.1).unwrap();
        let (mut world, stationary) = physical_fixture(record, bio, true, 0.25).unwrap();
        world.editor_remove_object(stationary).unwrap();
        let target = world
            .spawn_toy("movable", Vec3f::new(0.25, 0., 0.), true)
            .unwrap();
        let command = ActionCommand::structured(
            record.organism_id(),
            HeadlessActionIds::PLAY,
            ActionKind::Interact,
            ActionTarget::new(Some(target), None),
            Intensity::new(1.).unwrap(),
            DurationTicks::new(1),
            Confidence::new(1.).unwrap(),
            0,
            None,
            None,
            None,
        )
        .unwrap();
        let prepared = world.apply_command(&command).unwrap();
        assert!(prepared.execution.succeeded);
        assert_eq!(prepared.phase, ActionPhase::Preparation);
        assert_eq!(prepared.body_event.play_stimulation, 0.);
        let played = world.apply_command(&command).unwrap();
        assert!(played.execution.succeeded);
        assert_eq!(played.phase, ActionPhase::Completed);
        assert_eq!(played.body_event.play_stimulation, 1.);
        assert_eq!(played.body_event.nutrition, 0.);
        assert_eq!(played.body_event.player_reward, 0.);
    }
}
