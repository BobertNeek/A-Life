//! Fresh-only, weight-space boredom experiment on the drive-balance recipe.
//! No world type, action outcome, or external drive-to-action rule is consulted.
use super::{care_candidate, drive_balance_candidate};
use alife_core::*;
use alife_runtime::canonical_preparation::foundation_construction_development;
use alife_world::*;
use serde_json::json;
use std::collections::BTreeSet;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

pub fn construct() -> Result<(FoundationWeightAsset, BrainPhenotype, serde_json::Value)> {
    construct_variant(true, true)
}

pub fn construct_variant(
    bridge: bool,
    memory: bool,
) -> Result<(FoundationWeightAsset, BrainPhenotype, serde_json::Value)> {
    construct_parameters(bridge, memory, 4., 2., -3.)
}

pub fn construct_parameters(
    bridge: bool,
    memory: bool,
    signal_gain: f32,
    reference_gain: f32,
    tonic_gain: f32,
) -> Result<(FoundationWeightAsset, BrainPhenotype, serde_json::Value)> {
    if !signal_gain.is_finite()
        || !reference_gain.is_finite()
        || signal_gain.abs() > 64.
        || reference_gain.abs() > 64.
        || !tonic_gain.is_finite()
        || tonic_gain.abs() > 8.
    {
        return Err("invalid experiment readout gain".into());
    }
    let asset = drive_balance_candidate::construct_with_reference(true)?;
    let (config, _, _) = care_candidate::source_memory_gain(2026110901)?;
    let game = create_canonical_new_game_with_n2048_drive_balance_candidate(&config, &asset)?;
    let record = game.world.organism_registry().iter().next().unwrap();
    let genome = record.phenotype().brain_genome.clone();
    let dev = foundation_construction_development(
        &genome,
        &BrainCapacityClass::n2048(),
        &record.phenotype().development_state_at(Tick::ZERO)?,
    )?;
    let (p, _) = PhenotypeCompiler::compile_n2048_drive_balance_foundation_candidate(
        genome.clone(),
        dev.clone(),
        asset.clone(),
    )?;
    let (mut weights, mut report) = patch(&p, asset.weights())?;
    weights[report["bridge"][3].as_u64().unwrap() as usize] = tonic_gain;
    report["tonic_gain"] = json!(tonic_gain);
    for ((weight, old), syn) in weights.iter_mut().zip(asset.weights()).zip(p.synapses()) {
        if matches!(syn.kind(),CompiledSynapseKind::Decoder(c) if c.head()==DecoderHeadKind::ActionCandidate && c.family()==CandidateActionFamily::Other && c.input_lane()==18)
        {
            if syn.source() == report["motor"].as_u64().unwrap() as u32 {
                *weight = signal_gain;
            }
            if syn.source() == report["reference"].as_u64().unwrap() as u32 {
                *weight = reference_gain;
            }
        }
        let is_memory = matches!(syn.kind(),CompiledSynapseKind::Decoder(c) if c.head()==DecoderHeadKind::MemoryContext);
        if (is_memory && !memory) || (!is_memory && !bridge) {
            *weight = *old;
        }
    }
    report["readout_gains"] = json!([signal_gain, reference_gain]);
    report["bridge_enabled"] = json!(bridge);
    report["memory_enabled"] = json!(memory);
    report["changes"] = json!(
        asset
            .weights()
            .iter()
            .zip(&weights)
            .enumerate()
            .filter(|(_, (x, y))| x.to_bits() != y.to_bits())
            .map(|(i, (x, y))| json!({"id":i,"before":x,"after":y,"synapse":p.synapses()[i]}))
            .collect::<Vec<_>>()
    );
    let asset = FoundationWeightAsset::from_trained_weights(
        &p,
        weights,
        asset.manifest().training_stage(),
    )?;
    let (p, _) = PhenotypeCompiler::compile_n2048_drive_balance_foundation_candidate(
        genome,
        dev,
        asset.clone(),
    )?;
    Ok((asset, p, report))
}

pub fn validate_profile(profile: SensorProfile) -> Result<()> {
    if profile != SensorProfile::GroundedObjectSlotsV1 {
        return Err("boredom candidate requires the exact grounded-object profile".into());
    }
    Ok(())
}

pub fn patch(p: &BrainPhenotype, source: &[f32]) -> Result<(Vec<f32>, serde_json::Value)> {
    // In this profile the world's only object-directed Other primitive is Play.
    // Profile 4 adds Release in Other and must NOT inherit these physical rows.
    validate_profile(p.sensor_profile())?;
    if source.len() != p.synapses().len() {
        return Err("source shape mismatch".into());
    }
    let mut w = source.to_vec();
    let (_, existing) = care_candidate::whole_care(p)?;
    let used: BTreeSet<u32> = existing
        .iter()
        .filter(|r| r["role"] == "need")
        .flat_map(|r| r["bridge_synapses"].as_array().unwrap())
        .map(|i| p.synapses()[i.as_u64().unwrap() as usize].target())
        .collect();
    let mut outgoing = vec![vec![]; p.neuron_count() as usize];
    for (i, s) in p.synapses().iter().enumerate() {
        if s.kind() == CompiledSynapseKind::Recurrent {
            outgoing[s.source() as usize].push(i);
        }
    }
    let motors: BTreeSet<u32> = p
        .synapses()
        .iter()
        .filter_map(|s| match s.kind() {
            CompiledSynapseKind::Decoder(c)
                if c.head() == DecoderHeadKind::ActionCandidate
                    && c.family() == CandidateActionFamily::Other =>
            {
                Some(s.source())
            }
            _ => None,
        })
        .collect();
    let reference = *motors.last().ok_or("no Other motor")?;
    let input = p
        .sensor_encoder()
        .assignments()
        .iter()
        .find(|a| {
            a.source_group() == SensorEncoderSourceGroup::Homeostasis && a.source_index() == 9
        })
        .ok_or("boredom port absent")?
        .target_neuron();
    let tonic = p
        .lobe_layout()
        .region(LobeKind::FlexibleReserve)
        .unwrap()
        .start
        + 15;
    let mut path = None;
    'search: for &a in &outgoing[input as usize] {
        let sa = &p.synapses()[a];
        if sa.route_index() != 2 || used.contains(&sa.target()) || sa.target() == tonic {
            continue;
        }
        for &b in &outgoing[sa.target() as usize] {
            let sb = &p.synapses()[b];
            if sb.route_index() != 3 || used.contains(&sb.target()) {
                continue;
            }
            let Some(&t) = outgoing[tonic as usize].iter().find(|&&i| {
                p.synapses()[i].route_index() == 3 && p.synapses()[i].target() == sb.target()
            }) else {
                continue;
            };
            for &c in &outgoing[sb.target() as usize] {
                let sc = &p.synapses()[c];
                if sc.route_index() == 5
                    && motors.contains(&sc.target())
                    && sc.target() != reference
                {
                    path = Some((a, b, c, t, sc.target()));
                    break 'search;
                }
            }
        }
    }
    let (a, b, c, t, motor) = path.ok_or("no independent boredom bridge")?;
    assert!(
        [a, b, c, t].iter().all(|&i| source[i] == 0.),
        "boredom circuit overwrote an inherited pathway"
    );
    w[a] = 2.;
    w[b] = 2.;
    w[c] = 4.;
    w[t] = -3.;
    // Contact is real sensed contact, never an affordance or toy label. An
    // unfamiliar object may be tried; failed execution must then teach it.
    for (i, s) in p.synapses().iter().enumerate() {
        let CompiledSynapseKind::Decoder(d) = s.kind() else {
            continue;
        };
        if d.family() != CandidateActionFamily::Other {
            continue;
        }
        if d.head() == DecoderHeadKind::ActionCandidate {
            w[i] = if d.input_lane() == 18 {
                if s.source() == motor {
                    4.
                } else if s.source() == reference {
                    2.
                } else {
                    0.
                }
            } else {
                0.
            };
        }
        // Native memory rows are additive, NOT multiplied by motor activity.
        // Keep a modest signed valence reader so remembered pleasure cannot
        // overwhelm low current need, and a separate failed-attempt penalty.
        if d.head() == DecoderHeadKind::MemoryContext {
            let count = p
                .synapses()
                .iter()
                .filter(|s| {
                    matches!(s.kind(), CompiledSynapseKind::Decoder(x)
                if x.family()==d.family() && x.head()==d.head() && x.input_lane()==d.input_lane())
                })
                .count();
            w[i] = match d.input_lane() {
                32 => 12.,
                34 => -16.,
                _ => 0.,
            } / count as f32;
        }
    }
    let changed: Vec<_> = source
        .iter()
        .zip(&w)
        .enumerate()
        .filter(|(_, (x, y))| x.to_bits() != y.to_bits())
        .map(|(i, (x, y))| json!({"id":i,"before":x,"after":y,"synapse":p.synapses()[i]}))
        .collect();
    Ok((
        w,
        json!({"homeostatic_lane":9,"input_neuron":input,"motor":motor,"reference":reference,
        "bridge":[a,b,c,t],"changes":changed,"profile":"GroundedObjectSlotsV1",
        "memory":"exact-action Other valence and danger; additive, confidence weighted"}),
    ))
}
