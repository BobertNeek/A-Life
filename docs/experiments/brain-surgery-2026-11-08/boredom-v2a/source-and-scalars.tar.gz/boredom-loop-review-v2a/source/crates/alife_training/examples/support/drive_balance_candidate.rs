//! Rebind exact inherited v12 synapse genes to the explicit fresh birth recipe.
//! This never migrates an accepted life or rewrites its stored dendrites.
use super::{care_candidate, world_swap_legacy_v12};
use alife_core::*;
use alife_world::*;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
pub fn construct() -> Result<FoundationWeightAsset> {
    construct_with_reference(false)
}
pub fn construct_with_reference(recalibrate: bool) -> Result<FoundationWeightAsset> {
    construct_factors(recalibrate, false)
}
pub fn construct_factors(
    recalibrate: bool,
    ingest_geometry: bool,
) -> Result<FoundationWeightAsset> {
    construct_parameters(recalibrate,if ingest_geometry {0.2} else {1.},if ingest_geometry {16./6.} else {1.})
}
pub fn construct_parameters(recalibrate:bool,taste_scale:f32,distance_scale:f32)->Result<FoundationWeightAsset> {
    let old = world_swap_legacy_v12::construct()?;
    let (config, old_p, _) = care_candidate::source_memory_gain(2026110901)?;
    let game = create_canonical_new_game_with_n2048_memory_gain_candidate(&config, &old)?;
    let record = game.world.organism_registry().iter().next().unwrap();
    let genome = record.phenotype().brain_genome.clone();
    let development = alife_runtime::canonical_preparation::foundation_construction_development(
        &genome,
        &BrainCapacityClass::n2048(),
        &record.phenotype().development_state_at(Tick::ZERO)?,
    )?;
    let (p, _) = PhenotypeCompiler::compile_n2048_drive_balance_graph(
        genome,
        development,
        config.sensor_profile,
    )?;
    assert_eq!(p.synapses().len(), old_p.synapses().len());
    for (a, b) in p.synapses().iter().zip(old_p.synapses()) {
        assert_eq!(
            (a.kind(), a.source(), a.target(), a.route_index()),
            (b.kind(), b.source(), b.target(), b.route_index())
        );
    }
    let mut weights = old.weights().to_vec();
    if recalibrate {
        let (_, circuits) = care_candidate::whole_care(&p)?;
        for c in circuits.iter().filter(|c| {
            c["role"] == "reference" && matches!(c["family"].as_str(), Some("Approach" | "Inspect"))
        }) {
            let reference = c["reference_motor"].as_u64().unwrap() as u32;
            for (syn, w) in p.synapses().iter().zip(&mut weights) {
                if *w != 0.
                    && syn.source() == reference
                    && matches!(syn.kind(),CompiledSynapseKind::Decoder(k) if k.head()==DecoderHeadKind::ActionCandidate)
                {
                    *w = -*w;
                }
            }
        }
    }
    {
        for (syn, w) in p.synapses().iter().zip(&mut weights) {
            if let CompiledSynapseKind::Decoder(c) = syn.kind() {
                if c.head() == DecoderHeadKind::ActionCandidate
                    && c.family() == CandidateActionFamily::Ingest
                {
                    match c.input_lane() {
                        15 => *w *= taste_scale,
                        2 => *w *= distance_scale,
                        _ => {}
                    }
                }
            }
        }
    }
    Ok(FoundationWeightAsset::from_trained_weights(
        &p,
        weights,
        old.manifest().training_stage(),
    )?)
}
