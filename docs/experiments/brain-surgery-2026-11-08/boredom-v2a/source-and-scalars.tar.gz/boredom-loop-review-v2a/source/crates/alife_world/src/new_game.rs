use alife_core::{
    BrainCapacityClass, BrainScaleTier, FoundationGeneticIdentity, FoundationWeightAsset, GenomeId,
    LineageId, OrganismId, ScaffoldContractError, SensorProfile, Tick, Vec3f, WorldEntityId,
};

use crate::{
    CreatureAppearanceGenome, CreatureMindSaveSummary, CreatureSaveState, EcologyZoneId,
    HabitatAuthority, HabitatId, HeadlessWorld, LearningTraceSaveSummary, PortableAssetDigest,
    TerrainZone, TerrainZoneKind, WeightLayerSaveSummary, WorldEditorSpawnSpec, WorldObjectKind,
    WorldOrganismRecord,
};

pub const PHASE3_NEW_GAME_SCHEMA_VERSION: u16 = 1;
pub const PHASE3_DEFAULT_POPULATION: u16 = 6;
pub const PHASE3_MIN_POPULATION: u16 = 1;
pub const PHASE3_MAX_POPULATION: u16 = 8;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CanonicalNewGameConfig {
    pub schema_version: u16,
    pub world_seed: u64,
    /// Defaults to world_seed; explicit candidate cohorts may keep one
    /// inherited graph while varying the world's deterministic seed.
    pub founder_seed_base: u64,
    pub founder_count: u16,
    pub brain_class: BrainScaleTier,
    pub sensor_profile: SensorProfile,
}

impl CanonicalNewGameConfig {
    pub fn phase3(world_seed: u64, founder_count: u16) -> Result<Self, ScaffoldContractError> {
        if world_seed == 0
            || !(PHASE3_MIN_POPULATION..=PHASE3_MAX_POPULATION).contains(&founder_count)
        {
            return Err(ScaffoldContractError::InvalidId);
        }
        Ok(Self {
            schema_version: PHASE3_NEW_GAME_SCHEMA_VERSION,
            world_seed,
            founder_seed_base: world_seed,
            founder_count,
            brain_class: BrainScaleTier::Nano512,
            sensor_profile: SensorProfile::GroundedObjectSlotsV1,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CanonicalFounderReceipt {
    pub organism_id: OrganismId,
    pub world_entity_id: WorldEntityId,
    pub genome_id: GenomeId,
    pub lineage_id: LineageId,
    pub world_label: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CanonicalNewGameReceipt {
    pub schema_version: u16,
    pub world_seed: u64,
    pub requested_population: u16,
    pub founders: Vec<CanonicalFounderReceipt>,
}

#[derive(Debug, Clone)]
pub struct CanonicalNewGame {
    pub world: HeadlessWorld,
    pub creatures: Vec<CreatureSaveState>,
    pub receipt: CanonicalNewGameReceipt,
}

pub fn create_canonical_new_game(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    validate_phase3_inputs(config, foundation)?;
    create_new_game_inner(config, foundation, None, false)
}

/// Explicit N2048 experiment using the same ecology and inherited physiology.
/// The asset remains bound into each genome for archive and exact restore.
pub fn create_canonical_new_game_with_n2048_grip_reader_candidate(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    if !foundation.is_n2048_grip_reader_candidate()
        || config.sensor_profile != SensorProfile::GroundedGripObjectSlotsV1
    {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    create_n2048_candidate_inner(config, foundation)
}

pub fn create_canonical_new_game_with_n2048_drive_balance_candidate(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    if !foundation.is_n2048_drive_balance_candidate() {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    create_n2048_candidate_inner(config, foundation)
}
pub fn create_canonical_new_game_with_n2048_memory_gain_candidate(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    if !foundation.is_n2048_memory_gain_candidate() {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    create_n2048_candidate_inner(config, foundation)
}
pub fn create_canonical_new_game_with_n2048_experimental_candidate(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    if !foundation.is_n2048_experimental_graph() {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    create_n2048_candidate_inner(config, foundation)
}

pub fn create_canonical_new_game_with_n2048_candidate(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    if foundation.is_n2048_experimental_graph()
        || foundation.is_n2048_drive_balance_candidate()
        || foundation.is_n2048_memory_gain_candidate()
        || foundation.is_n2048_grip_reader_candidate()
    {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    create_n2048_candidate_inner(config, foundation)
}

fn create_n2048_candidate_inner(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    let mut expected = CanonicalNewGameConfig::phase3(config.world_seed, config.founder_count)?;
    expected.brain_class = BrainScaleTier::Standard2048;
    expected.founder_seed_base = config.founder_seed_base;
    expected.sensor_profile = foundation.manifest().sensor_profile();
    if config.founder_seed_base == 0
        || *config != expected
        || foundation.manifest().capacity_class_id() != BrainCapacityClass::N2048_ID
        || foundation.manifest().sensor_profile() != config.sensor_profile
    {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    foundation.encode_canonical()?;
    create_new_game_inner(config, foundation, None, false)
}

/// Explicit offline group of fifty newborns sharing one inherited neural policy.
/// Each has a distinct organism/body/chemistry/memory identity. The ordinary
/// New Game population limit is unchanged; this is a training admission only.
pub fn create_canonical_foundation_training_group(
    world_seed: u64,
    founder_seed_base: u64,
    foundation: &FoundationWeightAsset,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    let mut config = CanonicalNewGameConfig::phase3(world_seed, 1)?;
    if (foundation.is_n2048_experimental_graph()
        || foundation.is_n2048_drive_balance_candidate()
        || foundation.is_n2048_memory_gain_candidate()
        || foundation.is_n2048_grip_reader_candidate())
        || founder_seed_base == 0
        || foundation.manifest().capacity_class_id() != BrainCapacityClass::N2048_ID
    {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    foundation.encode_canonical()?;
    config.founder_count = 50;
    config.founder_seed_base = founder_seed_base;
    config.brain_class = BrainScaleTier::Standard2048;
    config.sensor_profile = foundation.manifest().sensor_profile();
    create_new_game_inner(&config, foundation, None, true)
}

/// Explicit experimental founder: candidate cognition and inherited pain sensing
/// from birth. This does not change builtin admission or copy acquired state.
pub fn create_canonical_new_game_with_nociceptive_candidate(
    config: &CanonicalNewGameConfig,
    candidate: &alife_core::Nano512ActionCreditCandidateV2,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    let foundation = FoundationWeightAsset::builtin_nano512_v1(config.sensor_profile)?;
    validate_phase3_inputs(config, &foundation)?;
    if candidate.source().sensor_profile() != config.sensor_profile {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    create_new_game_inner(config, &foundation, Some(candidate), false)
}

fn create_new_game_inner(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
    candidate: Option<&alife_core::Nano512ActionCreditCandidateV2>,
    training_group: bool,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    create_new_game_with_identity(config, foundation, candidate, training_group, 1)
}

/// Explicit offline new individual, with the usual newborn biology/ecology.
/// Identity is allocated by the training lineage owner, never reused from a save.
pub fn create_canonical_training_new_life(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
    organism_id: OrganismId,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    if organism_id.raw() == 0 || config.founder_count != 1 {
        return Err(ScaffoldContractError::InvalidId);
    }
    // Apply the ordinary candidate admission before allocating a new identity.
    create_canonical_new_game_with_n2048_candidate(config, foundation)?;
    create_new_game_with_identity(config, foundation, None, false, organism_id.raw())
}

fn create_new_game_with_identity(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
    candidate: Option<&alife_core::Nano512ActionCreditCandidateV2>,
    training_group: bool,
    first_organism_id: u64,
) -> Result<CanonicalNewGame, ScaffoldContractError> {
    let manifest = foundation.manifest();
    let foundation_identity = FoundationGeneticIdentity::new(
        manifest.foundation_id().raw(),
        u16::try_from(manifest.foundation_version().raw())
            .map_err(|_| ScaffoldContractError::InvalidId)?,
        manifest.compatibility_family_id().raw(),
        config.brain_class.default_class_id(),
    )?;
    let mut world = HeadlessWorld::new(config.world_seed);
    let mut habitats = HabitatAuthority::default();
    let mut creatures = Vec::with_capacity(usize::from(config.founder_count));
    let mut founders = Vec::with_capacity(usize::from(config.founder_count));

    for slot in 0..config.founder_count {
        let ordinal = u64::from(slot) + 1;
        let organism_id = OrganismId(
            first_organism_id
                .checked_add(u64::from(slot))
                .ok_or(ScaffoldContractError::InvalidId)?,
        );
        let founder_seed = config
            .founder_seed_base
            .checked_mul(16)
            .and_then(|seed| seed.checked_add(if training_group { 1 } else { ordinal }))
            .ok_or(ScaffoldContractError::InvalidId)?;
        let world_label = format!("founder-{ordinal:02}");
        let position = if training_group {
            Vec3f::new(
                (f32::from(slot % 10) - 4.5) * 24.0,
                (f32::from(slot / 10) - 2.0) * 24.0,
                0.0,
            )
        } else {
            founder_position(slot)
        };
        let mut genome =
            alife_core::CreatureGenome::early_mammal_founder(founder_seed, foundation_identity)?;
        // Founder reserve economics are inherited biology, not a survival timer.
        // The allele midpoint expresses ~1/400 legacy turnover; ordinary genetic
        // recombination/mutation can make descendants faster or slower.
        let turnover_log2 = (1.0_f32 / 400.0).log2();
        genome.body.metabolic_turnover_log2 = alife_core::ContinuousLocus::with_bounds(
            turnover_log2 - 0.1,
            turnover_log2 + 0.1,
            -10.0,
            0.0,
            0.5,
        )?;
        calibrate_inherited_founder_biochemistry(&mut genome)?;
        enable_inherited_newborn_nociception(&mut genome)?;
        if let Some(candidate) = candidate {
            genome = genome.with_nano512_action_credit_candidate(candidate.clone())?;
        }
        if config.brain_class == BrainScaleTier::Standard2048 {
            genome = genome.with_n2048_foundation_candidate(foundation.clone())?;
        }
        let phenotype = genome.express()?;
        let world_entity_id = world.spawn_social_agent(&world_label, organism_id, position, 0.0)?;
        let record = WorldOrganismRecord::newborn(
            organism_id,
            world_entity_id,
            genome,
            phenotype,
            Tick::ZERO,
        )
        .map_err(|_| ScaffoldContractError::InvalidId)?;
        let creature = initial_creature_save(&record, slot, founder_seed, config.brain_class)?;
        let receipt = CanonicalFounderReceipt {
            organism_id,
            world_entity_id,
            genome_id: record.genome().id,
            lineage_id: record.genome().lineage_id,
            world_label,
        };
        world.register_organism_record(record)?;
        habitats
            .register_creature(organism_id, HabitatId::DEFAULT_WILD, Tick::ZERO)
            .map_err(|_| ScaffoldContractError::InvalidId)?;
        creatures.push(creature);
        founders.push(receipt);
    }

    world
        .replace_habitat_authority(habitats)
        .map_err(|_| ScaffoldContractError::InvalidId)?;
    spawn_phase3_ecology(&mut world)?;
    if training_group {
        // Ordinary physical walls prevent accidental competition between plots.
        let mut obstacles = Vec::new();
        for founder in &founders {
            let p = world
                .entity(founder.world_entity_id)
                .ok_or(ScaffoldContractError::InvalidId)?
                .position;
            // Terrain admission converts legacy X/Y into grounded X/Z.
            let (x, z) = (p.x, p.y);
            obstacles.extend([
                [x - 8.2, z - 8.2, x - 7.8, z + 8.2, 0.0, 3.0],
                [x + 7.8, z - 8.2, x + 8.2, z + 8.2, 0.0, 3.0],
                [x - 8.2, z - 8.2, x + 8.2, z - 7.8, 0.0, 3.0],
                [x - 8.2, z + 7.8, x + 8.2, z + 8.2, 0.0, 3.0],
            ]);
        }
        world.enable_terrain_for_new_game(
            crate::WorldTerrain::new(
                crate::TerrainData {
                    width: 2,
                    depth: 2,
                    origin_x: -256.0,
                    origin_z: -256.0,
                    spacing: 512.0,
                    heights: vec![0.0; 4],
                    obstacles,
                    water_level: None,
                },
                crate::LocomotionLimits::default(),
            )?,
            Vec3f::ZERO,
        )?;
        // A shared habitat, with distinct local starting scenes. No success
        // labels or scores enter perception; all resources are ordinary objects.
        for founder in &founders {
            let position = world
                .entity(founder.world_entity_id)
                .ok_or(ScaffoldContractError::InvalidId)?
                .position;
            let angle = ((config.world_seed ^ founder.organism_id.raw().wrapping_mul(0x9e3779b9))
                % 6283) as f32
                / 1000.0;
            let distance = 0.6
                + ((config.world_seed.rotate_left(17)
                    ^ founder.organism_id.raw().wrapping_mul(7919))
                    % 1800) as f32
                    / 1000.0;
            let food = world.editor_spawn_object(WorldEditorSpawnSpec {
                label: format!("group-food-{}", founder.organism_id.raw()),
                kind: WorldObjectKind::Food,
                organism_id: None,
                position: Vec3f::new(
                    position.x + distance * angle.cos(),
                    position.y,
                    position.z + distance * angle.sin(),
                ),
                nutrition: 0.65,
                hazard_pain: 0.0,
                radius: 0.45,
                token_id: None,
            })?;
            world.set_food_variety(
                food,
                crate::FoodVariety::from_seed(config.world_seed ^ founder.organism_id.raw()),
            )?;
            if founder.organism_id.raw() % 3 == 0 {
                world.editor_spawn_object(WorldEditorSpawnSpec {
                    label: format!("group-hazard-{}", founder.organism_id.raw()),
                    kind: WorldObjectKind::Hazard,
                    organism_id: None,
                    position: Vec3f::new(
                        position.x - angle.sin() * 3.0,
                        0.0,
                        position.z + angle.cos() * 3.0,
                    ),
                    nutrition: 0.0,
                    hazard_pain: 0.12,
                    radius: 0.5,
                    token_id: None,
                })?;
            } else {
                world.spawn_toy(
                    &format!("group-toy-{}", founder.organism_id.raw()),
                    Vec3f::new(
                        position.x - angle.cos() * 2.5,
                        0.0,
                        position.z - angle.sin() * 2.5,
                    ),
                    founder.organism_id.raw() % 2 == 0,
                )?;
            }
        }
    }

    Ok(CanonicalNewGame {
        world,
        creatures,
        receipt: CanonicalNewGameReceipt {
            schema_version: PHASE3_NEW_GAME_SCHEMA_VERSION,
            world_seed: config.world_seed,
            requested_population: config.founder_count,
            founders,
        },
    })
}

fn calibrate_inherited_founder_biochemistry(
    genome: &mut alife_core::CreatureGenome,
) -> Result<(), ScaffoldContractError> {
    use alife_core::{
        AlleleSide, BiochemicalDriveChannel, BiochemicalSourceLocus, BiochemicalTargetLocus,
    };
    let graph = genome.chemistry.graph.expressed();
    let hunger = graph
        .receptors()
        .iter()
        .find(|receptor| {
            receptor.target == BiochemicalTargetLocus::Drive(BiochemicalDriveChannel::Hunger)
        })
        .ok_or(ScaffoldContractError::PhenotypeCompile)?
        .source;
    let hunger_emitter = graph
        .emitters()
        .iter()
        .position(|emitter| {
            emitter.source == BiochemicalSourceLocus::EnergyDeficit && emitter.target == hunger
        })
        .ok_or(ScaffoldContractError::PhenotypeCompile)?;
    let repair_receptor = graph
        .receptors()
        .iter()
        .position(|receptor| receptor.target == BiochemicalTargetLocus::OrganRepair)
        .ok_or(ScaffoldContractError::PhenotypeCompile)?;
    for allele in [AlleleSide::Maternal, AlleleSide::Paternal] {
        genome.chemistry.graph = genome
            .chemistry
            .graph
            .clone()
            // At full expression: .25 baseline + .03*(1-energy)/.04 decay.
            // Starting reserves produce ~.41 hunger, not a saturated signal.
            .with_emitter_gain(allele, hunger_emitter, 0.03)?
            // Repair remains reserve-paid and damage-limited after acute pain
            // fades (including during Rest); it cannot heal without reserve.
            .with_receptor_nominal(allele, repair_receptor, 0.02)?;
    }
    for allele in [AlleleSide::Maternal, AlleleSide::Paternal] {
        genome.chemistry.graph = genome
            .chemistry
            .graph
            .clone()
            .with_waking_recovery(allele)?
            .with_health_distress(allele)?
            .with_player_reward(allele)?
            .with_play_stimulation(allele)?;
    }
    Ok(())
}

fn enable_inherited_newborn_nociception(
    genome: &mut alife_core::CreatureGenome,
) -> Result<(), ScaffoldContractError> {
    use alife_core::{
        AlleleSide, BiochemicalDriveChannel, BiochemicalSourceLocus, BiochemicalTargetLocus,
    };
    let graph = genome.chemistry.graph.expressed();
    let pain = graph
        .receptors()
        .iter()
        .find(|receptor| {
            receptor.target == BiochemicalTargetLocus::Drive(BiochemicalDriveChannel::Pain)
        })
        .ok_or(ScaffoldContractError::PhenotypeCompile)?
        .source;
    let emitter = graph
        .emitters()
        .iter()
        .position(|emitter| {
            emitter.source == BiochemicalSourceLocus::Damage && emitter.target == pain
        })
        .ok_or(ScaffoldContractError::PhenotypeCompile)?;
    for allele in [AlleleSide::Maternal, AlleleSide::Paternal] {
        genome.chemistry.graph = genome
            .chemistry
            .graph
            .clone()
            .with_emitter_expression_floor(allele, emitter, 1.0)?;
    }
    Ok(())
}

fn spawn_phase3_ecology(world: &mut HeadlessWorld) -> Result<(), ScaffoldContractError> {
    let meadow = EcologyZoneId(1);
    world.add_terrain_zone(TerrainZone::new(
        meadow,
        "founder-meadow",
        TerrainZoneKind::Meadow,
        Vec3f::ZERO,
        12.0,
        0.8,
        0.0,
    )?)?;

    let food_id = world.editor_spawn_object(WorldEditorSpawnSpec {
        label: "food-01".to_string(),
        kind: WorldObjectKind::Food,
        organism_id: None,
        position: founder_position(0),
        nutrition: 0.65,
        hazard_pain: 0.0,
        radius: 0.45,
        token_id: None,
    })?;
    world.set_food_variety(food_id, crate::FoodVariety::from_seed(world.seed()))?;
    world.track_resource_lifecycle(food_id, meadow, 48, 240)?;
    world.spawn_toy("meadow-ball", Vec3f::new(4.0, 0.0, 0.0), true)?;
    world.spawn_toy("meadow-activity-toy", Vec3f::new(-4.0, 0.0, 0.0), false)?;

    world.editor_spawn_object(WorldEditorSpawnSpec {
        label: "hazard-01".to_string(),
        kind: WorldObjectKind::Hazard,
        organism_id: None,
        position: Vec3f::new(9.0, 6.0, 0.0),
        nutrition: 0.0,
        hazard_pain: 0.12,
        radius: 0.8,
        token_id: None,
    })?;
    for (label, position) in [
        ("obstacle-01", Vec3f::new(0.0, -7.0, 0.0)),
        ("obstacle-02", Vec3f::new(0.0, 7.0, 0.0)),
    ] {
        world.editor_spawn_object(WorldEditorSpawnSpec {
            label: label.to_string(),
            kind: WorldObjectKind::Obstacle,
            organism_id: None,
            position,
            nutrition: 0.0,
            hazard_pain: 0.0,
            radius: 1.1,
            token_id: None,
        })?;
    }
    Ok(())
}

fn validate_phase3_inputs(
    config: &CanonicalNewGameConfig,
    foundation: &FoundationWeightAsset,
) -> Result<(), ScaffoldContractError> {
    let canonical = CanonicalNewGameConfig::phase3(config.world_seed, config.founder_count)?;
    if *config != canonical
        || foundation
            != &FoundationWeightAsset::builtin_nano512_v1(SensorProfile::GroundedObjectSlotsV1)?
    {
        return Err(ScaffoldContractError::PhenotypeCompile);
    }
    Ok(())
}

fn founder_position(slot: u16) -> Vec3f {
    let angle = f32::from(slot) * core::f32::consts::TAU / f32::from(PHASE3_MAX_POPULATION);
    Vec3f::new(angle.cos() * 3.0, angle.sin() * 3.0, 0.0)
}

fn initial_creature_save(
    record: &WorldOrganismRecord,
    slot: u16,
    founder_seed: u64,
    brain_class: BrainScaleTier,
) -> Result<CreatureSaveState, ScaffoldContractError> {
    let biochemistry = record.biochemistry();
    let genome_bytes =
        serde_json::to_vec(record.genome()).map_err(|_| ScaffoldContractError::InvalidId)?;
    Ok(CreatureSaveState {
        organism_id: record.organism_id(),
        genome_id: record.genome().id,
        brain_class,
        development_tick: biochemistry.development.last_update_tick,
        appearance: CreatureAppearanceGenome::founder_for_species(
            u8::try_from(slot).map_err(|_| ScaffoldContractError::InvalidId)?,
            founder_seed,
        )
        .with_body_phenotype(&record.phenotype().body),
        mind: CreatureMindSaveSummary {
            tick: biochemistry.tick,
            homeostasis: biochemistry.homeostasis,
            memory_record_count: 0,
            memory_source_ids: Vec::new(),
            concept_count: 0,
            edge_count: 0,
            simplex_count: 0,
            unresolved_gap_count: 0,
            sleep_state_label: "awake".to_string(),
            diagnostics: vec!["new founder awaiting GPU admission".to_string()],
        },
        weights: WeightLayerSaveSummary {
            generated_weight_asset_id: None,
            genetic_fixed_digest: PortableAssetDigest::for_bytes(&genome_bytes).0,
            genetic_layer_mutable: false,
            lifetime_consolidated_entries: 0,
            h_operational_entries: 0,
            h_shadow_entries: 0,
        },
        learning: LearningTraceSaveSummary {
            lifetime_learning_enabled: true,
            lamarckian_mode_enabled: false,
            last_consolidated_tick: None,
        },
        composite_genetics: None,
        lifetime_state_asset: None,
        gpu_brain: None,
    })
}
