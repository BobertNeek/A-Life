# Boredom circuit experiment (fresh-only)

This is a weight-space candidate, not a production promotion. It starts from the
protected drive-balance birth recipe and inherited v12 whole-care genes, with
the previously examined signed Approach/Inspect reference readout. A new
boredom pathway and bounded acquired Play consequence reader are under test.
No accepted brain, defaults, acquired weights, optimizer, or checkpoint is
edited. No private retained creature checkpoint is read.

## Grounding and scope

Homeostatic input 9 is boredom, not curiosity (input 5). A compiled recurrent
path carries that input through flexible reserve and temporal neurons to an
Other motor population. Signed motor genes read real object contact (feature
18). The source code never asks whether the object is a toy. World validation
and the actual Play body event decide whether stimulation occurs. Native grounded novelty further divides successful activation into investigation and familiar stimulation; execution is not itself relief. Food and
praise are not substituted for that event.

This candidate deliberately binds GroundedObjectSlotsV1. In its existing
world enumerator, the object-directed Other action is Play. Vocal/no-posture
candidates have no contact feature and retain their own memory namespace.
GroundedGripObjectSlotsV1 has object-directed Release in Other, so this patch
rejects that profile rather than overloading port 53 or sharing its motivation.
It also rejects privileged-affordance and terrain profiles. It does not add a
new action-ID lookup, goal oracle, or host drive-to-action planner.

Existing exact-action episodic family memory supplies acquired consequence
valence (input 32) and danger/failure (input 34). Those rows are additive and
confidence weighted; they do not multiply current neural activation. Positive
memory must therefore be bounded against low current need, rather than treated
as a drive-gated signal. A consequence recorded from a successful Play is
experiential memory; it is not optimizer learning. Native fast/lifetime updates
remain enabled in the actual host fixtures and are reported separately.

## Controls

The probe uses one fixed disposable fixture seed, not a new autonomous cohort.
It compares low/mid/high chemically derived boredom, a physically matched
non-playable object, tiredness, and an inaccessible target. It runs actual CPU
neural selection and world/biology, captures graded detached counterfactual
replays separately, and round-trips live acquired state at a sealed boundary.
Nonzero optimizer moment/age sentinels must remain bitwise unchanged. Source
tests verify the patch's narrow gene scope, exact source preservation, sensor
binding, and lack of a targetless/operation-port alias.

Results, all failures, tuning history, and the final qualification decision are
recorded alongside the probe output. No claim of autonomous mastery or GPU
execution is warranted by these CPU fixtures.

## Method

The motivating weight-space-programming paper is
https://rikiyat.github.io/blog/weight-space-programming/ . Its experiment 4 is
targeted repair; experiment 5 is a static whole policy; experiment 6 adds
iterative feedback. This candidate is bounded targeted repair with actual
world feedback for diagnosis. It does not claim the paper's broader capability.

## Reproduction and parameter audit

Build/test with `cargo test -p alife_training --features cpu-backend --example
probe_boredom_loop -- --test-threads=1`, then build the same example. Invoke the
executable as `probe_boredom_loop OUTPUT TICKS VARIANT SIGNAL REFERENCE TONIC [SAMPLING_STREAM] [SCENE]`.
`VARIANT` is `full`, `no-drive`, `no-memory`, or `baseline`. Here no-drive removes the added bridge AND action readouts; no-memory removes only the new Other consequence reader, not memory storage or inherited readers. The last three
arguments are explicit fresh gene coefficients, never live action scores.
Every output records their actual values and all changed synapse coordinates.
Output paths are create-new only; failed or superseded runs must not be replaced.
The current defaults are signal 4/reference 2/tonic -3. They are a fresh research candidate, not a production qualification claim. Optional arguments after TONIC select a sampling stream and a single scene. See plan-v2.json for the frozen counts and results.md for the limits.

The fixture probe writes each completed fixture to a separate sidecar before
its combined output, preserving completed evidence if a later fixture fails.
`summarize.py OUTPUT` extracts choices, real boredom deltas, graded frozen-score
probes, exact Play memory inputs, native plasticity counts and preservation
checks. The full receipts, not these summaries, remain the evidence authority.
