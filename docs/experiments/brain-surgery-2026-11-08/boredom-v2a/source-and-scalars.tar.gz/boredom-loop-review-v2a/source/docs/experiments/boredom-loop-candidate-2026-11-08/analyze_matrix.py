#!/usr/bin/env python3
"""Exact primitive/target/physical-receipt summaries for the frozen matrix."""
import json, math, pathlib, sys
root=pathlib.Path(sys.argv[1]); runs=[]
for path in sorted(root.glob('*.json')):
    if any(x in path.name for x in ['.json.']): continue
    d=json.load(open(path))
    if 'results' not in d: continue
    for f in d['results']:
        target=f['fixture_target']; rows=f['rows']; selected=[]; played=[]; failed=[]; relief=[]; rests=[]; samples=[]
        for r in rows:
            tick=r['tick']; channels=(r['bundle'] or {}).get('channels',[])
            commands=[c for c in channels if c['channel']=='Manipulation' and c['primitive']==213]
            receipts=(r['outcome'].get('joint') or {}).get('channel_outcomes',[])
            for c in commands:
                entity=(c.get('target') or {}).get('entity')
                matched=[x['physical'] for x in receipts if x['channel']=='Manipulation' and x['physical']['target_entity']==entity]
                selected.append(tick)
                if any(x['contact']=='Touch' for x in matched): played.append(tick)
                else: failed.append(tick)
            delta=r['outcome']['homeostatic_delta']['drives']['extension'][0]
            if delta < -0.001:
                assert commands, 'Biological relief without a selected Play primitive'
                relief.append({'tick':tick,'delta':delta})
            if any(c['channel']=='Posture' and c['primitive']==3 for c in channels): rests.append(tick)
            c=next((c for c in r['candidates'] if c['id']==213 and c['target']['entity']==target),None)
            if c:
                alternatives=[x['logit'] for x in r['candidates'] if x['kind']=='Interact']
                best=max(alternatives); denom=sum(math.exp((x-best)/d['temperature']) for x in alternatives)
                samples.append({'tick':tick,'boredom':r['drives']['extension'][0],'score':c['logit'],
                    'boredom_delta':delta,'curiosity_delta':r['outcome']['homeostatic_delta']['drives']['curiosity'],
                    'novelty_scalar':None,
                    'conditional_manipulation_softmax':math.exp((c['logit']-best)/d['temperature'])/denom,
                    'memory_valence':c['memory'][8],'memory_danger':c['memory'][10],
                    'contact':c['features'][18],'motor':r['motor_activation'],'reference':r['reference_activation']})
        probes=[]
        if rows:
            ci=next((c['index'] for c in rows[0]['candidates'] if c['id']==213 and c['target']['entity']==target),None)
            probes=[{'level':x['level'],'score':x['logits'][-1][ci]} for x in f['detached_pressure_replay']] if ci is not None else []
        runs.append({'file':path.name,'variant':d['variant'],'sampling_seed':d['sampling_seed'],'ticks':d['ticks'],'scene':f['name'],
            'decisions':len(rows),'sleeping_ticks':f['sleeping_ticks'],'boredom_before':f['initial']['homeostasis']['drives']['extension'][0],
            'boredom_after':f['final']['homeostasis']['drives']['extension'][0], 'fatigue_after':f['final']['homeostasis']['drives']['fatigue'],
            'hunger_after':f['final']['homeostasis']['drives']['hunger'],'selected_play_ticks':selected,'actual_play_touch_ticks':played,
            'failed_or_non_touch_play_ticks':failed,'relief':relief,'rest_ticks':rests,'food_consumed':f['food_consumed'],
            'probes':probes,'samples':samples,'optimizer_preserved':d['optimizer_preserved'],'roundtrip':f['checkpoint_roundtrip'],
            'nonzero_fast':f['acquired_nonzero_fast'],'nonzero_lifetime':f['acquired_nonzero_lifetime']})
    if len(d['results'])==6:
        a=next(f for f in d['results'] if f['name']=='toy-high')['rows'][0]
        b=next(f for f in d['results'] if f['name']=='matched-nonplayable-high')['rows'][0]
        assert a['first_frame_encoded_inputs']==b['first_frame_encoded_inputs'], 'Unmatched encoded observations'
        assert [(c['id'],c['features']) for c in a['candidates']]==[(c['id'],c['features']) for c in b['candidates']], 'Unmatched candidate features'
        assert [c['logit'] for c in a['candidates']]==[c['logit'] for c in b['candidates']], 'Matched first scores differ'
print(json.dumps({'scope':'Controlled policy episodes on one inherited candidate; two sampling streams, not genetic replication',
    'matched_first_frames_checked':True,'episodes':runs},indent=2))
