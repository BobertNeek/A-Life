#!/usr/bin/env python3
"""Create finite scalar/physical review receipts without copying acquired banks.

This is an allowlist projection, not a checkpoint serializer. It neither runs
policy nor modifies original outputs. Source-derived quantities are labeled.
"""
import hashlib
import json
import math
import pathlib
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pick(value, keys):
    return {key: value[key] for key in keys}


def vector(value):
    return None if value is None else pick(value, ('x', 'y', 'z'))


def physical(value):
    return dict(pick(value, ('contact', 'energy_cost', 'target_entity')),
                displacement=vector(value['displacement']),
                collision_normal=vector(value['collision_normal']))


def homeostasis(value):
    d, h = value['drives'], value['hormones']
    return {'drives': dict(pick(d, ('hunger', 'fatigue', 'fear', 'pain',
                                    'loneliness', 'curiosity', 'brain_atp',
                                    'temperature_stress', 'reproductive_drive')),
                           boredom=d['extension'][0], extension1=d['extension'][1]),
            'hormones': pick(h, ('adrenaline', 'cortisol', 'dopamine', 'oxytocin',
                                'serotonin', 'acetylcholine', 'developmental_hormone',
                                'sleep_pressure', 'learning_modulator'))}


def biology(value):
    return {'tick': value['tick'],
            'body': pick(value['body'], ('sleeping', 'energy', 'health', 'injury', 'temperature_stress')),
            'development': pick(value['development'], ('age_ticks', 'last_update_tick',
                                'maturation', 'biochemical_expression', 'sleep_maturation_ready')),
            'homeostasis': homeostasis(value['homeostasis']),
            # One named concentration only, not the chemical or neural state arrays.
            'fatigue_species_concentration': value['graph_state']['concentrations'][1]}


def command(value):
    target = value.get('target')
    return dict(pick(value, ('channel', 'primitive', 'intensity')),
                target_entity=None if target is None else target['entity'],
                target_position=None if target is None else vector(target['position']))


def finite(value):
    if isinstance(value, float):
        assert math.isfinite(value)
    elif isinstance(value, dict):
        for item in value.values(): finite(item)
    elif isinstance(value, list):
        for item in value: finite(item)
    else:
        assert value is None or isinstance(value, (str, int, bool))


def project(path):
    data = json.loads(path.read_text())
    episodes = []
    for fixture in data['results']:
        rows = []
        for row in fixture['rows']:
            outcome = row['outcome']
            phys = outcome['measured_physiology']
            joint = outcome['joint']
            commands = [command(c) for c in row['bundle']['channels']]
            moved = any(any(v != 0 for v in c['physical']['displacement'].values())
                        for c in joint['channel_outcomes'])
            rest = any(c['channel'] == 'Posture' and c['primitive'] == 3 for c in commands)
            dose = float(rest and not moved)
            if fixture['name'] == 'toy-high-tired':
                assert bool(dose) == phys['after']['body']['sleeping']
            rows.append({'decision_tick': row['tick'], 'outcome_tick': outcome['outcome_tick'],
                         'commands': commands,
                         'candidates': [dict(pick(c, ('id', 'index', 'kind', 'family', 'logit', 'selected', 'port53')),
                            target_entity=c['target']['entity'],
                            target_position=vector(c['target']['position']),
                            contact_feature=c['features'][18],
                            acquired_valence_input=c['memory'][8],
                            acquired_danger_input=c['memory'][10]) for c in row['candidates']],
                         'motor_activation': row['motor_activation'],
                         'reference_activation': row['reference_activation'],
                         'boredom_activation': row['boredom_activation'],
                         'before': biology(phys['before']), 'after': biology(phys['after']),
                         'measured_homeostatic_delta': homeostasis(outcome['homeostatic_delta']),
                         'measured_energy_delta': outcome['energy_delta'],
                         'measured_pain_delta': outcome['pain_delta'],
                         'success': outcome['success'],
                         'channel_outcomes': [{'channel': c['channel'], 'physical': physical(c['physical'])}
                                              for c in joint['channel_outcomes']],
                         'channel_observations': [dict(pick(c, ('channel','executed','measured_intensity')),
                                                displacement=vector(c['displacement'])) for c in joint['channel_observations']],
                         'novelty_scalar': None, 'investigation_dose': None,
                         'sleep_recovery_dose_directly_logged': False,
                         'sleep_recovery_dose_source_derived': dose})
        first = fixture['rows'][0]['candidates']
        pressure = [{'boredom_input_level': p['level'], 'scores': [
            {'candidate_id': c['id'], 'target_entity': c['target']['entity'], 'score': p['logits'][-1][c['index']]}
            for c in first]} for p in fixture['detached_pressure_replay']]
        episodes.append(dict(pick(fixture, ('name', 'fixture_target', 'food_target', 'food_consumed',
                                           'checkpoint_roundtrip', 'acquired_nonzero_fast', 'acquired_nonzero_lifetime')),
                             host_scheduled_sleep_ticks=fixture['sleeping_ticks'],
                             initial=biology(fixture['initial']), final=biology(fixture['final']),
                             detached_pressure_replay=pressure, intervals=rows))
    output = {'schema': 'boredom-safe-physical-scalars-v1',
              'source_file': path.name, 'source_sha256': sha(path),
              'scope': data['scope'],
              **pick(data, ('variant', 'sampling_seed', 'ticks', 'temperature', 'optimizer_preserved')),
              'limits': ['No directly recorded per-object novelty, investigation dose or final BodyEventDelta.',
                         'SleepRecovery dose is derived from the exact Rest/motion source rules and physical receipts.',
                         'Named memory inputs are finite readout scalars, not stored memories or learned arrays.',
                         'Detached pressure replay is not acted policy or learning.'],
              'episodes': episodes}
    finite(output)
    return output


def main():
    root, destination = map(pathlib.Path, sys.argv[1:3])
    destination.mkdir(parents=True, exist_ok=False)
    for path in sorted((root / 'matrix-v2').glob('*.json')):
        if '.json.' in path.name: continue
        output = project(path)
        (destination / path.name).write_text(json.dumps(output, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    main()
