# Publication boundary

The raw local outputs contain acquired memory banks and must not be published.
The frozen executable is also local-only. The separate review package contains
only explicitly selected source, source patches, plan/provenance, static gene
diffs, named finite scalar diagnostics and physical action receipts.

`project_receipts.py` is the exact field allowlist for the 60-episode projection.
It constructs every output field explicitly. It does not recursively copy raw
rows, complete biology objects, memory banks or learned arrays. It checks that
all numeric values are finite. Per-object novelty and investigation dose are
null because they were not recorded. SleepRecovery event dose is marked as
source-derived rather than directly logged.

The external package manifest lists every included file, size and SHA256. The
source-only patch contains no receipts, executables or checkpoints. Its two
dependencies are the original drive-audit source patch and the exact common
Rest-motion patch. All original evidence remains unchanged locally. No upload
or publication is performed by this worker.
