# Candidate and control revisions

All are fresh static gene edits evaluated with native CPU neural/world/biology.
None is an optimizer training update, a retained creature migration, or a new
accepted gameplay default.

1. Initial proposal: signal 12, reference -8, tonic -4; six eight-tick diagnostic
   episodes, fixed stream 2026110901. High boredom 0.8 fell to zero through five
   actual Play receipts. Low boredom also played, and frozen zero-boredom Play
   score remained +4.8648. This proposal failed the release goal. The tonic path
   drove a positive temporal/motor operating point even after pressure fell.
   Positive memory alone was not established as the cause.
2. Lower tonic: signal 2, reference 3, tonic -1; six 24-tick diagnostics on the
   same stream. No real Play in accessible toy fixtures, even with high boredom.
   Frozen Play scores stayed near -2.6. Rejected as over-suppressed.
3. Operating-point probe: signal 4, reference 0, tonic -3; six eight-tick
   diagnostics on the same stream. Frozen scores graded from +0.1063 at zero
   pressure to +0.8463 at 0.9. One actual Play occurred in the high fixture at
   tick 7. This short single-stream result is not a release or learning proof.
4. Before any matrix exposure, freeze signal 4/reference 2/tonic -3, adding a small
   signed reference subtraction. Plan and counts are in plan-v2.json. Do not
   retune this candidate using the planned matrix and still call it held out.

## Control correction and common world

The first three diagnostics used an obstacle with copied physical properties as
an intended non-playable match. Although its global encoded input matched, its
candidate contact feature did not: the obstacle blocked the reach segment.
Those rows are valid failures but invalid as a contact-matched causal control.
The corrected control is a zero-pain, nonblocking Hazard object with identical
physical properties and geometry. No hazard dose or chemistry code is changed.
A unit guard must verify all initial sensory/candidate inputs including contact
match, while actual Play succeeds only on the toy and neither action supplies
nutrition, player reward, or damage.

The matrix also applies the separately qualified common Rest-translation world
correction, SHA256 c394e2fbfadcf2fea7e7ecba15ad44ba7f757e0d366a06b7f8e50871010169dc,
to every arm. Its four rest_motion_ guards must pass. Moving while Rest is selected
must not masquerade as recovery in the fatigue competition control.

The frozen first source and binary are retained outside the source deliverable,
with their exact source/binary digests. All initial outputs remain unchanged.
