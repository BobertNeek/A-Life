#!/usr/bin/env bash
set -euo pipefail
binary=./probe-boredom-v3
mkdir -p matrix-v2
for seed in 17 29; do
  for arm in full no-drive no-memory baseline; do
    "$binary" "matrix-v2/${arm}-${seed}.json" 24 "$arm" 4 2 -3 "$seed" 2>&1 | tee "matrix-v2/${arm}-${seed}.log"
  done
done
for seed in 17 29; do
  for arm in full no-drive no-memory baseline; do
    "$binary" "matrix-v2/long-${arm}-${seed}.json" 96 "$arm" 4 2 -3 "$seed" toy-high 2>&1 | tee "matrix-v2/long-${arm}-${seed}.log"
  done
  for arm in full baseline; do
    "$binary" "matrix-v2/hunger-${arm}-${seed}.json" 24 "$arm" 4 2 -3 "$seed" hungry-toy-and-food 2>&1 | tee "matrix-v2/hunger-${arm}-${seed}.log"
  done
done
