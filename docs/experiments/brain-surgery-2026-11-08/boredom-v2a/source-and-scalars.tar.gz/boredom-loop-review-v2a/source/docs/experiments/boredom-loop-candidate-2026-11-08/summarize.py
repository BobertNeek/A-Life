#!/usr/bin/env python3
"""Summarize fresh fixture evidence without replacing full receipts."""
import json,sys,math
p=sys.argv[1]; d=json.load(open(p)); result=[]
for f in d['results']:
 rows=f['rows']; cs=rows[0]['candidates'] if rows else []
 play=next((x for x in cs if x['family']=='Other' and x['kind']=='Interact'),None)
 idx=play['index'] if play else None
 choices=[r['tick'] for r in rows if any(x['selected'] and x['index']==idx for x in r['candidates'])]
 relief=[{'tick':r['tick'],'delta':r['outcome']['homeostatic_delta']['drives']['extension'][0]} for r in rows if r['outcome']['homeostatic_delta']['drives']['extension'][0]<-0.001]
 probes=[{'level':x['level'],'play_final_score':x['logits'][-1][idx] if idx is not None else None} for x in f['detached_pressure_replay']]
 scores=[next((x['logit'] for x in r['candidates'] if x['index']==idx),None) for r in rows]
 memories=[next((x['memory'][8:12] for x in r['candidates'] if x['index']==idx),None) for r in rows]
 result.append({'name':f['name'],'decisions':len(rows),'sleeping_ticks':f['sleeping_ticks'],'initial_boredom':f['initial']['homeostasis']['drives']['extension'][0],
  'final_boredom':f['final']['homeostasis']['drives']['extension'][0],'play_ticks':choices,'real_relief':relief,'pressure_probes':probes,
  'play_scores':scores,'play_memory':memories,'roundtrip':f['checkpoint_roundtrip'],'nonzero_fast':f['acquired_nonzero_fast'],'nonzero_lifetime':f['acquired_nonzero_lifetime'],'food_consumed':f.get('food_consumed')})
summary={'source':p,'variant':d['variant'],'recipe':{k:v for k,v in d['recipe'].items() if k!='changes'},'optimizer_preserved':d['optimizer_preserved'],'fixtures':result}
print(json.dumps(summary,indent=2))
