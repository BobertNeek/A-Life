# V7 CPU interruption qualification (not GPU promotion)

Exact commit/tree/base, native counts, excluded-executable hashes and build configuration are in bindings.json. Read cognitive-interruption-cpu-v7-review.md for scope. Full patch applies only to the original research base; delta applies to frozen V6. The source directory contains changed full files for review, not a complete standalone checkout. The complete immutable tracked tree is bound by tracked-source-closure.git-tree.txt.

No executables, bank/checkpoint files, private lives or whole learned-state arrays are included. The raw initial CPU assertion failure stays local and is deliberately omitted. Source-only tests and successful scalar logs are included.

Native commands with the recorded toolchain/environment:
- cargo test -p alife_core --test gpu_sleep_contracts --offline -- --test-threads=1
- cargo test -p alife_runtime --test automatic_sleep_scheduler --offline -- --test-threads=1
- cargo test -p alife_training --features cpu-backend --test cpu_collector --offline -- --test-threads=1
- cargo clippy -p alife_core -p alife_runtime -p alife_training --features alife_training/cpu-backend --lib --tests --offline -- -D warnings
- cargo fmt --all -- --check; git diff --check

CPU natural end-to-end coverage is None/Committed. Pending/prepared/submitted/completed preservation is core-contract and deterministic scheduler coverage, not an actual GPU optimizer job. GPU journal, exact neural authority and Completed permits remain separate V8 work. Normal main extraction and default activation are not claimed.
