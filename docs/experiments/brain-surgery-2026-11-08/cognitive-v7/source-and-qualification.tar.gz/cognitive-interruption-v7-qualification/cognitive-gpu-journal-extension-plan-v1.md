# Bounded GPU interruption journal extension plan

Current CPU/core/scheduler stage: tree606aa71f2c16feb0b945c87ccd60967d9fc5181b, CPU32/0/1, core14/14, deterministic scheduler9/9. This plan is not implemented or qualified. GPU arousal activation remains off.

## Explicit durable representation
Use the journal's existing serialized schema_version discriminator for a new version3, preserving version2 bytes/digest domains/acceptance for legacy states. No fields are appended to nested sequence structs. New entries are explicitly distinguished by their embedded SleepState schema3 transition; old source2→target3 is an interrupt edge, source3→target3 supports later drain/resume. Version2 containers reject these new entries. Entry and container digests get separate version3 domains; legacy inputs keep exact old domains. Existing public legacy type names can retain compatibility aliases while constructors choose the explicit supported format.

A canonical interrupt/resume edge must preserve the entire consolidation payload, active cycle, entered tick, completed count, last consolidated cycle and original trigger. It changes only the correctly paired phase, phase-start tick and (first interruption only) schema2→3. Same-stage Pending/Prepared/Submitted/Completed edges are not generic permission to rewrite state. A repeated acute-contact refresh produces no state edge. No new consolidation intent while interrupted.

Allow a bounded third same-tick entry only when it is the final canonical interruption edge after an already-valid two-edge phase→pending chain. Preserve exact same-organism/tick ordinal order and exact target→source continuity. A resume may follow one real drain edge in the interval. Reject duplicate arousal, swapped edges, invalid source phases, changed frozen request/job/output identity and fabricated completion.

## Consumer integration
- staged_tick dispatch must use start/end neural-write permission and retained-learning guards, not phase==Awake. A frozen drain becoming Committed must not also receive a new policy decision in the same interval.
- durability_hold must distinguish physically aroused but frozen work from real neural-write eligibility. Interrupted None/Committed may proceed only with honest authority; in-flight work still drains under existing recovery rules.
- Body-only and action receipts supply actual fresh damage. Late body arousal is sealed once, after biology, with no voluntary episode or optimizer credit. Quiet intervals resume the original phase; restored ordinary execution must release an existing interrupted state without needing a per-call flag.
- Visuals show actual arousal while cognitive work may still be draining.

## Neural authority question to resolve before activation
A real aroused decision changes neural state. Resuming the same unfinished sleep cycle cannot validate against a stale cached pre-arousal SleepJournalNeuralAuthority or pretend those writes persisted in a compact phase journal. Trace the ordinary Awake→sleep publication path and bind the actual new neural generation/authority on resume. Do not relax compact authority checks, skip journal representation, or manufacture checkpoint progress merely to admit dispatch. If new exact state persistence is genuinely necessary to represent new writes, make that explicit and test its real boundary/rollback rather than calling it a phase-only edge.

## Required tests
1. Literal version2 nested wire/digest fixtures unchanged; version3 roundtrip and legacy-container rejection.
2. Every frozen stage interrupt/drain/resume, three-edge ordering/tampering/duplication, exact restore, no fake commit.
3. Active/blocked fresh contact, quiet/chronic-only controls, action vs body-only single biology, late failure rollback.
4. Actual native GPU transaction or honest explicit offline transaction harness: pending eligibility, real sealed V13 outcome, one commit, duplicate/retry rejection, checkpoint continuation and preserved replay/optimizer/cursors. Existing SwiftShader evaluator proof alone is not this test.
5. Exact-main extraction onto b0b4e5ab85473f1ace63f0629ecf4704e7b0fb81, avoiding duplicate ordinary dose/Rest/ABI repairs, then normal CPU/GPU activation only after these technical guards.
