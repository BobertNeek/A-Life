//! Automatic GPU sleep scheduling.

use alife_core::sleep::SleepWorkReceipt;
use alife_core::{
    BodyEventDelta, ConsolidationDriverEvent, ConsolidationIntent, ConsolidationState,
    HomeostaticParameters, HomeostaticSnapshot, OrganismId, ScaffoldContractError,
    SleepConsolidationConfig, SleepController, SleepPhase, SleepState, SleepTransition,
    SleepTrigger, Tick, Validate,
};
use alife_world::{OrganismSleepInput, WorldOrganismRecord};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct SleepWorkDue(u8);

impl SleepWorkDue {
    pub const REPLAY: Self = Self(1 << 0);
    pub const FAST_TO_LIFETIME: Self = Self(1 << 1);
    pub const PREDICTOR: Self = Self(1 << 2);
    pub const CONCEPT_GAP: Self = Self(1 << 3);
    pub const STRUCTURAL_GROWTH_PRUNING: Self = Self(1 << 4);

    pub const fn empty() -> Self {
        Self(0)
    }

    pub const fn is_empty(self) -> bool {
        self.0 == 0
    }

    pub const fn bits(self) -> u8 {
        self.0
    }

    pub const fn contains(self, other: Self) -> bool {
        self.0 & other.0 == other.0
    }

    const fn insert(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct SleepSubsystemCadence {
    pub replay_ticks: u64,
    pub fast_to_lifetime_ticks: u64,
    pub predictor_ticks: u64,
    pub concept_gap_ticks: u64,
    pub structural_growth_pruning_ticks: u64,
}

impl SleepSubsystemCadence {
    pub const fn reference() -> Self {
        Self {
            replay_ticks: 1,
            fast_to_lifetime_ticks: 2,
            predictor_ticks: 2,
            concept_gap_ticks: 4,
            structural_growth_pruning_ticks: 4,
        }
    }

    pub fn validate(self) -> Result<(), ScaffoldContractError> {
        if self.replay_ticks == 0
            || self.fast_to_lifetime_ticks == 0
            || self.predictor_ticks == 0
            || self.concept_gap_ticks == 0
            || self.structural_growth_pruning_ticks == 0
        {
            return Err(ScaffoldContractError::ScalarOutOfRange);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SleepPhaseReceipt {
    pub phase: SleepPhase,
    pub cycle_id: u64,
    pub tick: Tick,
    pub due_work: SleepWorkDue,
    pub work_units: u64,
    pub cumulative_work_units: u64,
    pub sealed: bool,
}

pub trait GpuSleepConsolidationDriver {
    fn progress(
        &mut self,
        organism_id: OrganismId,
        state: SleepState,
        intent: Option<ConsolidationIntent>,
    ) -> Result<Option<ConsolidationDriverEvent>, ScaffoldContractError>;

    /// Runs the due bounded core sleep transaction.
    ///
    /// Organism-aware scheduling requires the completed core transaction receipt.
    /// The default reports no core work.
    fn run_bounded_sleep_transaction(
        &mut self,
        _organism_id: OrganismId,
        _state: SleepState,
        _homeostasis: &HomeostaticSnapshot,
        _tick: Tick,
        _due_work: SleepWorkDue,
    ) -> Result<Option<SleepWorkReceipt>, ScaffoldContractError> {
        Ok(None)
    }

    /// Reports whether this cycle has replay-backed phase data for bounded
    /// memory, predictor, concept, and structural sleep work.
    ///
    /// Empty newborn replay is an explicit no-work state. Nonempty replay
    /// still requires a validated transaction.
    fn has_bounded_sleep_phase_data(
        &mut self,
        _organism_id: OrganismId,
        _state: SleepState,
    ) -> Result<bool, ScaffoldContractError> {
        Ok(true)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GpuSleepScheduleEvent {
    pub tick: Tick,
    pub phase: SleepPhase,
    pub cycle_id: u64,
    pub transition: Option<SleepTransition>,
    pub consolidation_kind_raw: u16,
    pub motor_eligible: bool,
    pub sleep_work_units: u64,
    pub phase_receipt: SleepPhaseReceipt,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct GpuSleepScheduler {
    controller: SleepController,
    cadence: SleepSubsystemCadence,
    last_emitted_intent_cycle: Option<u64>,
    last_sleep_work_cycle: Option<u64>,
    last_sleep_work_ticks: [Option<Tick>; 5],
}

impl GpuSleepScheduler {
    pub fn new(config: SleepConsolidationConfig) -> Result<Self, ScaffoldContractError> {
        Self::with_cadence(config, SleepSubsystemCadence::reference())
    }

    pub fn with_cadence(
        config: SleepConsolidationConfig,
        cadence: SleepSubsystemCadence,
    ) -> Result<Self, ScaffoldContractError> {
        cadence.validate()?;
        Ok(Self {
            controller: SleepController::new(config)?,
            cadence,
            last_emitted_intent_cycle: None,
            last_sleep_work_cycle: None,
            last_sleep_work_ticks: [None; 5],
        })
    }

    pub fn restore(
        config: SleepConsolidationConfig,
        state: SleepState,
    ) -> Result<Self, ScaffoldContractError> {
        Self::restore_with_cadence(config, state, SleepSubsystemCadence::reference())
    }

    pub fn restore_with_cadence(
        config: SleepConsolidationConfig,
        state: SleepState,
        cadence: SleepSubsystemCadence,
    ) -> Result<Self, ScaffoldContractError> {
        cadence.validate()?;
        let controller = SleepController::restore(config, state)?;
        let last_emitted_intent_cycle = if state.phase.resumed_phase() == SleepPhase::Consolidating
            && state.consolidation != ConsolidationState::None
        {
            Some(state.active_cycle_id)
        } else {
            None
        };
        Ok(Self {
            controller,
            cadence,
            last_emitted_intent_cycle,
            last_sleep_work_cycle: None,
            last_sleep_work_ticks: [None; 5],
        })
    }

    pub const fn state(&self) -> SleepState {
        self.controller.state()
    }

    pub fn interrupt_for_acute_pain(
        &mut self,
        tick: Tick,
    ) -> Result<Option<SleepTransition>, ScaffoldContractError> {
        self.controller.interrupt_for_acute_pain(tick)
    }

    pub fn resume_interrupted_sleep(
        &mut self,
        tick: Tick,
    ) -> Result<Option<SleepTransition>, ScaffoldContractError> {
        self.controller.resume_interrupted_sleep(tick)
    }

    pub const fn cadence(&self) -> SleepSubsystemCadence {
        self.cadence
    }

    pub fn force_recovery_sleep(
        &mut self,
        tick: Tick,
    ) -> Result<SleepTransition, ScaffoldContractError> {
        self.controller
            .force_sleep(tick, SleepTrigger::RecoveryProtocol)
    }

    pub fn scheduled_tick<D: GpuSleepConsolidationDriver>(
        &mut self,
        organism_id: OrganismId,
        homeostasis: &HomeostaticSnapshot,
        parameters: HomeostaticParameters,
        tick: Tick,
        driver: &mut D,
    ) -> Result<GpuSleepScheduleEvent, ScaffoldContractError> {
        let phase_before = self.controller.state().phase;
        let transition = if phase_before == SleepPhase::Awake {
            self.controller
                .evaluate_homeostasis(homeostasis, parameters, tick)?
        } else {
            self.controller.advance(tick)?
        };

        self.progress_driver(organism_id, driver)?;

        let state = self.controller.state();
        if state.phase == SleepPhase::Awake {
            self.last_emitted_intent_cycle = None;
            self.reset_sleep_work_schedule();
        }
        Ok(self.event(
            tick,
            transition,
            state,
            state.permits_neural_activity(),
            SleepWorkDue::empty(),
            0,
            0,
            false,
        ))
    }

    /// Schedules sleep from the world-owned biological record.
    ///
    /// The world record advances biology once for the requested tick. The
    /// first due bounded transaction runs before the consolidation driver binds
    /// its replay identity. Later in-flight work cannot mutate structural replay
    /// inputs. Each completed bounded transaction is consumed as one work
    /// receipt and sealed back into the organism for persistence and presentation.
    pub fn scheduled_tick_with_organism<D: GpuSleepConsolidationDriver>(
        &mut self,
        organism: &mut WorldOrganismRecord,
        parameters: HomeostaticParameters,
        tick: Tick,
        driver: &mut D,
        explicit_sleep_behavior: bool,
    ) -> Result<GpuSleepScheduleEvent, ScaffoldContractError> {
        let before = organism.authoritative_sleep_input()?;
        if !before.lifecycle.is_alive() {
            return Err(ScaffoldContractError::InvalidId);
        }

        let phase_before = self.controller.state().phase;
        organism.advance_biology_once(
            tick,
            BodyEventDelta {
                sleep_recovery: if phase_before.is_physical_sleep()
                    || (!phase_before.is_interrupted() && before.body_sleeping)
                {
                    1.0
                } else {
                    0.0
                },
                ..BodyEventDelta::zero()
            },
        )?;
        let input = organism.authoritative_sleep_input()?;
        if input.biological_tick != tick {
            return Err(ScaffoldContractError::NonMonotonicTick);
        }

        let transition = self.advance_authoritative(&input, parameters, tick)?;

        let state_before_progress = self.controller.state();
        let mut due_work = SleepWorkDue::empty();
        let mut work_units = 0;
        if state_before_progress.phase == SleepPhase::Consolidating
            && state_before_progress.consolidation == ConsolidationState::None
            && driver.has_bounded_sleep_phase_data(input.organism_id, state_before_progress)?
        {
            due_work = self.sleep_work_due_before_pending(state_before_progress, tick);
            work_units = self.run_due_sleep_work(
                driver,
                input.organism_id,
                state_before_progress,
                &input.homeostasis,
                tick,
                due_work,
            )?;
        }

        self.progress_driver(input.organism_id, driver)?;

        let state = self.controller.state();
        if state.phase == SleepPhase::Awake {
            self.last_emitted_intent_cycle = None;
            self.reset_sleep_work_schedule();
        }

        let cycle_id = Self::cycle_id(state);
        organism.seal_sleep_phase(state.phase, cycle_id, tick, work_units)?;
        let seal = organism.sleep_seal();
        Ok(self.event(
            tick,
            transition,
            state,
            state.permits_neural_activity()
                || (explicit_sleep_behavior && !state.requires_interrupted_drain()),
            due_work,
            work_units,
            seal.work_units,
            true,
        ))
    }

    fn homeostasis_for_due_work(
        homeostasis: &HomeostaticSnapshot,
        config: SleepConsolidationConfig,
    ) -> HomeostaticSnapshot {
        let mut effective = *homeostasis;
        effective.drives.fatigue = effective.drives.fatigue.max(config.fatigue_threshold.raw());
        effective.hormones.sleep_pressure = effective
            .hormones
            .sleep_pressure
            .max(config.sleep_pressure_threshold.raw());
        effective
    }

    fn run_due_sleep_work<D: GpuSleepConsolidationDriver>(
        &mut self,
        driver: &mut D,
        organism_id: OrganismId,
        state: SleepState,
        homeostasis: &HomeostaticSnapshot,
        tick: Tick,
        due_work: SleepWorkDue,
    ) -> Result<u64, ScaffoldContractError> {
        if due_work.is_empty() {
            return Ok(0);
        }
        let work_homeostasis =
            Self::homeostasis_for_due_work(homeostasis, self.controller.config());
        let receipt = driver
            .run_bounded_sleep_transaction(organism_id, state, &work_homeostasis, tick, due_work)?
            .ok_or(ScaffoldContractError::MissingPhaseData)?;
        receipt.validate_contract()?;
        if receipt.tick != tick {
            return Err(ScaffoldContractError::NonMonotonicTick);
        }
        self.commit_sleep_work(state.active_cycle_id, tick, due_work);
        Ok(receipt.work_units)
    }

    fn advance_authoritative(
        &mut self,
        input: &OrganismSleepInput,
        parameters: HomeostaticParameters,
        tick: Tick,
    ) -> Result<Option<SleepTransition>, ScaffoldContractError> {
        let phase = self.controller.state().phase;
        if phase == SleepPhase::Awake {
            // Food restores body reserves; sleep restores fatigue and neural readiness.
            // A hungry organism must remain able to wake and seek food.
            self.controller
                .evaluate_homeostasis(&input.homeostasis, parameters, tick)
        } else if phase == SleepPhase::Waking {
            let config = self.controller.config();
            let wake_ready = input.homeostasis.drives.fatigue < config.fatigue_threshold.raw()
                && input.homeostasis.hormones.sleep_pressure
                    < config.sleep_pressure_threshold.raw();
            if wake_ready {
                self.controller.advance(tick)
            } else {
                Ok(None)
            }
        } else {
            self.controller.advance(tick)
        }
    }

    fn progress_driver<D: GpuSleepConsolidationDriver>(
        &mut self,
        organism_id: OrganismId,
        driver: &mut D,
    ) -> Result<(), ScaffoldContractError> {
        let state_before_driver = self.controller.state();
        let intent = if state_before_driver.phase == SleepPhase::Consolidating
            && state_before_driver.consolidation == ConsolidationState::None
            && self.last_emitted_intent_cycle != Some(state_before_driver.active_cycle_id)
        {
            Some(ConsolidationIntent {
                cycle_id: state_before_driver.active_cycle_id,
            })
        } else {
            None
        };

        if state_before_driver.phase == SleepPhase::Consolidating
            || state_before_driver.requires_interrupted_drain()
        {
            let progress = driver.progress(organism_id, state_before_driver, intent)?;
            if intent.is_some() && progress.is_none() {
                return Err(ScaffoldContractError::MissingPhaseData);
            }
            if let Some(progress) = progress {
                self.controller.apply_consolidation_driver_event(progress)?;
                if let Some(intent) = intent {
                    self.last_emitted_intent_cycle = Some(intent.cycle_id);
                }
            }
        }
        Ok(())
    }

    fn sleep_work_due_before_pending(&self, state: SleepState, tick: Tick) -> SleepWorkDue {
        if state.phase != SleepPhase::Consolidating
            || state.consolidation != ConsolidationState::None
        {
            return SleepWorkDue::empty();
        }
        self.sleep_work_due_for_cycle(state.active_cycle_id, tick)
    }

    fn sleep_work_due_for_cycle(&self, cycle_id: u64, tick: Tick) -> SleepWorkDue {
        let previous = if self.last_sleep_work_cycle == Some(cycle_id) {
            self.last_sleep_work_ticks
        } else {
            [None; 5]
        };
        let periods = [
            self.cadence.replay_ticks,
            self.cadence.fast_to_lifetime_ticks,
            self.cadence.predictor_ticks,
            self.cadence.concept_gap_ticks,
            self.cadence.structural_growth_pruning_ticks,
        ];
        let flags = [
            SleepWorkDue::REPLAY,
            SleepWorkDue::FAST_TO_LIFETIME,
            SleepWorkDue::PREDICTOR,
            SleepWorkDue::CONCEPT_GAP,
            SleepWorkDue::STRUCTURAL_GROWTH_PRUNING,
        ];
        let mut due = SleepWorkDue::empty();
        for index in 0..periods.len() {
            if previous[index]
                .is_none_or(|last| tick.raw().saturating_sub(last.raw()) >= periods[index])
            {
                due.insert(flags[index]);
            }
        }
        due
    }

    fn commit_sleep_work(&mut self, cycle_id: u64, tick: Tick, due: SleepWorkDue) {
        if self.last_sleep_work_cycle != Some(cycle_id) {
            self.last_sleep_work_cycle = Some(cycle_id);
            self.last_sleep_work_ticks = [None; 5];
        }
        let flags = [
            SleepWorkDue::REPLAY,
            SleepWorkDue::FAST_TO_LIFETIME,
            SleepWorkDue::PREDICTOR,
            SleepWorkDue::CONCEPT_GAP,
            SleepWorkDue::STRUCTURAL_GROWTH_PRUNING,
        ];
        for (index, flag) in flags.into_iter().enumerate() {
            if due.contains(flag) {
                self.last_sleep_work_ticks[index] = Some(tick);
            }
        }
    }

    fn reset_sleep_work_schedule(&mut self) {
        self.last_sleep_work_cycle = None;
        self.last_sleep_work_ticks = [None; 5];
    }

    #[expect(
        clippy::too_many_arguments,
        reason = "the event records the phase transition and exact scheduled work receipt fields"
    )]
    fn event(
        &self,
        tick: Tick,
        transition: Option<SleepTransition>,
        state: SleepState,
        motor_eligible: bool,
        due_work: SleepWorkDue,
        work_units: u64,
        cumulative_work_units: u64,
        sealed: bool,
    ) -> GpuSleepScheduleEvent {
        let cycle_id = Self::cycle_id(state);
        GpuSleepScheduleEvent {
            tick,
            phase: state.phase,
            cycle_id,
            transition,
            consolidation_kind_raw: state.consolidation.kind_raw(),
            motor_eligible,
            sleep_work_units: work_units,
            phase_receipt: SleepPhaseReceipt {
                phase: state.phase,
                cycle_id,
                tick,
                due_work,
                work_units,
                cumulative_work_units,
                sealed,
            },
        }
    }

    const fn cycle_id(state: SleepState) -> u64 {
        if state.active_cycle_id == 0 {
            state.last_consolidated_cycle_id
        } else {
            state.active_cycle_id
        }
    }
}
