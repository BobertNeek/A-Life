# Frozen V6 qualification

Read bindings.json and reflex-gpu-integration-v6-review.md first. Full patch applies to the exact research base listed in bindings; delta applies to frozen body-only v5. Source files are included for review, not a complete standalone repository. tracked-source-closure.git-tree.txt binds the entire immutable tracked repository tree.

Native toolchain Rust1.99.1; jobs1, incremental0, dev/test debug0; offline after official missing dependency retrieval. Production defaults remain unchanged. No binaries, private checkpoints or whole learned arrays are included.

Commands (run from reconstructed exact source with the recorded toolchain/target environment):
- cargo test -p alife_game_app --features gpu-runtime --lib --offline -- --test-threads=1
- cargo test -p alife_training --features cpu-backend --test cpu_collector --offline -- --test-threads=1
- cargo clippy -p alife_game_app --features gpu-tests --lib --tests --offline -- -D warnings
- cargo clippy -p alife_gpu_backend --features gpu-tests --test oja_credit_stability --offline -- -D warnings
- cargo fmt --all -- --check; git diff --check

For actual software Vulkan evaluator set VK_ICD_FILENAMES=/usr/lib/chromium/vk_swiftshader_icd.json and ALIFE_V13_PRODUCER_FIXTURE to the included JSON artifact, then:
- cargo test -p alife_gpu_backend --features gpu-tests --test oja_credit_stability sealed_v13_producer_credit_reaches_production_plasticity_evaluator --offline -- --ignored --nocapture --test-threads=1
- cargo test -p alife_gpu_backend --features gpu-tests --test oja_credit_stability actual_route_masks_decoder_selection_and_persisted_eligibility_gate_updates --offline -- --ignored --nocapture --test-threads=1

To regenerate the artifact use the focused game_app test gpu_world_producer_seals_v13_reflex_without_rewriting_voluntary_receipts with ALIFE_V13_PRODUCER_FIXTURE set to a NEW output path. The fixture refuses to overwrite an existing artifact.

Failed attempts remain labeled in logs: offline missing dependency, one added-argument compile fix, and one missing Validate trait import. These are not counted as passing runs. baseline-diagnostics separately retains the preexisting pinned-output failure and same-adapter frozen-original comparison, without replacing goldens.
