//! Engine-independent A-Life cognition and biology.

pub mod action;
pub mod activity;
pub mod archive;
pub mod attention;
pub mod biochemical_graph;
pub mod biochemistry;
mod blake3_digest;
pub mod brain_class;
pub mod canonical_digest;
pub mod checkpoint;
pub mod chemistry;
#[path = "newphenotype/cognitive_channel.rs"]
pub mod cognitive_channel;
pub mod cognitive_context;
pub mod cognitive_work;
pub mod dendritic;
pub mod diagnostics;
pub mod embodiment;
pub mod error;
pub mod evaluation;
pub mod evidence_digest;
pub mod evolutionary_genetics;
pub mod experience;
mod factorized_selection;
pub mod foundation;
pub mod genome;
pub mod grip_research;
pub mod grounding;
pub use grip_research::{GripObservationV1, GripOperationV1, GripOwnershipV1, GroundedGripSlotV1};
pub mod ids;
pub mod language;
pub mod learning;
mod legacy_nano512_compatibility;
mod n2048_experimental_graph;
mod nano512_readout_candidate;
pub use cognitive_channel::{
    CognitiveChannelExtensionV1, CognitiveChannelPlanV1,
    COGNITIVE_CHANNEL_EXTENSION_SCHEMA_VERSION, COGNITIVE_CHANNEL_FAMILY_COUNT,
    COGNITIVE_CHANNEL_LANE_COUNT, COGNITIVE_CHANNEL_LANE_END, COGNITIVE_CHANNEL_LANE_START,
    COGNITIVE_CHANNEL_REPLAY_CAPTURE_LIMIT, COGNITIVE_CHANNEL_TOTAL_SYNAPSES,
    COGNITIVE_CONTEXT_DECODER_HEAD_RAW, COGNITIVE_DECODER_ROLE_RAW,
};
pub use factorized_selection::{
    arbitrate_gpu_selected_command_into_factorized_bundle, channel_command_for_action,
    factorized_motor_bundle_for_candidates, factorized_motor_channel_order,
    normalized_motor_bundle_digest, JointActionSelectionV1, VOCAL_CHANNEL_PAYLOAD_MAGIC_V1,
};
pub use genome::ActionCandidateCreditProfileV1;
pub use n2048_experimental_graph::N2048ExperimentalGraphV1;
mod n2048_grip_reader_candidate;
pub use n2048_grip_reader_candidate::N2048GripReaderCandidateV1;
mod n2048_memory_gain_candidate;
pub use n2048_memory_gain_candidate::N2048MemoryGainCandidateV1;
pub use nano512_readout_candidate::{Nano512ActionCreditCandidateV2, Nano512ReadoutCandidateV1};
pub mod lobe;
pub mod math;
pub mod memory;
pub mod memory_query;
pub mod migration_v2;
pub mod motor;
pub mod neural;
pub mod neural_receptors;
pub mod packed_log;
pub mod perception;
pub mod phenotype;
pub mod predictive;
pub mod reference_brain;
pub mod routing;
pub mod sensory_abi;
pub mod sleep;
pub mod structural_plasticity;
pub mod topology;
pub mod traits;
pub mod units;
pub mod validation;
pub mod version;

pub use action::{
    heuristic_baseline_arbitrate, ActionArbitrationConfig, ActionArbitrationTrace,
    ActionArbitrationTraceRef, ActionBiasSource, ActionCommand, ActionDecision,
    ActionDecisionStatus, ActionFallbackReason, ActionInhibitionSample, ActionKind, ActionProposal,
    ActionRegistryEntry, ActionScoreBias, ActionTarget, ActionWtaResult, InhibitionNeighborhood,
    MotorPayloadKind, MotorPayloadRef, RankedActionProposal, SuppressedProposal, SuppressionReason,
    TeacherLessonMetadata, TeacherLessonResponseChannel,
};
pub use activity::{
    BrainActivityPolicyV1, BrainAtpCostModel, BrainDispatchIdentity, BrainWorkCounters,
    BrainWorkReceipt, GpuPressureSample, GpuPressureSampleInput, NeuralThrottleDecision,
    NeuralThrottleLevel, BRAIN_ACTIVITY_POLICY_VERSION, BRAIN_ACTIVITY_SCHEMA_VERSION,
    BRAIN_ATP_BASAL_DEBIT_Q16, BRAIN_ATP_Q16_MAX, BRAIN_ATP_SLEEP_RECOVERY_Q16,
};
pub use archive::{
    ArchiveAssetKind, ArchiveAssetRef, ArchiveCheckpointDisposition, ArchiveCheckpointRef,
    ArchiveCheckpointRetention, ArchiveLearnedCapturePolicy, ArchivePageRef,
    ArchiveRetirementReceipt, CreatureArchiveManifest, CreatureLifeArchiveRecord,
    FounderCohortManifest, FounderIdentityRemap, FounderMode, FounderProvenance, FounderSelection,
    GeneticArchiveRecord, CREATURE_ARCHIVE_SCHEMA_VERSION, FOUNDER_COHORT_SCHEMA_VERSION,
};
pub use attention::{
    select_focal_targets, AttentionBudgetReceipt, AttentionFrame, AttentionSelectionPolicy,
    HysteresisState, NeuralStructuralIdentity, PeripheralSummary, SalienceComponents,
    StableFocusIdentity, ATTENTION_SCHEMA_VERSION, MAX_ATTENTION_SALIENCE_COMPONENTS,
    MAX_FOCAL_TARGETS, MAX_PERIPHERAL_SUMMARIES,
};
pub use biochemical_graph::{
    BiochemicalEmitter, BiochemicalGraphState, BiochemicalPhenotype, BiochemicalReceptor,
    BiochemicalSourceLocus, BiochemicalTargetLocus, BiochemicalWorkReceipt, ChemicalCompartment,
    ChemicalSpecies, ChemicalSpeciesId, ChemicalSpeciesKind,
    DriveChannel as BiochemicalDriveChannel, EmitterResponse, EndocrineChannel, NeuralEmission,
    NeuralEmissionClass, NeuralEmissionFrame, NeuralReceptorActivation, NeuralReceptorClass,
    NeuralReceptorFrame, Neuroemitter, SparseReaction, StoichiometricTerm,
    BIOCHEMICAL_GRAPH_SCHEMA_VERSION, MAX_ACTIVE_CHEMICAL_SPECIES, MAX_ACTIVE_EMITTERS,
    MAX_ACTIVE_NEUROEMITTERS, MAX_ACTIVE_REACTIONS, MAX_ACTIVE_RECEPTORS, MAX_NEURAL_EMISSIONS,
    MAX_NEURAL_RECEPTOR_ACTIVATIONS,
};
pub use biochemistry::{
    BiochemistryCadence, BiochemistryState, BodyEventDelta, BodyState, DevelopmentReadiness,
    OrganKind, OrganPhysiology, PassiveBodyUpkeepPolicy, ReproductionReadiness,
    MAX_BIOCHEMISTRY_CATCH_UP_STEPS, ORGAN_KIND_COUNT,
};
pub use blake3_digest::Blake3Digest;
pub use brain_class::{BrainClassSpec, BrainComputeBudget, BrainScaleTier};
pub use canonical_digest::CanonicalDigestBuilder;
pub use checkpoint::{BrainCheckpointMode, BRAIN_CHECKPOINT_MODE_SCHEMA_VERSION};
pub use chemistry::{
    BiologicalValueProfile, ChemistryModulation, DriveDelta, DriveSnapshot, EndocrineDelta,
    EndocrineProfile, EndocrineSnapshot, HomeostaticDelta, HomeostaticParameters,
    HomeostaticSnapshot, RecoveryAssessment, RecoveryTrigger, DRIVE_EXTENSION_SLOTS,
    ENDOCRINE_EXTENSION_SLOTS,
};
pub use cognitive_context::{
    CognitiveBudgetView, CognitiveConceptActivation, CognitiveConceptView, CognitiveContextFrame,
    CognitiveFocalView, CognitiveGapActivation, CognitiveGapView, CognitiveInteroceptiveView,
    CognitiveMemoryExpectancy, CognitiveMemoryView, CognitivePeripheralView,
    CognitivePredictionView, COGNITIVE_CONTEXT_SCHEMA_VERSION, MAX_ACTIVE_CONCEPTS,
    MAX_ACTIVE_GAPS, MAX_CONTEXT_MEMORY_EXPECTANCIES, MAX_PREDICTION_ERROR_FEATURES,
};
pub use cognitive_work::{
    CognitiveWorkReceipt, COGNITIVE_WORK_POLICY_VERSION, COGNITIVE_WORK_SCHEMA_VERSION,
    MAX_COGNITIVE_WORK_COUNTER,
};
pub use dendritic::{
    apply_dendritic_conjunctions, DendriticBranch, DendriticBranchSet, DendriticInputRef,
    DendriticWorkReceipt, MAX_DENDRITIC_BRANCHES, MAX_DENDRITIC_BRANCHES_PER_NEURON,
    MAX_DENDRITIC_INPUTS,
};
pub use diagnostics::{ContractDiagnostic, DiagnosticCode};
pub use embodiment::{
    EffectorCapability, EffectorPortDescriptor, EmbodimentState, SensorCapability,
    SensorPortDescriptor, EMBODIMENT_STATE_SCHEMA_VERSION, MAX_BODY_SCHEMA_VALUES,
    MAX_EMBODIMENT_PORTS,
};
pub use error::ScaffoldContractError;
pub use evaluation::{
    EnvironmentalRegime, MetricReading, PassiveLifeEvent, PassiveLifeStatistics, PassiveMetricKind,
    PASSIVE_LIFE_STATISTICS_SCHEMA_VERSION,
};
pub use evidence_digest::{
    lobe_layout_evidence_digest, projection_plan_evidence_digest, synapse_payload_evidence_digest,
    GpuClosedLoopBenchmarkProtocolV1, PhenotypeEvidenceManifest,
    GPU_CLOSED_LOOP_BENCHMARK_BASE_SEED, GPU_CLOSED_LOOP_BENCHMARK_MEASURED_TICKS,
    GPU_CLOSED_LOOP_BENCHMARK_PROTOCOL_VERSION, GPU_CLOSED_LOOP_BENCHMARK_SCHEMA,
    GPU_CLOSED_LOOP_BENCHMARK_TIMESTAMP_SCOPE_SPLIT, GPU_CLOSED_LOOP_BENCHMARK_WARMUP_TICKS,
    GPU_PHENOTYPE_EVIDENCE_MANIFEST_SCHEMA,
};
pub use evolutionary_genetics::{
    AlleleDominance, AlleleSide, BiochemicalGraphChromosome, BodyChromosome, BodyFrame,
    BodyPhenotype, BrainChromosome, BrainConstructionChromosome, ChemistryChromosome,
    ChemistryPhenotype, ChromosomeKind, ChromosomeRecombinationRecord, ContinuousLocus,
    CreatureGenome, CreaturePhenotype, DevelopmentChromosome, DevelopmentPhenotype, DiscreteAllele,
    DiscreteExpression, DiscreteLocus, FoundationGeneticIdentity, GeneticLineageProvenance,
    MatePreference, MutationRecord, PredispositionChromosome, PredispositionPhenotype,
    ReproductionChromosome, ReproductionPhenotype, StarterVocabularyProfile,
    CREATURE_GENOME_SCHEMA_VERSION, MAX_CROSSOVER_SEGMENTS, MAX_MUTATION_DELTA,
    MAX_MUTATION_RECORDS,
};
pub use experience::{
    ConceptHint, ContactWithdrawalDirectionBasis, ContactWithdrawalEvidence, DecisionEvidence,
    DecisionSnapshot, EvidenceKind, ExperiencePatch, ExperiencePatchBuilder, ExperiencePatchHeader,
    ExperiencePatchPhase, HeuristicDecisionEvidence, HeuristicPreActionEvidence,
    JointPhysicalOutcome, MeasuredPhysiologyTransition, MemoryExpectancySnapshot, MemoryHint,
    NeuralDecisionEvidence, PhysicalActionOutcome, PhysicalContactKind, PostActionOutcome,
    PreActionBrainEvidence, PreActionSnapshot, TeacherFeedbackObservation,
    V11_EXPERIENCE_ABI_VERSION, V12_EXPERIENCE_ABI_VERSION, V13_EXPERIENCE_ABI_VERSION,
};
pub use foundation::{
    FoundationAbiBinding, FoundationCompatibilityFamilyId, FoundationId, FoundationLayoutId,
    FoundationManifest, FoundationPromotionReceipt, FoundationSectionPolicy, FoundationVersion,
    FoundationWeightAsset, FoundationWeightAssetRef, LifetimePlasticityBand,
    N2048FoundationLayoutV1, N2048FoundationRouteSpec, TrainingStageManifest,
};
pub use genome::{
    AlphaMask, AlphaStoragePolicy, BrainGenome, CriticalPeriod, CrossoverPolicy,
    DecoderLifetimeRatePolicyV1, DevelopmentStage, DevelopmentState, DevelopmentalMilestone,
    DevelopmentalSchedule, DriveThresholdKind, EffectiveWeightSample, EndocrineConstantKind,
    GenomeSeedSet, HOperational, HShadow, InheritancePolicy, InnatePriorityGenes,
    LifetimeConsolidationDelta, LobeAlphaOverride, LobeRatioOverride, LobeRatioPlan,
    LobeRatioRegistryRef, MacroConnectomeMask, MotorAffordanceGene, MotorAffordanceKind,
    MutationRates, PlasticityGenomeParameters, PlasticityMask, ProjectionAlphaOverride,
    ProjectionKey, ProjectionPlasticityMask, SensorChannelGene, SensorChannelKind,
    SensorLayoutGene, SparseDensityPrior, SynapseAddress, SynapseAlphaOverride, TileAddress,
    TileAlphaOverride, WEffective, WGeneticFixed, WLifetimeConsolidated, WeightLayerDescriptor,
    WeightLayerKind, WeightSplitContract, WeightStorageSemantics,
};
pub use grounding::{
    GroundedObjectSlotV1, SensorProfileId, SensorProfileIdentity, SensorProfileProvenance,
    GROUNDED_OBJECT_SLOT_SCHEMA_VERSION, MAX_GROUNDED_OBJECT_SLOTS,
};
pub use ids::{
    validate_optional_target, ActionId, BrainClassId, ConceptCellId, CreatureId,
    ExperienceSequenceId, GaussianClusterId, GenomeId, LineageId, LobeIndex, MemoryId, NeuronIndex,
    OrganismId, TrackedObjectId, WorldEntityId,
};
pub use language::{
    LanguageCodebookId, LanguageCodebookV1, LanguageGroundingEntry, LanguageGroundingLedger,
    LanguageTokenClass, LanguageTokenId, NovelLanguageToken, PlayerUtterance, SpeechActKind,
    SpeechDecoderLayoutV1, SpeechMotorPayload, SpeechTranslationInput, SpeechTranslationReceipt,
    SpeechTranslationRequest, SurfaceTokenBinding, UtteranceGroundingReceiptV2, UtteranceId,
    UtteranceSourceKind, LANGUAGE_GROUNDING_LEDGER_CAPACITY, SPEECH_TRANSLATION_MAX_BINDINGS,
    SPEECH_TRANSLATION_MAX_SURFACE_CHARS, UTTERANCE_GROUNDING_RECEIPT_V2_SCHEMA_VERSION,
};
pub use learning::{
    validate_outcome_credit_schema, FastWeightSemantics, LearningCommitToken,
    LearningSequenceGuard, NeuromodulatorSample, NeuromodulatoryFrame, OutcomeCreditPacket,
    OutcomeCreditReplayKey, PlasticityReceptorProfile, NEUROMODULATORY_LANE_COUNT,
};
pub use legacy_nano512_compatibility::{
    FoundationAbiSelection, LegacyFoundationAbiId, LegacyNano512CompatibilityAbiDescriptor,
    LegacyNano512CompatibilityAdmission, LegacyNano512CompatibilityReceipt,
    MigratedN2048FoundationV1Descriptor, ProductionRuntimeAbiId, ProductionRuntimePath,
    LEGACY_NANO512_V1_COORDINATE_SEED,
};
pub use lobe::{
    ActivationPolicy, LegacyLobeKindV1, LobeEssentiality, LobeKind, LobeLayout, LobeRegion,
    LobeThrottlePriority, PlasticityPolicy, UpdateCadence,
};
pub use math::{validate_finite, validate_finite_slice, Aabb, Pose, Quatf, Vec2f, Vec3f, Velocity};
pub use memory::{
    CandidateMemoryRecallReceipt, FinalizedMemoryRecall, MemoryBank, MemoryBankConfig,
    MemoryBucketReceiptKey, MemoryCompactionCheckpoint, MemoryCompactionIdentity,
    MemoryCompactionPhase, MemoryCompactionReceipt, MemoryConsolidationBatch, MemoryConsolidator,
    MemoryExpectancy, MemoryMatch, MemoryOutcomeSummary, MemoryQuery, MemoryRecallChannel,
    MemoryRecallDegradation, MemoryRecallReceipt, MemoryRecord, MemorySidecarState,
    MemoryUpdateKind, MemoryUpdateReceipt, PortableMemoryBankAssetV2, PortableMemoryRecordV2,
    PreparedMemoryCompaction, PreparedMemoryRecall, RuntimeMemoryRecallCache,
    TargetMemoryBucketReceiptKey, MEMORY_BANK_MAX_CAPACITY, MEMORY_FAMILY_SEARCH_CAP,
    MEMORY_FEATURE_VECTOR_MAX_LEN, MEMORY_MERGE_SIMILARITY, MEMORY_MIN_SIMILARITY,
    MEMORY_RECALL_SCHEMA_VERSION, MEMORY_RECALL_TOP_K, MEMORY_TARGET_SEARCH_CAP,
    MEMORY_TOTAL_SEARCH_CAP, RUNTIME_MEMORY_SEARCH_CAP,
};
pub use memory_query::{
    finalized_memory_attention_evidence, CandidateMemoryContextV1, CandidateMemoryQueryV2,
    EpisodicDecisionKeyV2, EpisodicRetrievalContextV1, FinalizedMemoryAttentionEvidence,
    MemoryQueryEncoderV2, MemoryQueryVersion, EPISODIC_RETRIEVAL_CONTEXT_SCHEMA_VERSION,
    MEMORY_ACTION_FAMILY_RANGE, MEMORY_ACTION_KIND_RANGE, MEMORY_BODY_RANGE,
    MEMORY_CONTEXT_V1_LANES_PER_CANDIDATE, MEMORY_CONTEXT_V1_MAX_SOURCES, MEMORY_DRIVE_RANGE,
    MEMORY_HORMONE_RANGE, MEMORY_LATENT_V1_COUNT, MEMORY_PROFILE_RANGE,
    MEMORY_QUERY_V2_FEATURE_COUNT, MEMORY_RESERVED_RANGE, MEMORY_STATE_SENSORY_RANGE,
    MEMORY_TARGET_RANGE, MEMORY_VALUE_V1_COUNT,
};
pub use migration_v2::{
    migrate_body_v2_to_v3, migrate_founder_region_ranges_v1_to_v2, migrate_neuromodulator_v2_to_v3,
    require_complete_v3_organism_state, ArchitectureMigrationError, ArchitectureMigrationKind,
    ArchitectureMigrationReceipt, LegacyBodyStateV2, LegacyLobeRangeV1, LegacyNeuromodulatorV2,
    MigratedFounderRangeV2,
};
pub use motor::{
    BoundedCoordinationSummary, BoundedMotorPayload, ChannelCommand, CoordinationGroup,
    EgocentricDirection, MeasuredChannelObservation, MotorChannel, MotorCommandBundle,
    TargetBinding, MAX_COORDINATION_GROUPS, MAX_MOTOR_CHANNELS, MAX_MOTOR_PAYLOAD_VALUES,
    MOTOR_COMMAND_SCHEMA_VERSION,
};
pub use neural::{
    cpu_spmv_projection, finalize_cpu_activations, update_oja_shadow_traces, ActivationFunction,
    CooEntry, CooTile, CpuNeuralState, DecodedSynapse, DenseTile, LobeActivationView, Microtile,
    NeuralActivationConfig, NeuralDiagnostics, NeuralProjectionSchema, NeuralUpdateMetadata,
    NeuralUpdateReport, NeuronRange, OjaUpdateConfig, PlasticityTraceBuffers, ProjectionRoutingRef,
    ProjectionTile, SparseProjection, SparseTileCoord, SparseTilePayload, SparseTileType,
    SupertileMask, SynapseWeightSplit, TileMetadata, MICROTILE_CELLS, MICROTILE_EDGE,
    SUPERTILE_EDGE, SUPERTILE_MICROTILES,
};
pub use neural_receptors::{NeuralReceptorEffects, NeuralReceptorPhenotype};
pub use packed_log::{
    ExperiencePacker, InMemoryPackedExperienceLog, PackedExperienceFrame, PackedExperienceRecord,
    PackedExperienceSink, PackedExperienceSummary, PackedLogEntryRef, PackedSideBufferKind,
    PackedSideBufferRecord, PackedSideBufferSpans, PackedSideBuffers, SideBufferSpan,
    PACKED_DRIVE_SUMMARY_CHANNELS, PACKED_EXPERIENCE_FRAME_RESERVED_U32S,
    PACKED_EXPERIENCE_SCHEMA_VERSION, PACKED_FLAG_CONTRADICTION_OBSERVED,
    PACKED_FLAG_HAS_GAUSSIAN_CONTEXT, PACKED_FLAG_HAS_MOTOR_PAYLOAD,
    PACKED_FLAG_HAS_SEMANTIC_CONTEXT, PACKED_FLAG_HAS_TARGET_ENTITY,
    PACKED_FLAG_HAS_TARGET_POSITION, PACKED_FLAG_HAS_TEACHER_FEEDBACK,
    PACKED_FLAG_HAS_TEACHER_LESSON, PACKED_FLAG_SUCCESS, PACKED_HORMONE_SUMMARY_CHANNELS,
    PACKED_LOG_DEFAULT_SIDE_BUFFER_CAPACITY_RECORDS, PACKED_SIDE_BUFFER_GROUP_COUNT,
};
pub use perception::{
    ActionCandidate, BodySnapshot, CandidateActionFamily, CandidateFeatureDigest,
    CandidateFeatureVector, CandidateObservationRef, NeuralActionSelection, PerceptionBaseDigest,
    PerceptionContextBlock, PerceptionContextDigest, PerceptionContextKind, PerceptionFrame,
    PerceptionFrameDigest, PerceptionFrameDraft, PolicyBackend, SensorProfile,
    CANDIDATE_FEATURE_COUNT, MAX_ACTION_CANDIDATES,
};
pub use phenotype::{
    validate_weight_only_policy_successor, AuxiliaryDecoderPlan, BrainCapacityClass,
    BrainExecutionBudget, BrainPhenotype, CandidateDecoderFamilyPlan, CandidateDecoderPlan,
    CompiledBudgets, CompiledProjection, CompiledSynapse, CompiledSynapseKind, DecoderHeadKind,
    DecoderSynapseCoordinate, FoundationWeightApplication, GlobalPhenotypeBudgetReceipt,
    MemoryChannelPlan, N2048LivePolicyProvenanceV1, N2048LivePolicyTransition,
    N4096ResearchLayoutV1, N512FounderFoundationProjection, N512FounderProjectionReceipt,
    N512FrozenAbiRecipe, NeuronDynamics, PersistentAddressMap, PersistentDecoderAddress,
    PersistentDecoderAddressEntry, PersistentNeuronAddress, PersistentNeuronAddressEntry,
    PersistentProjectionAddress, PersistentProjectionAddressEntry, PersistentProjectionRole,
    PersistentSynapseAddress, PersistentSynapseAddressEntry, PhenotypeCompiler,
    PhenotypeCompilerInputs, PhenotypeGrowthMigration, PhenotypeGrowthReceipt, PhenotypeHash,
    PlasticityReceptorPlan, ReplayCapturePlan, RouteBudgetReceipt, SensorEncoderAssignment,
    SensorEncoderPlan, SensorEncoderSourceGroup, SleepConsolidationPlan,
    MAX_REPLAY_CAPTURE_SYNAPSES, REQUIRED_GPU_FEATURE_MASK,
};
pub use predictive::{
    GroundedSuccessorPredictor, JointMotorCondition, MotorChannelFactor,
    PredictionCategoryCoverage, PredictionTargetFamily, PredictionTargetReceipt,
    SemanticStateVector, GROUNDED_PREDICTOR_ABI_VERSION, JOINT_MOTOR_CONDITION_ABI_V1,
    JOINT_MOTOR_CONDITION_ABI_V2, JOINT_MOTOR_CONDITION_SCHEMA_VERSION, MAX_PREDICTOR_CATEGORIES,
    MAX_SEMANTIC_STATE_VALUES, MAX_SUCCESSOR_FEATURES, PREDICTION_TARGET_SCHEMA_VERSION,
    SEMANTIC_STATE_VECTOR_ABI_V1, SEMANTIC_STATE_VECTOR_SCHEMA_VERSION, SUCCESSOR_FEATURE_ABI_V1,
};
pub use reference_brain::{
    BrainTickDiagnostics, BrainTickInput, BrainTickOutput, BrainTickStatus, CreatureActionState,
    CreatureBodyState, CreatureMind, ReferenceActionExecution, ReferenceActionExecutor,
    ReferenceActionFailure, ReferenceOutcomeObservation, ReferenceOutcomeObserver,
    ReferenceOutcomeRequest, ReferenceSensoryAdapter, ReferenceSensoryRequest,
};
pub use routing::{
    ActiveTilePolicy, BiologicalPriority, ProjectionType, RoutingMask, RoutingMatrix,
};
pub use sensory_abi::{
    AffordanceBits, CompressedSemanticCode, ContextFeatureFlags, ContextStreams,
    EnvironmentStreamEntry, GaussianContextRef, GaussianSalienceEntry, HeardToken,
    LanguageContextSnapshot, SemanticContextRef, SemanticSalienceEntry, SensoryAbiVersion,
    SensoryChannels, SensorySnapshot, SocialAgentSnapshot, SocialContextSnapshot,
    SocialProximityEntry, TeacherPerceptionChannel, VocalizedToken, MAX_HEARD_TOKENS,
    MAX_OPTIONAL_ENVIRONMENT_STREAMS, MAX_SOCIAL_AGENTS, SENSORY_ABI_CHANNEL_COUNT,
    SENSORY_AUDITORY_CHANNEL_COUNT, SENSORY_PAIN_NOVELTY_CHANNEL_COUNT,
    SENSORY_SMELL_CHANNEL_COUNT, SENSORY_TACTILE_CHANNEL_COUNT,
    SENSORY_VISUAL_AFFORDANCE_CHANNEL_COUNT,
};
pub use sleep::{
    compute_gpu_sleep_commit_digest, compute_gpu_sleep_input_weight_digest,
    compute_gpu_sleep_mutable_state_digest, compute_gpu_sleep_output_weight_digest,
    decode_replay_eligibility_q15, encode_replay_eligibility_q15, BoundedReplayBatch,
    ConceptConsolidationReport, ConsolidationDriverEvent, ConsolidationIntent, ConsolidationJobId,
    ConsolidationStagedOutput, ConsolidationState, GpuConsolidationRequest, HTraceDrainReport,
    MemoryCompressionReport, ReplayEligibilitySample, ReplaySynapseSpan, SleepConsolidationConfig,
    SleepConsolidationReport, SleepConsolidator, SleepController, SleepPhase, SleepReplayEvent,
    SleepReplayJournal, SleepState, SleepTransition, SleepTrigger, StructuralEditApplicationStatus,
    StructuralEditBatch, StructuralEditCandidate, StructuralEditKind, StructuralEditReason,
    TraitPromotionReport, BOUNDED_REPLAY_BATCH_SCHEMA_VERSION,
    GPU_CONSOLIDATION_REQUEST_SCHEMA_VERSION, SLEEP_CONSOLIDATION_SCHEMA_VERSION,
};
pub use structural_plasticity::{
    CoactivationEvidence, StructuralDiscoveryReceipt, StructuralPlasticityConfig,
    StructuralPlasticityError, StructuralPlasticityState, StructuralWorkReceipt,
    MAX_ACCEPTED_PER_PHASE, MAX_CANDIDATES_PER_REGION, MAX_EVIDENCE_PER_PHASE,
    MAX_REGIONS_PER_STATE, MAX_STRUCTURAL_EDGES,
};
pub use topology::{
    ActionObservationFact, CognitiveEdge, CognitiveEdgeId, CognitiveSimplex, CognitiveSimplexId,
    ConceptBindings, ConceptCell, ContradictionType, CuriosityBias, DriveBinding, DriveChannel,
    EdgeRelationKind, EmotionValenceSummary, GapResolutionStatus, PortableTopologyActionBindingV1,
    PortableTopologyBindingSetV1, PortableTopologyConceptV1, PortableTopologyDriveBindingV1,
    PortableTopologyEdgeV1, PortableTopologyGapV1, PortableTopologySidecarAssetV1,
    PortableTopologySimplexV1, TopologicalMap, TopologicalMapConfig, TopologyCounts,
    TopologyDegradationKind, TopologyIdCounters, TopologyObservationReceipt, TopologySidecar,
    TopologySidecarDiagnostics, TopologyUpdate, UnresolvedGap, UnresolvedGapId,
};
pub use traits::{
    SemanticPriorPacket, SemanticPriorRequest, SEMANTIC_PRIOR_MAX_GAIN,
    SEMANTIC_PRIOR_MAX_LEXICON_BIAS_SLOTS, SEMANTIC_PRIOR_MAX_PACKET_TICKS,
};

pub use language::{basic_vocabulary_bindings, BASIC_VOCABULARY_V1, FOUNDATION_LESSON_VOCABULARY};
pub use units::{
    Confidence, DurationTicks, FixedPointScale, Intensity, NormalizedScalar, Seconds,
    SignedValence, Tick,
};
pub use validation::{ensure_current_version, Validate};
pub use version::{
    require_current_version, require_version, ContractVersion, SchemaKind, SchemaVersions,
};
