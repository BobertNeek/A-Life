//! Frozen baseline fields copied from source 2da9dd323ad6f074556a851174a2edbc9e34e216.
//! Test the actually supported old codecs, not an invented append-only surrogate.
use super::*;
use alife_core::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
struct BaselinePostActionOutcome {
    pub abi_version: u16,
    pub organism_id: OrganismId,
    pub sequence_id: ExperienceSequenceId,
    pub outcome_tick: Tick,
    pub success: bool,
    pub physical: PhysicalActionOutcome,
    pub homeostatic_delta: HomeostaticDelta,
    pub reward_valence: SignedValence,
    pub frustration_delta: NormalizedScalar,
    /// Fresh pain or tissue harm for learning and memory. The signed change
    /// in the pain drive remains in `measured_physiology.pain_delta`.
    pub pain_delta: NormalizedScalar,
    pub energy_delta: SignedValence,
    pub prediction_error: NormalizedScalar,
    pub contradiction_observed: bool,
    pub concept_hints: Vec<ConceptHint>,
    pub memory_hints: Vec<MemoryHint>,
    pub teacher_feedback: Option<TeacherFeedbackObservation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub joint: Option<JointPhysicalOutcome>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cognitive_work: Option<CognitiveWorkReceipt>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub measured_physiology: Option<MeasuredPhysiologyTransition>,
}

fn encode<T: Serialize>(value: &T) -> Result<Vec<u8>, bincode::error::EncodeError> {
    bincode::serde::encode_to_vec(value, bincode::config::standard())
}

fn decode<T: serde::de::DeserializeOwned>(bytes: &[u8]) -> Result<T, bincode::error::DecodeError> {
    let (value, consumed) = bincode::serde::decode_from_slice(bytes, bincode::config::standard())?;
    assert_eq!(
        consumed,
        bytes.len(),
        "nested decode must consume exactly the envelope"
    );
    Ok(value)
}

fn invalid_patch(value: serde_json::Value) -> bool {
    match serde_json::from_value::<ExperiencePatch>(value) {
        Ok(patch) => patch.validate_contract().is_err() && patch.causal_digest().is_err(),
        Err(_) => true,
    }
}

fn evidence() -> ContactWithdrawalEvidence {
    ContactWithdrawalEvidence::new(
        ContactWithdrawalDirectionBasis::LocalizedContact,
        vec![WorldEntityId(90)],
        Vec3f::new(-0.2, 0.0, 0.0),
        false,
        0.02,
    )
    .unwrap()
}

fn v12_patch() -> ExperiencePatch {
    ExperiencePatch::new_v12(
        legacy_pre_action(Tick::new(10)),
        bundle(),
        measured_v12_outcome(v12_joint_outcome()),
        prediction(),
        work(),
        context(),
    )
    .unwrap()
}

fn v13_patch(evidence: ContactWithdrawalEvidence) -> ExperiencePatch {
    let old = v12_patch();
    let mut joint = v12_joint_outcome();
    joint.execution.displacement.x += evidence.displacement.x;
    joint.execution.displacement.y += evidence.displacement.y;
    joint.execution.displacement.z += evidence.displacement.z;
    let voluntary_energy = joint.channel_outcomes.iter().fold(0.0f32, |sum, channel| {
        (sum + channel.physical.energy_cost.raw()).clamp(0.0, 1.0)
    });
    joint.execution.energy_cost =
        NormalizedScalar::new((voluntary_energy + evidence.energy_cost).min(1.0)).unwrap();
    ExperiencePatch::new_v13_with_decision(
        old.pre_action().clone(),
        old.decision().clone(),
        bundle(),
        measured_v12_outcome(joint)
            .with_v13_contact_withdrawal(evidence)
            .unwrap(),
        prediction(),
        work(),
        context(),
    )
    .unwrap()
}

fn baseline(outcome: &PostActionOutcome) -> BaselinePostActionOutcome {
    serde_json::from_value(serde_json::to_value(outcome).unwrap()).unwrap()
}

#[test]
fn old_outcome_serializers_and_supported_json_sequences_are_unchanged() {
    let names = [
        "abi_version",
        "organism_id",
        "sequence_id",
        "outcome_tick",
        "success",
        "physical",
        "homeostatic_delta",
        "reward_valence",
        "frustration_delta",
        "pain_delta",
        "energy_delta",
        "prediction_error",
        "contradiction_observed",
        "concept_hints",
        "memory_hints",
        "teacher_feedback",
        "joint",
        "cognitive_work",
        "measured_physiology",
    ];
    for outcome in [
        legacy_outcome(1),
        legacy_outcome(2),
        legacy_outcome(PostActionOutcome::ABI_VERSION),
        measured_outcome(joint_outcome()),
        measured_v12_outcome(v12_joint_outcome()),
    ] {
        let baseline = baseline(&outcome);
        assert_eq!(
            serde_json::to_vec(&baseline).unwrap(),
            serde_json::to_vec(&outcome).unwrap()
        );
        assert_eq!(encode(&baseline).unwrap(), encode(&outcome).unwrap());
        let map = serde_json::to_value(&baseline).unwrap();
        let sequence = serde_json::Value::Array(
            names
                .iter()
                .filter_map(|name| map.get(*name).cloned())
                .collect(),
        );
        let old_decoded: BaselinePostActionOutcome =
            serde_json::from_value(sequence.clone()).unwrap();
        let decoded: PostActionOutcome = serde_json::from_value(sequence).unwrap();
        assert_eq!(
            serde_json::to_value(old_decoded).unwrap(),
            serde_json::to_value(decoded).unwrap()
        );
    }
}

#[derive(Debug, Serialize, Deserialize)]
struct Envelope<T> {
    outcome: T,
    sentinel: u64,
}

/// Explicit positional fixture, not a copy of the production serializer.
struct ExplicitOutcomeSequence<'a>(&'a PostActionOutcome);
impl Serialize for ExplicitOutcomeSequence<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::SerializeTuple;
        let v13 = self.0.abi_version == PostActionOutcome::V13_ABI_VERSION;
        let mut tuple = serializer.serialize_tuple(if v13 { 20 } else { 19 })?;
        tuple.serialize_element(&self.0.abi_version)?;
        tuple.serialize_element(&self.0.organism_id)?;
        tuple.serialize_element(&self.0.sequence_id)?;
        tuple.serialize_element(&self.0.outcome_tick)?;
        tuple.serialize_element(&self.0.success)?;
        tuple.serialize_element(&self.0.physical)?;
        tuple.serialize_element(&self.0.homeostatic_delta)?;
        tuple.serialize_element(&self.0.reward_valence)?;
        tuple.serialize_element(&self.0.frustration_delta)?;
        tuple.serialize_element(&self.0.pain_delta)?;
        tuple.serialize_element(&self.0.energy_delta)?;
        tuple.serialize_element(&self.0.prediction_error)?;
        tuple.serialize_element(&self.0.contradiction_observed)?;
        tuple.serialize_element(&self.0.concept_hints)?;
        tuple.serialize_element(&self.0.memory_hints)?;
        tuple.serialize_element(&self.0.teacher_feedback)?;
        tuple.serialize_element(&self.0.joint)?;
        tuple.serialize_element(&self.0.cognitive_work)?;
        tuple.serialize_element(&self.0.measured_physiology)?;
        if v13 {
            tuple.serialize_element(&self.0.contact_withdrawal)?;
        }
        tuple.end()
    }
}

#[test]
fn baseline_measured_physiology_binary_limitation_is_not_new() {
    let outcome = measured_v12_outcome(v12_joint_outcome());
    let bytes = encode(&Envelope {
        outcome: baseline(&outcome),
        sentinel: 0xf1e2d3c4b5a69788,
    })
    .unwrap();
    assert!(decode::<Envelope<BaselinePostActionOutcome>>(&bytes).is_err());
    assert!(decode::<Envelope<PostActionOutcome>>(&bytes).is_err());
    // Pin the failing nested type rather than claiming wholepatch support.
    let bytes = encode(&outcome.measured_physiology).unwrap();
    assert!(decode::<Option<MeasuredPhysiologyTransition>>(&bytes).is_err());
}

#[test]
fn baseline_readable_explicit_sequence_does_not_consume_enclosing_sentinel() {
    // Decoder compatibility only: explicit None avoids the pre-existing nested
    // physiology codec limitation. The old encoder skips this None field, so
    // this controlled sequence is not claimed as an old encoder roundtrip.
    let mut outcome = measured_v12_outcome(v12_joint_outcome());
    outcome.measured_physiology = None;
    let bytes = encode(&Envelope {
        outcome: ExplicitOutcomeSequence(&outcome),
        sentinel: 0xf1e2d3c4b5a69788,
    })
    .unwrap();
    // First prove this exact nested format was supported by the old wire.
    let old: Envelope<BaselinePostActionOutcome> = decode(&bytes).unwrap();
    let new: Envelope<PostActionOutcome> = decode(&bytes).unwrap();
    assert_eq!(new.sentinel, old.sentinel);
    assert_eq!(new.outcome, outcome);
    assert_eq!(
        bytes,
        encode(&Envelope {
            outcome: ExplicitOutcomeSequence(&outcome),
            sentinel: old.sentinel
        })
        .unwrap()
    );
}

#[test]
fn v13_json_roundtrip_and_controlled_binary_decoder_sequence() {
    let patch = v13_patch(evidence());
    let encoded = serde_json::to_vec(&patch).unwrap();
    let decoded: ExperiencePatch = serde_json::from_slice(&encoded).unwrap();
    assert_eq!(patch, decoded);
    assert_eq!(
        patch.causal_digest().unwrap(),
        decoded.causal_digest().unwrap()
    );
    let mut binary_outcome = patch.outcome().clone();
    binary_outcome.measured_physiology = None;
    let bytes = encode(&Envelope {
        outcome: ExplicitOutcomeSequence(&binary_outcome),
        sentinel: 0x8877665544332211,
    })
    .unwrap();
    let decoded: Envelope<PostActionOutcome> = decode(&bytes).unwrap();
    assert_eq!(decoded.outcome, binary_outcome);
    assert_eq!(decoded.sentinel, 0x8877665544332211);
    for version in [
        patch.header().abi_version,
        patch.pre_action().abi_version,
        patch.decision().abi_version,
        patch.outcome().abi_version,
    ] {
        assert_eq!(version, ExperiencePatch::V13_ABI_VERSION);
    }
    let packed = ExperiencePacker::default().pack(&patch).unwrap();
    assert_eq!(
        packed.frame.experience_schema_version,
        ExperiencePatch::V13_ABI_VERSION
    );
    packed.frame.validate_contract().unwrap();
    // Whole ExperiencePatch bincode decoding is not asserted: its existing
    // untagged JSON migration envelope does not support that codec.
}

#[test]
fn reflex_metadata_changes_sealed_digest_and_cannot_be_relabelled_as_v12() {
    let patch = v13_patch(evidence());
    let digest = patch.causal_digest().unwrap();
    assert_ne!(digest, v12_patch().causal_digest().unwrap());
    let mut variants = vec![];
    let mut item = evidence();
    item.sources = vec![WorldEntityId(91)];
    variants.push(item);
    let mut item = evidence();
    item.direction_basis = ContactWithdrawalDirectionBasis::AcuteDamageHeadingFallback;
    variants.push(item);
    let mut item = evidence();
    item.displacement.x = -0.1;
    variants.push(item);
    let mut item = evidence();
    item.energy_cost = 0.03;
    variants.push(item);
    let mut item = evidence();
    item.blocked = true;
    item.displacement = Vec3f::ZERO;
    variants.push(item);
    for item in variants {
        assert_ne!(v13_patch(item).causal_digest().unwrap(), digest);
    }
    let mut value = serde_json::to_value(&patch).unwrap();
    for part in ["header", "pre_action", "decision", "outcome"] {
        value[part]["abi_version"] = serde_json::json!(ExperiencePatch::V12_ABI_VERSION);
    }
    assert!(invalid_patch(value));
    let mut missing = serde_json::to_value(&patch).unwrap();
    missing["outcome"]
        .as_object_mut()
        .unwrap()
        .remove("contact_withdrawal");
    assert!(invalid_patch(missing));
    for part in ["header", "pre_action", "decision", "outcome"] {
        let mut mismatched = serde_json::to_value(&patch).unwrap();
        mismatched[part]["abi_version"] = serde_json::json!(ExperiencePatch::V12_ABI_VERSION);
        assert!(invalid_patch(mismatched));
    }
}

#[test]
fn reflex_evidence_rejects_invalid_unbounded_or_ambiguous_physical_data() {
    let mut variants = vec![];
    let mut item = evidence();
    item.schema_version = 2;
    variants.push(item);
    let mut item = evidence();
    item.sources.clear();
    variants.push(item);
    let mut item = evidence();
    item.sources = vec![WorldEntityId(0)];
    variants.push(item);
    let mut item = evidence();
    item.sources.push(WorldEntityId(90));
    variants.push(item);
    let mut item = evidence();
    item.sources = (1..=257).map(WorldEntityId).collect();
    variants.push(item);
    let mut item = evidence();
    item.displacement.x = f32::NAN;
    variants.push(item);
    let mut item = evidence();
    item.displacement.z = f32::INFINITY;
    variants.push(item);
    let mut item = evidence();
    item.energy_cost = -0.01;
    variants.push(item);
    let mut item = evidence();
    item.energy_cost = f32::INFINITY;
    variants.push(item);
    let mut item = evidence();
    item.energy_cost = 1.01;
    variants.push(item);
    let mut item = evidence();
    item.blocked = true;
    variants.push(item);
    for item in variants {
        assert!(item.validate_contract().is_err());
    }
    ContactWithdrawalEvidence::new(
        ContactWithdrawalDirectionBasis::AcuteDamageHeadingFallback,
        vec![],
        Vec3f::ZERO,
        true,
        0.02,
    )
    .unwrap();
    let mut old = measured_v12_outcome(v12_joint_outcome());
    old.contact_withdrawal = Some(evidence());
    assert!(old.validate_contract().is_err());
}

#[test]
fn old_map_duplicate_unknown_and_numeric_field_behavior_is_preserved() {
    let old = measured_v12_outcome(v12_joint_outcome());
    let text = serde_json::to_string(&old).unwrap();
    let duplicate = text.replacen("{", &format!("{{\"abi_version\":{},", old.abi_version), 1);
    assert!(serde_json::from_str::<BaselinePostActionOutcome>(&duplicate).is_err());
    assert!(serde_json::from_str::<PostActionOutcome>(&duplicate).is_err());
    let mut value = serde_json::to_value(&old).unwrap();
    value["unknown_future_field"] = serde_json::json!([1, 2, 3]);
    assert!(serde_json::from_value::<BaselinePostActionOutcome>(value.clone()).is_ok());
    assert_eq!(
        serde_json::from_value::<PostActionOutcome>(value).unwrap(),
        old
    );
    // Numeric field identifiers are exercised through serde's value adapters,
    // independent of JSON (whose object keys can only be strings).
    let map = serde_json::to_value(&old).unwrap();
    let names = [
        "abi_version",
        "organism_id",
        "sequence_id",
        "outcome_tick",
        "success",
        "physical",
        "homeostatic_delta",
        "reward_valence",
        "frustration_delta",
        "pain_delta",
        "energy_delta",
        "prediction_error",
        "contradiction_observed",
        "concept_hints",
        "memory_hints",
        "teacher_feedback",
        "joint",
        "cognitive_work",
        "measured_physiology",
    ];
    let full_fields: Vec<_> = names
        .iter()
        .enumerate()
        .filter_map(|(i, name)| map.get(*name).map(|value| (i as u64, value.clone())))
        .collect();
    let old_full =
        BaselinePostActionOutcome::deserialize(serde::de::value::MapDeserializer::<
            _,
            serde_json::Error,
        >::new(full_fields.clone().into_iter()))
        .unwrap();
    let new_full = PostActionOutcome::deserialize(serde::de::value::MapDeserializer::<
        _,
        serde_json::Error,
    >::new(full_fields.into_iter()))
    .unwrap();
    assert_eq!(new_full, old);
    assert_eq!(
        serde_json::to_value(old_full).unwrap(),
        serde_json::to_value(new_full).unwrap()
    );
    let fields = [(0u64, old.abi_version)];
    let old_error = BaselinePostActionOutcome::deserialize(serde::de::value::MapDeserializer::<
        _,
        serde::de::value::Error,
    >::new(fields.into_iter()))
    .unwrap_err();
    let new_error = PostActionOutcome::deserialize(serde::de::value::MapDeserializer::<
        _,
        serde::de::value::Error,
    >::new(fields.into_iter()))
    .unwrap_err();
    assert_eq!(old_error.to_string(), new_error.to_string());
    assert!(old_error.to_string().contains("organism_id"));
}

#[test]
fn v12_explicit_null_is_legacy_and_v13_requires_actual_reflex_evidence() {
    let original = v12_patch();
    let mut value = serde_json::to_value(&original).unwrap();
    value["outcome"]["contact_withdrawal"] = serde_json::Value::Null;
    let decoded: ExperiencePatch = serde_json::from_value(value).unwrap();
    decoded.validate_contract().unwrap();
    assert_eq!(decoded, original);
    assert_eq!(
        decoded.causal_digest().unwrap(),
        original.causal_digest().unwrap()
    );
    assert_eq!(
        serde_json::to_vec(&decoded).unwrap(),
        serde_json::to_vec(&original).unwrap()
    );

    for omit in [false, true] {
        let mut value = serde_json::to_value(v13_patch(evidence())).unwrap();
        if omit {
            value["outcome"]
                .as_object_mut()
                .unwrap()
                .remove("contact_withdrawal");
        } else {
            value["outcome"]["contact_withdrawal"] = serde_json::Value::Null;
        }
        // Deserialization is intentionally not the contract-validation boundary.
        let decoded: ExperiencePatch = serde_json::from_value(value).unwrap();
        assert!(decoded.validate_contract().is_err());
        assert!(decoded.causal_digest().is_err());
    }
}

#[test]
fn old_json_sequence_lengths_keep_baseline_acceptance_boundary() {
    let old = measured_v12_outcome(v12_joint_outcome());
    let map = serde_json::to_value(&old).unwrap();
    let names = [
        "abi_version",
        "organism_id",
        "sequence_id",
        "outcome_tick",
        "success",
        "physical",
        "homeostatic_delta",
        "reward_valence",
        "frustration_delta",
        "pain_delta",
        "energy_delta",
        "prediction_error",
        "contradiction_observed",
        "concept_hints",
        "memory_hints",
        "teacher_feedback",
        "joint",
        "cognitive_work",
        "measured_physiology",
    ];
    let mut fields: Vec<_> = names.iter().map(|name| map[*name].clone()).collect();
    fields.push(serde_json::Value::Null);
    for length in 0..=20 {
        let value = serde_json::Value::Array(fields[..length].to_vec());
        let baseline = serde_json::from_value::<BaselinePostActionOutcome>(value.clone());
        let actual = serde_json::from_value::<PostActionOutcome>(value);
        assert_eq!(baseline.is_ok(), actual.is_ok(), "sequence length {length}");
        // All sixteen original fields are positional; the last three are defaultable.
        assert_eq!(baseline.is_ok(), (16..=19).contains(&length));
        if let (Ok(baseline), Ok(actual)) = (baseline, actual) {
            assert_eq!(
                serde_json::to_value(baseline).unwrap(),
                serde_json::to_value(actual).unwrap()
            );
        }
    }
}

#[test]
fn v13_rejects_joint_totals_that_omit_or_double_count_the_reflex() {
    for doubled in [false, true] {
        let mut outcome = v13_patch(evidence()).outcome().clone();
        let reflex = outcome.contact_withdrawal.as_ref().unwrap();
        let sign = if doubled { 1.0 } else { -1.0 };
        outcome.physical.displacement.x += sign * reflex.displacement.x;
        outcome.joint.as_mut().unwrap().execution = outcome.physical;
        assert!(outcome.validate_contract().is_err());
    }
    let mut outcome = v13_patch(evidence()).outcome().clone();
    outcome.physical.energy_cost = NormalizedScalar::new(0.9).unwrap();
    outcome.joint.as_mut().unwrap().execution = outcome.physical;
    assert!(outcome.validate_contract().is_err());
}

#[test]
fn v13_requires_voluntary_channel_receipts_for_physical_split() {
    let mut outcome = v13_patch(evidence()).outcome().clone();
    outcome.joint.as_mut().unwrap().channel_outcomes.clear();
    assert!(outcome.validate_contract().is_err());
}

#[test]
fn legacy_header_cannot_downgrade_nested_v13_evidence() {
    let mut value = serde_json::to_value(v13_patch(evidence())).unwrap();
    value["header"]["abi_version"] = serde_json::json!(ExperiencePatchHeader::ABI_VERSION);
    value.as_object_mut().unwrap().remove("prediction_target");
    value.as_object_mut().unwrap().remove("cognitive_work");
    assert!(
        invalid_patch(value),
        "legacy header must not bypass nested V13 evidence validation or select legacy digest"
    );
}

#[test]
fn sealed_patch_parts_must_match_header_for_all_supported_versions() {
    for patch in [v12_patch(), v13_patch(evidence())] {
        for part in ["header", "pre_action", "decision", "outcome"] {
            let mut value = serde_json::to_value(&patch).unwrap();
            value[part]["abi_version"] = serde_json::json!(ExperiencePatchHeader::ABI_VERSION);
            if part == "header" {
                value.as_object_mut().unwrap().remove("prediction_target");
                value.as_object_mut().unwrap().remove("cognitive_work");
            }
            assert!(invalid_patch(value), "mismatched {part} must be rejected");
        }
        let roundtrip: ExperiencePatch =
            serde_json::from_value(serde_json::to_value(&patch).unwrap()).unwrap();
        roundtrip.validate_contract().unwrap();
        assert_eq!(
            roundtrip.causal_digest().unwrap(),
            patch.causal_digest().unwrap()
        );
    }
}
