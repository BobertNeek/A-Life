//! Fresh, fixed CPU integration fixtures. No retained creature exposure.
use super::*;

pub(super) fn prepared(painful: bool) -> (CpuCanonicalHost, CpuFoundationTrainer) {
    let (game, trainer) = new_game_fixture(None);
    let (host, ()) = CpuCanonicalHost::new_prepared_cohort(game, &trainer, 0x5271, |world| {
        // Remove unrelated painful geometry so the fixture has exactly one cause.
        let hazards = world
            .object_snapshots()
            .into_iter()
            .filter(|o| o.kind == WorldObjectKind::Hazard)
            .map(|o| o.id)
            .collect::<Vec<_>>();
        for id in hazards {
            world.editor_remove_object(id)?;
        }
        if painful {
            let (_, body) = world.organism_entity_ids()[0];
            let p = world.entity(body).unwrap().position;
            world.editor_spawn_object(WorldEditorSpawnSpec {
                label: "reflex-fixture-contact".into(),
                kind: WorldObjectKind::Hazard,
                organism_id: None,
                position: Vec3f::new(p.x + 0.2, p.y, p.z),
                nutrition: 0.0,
                hazard_pain: 0.12,
                radius: 0.6,
                token_id: None,
            })?;
        }
        Ok::<_, ScaffoldContractError>(())
    })
    .unwrap();
    (host, trainer)
}

#[test]
fn cpu_contact_withdrawal_candidate_seals_one_actual_reflex_and_restores_exactly() {
    let (mut host, trainer) = prepared(true);
    let mut baseline = host.clone();
    let founder_before = trainer.checkpoint();
    let before = host.checkpoint(&trainer).unwrap();
    let voluntary = baseline.step(&trainer, 1.0).unwrap();
    let step = host
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    assert_eq!(step.decisions.len(), 1);
    let patch = &step.decisions[0].patch;
    patch.validate_contract().unwrap();
    let reflex = patch.outcome().contact_withdrawal.as_ref().unwrap();
    assert_eq!(patch.header().abi_version, ExperiencePatch::V13_ABI_VERSION);
    assert_eq!(
        reflex.direction_basis,
        ContactWithdrawalDirectionBasis::LocalizedContact
    );
    assert!(!reflex.blocked);
    assert_eq!(
        patch.selected_bundle(),
        voluntary.decisions[0].patch.selected_bundle()
    );
    assert_eq!(
        patch.outcome().joint.as_ref().unwrap().channel_outcomes,
        voluntary.decisions[0]
            .patch
            .outcome()
            .joint
            .as_ref()
            .unwrap()
            .channel_outcomes
    );
    let movement = voluntary.decisions[0].patch.outcome().physical.displacement;
    assert_eq!(
        patch.outcome().physical.displacement,
        Vec3f::new(
            movement.x + reflex.displacement.x,
            movement.y + reflex.displacement.y,
            movement.z + reflex.displacement.z
        )
    );
    let after = host.checkpoint(&trainer).unwrap();
    assert_eq!(after.sampling_counter, before.sampling_counter + 1);
    assert_eq!(
        after.residents[0].next_sequence,
        before.residents[0].next_sequence + 1
    );
    assert_eq!(
        after.residents[0].neural.weight_generation,
        before.residents[0].neural.weight_generation + 1
    );
    assert_eq!(
        trainer.checkpoint(),
        founder_before,
        "founder weights, moments and optimizer ages stay untouched"
    );
    let row: CpuCollectedDecision =
        serde_json::from_slice(&serde_json::to_vec(&step.decisions[0]).unwrap()).unwrap();
    assert_eq!(row.patch, *patch);
    let after: CpuCanonicalCheckpoint =
        serde_json::from_slice(&serde_json::to_vec(&after).unwrap()).unwrap();
    let mut restored = CpuCanonicalHost::from_checkpoint(after, &trainer).unwrap();
    let a = host
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    let b = restored
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    assert_eq!(
        serde_json::to_vec(&a.decisions).unwrap(),
        serde_json::to_vec(&b.decisions).unwrap()
    );
    assert_eq!(
        serde_json::to_vec(&host.checkpoint(&trainer).unwrap()).unwrap(),
        serde_json::to_vec(&restored.checkpoint(&trainer).unwrap()).unwrap()
    );
    assert_eq!(trainer.checkpoint(), founder_before);
}

#[test]
fn cpu_contact_withdrawal_candidate_without_damage_is_exact_v12_noop() {
    let (mut candidate, trainer) = prepared(false);
    let mut baseline = candidate.clone();
    let a = baseline.step(&trainer, 1.0).unwrap();
    let b = candidate
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    assert!(b
        .decisions
        .iter()
        .all(|r| r.patch.outcome().contact_withdrawal.is_none()));
    assert_eq!(
        serde_json::to_vec(&a.decisions).unwrap(),
        serde_json::to_vec(&b.decisions).unwrap()
    );
    assert_eq!(
        serde_json::to_vec(&baseline.checkpoint(&trainer).unwrap()).unwrap(),
        serde_json::to_vec(&candidate.checkpoint(&trainer).unwrap()).unwrap()
    );
}

#[test]
fn cpu_v13_completed_reflex_credit_cannot_be_applied_twice() {
    let (mut host, trainer) = prepared(true);
    let step = host
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    let patch = &step.decisions[0].patch;
    assert_eq!(patch.header().abi_version, ExperiencePatch::V13_ABI_VERSION);
    let checkpoint = host.checkpoint(&trainer).unwrap();
    let mut neural = CpuOrganismState::from_checkpoint(
        trainer.phenotype(),
        checkpoint.residents[0].neural.clone(),
    )
    .unwrap();
    let before = neural.checkpoint().unwrap();
    let record = host
        .world()
        .organism_registry()
        .get(step.decisions[0].organism_id)
        .unwrap();
    let receptors = record
        .biochemistry()
        .neural_receptor_frame(record.phenotype())
        .unwrap();
    let development = record
        .phenotype()
        .development_state_at(record.biochemistry().tick)
        .unwrap();
    assert!(neural
        .apply_credit(
            &trainer,
            patch,
            &receptors,
            &development,
            &record.phenotype().brain_genome.plasticity_parameters()
        )
        .is_err());
    assert_eq!(neural.checkpoint().unwrap(), before);
    assert_eq!(
        serde_json::to_vec(&host.checkpoint(&trainer).unwrap()).unwrap(),
        serde_json::to_vec(&checkpoint).unwrap()
    );
}

#[test]
fn cpu_body_only_reflex_does_not_invent_credit_or_complete_cognitive_sleep() {
    let (game, trainer) = new_game_fixture(Some(0.0));
    let (mut host, ()) = CpuCanonicalHost::new_prepared_cohort(game, &trainer, 0x5272, |world| {
        let hazards = world
            .object_snapshots()
            .into_iter()
            .filter(|o| o.kind == WorldObjectKind::Hazard)
            .map(|o| o.id)
            .collect::<Vec<_>>();
        for id in hazards {
            world.editor_remove_object(id)?;
        }
        let (_, body) = world.organism_entity_ids()[0];
        let p = world.entity(body).unwrap().position;
        world.editor_spawn_object(WorldEditorSpawnSpec {
            label: "sleep-reflex-fixture".into(),
            kind: WorldObjectKind::Hazard,
            organism_id: None,
            position: Vec3f::new(p.x + 0.2, p.y, p.z),
            nutrition: 0.0,
            hazard_pain: 0.12,
            radius: 0.6,
            token_id: None,
        })?;
        Ok::<_, ScaffoldContractError>(())
    })
    .unwrap();
    let first = host.step(&trainer, 1.0).unwrap();
    assert!(first.decisions.is_empty());
    let second = host.step(&trainer, 1.0).unwrap();
    assert!(second.decisions.is_empty());
    let before = host.checkpoint(&trainer).unwrap();
    assert_eq!(
        before.residents[0].sleep.state().phase,
        SleepPhase::ForcedRecoverySleep
    );
    let organism = host.world().organism_entity_ids()[0].0;
    assert!(
        host.world()
            .organism_registry()
            .get(organism)
            .unwrap()
            .biochemistry()
            .body
            .sleeping
    );
    let founder = trainer.checkpoint();
    let mut restored = CpuCanonicalHost::from_checkpoint(before.clone(), &trainer).unwrap();
    let step = host
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    let replay = restored
        .step_with_contact_withdrawal_candidate(&trainer, 1.0)
        .unwrap();
    assert!(step.decisions.is_empty());
    assert_eq!(step.sleep_consolidations, 0);
    assert_eq!(step.body_only_contact_responses.len(), 1);
    let response = &step.body_only_contact_responses[0];
    assert!(response.sleep_recovery_interrupted);
    assert!(response.withdrawal.as_ref().is_some_and(|r| !r.blocked));
    let after = host.checkpoint(&trainer).unwrap();
    assert_eq!(
        after.residents[0].next_sequence,
        before.residents[0].next_sequence
    );
    assert_eq!(after.residents[0].neural, before.residents[0].neural);
    assert_eq!(
        after.residents[0].sleep.state().cycles_completed,
        before.residents[0].sleep.state().cycles_completed
    );
    assert_ne!(after.residents[0].sleep.state().phase, SleepPhase::Awake);
    assert!(
        !host
            .world()
            .organism_registry()
            .get(response.organism_id)
            .unwrap()
            .biochemistry()
            .body
            .sleeping
    );
    assert_eq!(
        step.body_only_contact_responses,
        replay.body_only_contact_responses
    );
    assert_eq!(
        serde_json::to_vec(&after).unwrap(),
        serde_json::to_vec(&restored.checkpoint(&trainer).unwrap()).unwrap()
    );
    assert_eq!(trainer.checkpoint(), founder);
}
