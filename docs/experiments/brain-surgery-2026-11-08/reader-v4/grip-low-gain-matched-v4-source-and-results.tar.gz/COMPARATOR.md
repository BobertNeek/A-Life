# Exact scope of paired initial comparisons

The only treatment is16 inherited MemoryContext lane53 weights: eight Contact +0.0625 and eight Other -0.0625 against positive bitwise zero. All other weight bits, synapse coordinates/routing/receptors/alpha/kind, projections and neuronal dynamics match. Legitimate separate candidate construction binds both identities. The gene guard runs before construction/preparation and again at the pair barrier.

First compare the existing narrow policy-weight world signature at birth, BEFORE host admission. That existing projection excludes only subject asset weights/digests and rederives the resulting genetics-development digest. Host admission already seals private authority before the preparation callback, so no post-preparation signature is falsely described as pre-seal.

After600 ticks per arm, compare the complete serialized portable world, removing only these five fields from the sole subject record:
- genome.n2048_foundation_candidate.weights
- genome.n2048_foundation_candidate.digest
- genome.n2048_foundation_candidate.manifest.weight_asset.digest
- state_graph.genetics_development.content_digest
- state_graph.brain.content_digest

The first three are the declared parameter treatment and its references; the fourth hashes that genome; the fifth hashes the complete private resident including the legitimate neural phenotype hash. All other record, world, scene, physiology, creature-summary, registry, RNG and metadata fields remain compared. There is no arbitrary world-state exclusion.

Before projecting, each complete disposable prepared checkpoint is validated through the unmodified native exact self-restore contract using its OWN genotype, with full round-trip byte equality. This validates the actual private seal and inherited asset, not merely its shape. The detached verifier is dropped; neither live host is replaced or advanced. No cross-genotype restore is attempted and no restore validation is changed.

Full resident checkpoints are compared as serialized bytes after deleting exactly neural.phenotype_hash from each resident. Each value must equal that arm's validated phenotype. Memory, staged memory, replay, all dynamic neural state, eligibility, topology, language state, predictor, sleep, activity, hysteresis and sequence remain compared. The detached projection-unit test changes eligibility and next_sequence and requires inequality, while genotype-only hash differences compare equal. It is a serialized-state unit fixture, not an extra life.

Founder optimizer checkpoints are compared after excluding exactly phenotype_hash, source_foundation_digest and weights. Phenotype and weight bindings are checked, the exact16 guard checks all weight bits, and native self-restore validates the admitted asset identity. Moments, ages, configuration, mask, step and schema remain byte-identical. Full checkpoint hashes remain distinct and are recorded separately. No projected data is restored. Any unexplained mismatch stops the study without changing exclusions after exposure.

At the top-level checkpoint, phenotype_hash and founder_weight_digest are deliberately distinct and validated by each arm's own exact restore. Schema, sampling seed/counter and tracked-object registry are checked directly; world and residents receive the complete comparisons above. The manifest lists these two top-level binding differences in addition to the nine projected nested fields.
