#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/source"
export ROOT=/workspace/scratch/ee5e08a3ca9b/recovered-toolchain-rust-1.99.1-20261107
export CARGO_HOME=$ROOT/cargo RUSTUP_HOME=$ROOT/rustup PATH=$ROOT/rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:$ROOT/cargo/bin:$PATH
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUST_MIN_STACK=33554432
export CARGO_TARGET_DIR=/workspace/shared/grip-integration-qualification-20261108/grip-candidate-qualification/target
python - <<'PY'
from pathlib import Path
import hashlib,json,time
paths=sorted(p for p in Path('.').rglob('*') if p.is_file() and '.git' not in p.parts and 'target' not in p.parts)
before=[(str(p),hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
for p in paths:p.touch()
assert before==[(str(p),hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
Path('../freshness.json').write_text(json.dumps({'files_touched':len(paths),'content_unchanged':True,'unix':time.time()},indent=2)+'\n')
PY
cargo test --offline -p alife_world --lib rest_motion_ -- --test-threads=1 > ../fresh-rest.log 2>&1
cargo test --offline -p alife_training --features cpu-backend --example probe_grip_matched -- --test-threads=1 > ../fresh-matched-tests.log 2>&1
cargo test --offline -p alife_training --features cpu-backend --example probe_grip_reader reconstructed_v12_identity_and_all_coordinate_changes_are_accounted_for -- --test-threads=1 > ../fresh-inheritance.log 2>&1
cargo clippy --offline -p alife_training --features cpu-backend --example probe_grip_matched -- -D warnings > ../fresh-clippy.log 2>&1
cargo build --offline -p alife_training --features cpu-backend --example probe_grip_matched --message-format=json-render-diagnostics > ../native-build-artifacts.jsonl 2> ../fresh-build.log
mkdir -p ../bin
cp "$CARGO_TARGET_DIR/debug/examples/probe_grip_matched" ../bin/probe_grip_matched
sha256sum ../bin/probe_grip_matched
