//! Fresh bounded matched actual-policy reader comparison.
//! Two gains, two fresh sampling identities, one frozen merged world.
#![allow(dead_code)]
use alife_core::*;
use alife_runtime::canonical_preparation::foundation_construction_development;
use alife_training::{cpu::*, AdamWConfig, StageTrainableMask, TrainingSequence};
use alife_world::*;
use serde::Serialize;
use sha2::{Digest, Sha256};
#[path = "support/care_candidate.rs"]
mod care_candidate;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
const PREPARATION_TICKS: u16 = 600;
const PRIMARY_TICKS: u16 = 256;
const TEMPERATURE: f32 = 1.0;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Scene {
    seed: u64,
    harmful_slot: usize,
    appearance: [usize; 2],
    spawn_order: [usize; 2],
}
const SCENES: [Scene; 2] = [
    Scene {
        seed: 2026112501,
        harmful_slot: 0,
        appearance: [0, 1],
        spawn_order: [0, 1],
    },
    Scene {
        seed: 2026112502,
        harmful_slot: 1,
        appearance: [0, 1],
        spawn_order: [0, 1],
    },
];
fn bytes<T: Serialize>(x: &T) -> Result<Vec<u8>> {
    Ok(serde_json::to_vec(x)?)
}
fn digest(b: &[u8]) -> String {
    format!("{:x}", Sha256::digest(b))
}
#[derive(Debug)]
struct Gate(&'static str);
impl std::fmt::Display for Gate {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}
impl std::error::Error for Gate {}
fn require(ok: bool, code: &'static str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(Box::new(Gate(code)))
    }
}
struct Life {
    host: CpuCanonicalHost,
    trainer: CpuFoundationTrainer,
    own: OrganismId,
    targets: [WorldEntityId; 2],
    initial_body_biology: Vec<u8>,
    initial_scene: Vec<u8>,
    sampling_seed: u32,
    gain: f32,
    birth_world: Vec<u8>,
}
fn body_biology(world: &HeadlessWorld, own: OrganismId) -> Result<Vec<u8>> {
    let r = world
        .organism_registry()
        .get(own)
        .ok_or("missing_organism")?;
    let p = r.phenotype();
    bytes(&(
        r.organism_id(),
        r.birth_tick(),
        &p.body,
        &p.chemistry,
        &p.development,
        &p.reproduction,
        &p.predisposition,
        r.embodiment(),
        r.biochemistry(),
        r.lifecycle(),
    ))
}
fn preparation_guard(alive: bool, health: f32, injury: f32) -> bool {
    alive && health.is_finite() && injury.is_finite() && health >= 0.70 && injury <= 0.25
}
fn preparation_world_guard(world: &HeadlessWorld, own: OrganismId) -> Result<()> {
    let r = world
        .organism_registry()
        .get(own)
        .ok_or("preparation organism")?;
    require(
        preparation_guard(
            r.lifecycle().is_alive(),
            r.biochemistry().body.health,
            r.biochemistry().body.injury,
        ),
        "preparation safeguard",
    )
}
fn make_life<const PREPARE: u16>(
    scene: Scene,
    frozen_asset: &FoundationWeightAsset,
) -> Result<Life> {
    make_life_observed::<PREPARE>(scene, frozen_asset, |_| Ok(()))
}
fn make_life_observed<const PREPARE: u16>(
    scene: Scene,
    frozen_asset: &FoundationWeightAsset,
    mut preparation_progress: impl FnMut(bool) -> Result<()>,
) -> Result<Life> {
    let asset = frozen_asset.clone();
    let mut config = CanonicalNewGameConfig::phase3(scene.seed, 1)?;
    config.brain_class = BrainScaleTier::Standard2048;
    config.sensor_profile = SensorProfile::GroundedGripObjectSlotsV1;
    let mut game = create_canonical_new_game_with_n2048_grip_reader_candidate(&config, &asset)?;
    let original = game
        .world
        .organism_registry()
        .iter()
        .next()
        .ok_or("missing_founder")?
        .clone();
    let genome = original.phenotype().brain_genome.clone();
    let development = foundation_construction_development(
        &genome,
        &BrainCapacityClass::n2048(),
        &original.phenotype().development_state_at(Tick::ZERO)?,
    )?;
    let (p, _) = PhenotypeCompiler::compile_n2048_grip_reader_foundation_candidate(
        genome.clone(),
        development.clone(),
        asset.clone(),
    )?;
    let trainer = CpuFoundationTrainer::new(
        p.clone(),
        asset,
        StageTrainableMask::recurrent_only(&p)?,
        AdamWConfig::default(),
    )?;
    let gain = p
        .synapses()
        .iter()
        .zip(trainer.weights())
        .find_map(|(s, w)| {
            if let CompiledSynapseKind::Decoder(c) = s.kind() {
                if c.head() == DecoderHeadKind::MemoryContext
                    && c.input_lane() == 53
                    && c.family() == CandidateActionFamily::Contact
                {
                    return Some(*w);
                }
            }
            None
        })
        .ok_or("reader_gain")?;
    require(gain == 0. || gain == 0.0625, "actual_gain")?;
    let own = original.organism_id();
    let mut world = HeadlessScenarioBuilder::new(scene.seed)
        .agent("learner", own, Vec3f::ZERO)
        .terrain_zone(
            1,
            "assay",
            TerrainZoneKind::Meadow,
            Vec3f::ZERO,
            12.0,
            0.0,
            0.0,
        )
        .build()?;
    let common = GroundedPhysicalProperties {
        velocity: Vec3f::ZERO,
        color: [0.9, 0.2, 0.2],
        material: [0.35, 0.15, 0.65],
        shape: [0.2, 0.8, 0.2],
        chemical: [0.85, 0.1, 0.2],
        surface_temperature: 0.1,
        terrain: [0.5, 0.25],
    };
    let mut slots = [None, None];
    for slot in scene.spawn_order {
        let id = world.editor_spawn_object(WorldEditorSpawnSpec {
            label: format!("resource_{slot}"),
            kind: WorldObjectKind::Food,
            organism_id: None,
            position: Vec3f::new(0.35, 0.0, if slot == 0 { -0.35 } else { 0.35 }),
            nutrition: 0.05,
            hazard_pain: if slot == scene.harmful_slot {
                0.35
            } else {
                0.0
            },
            radius: 0.5,
            token_id: None,
        })?;
        let mut physical = common;
        if scene.appearance[slot] == 1 {
            physical.color = [0.2, 0.2, 0.9];
        }
        world.set_grounded_physical_properties(id, physical)?;
        world.track_resource_lifecycle(id, EcologyZoneId(1), 16, 512)?;
        slots[slot] = Some(id);
    }
    let mut chemistry = *original.biochemistry();
    chemistry.body.set_energy(0.4)?;
    world.register_organism_record(WorldOrganismRecord::new(
        own,
        world.entity_id("learner").ok_or("missing_body")?,
        original.genome().clone(),
        original.phenotype().clone(),
        chemistry,
        original.birth_tick(),
    )?)?;
    let targets = [
        slots[scene.harmful_slot].ok_or("missing_h")?,
        slots[1 - scene.harmful_slot].ok_or("missing_s")?,
    ];
    game.world = world;
    let sampling_seed = (scene.seed ^ (scene.seed >> 32)) as u32;
    let birth_world = bytes(&game.world.policy_weight_comparison_signature_v1(own)?)?;
    let (host, _) =
        CpuCanonicalHost::new_prepared_cohort(game, &trainer, sampling_seed, |world| {
            preparation_world_guard(world, own)?;
            for _ in 0..PREPARE {
                preparation_progress(false)?;
                world.try_advance_tick()?;
                preparation_progress(true)?;
                preparation_world_guard(world, own)?;
            }
            Ok::<_, Box<dyn std::error::Error>>(())
        })?;
    let initial_body_biology = body_biology(host.world(), own)?;
    let initial_scene = bytes(
        &targets
            .iter()
            .map(|&id| {
                WorldObjectSaveState::from(host.world().entity(id).expect("new resource").clone())
            })
            .collect::<Vec<_>>(),
    )?;
    require(
        host.checkpoint(&trainer)?
            .residents
            .iter()
            .all(|r| r.memory.records.is_empty()),
        "nonempty_initial_memory",
    )?;
    Ok(Life {
        host,
        trainer,
        own,
        targets,
        initial_body_biology,
        initial_scene,
        sampling_seed,
        gain,
        birth_world,
    })
}

fn candidate_gain(
    seed: u64,
    per_gene_gain: f32,
) -> Result<(BrainPhenotype, FoundationWeightAsset)> {
    let mut config = CanonicalNewGameConfig::phase3(seed, 1)?;
    config.brain_class = BrainScaleTier::Standard2048;
    let builtin = FoundationWeightAsset::builtin_n2048_v1(config.sensor_profile)?;
    let game = create_canonical_new_game_with_n2048_candidate(&config, &builtin)?;
    let record = game
        .world
        .organism_registry()
        .iter()
        .next()
        .ok_or("no fresh founder")?;
    let genome = record.phenotype().brain_genome.clone();
    let development = foundation_construction_development(
        &genome,
        &BrainCapacityClass::n2048(),
        &record.phenotype().development_state_at(Tick::ZERO)?,
    )?;
    let (p, _) = PhenotypeCompiler::compile_n2048_grip_reader_graph(
        genome.clone(),
        development.clone(),
        SensorProfile::GroundedGripObjectSlotsV1,
    )?;
    let (mut weights, _) = care_candidate::whole_care(&p)?;
    let mut counts = std::collections::BTreeMap::new();
    for synapse in p.synapses() {
        if let CompiledSynapseKind::Decoder(c) = synapse.kind() {
            if c.head() == DecoderHeadKind::MemoryContext {
                *counts
                    .entry((c.family().raw(), c.input_lane()))
                    .or_insert(0usize) += 1;
            }
        }
    }
    for (synapse, weight) in p.synapses().iter().zip(&mut weights) {
        let CompiledSynapseKind::Decoder(c) = synapse.kind() else {
            continue;
        };
        if c.head() == DecoderHeadKind::ActionCandidate {
            *weight *= 0.25;
        }
        if c.head() != DecoderHeadKind::MemoryContext {
            continue;
        }
        // Preserve the v12 inherited target-reader and Ingest-family coefficients.
        // Its source file and historical assets are not edited or loaded here.
        let total = match (c.family(), c.input_lane()) {
            (CandidateActionFamily::Ingest, 25) => -16.,
            (CandidateActionFamily::Ingest, 26) => -64.,
            (CandidateActionFamily::Ingest, 32) => 32.,
            (CandidateActionFamily::Approach | CandidateActionFamily::Contact, 25) => -8.,
            (CandidateActionFamily::Approach | CandidateActionFamily::Contact, 26) => -32.,
            (CandidateActionFamily::Avoid, 25) => 16.,
            (CandidateActionFamily::Avoid, 26) => 128.,
            (CandidateActionFamily::Contact, 53) => 8. * per_gene_gain,
            (CandidateActionFamily::Other, 53) if per_gene_gain != 0. => -8. * per_gene_gain,
            _ => 0.,
        };
        *weight = total / counts[&(c.family().raw(), c.input_lane())] as f32;
    }
    let asset = FoundationWeightAsset::from_trained_weights(
        &p,
        weights,
        TrainingStageManifest::bootstrap(),
    )?;
    let (bound, _) = PhenotypeCompiler::compile_n2048_grip_reader_foundation_candidate(
        genome,
        development,
        asset.clone(),
    )?;
    Ok((bound, asset))
}

use serde_json::{json, Value};
use std::io::Write;
struct Sink {
    file: std::fs::File,
    written: usize,
    deadline: std::time::Instant,
    stage: &'static str,
    arm: &'static str,
    root: std::path::PathBuf,
}
impl Sink {
    fn emit(&mut self, mut value: Value) -> Result<()> {
        value
            .as_object_mut()
            .ok_or("event_object")?
            .insert("arm".into(), json!(self.arm));
        require(self.deadline.elapsed().as_secs() < 1800, "deadline")?;
        let mut raw = serde_json::to_vec(&value)?;
        raw.push(b'\n');
        require(
            raw.len() <= 512 * 1024 && self.written + raw.len() <= 64 * 1024 * 1024,
            "output_bound",
        )?;
        self.file.write_all(&raw)?;
        self.file.sync_data()?;
        self.written += raw.len();
        Ok(())
    }
}
fn role(life: &Life, target: Option<WorldEntityId>) -> &'static str {
    match target {
        Some(t) if t == life.targets[0] => "h",
        Some(t) if t == life.targets[1] => "s",
        None => "none",
        _ => "other",
    }
}
fn finite(x: f32) -> Result<f32> {
    require(x.is_finite(), "nonfinite")?;
    Ok(x)
}
fn probability(logits: &[f32], index: usize, mask: u32) -> f32 {
    if mask & (1 << index) == 0 {
        return 0.;
    }
    let max = logits
        .iter()
        .enumerate()
        .filter(|(i, _)| mask & (1 << i) != 0)
        .map(|(_, v)| *v)
        .fold(f32::NEG_INFINITY, f32::max);
    let total: f32 = logits
        .iter()
        .enumerate()
        .filter(|(i, _)| mask & (1 << i) != 0)
        .map(|(_, v)| (*v - max).exp())
        .sum();
    (logits[index] - max).exp() / total
}
struct Components {
    memory: f32,
    cognitive: f32,
    action: f32,
    op: f32,
    target: f32,
    family: f32,
    inherited_coeff: [f32; 3],
    effective_coeff: [f32; 3],
    family_bias: f32,
    total: f32,
}
fn components(
    p: &BrainPhenotype,
    weights: &[f32],
    tick: &alife_training::TrainingReplayTick,
    activations: &[f32],
    index: usize,
) -> Result<Components> {
    let input = &tick.candidates[index];
    let family_bias = p
        .candidate_decoder()
        .families()
        .iter()
        .find(|f| f.family() == input.family)
        .ok_or("family")?
        .bias();
    let mut total = family_bias + input.innate_bias;
    let mut memory = 0.;
    let mut cognitive = 0.;
    let mut action = 0.;
    let mut op = 0.;
    let mut target = 0.;
    let mut family = 0.;
    let mut inherited_coeff = [0.; 3];
    let mut effective_coeff = [0.; 3];
    for (j, synapse) in p.synapses().iter().enumerate() {
        let CompiledSynapseKind::Decoder(c) = synapse.kind() else {
            continue;
        };
        if c.family() != input.family {
            continue;
        }
        let effective = weights[j] + tick.effective_weight_offsets[j];
        let v = input.decoder_inputs[c.input_lane() as usize] * effective;
        match c.head() {
            DecoderHeadKind::MemoryContext => {
                memory += v;
                if c.input_lane() == 53 {
                    op += v;
                }
                if [25, 26].contains(&c.input_lane()) {
                    target += v;
                }
                if c.input_lane() == 32 {
                    family += v;
                }
                for (k, lane) in [25, 26, 53].into_iter().enumerate() {
                    if c.input_lane() == lane {
                        inherited_coeff[k] += weights[j];
                        effective_coeff[k] += effective;
                    }
                }
            }
            DecoderHeadKind::CognitiveContext => cognitive += v,
            DecoderHeadKind::ActionCandidate => {
                let contribution = activations[synapse.source() as usize] * v;
                action += contribution;
                total += contribution;
            }
            _ => {}
        }
    }
    total += memory.clamp(-12., 12.) + cognitive.clamp(-12., 12.);
    Ok(Components {
        memory,
        cognitive,
        action,
        op,
        target,
        family,
        inherited_coeff,
        effective_coeff,
        family_bias,
        total,
    })
}
fn project(life: &Life, row: &CpuCollectedDecision, audit: &CpuSwapAudit) -> Result<Value> {
    let host_before = bytes(&life.host.checkpoint(&life.trainer)?)?;
    let trainer_before = bytes(&life.trainer.checkpoint())?;
    let frame = row.patch.pre_action().perception();
    require(
        frame.frame_digest() == audit.frame_digest
            && audit.candidates.len() == frame.candidates().len(),
        "audit_binding",
    )?;
    require(frame.candidates().len() <= 32, "candidate_bound")?;
    let mut variant_rows = Vec::new();
    {
        let (gain, trainer) = (life.gain, &life.trainer);
        let checkpoint_before = bytes(&trainer.checkpoint())?;
        require(
            bytes(&life.host.checkpoint(&life.trainer)?)? == host_before
                && bytes(&life.trainer.checkpoint())? == trainer_before,
            "before_shadow_preservation",
        )?;
        let p = trainer.phenotype();
        let q = TrainingSequence {
            phenotype_hash: p.phenotype_hash(),
            initial: row.initial.clone(),
            ticks: vec![row.replay_tick.clone()],
            burn_in_ticks: 0,
            memory_candidate_gain: 12.,
        };
        let output = trainer.evaluate_replay(&q)?;
        let logits = &output.candidate_logits[0];
        let choice = sample_cpu_joint_action(
            p,
            frame,
            logits,
            life.sampling_seed,
            row.sampling_counter.ok_or("counter")?,
            TEMPERATURE,
        )?;
        require(
            bytes(&choice)? == bytes(&row.action)?,
            "actual_replay_mismatch",
        )?;
        let mut candidates = Vec::new();
        for (i, (candidate, input)) in frame
            .candidates()
            .iter()
            .zip(&row.replay_tick.candidates)
            .enumerate()
        {
            let evidence = &audit.candidates[i];
            require(
                evidence.candidate_index as usize == i
                    && evidence.world_target == candidate.target.entity,
                "candidate_binding",
            )?;
            let Components {
                memory,
                cognitive,
                action,
                op,
                target,
                family,
                inherited_coeff,
                effective_coeff,
                family_bias,
                total,
            } = components(
                p,
                trainer.weights(),
                &row.replay_tick,
                &output.final_activations[0],
                i,
            )?;
            require(
                total.to_bits() == logits[i].to_bits(),
                "score_decomposition",
            )?;
            let motor_probability: Vec<f32> = choice
                .motor_masks
                .iter()
                .map(|mask| probability(logits, i, *mask))
                .collect();
            for v in logits
                .iter()
                .chain(inherited_coeff.iter())
                .chain(effective_coeff.iter())
                .chain(motor_probability.iter())
                .chain([memory, cognitive, action, op, target, family, total].iter())
            {
                finite(*v)?;
            }
            let source = evidence.best_family_source.as_ref();
            candidates.push(json!({"index":i,"target":role(life,candidate.target.entity),"action":candidate.action_id.0,"family":candidate.family.raw(),"input53":finite(input.decoder_inputs[53])?,"input25":finite(input.decoder_inputs[25])?,"input26":finite(input.decoder_inputs[26])?,"input32":finite(input.decoder_inputs[32])?,"memory_raw":memory,"memory_clamped":memory.clamp(-12.,12.),"operation_component":op,"target25_26_component":target,"family32_component":family,"action_component":action,"cognitive_raw":cognitive,"cognitive_clamped":cognitive.clamp(-12.,12.),"innate":input.innate_bias,"family_bias":family_bias,"logit":logits[i],"inherited_coeff25_26_53":inherited_coeff,"effective_coeff25_26_53":effective_coeff,"representative_probability":finite(probability(logits,i,choice.representative_mask))?,"motor_conditional_probabilities":motor_probability,"selected_motor_slots":choice.motor_candidates.map(|c|c==Some(i as u16)),"selected_representative":choice.representative==i as u16,"family_confidence":evidence.family_confidence,"target_confidence":evidence.target_confidence,"family_sources":evidence.family_source_count,"target_sources":evidence.target_source_count,"source_sequence":source.map(|s|s.sequence),"source_ingest_family":source.is_some_and(|s|s.family==u16::from(CandidateActionFamily::Ingest.raw())),"source_exact_consumed":source.is_some_and(|s|s.contact==Some(PhysicalContactKind::Consumed)),"source_same_tracked_target":source.is_some_and(|s|Some(TrackedObjectId(s.tracked_target))==evidence.tracked_target),"held":evidence.physical.owner==SwapOwner::ThisOrganism,"held_count":evidence.physical.self_held_object_count,"contact_reachable":evidence.physical.physical_contact_reachable,"grasp_reachable":evidence.physical.grasp_reachable,"active":evidence.physical.active,"grip_mode":grip_mode(evidence.physical.mode)}));
        }
        variant_rows.push(json!({"gain":gain,"representative":choice.representative,"motor_candidates":choice.motor_candidates,"joint_log_probability":finite(choice.old_joint_log_probability)?,"candidates":candidates}));
        require(
            bytes(&trainer.checkpoint())? == checkpoint_before
                && bytes(&life.host.checkpoint(&life.trainer)?)? == host_before
                && bytes(&life.trainer.checkpoint())? == trainer_before,
            "after_shadow_preservation",
        )?;
    }
    let physical:Vec<Value>=audit.motor.channel_receipts.iter().map(|c|json!({"action":c.command.primitive.0,"target":role(life,c.command.target.and_then(|t|t.entity)),"succeeded":c.succeeded,"contact_consumed":c.physical.contact==PhysicalContactKind::Consumed,"displacement":[c.physical.displacement.x,c.physical.displacement.y,c.physical.displacement.z],"transfers":c.grip_transfers.iter().map(|t|json!({"target":role(life,Some(t.object)),"kind":match t.kind {GripTransferKind::Acquired=>"acquired",GripTransferKind::Released=>"released",GripTransferKind::Placed=>"placed",GripTransferKind::Consumed=>"consumed"}})).collect::<Vec<_>>()})).collect();
    require(
        bytes(&life.host.checkpoint(&life.trainer)?)? == host_before
            && bytes(&life.trainer.checkpoint())? == trainer_before,
        "projection_preservation",
    )?;
    Ok(
        json!({"sequence":audit.sequence.raw(),"sampling_counter":row.sampling_counter,"baseline_replay_matches_actual":true,"preservation":true,"variants":variant_rows,"actual_physical":physical}),
    )
}
fn prepare(scene: Scene, asset: &FoundationWeightAsset, sink: &mut Sink) -> Result<Life> {
    sink.stage = "construction";
    let mut attempt = std::fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(
            sink.root
                .join(format!("life-{}-{}-ATTEMPT.json", scene.seed, sink.arm)),
        )?;
    attempt.write_all(&bytes(
        &json!({"seed":scene.seed,"arm":sink.arm,"attempted":true,"retry_allowed":false}),
    )?)?;
    attempt.sync_all()?;
    sink.emit(json!({"kind":"life_attempt","seed":scene.seed}))?;
    let mut prep_attempts = 0u16;
    let mut prep_returned = 0u16;
    let life = make_life_observed::<PREPARATION_TICKS>(scene, asset, |returned| {
        if returned {
            prep_returned += 1;
        } else {
            prep_attempts += 1;
        }
        sink.stage = "preparation";
        sink.emit(json!({"kind":"preparation_progress","seed":scene.seed,"attempted":prep_attempts,"returned":prep_returned}))
    })?;
    require(
        prep_attempts == 600 && prep_returned == 600,
        "preparation_count",
    )?;
    Ok(life)
}
fn grip_mode(mode: SwapGripMode) -> &'static str {
    match mode {
        SwapGripMode::None => "none",
        SwapGripMode::Activity => "activity",
        SwapGripMode::Deliberate => "deliberate",
    }
}
fn situation(life: &Life) -> Result<Value> {
    let bio = life
        .host
        .world()
        .organism_registry()
        .get(life.own)
        .ok_or("organism")?
        .biochemistry();
    let targets: Vec<Value>=life.targets.iter().map(|id| {
        let f=life.host.world().research_swap_physical_facts(life.own,ActionId(210),Some(*id));
        json!({"target":role(life,Some(*id)),"active":f.active,"held":f.owner==SwapOwner::ThisOrganism,"mode":grip_mode(f.mode),"contact_reachable":f.physical_contact_reachable,"grasp_reachable":f.grasp_reachable})
    }).collect();
    Ok(
        json!({"hunger":finite(bio.homeostasis.drives.hunger)?,"fatigue":finite(bio.homeostasis.drives.fatigue)?,"targets":targets}),
    )
}
fn run(scene: Scene, life: &mut Life, sink: &mut Sink) -> Result<Value> {
    let prep_returned = PREPARATION_TICKS;
    let mut meals = [0u16; 2];
    let mut steps = 0u16;
    let mut decisions = 0u16;
    let mut stop = "tick_budget";
    let founder_before = bytes(&life.trainer.checkpoint())?;
    sink.emit(json!({"kind":"life_prepared","seed":scene.seed,"world_tick":life.host.world().tick().raw(),"sampling_seed":life.sampling_seed,"initial_body_sha256":digest(&life.initial_body_biology),"initial_scene_sha256":digest(&life.initial_scene)}))?;
    for index in 0..PRIMARY_TICKS {
        sink.stage = "host_step";
        sink.emit(json!({"kind":"step_attempt","seed":scene.seed,"primary_step":index+1,"returned_steps":steps}))?;
        let before_situation = situation(life)?;
        let step = life.host.step_with_swap_audit(&life.trainer, TEMPERATURE)?;
        steps += 1;
        sink.emit(json!({"kind":"step_returned","seed":scene.seed,"primary_step":steps}))?;
        require(
            step.decisions.len() <= 1 && step.decisions.len() == step.swap_audits.len(),
            "population",
        )?;
        let mut projections = Vec::new();
        for (row, audit) in step.decisions.iter().zip(&step.swap_audits) {
            decisions += 1;
            sink.stage = "passive_replay";
            projections.push(project(life, row, audit)?);
            for (i, target) in life.targets.iter().enumerate() {
                if audit.motor.channel_receipts.iter().any(|c| {
                    c.physical.contact == PhysicalContactKind::Consumed
                        && c.physical.target_entity == Some(*target)
                }) {
                    meals[i] += 1;
                }
            }
        }
        require(
            bytes(&life.trainer.checkpoint())? == founder_before,
            "founder_mutation",
        )?;
        let record = life
            .host
            .world()
            .organism_registry()
            .get(life.own)
            .ok_or("organism")?;
        let body = record.biochemistry().body;
        let alive = record.lifecycle().is_alive();
        finite(body.health)?;
        finite(body.injury)?;
        finite(body.energy)?;
        sink.stage = "public_projection";
        sink.emit(json!({"kind":"step","seed":scene.seed,"primary_step":steps,"world_tick":life.host.world().tick().raw(),"health":body.health,"injury":body.injury,"energy":body.energy,"alive":alive,"sleeping":step.sleeping_organisms,"consolidations":step.sleep_consolidations,"meals_h_s":meals,"before_situation":before_situation,"after_situation":situation(life)?,"decisions":projections}))?;
        if !alive {
            stop = "death";
            break;
        }
        if body.health < 0.70 {
            stop = "health";
            break;
        }
        if body.injury > 0.25 {
            stop = "injury";
            break;
        }
        if meals[0] >= 3 {
            stop = "third_harmful_meal";
            break;
        }
    }
    let summary = json!({"kind":"life_complete","seed":scene.seed,"preparation_ticks":prep_returned,"primary_steps":steps,"decisions":decisions,"meals_h_s":meals,"stop":stop});
    sink.emit(summary.clone())?;
    Ok(summary)
}
// These are comparison projections only, never restore inputs.
fn genetic_pair(pa: &BrainPhenotype, pb: &BrainPhenotype, wa: &[f32], wb: &[f32]) -> Result<()> {
    require(
        wa.len() == pa.synapses().len() && wb.len() == pb.synapses().len(),
        "pair_weight_length",
    )?;
    require(
        pa.projections() == pb.projections()
            && pa.neuron_dynamics() == pb.neuron_dynamics()
            && pa.synapses().len() == pb.synapses().len(),
        "pair_graph",
    )?;
    let mut diff = 0;
    for ((sa, sb), (wa, wb)) in pa
        .synapses()
        .iter()
        .zip(pb.synapses())
        .zip(wa.iter().zip(wb))
    {
        require(
            sa.kind() == sb.kind()
                && sa.source() == sb.source()
                && sa.target() == sb.target()
                && sa.alpha() == sb.alpha()
                && sa.route_index() == sb.route_index()
                && sa.receptor_index() == sb.receptor_index(),
            "pair_coordinates",
        )?;
        if wa.to_bits() != wb.to_bits() {
            diff += 1;
            let CompiledSynapseKind::Decoder(c) = sa.kind() else {
                return Err(Box::new(Gate("pair_non_decoder")));
            };
            require(
                c.head() == DecoderHeadKind::MemoryContext
                    && c.input_lane() == 53
                    && wa.to_bits() == 0f32.to_bits()
                    && match c.family() {
                        CandidateActionFamily::Contact => *wb == 0.0625,
                        CandidateActionFamily::Other => *wb == -0.0625,
                        _ => false,
                    },
                "pair_gene_scope",
            )?;
        }
    }
    require(diff == 16, "pair_gene_count")?;
    Ok(())
}

fn resident_projection(mut v: Value, expected_hash: Value) -> Result<Value> {
    for r in v.as_array_mut().ok_or("resident_array")? {
        let n = r
            .get_mut("neural")
            .and_then(Value::as_object_mut)
            .ok_or("neural_object")?;
        require(
            n.remove("phenotype_hash") == Some(expected_hash.clone()),
            "resident_binding",
        )?;
    }
    Ok(v)
}

fn paired_initial(a: &Life, b: &Life) -> Result<()> {
    require(a.gain == 0. && b.gain == 0.0625, "pair_gains")?;
    require(
        a.birth_world == b.birth_world && !a.birth_world.is_empty(),
        "pair_world",
    )?;
    require(
        a.initial_body_biology == b.initial_body_biology && a.initial_scene == b.initial_scene,
        "pair_body_scene",
    )?;
    let pa = a.trainer.phenotype();
    let pb = b.trainer.phenotype();
    genetic_pair(pa, pb, a.trainer.weights(), b.trainer.weights())?;
    require(
        a.host.world().tick().raw() == 600 && b.host.world().tick().raw() == 600,
        "pair_prepared_tick",
    )?;
    let ca = a.host.checkpoint(&a.trainer)?;
    let cb = b.host.checkpoint(&b.trainer)?;
    // Validate each disposable initial snapshot against its own exact restore
    // contract, never across genotypes and never changing either live host.
    for (c, t) in [(&ca, &a.trainer), (&cb, &b.trainer)] {
        let checked = CpuCanonicalHost::from_checkpoint(c.clone(), t)?;
        require(
            bytes(&checked.checkpoint(t)?)? == bytes(c)?,
            "pair_exact_self_restore",
        )?;
    }
    fn world_projection(c: &CpuCanonicalCheckpoint) -> Result<Value> {
        let mut v = serde_json::to_value(&c.world)?;
        let records = v
            .pointer_mut("/world/organism_records")
            .and_then(Value::as_array_mut)
            .ok_or("world_records")?;
        require(records.len() == 1, "pair_world_population")?;
        let r = &mut records[0];
        for (pointer, key) in [
            ("/genome/n2048_foundation_candidate", "weights"),
            ("/genome/n2048_foundation_candidate", "digest"),
            (
                "/genome/n2048_foundation_candidate/manifest/weight_asset",
                "digest",
            ),
            ("/state_graph/genetics_development", "content_digest"),
            ("/state_graph/brain", "content_digest"),
        ] {
            require(
                r.pointer_mut(pointer)
                    .and_then(Value::as_object_mut)
                    .and_then(|m| m.remove(key))
                    .is_some(),
                "world_projection_field",
            )?;
        }
        Ok(v)
    }
    require(
        bytes(&world_projection(&ca)?)? == bytes(&world_projection(&cb)?)?,
        "pair_complete_prepared_world",
    )?;

    require(
        ca.phenotype_hash == pa.phenotype_hash()
            && cb.phenotype_hash == pb.phenotype_hash()
            && ca.phenotype_hash != cb.phenotype_hash,
        "pair_binding",
    )?;
    require(
        ca.schema_version == cb.schema_version
            && ca.sampling_seed == cb.sampling_seed
            && ca.sampling_counter == 0
            && cb.sampling_counter == 0
            && bytes(&ca.tracked_objects)? == bytes(&cb.tracked_objects)?,
        "pair_rng_registry",
    )?;
    require(
        bytes(&resident_projection(
            serde_json::to_value(&ca.residents)?,
            serde_json::to_value(ca.phenotype_hash)?,
        )?)? == bytes(&resident_projection(
            serde_json::to_value(&cb.residents)?,
            serde_json::to_value(cb.phenotype_hash)?,
        )?)?,
        "pair_private_state",
    )?;
    fn optimizer_projection(t: &CpuFoundationTrainer) -> Result<Value> {
        let c = t.checkpoint();
        require(
            c.phenotype_hash == t.phenotype().phenotype_hash() && c.weights == t.weights(),
            "optimizer_binding",
        )?;
        let mut v = serde_json::to_value(c)?;
        let m = v.as_object_mut().ok_or("optimizer_object")?;
        for key in ["phenotype_hash", "source_foundation_digest", "weights"] {
            require(m.remove(key).is_some(), "optimizer_field")?;
        }
        Ok(v)
    }
    require(
        bytes(&optimizer_projection(&a.trainer)?)? == bytes(&optimizer_projection(&b.trainer)?)?,
        "pair_optimizer",
    )?;
    Ok(())
}

fn execute() -> Result<()> {
    let root = std::env::args().nth(1).ok_or("output_path")?;
    std::fs::create_dir(&root)?;
    let file = std::fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(std::path::Path::new(&root).join("events.ndjson"))?;
    let mut sink = Sink {
        file,
        written: 0,
        deadline: std::time::Instant::now(),
        stage: "asset_construction",
        arm: "none",
        root: std::path::PathBuf::from(&root),
    };
    sink.emit(json!({"kind":"invocation","seeds":[2026112501u64,2026112502u64],"gains":[0.,0.0625],"max_lives":4,"max_preparation_per_life":600,"max_primary_per_life":256,"max_public_bytes":64*1024*1024,"backend":"CPU","variant_actions_applied":true}))?;
    let result = (|| -> Result<()> {
        let (off_p, off) = candidate_gain(2026110901, 0.)?;
        let (on_p, on) = candidate_gain(2026110901, 0.0625)?;
        genetic_pair(&off_p, &on_p, off.weights(), on.weights())?;
        sink.emit(json!({"kind":"asset_bindings","off_asset_sha256":digest(&off.encode_canonical()?),"on_asset_sha256":digest(&on.encode_canonical()?)}))?;
        for (index, scene) in SCENES.into_iter().enumerate() {
            sink.arm = "OFF";
            let mut a = prepare(scene, &off, &mut sink)?;
            sink.arm = "gain_1_16";
            let mut b = prepare(scene, &on, &mut sink)?;
            sink.arm = "pair";
            sink.stage = "paired_initial_validation";
            paired_initial(&a, &b)?;
            sink.emit(json!({"kind":"paired_initial_equal","seed":scene.seed,"exact_gene_differences":16,"off_checkpoint_sha256":digest(&bytes(&a.host.checkpoint(&a.trainer)?)?),"on_checkpoint_sha256":digest(&bytes(&b.host.checkpoint(&b.trainer)?)?)}))?;
            if index == 0 {
                sink.arm = "OFF";
                run(scene, &mut a, &mut sink)?;
                sink.arm = "gain_1_16";
                run(scene, &mut b, &mut sink)?;
            } else {
                sink.arm = "gain_1_16";
                run(scene, &mut b, &mut sink)?;
                sink.arm = "OFF";
                run(scene, &mut a, &mut sink)?;
            }
        }
        Ok(())
    })();
    match result {
        Ok(()) => {
            sink.emit(json!({"kind":"invocation_complete"}))?;
            println!("matched_probe_complete");
            Ok(())
        }
        Err(error) => {
            let stage = sink.stage;
            let code = error
                .downcast_ref::<Gate>()
                .map_or("closed_native_failure", |e| e.0);
            let _=sink.emit(json!({"kind":"invocation_failed","stage":stage,"error":code,"retry_permitted":false}));
            Err("closed_native_failure".into())
        }
    }
}
fn main() {
    std::panic::set_hook(Box::new(|_| eprintln!("closed_native_panic")));
    if execute().is_err() {
        eprintln!("closed_shadow_failure");
        std::process::exit(1);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_actual_pair_genes_reject_extra_change() -> Result<()> {
        let (a, x) = candidate_gain(2026110901, 0.)?;
        let (b, y) = candidate_gain(2026110901, 0.0625)?;
        genetic_pair(&a, &b, x.weights(), y.weights())?;
        let mut corrupted = y.weights().to_vec();
        corrupted[0] += 0.125;
        assert!(genetic_pair(&a, &b, x.weights(), &corrupted).is_err());
        Ok(())
    }
    #[test]
    fn resident_projection_rejects_nonidentity_changes() -> Result<()> {
        // Projection-unit fixture only: no host, world, ticks, or private life.
        let a = json!([{"neural":{"phenotype_hash":"off","inactive_activations":[0.0],"eligibility":[0.0]},"next_sequence":1,"replay":[]}]);
        let mut b = a.clone();
        b[0]["neural"]["phenotype_hash"] = json!("on");
        assert_eq!(
            bytes(&resident_projection(a.clone(), json!("off"))?)?,
            bytes(&resident_projection(b.clone(), json!("on"))?)?
        );
        b[0]["neural"]["eligibility"][0] = json!(0.125);
        assert_ne!(
            bytes(&resident_projection(a.clone(), json!("off"))?)?,
            bytes(&resident_projection(b, json!("on"))?)?
        );
        let mut c = a.clone();
        c[0]["next_sequence"] = json!(2);
        assert_ne!(
            bytes(&resident_projection(a, json!("off"))?)?,
            bytes(&resident_projection(c, json!("off"))?)?
        );
        Ok(())
    }
    #[test]
    fn bounded_scalar_probability() {
        assert_eq!(probability(&[0., 0.], 0, 3), 0.5);
        assert_eq!(probability(&[0., 0.], 1, 1), 0.);
        assert_eq!(probability(&[0., 0.], 0, 1), 1.);
    }
    #[test]
    fn detached_nonzero_components_offsets_and_gain_identity() -> Result<()> {
        use alife_training::{TrainingInitialState, TrainingReplayCandidate, TrainingReplayTick};
        let (base, base_asset) = candidate_gain(2026110901, 0.)?;
        let mut baseline_recurrent = None;
        let mut cap_seen = false;
        for gain in [0., 0.0625, 4.] {
            let (p, asset) = candidate_gain(2026110901, gain)?;
            let repacked = FoundationWeightAsset::from_trained_weights(
                &p,
                asset.weights().to_vec(),
                TrainingStageManifest::bootstrap(),
            )?;
            assert_eq!(repacked.digest(), asset.digest());
            let changed = base_asset
                .weights()
                .iter()
                .zip(asset.weights())
                .filter(|(a, b)| a.to_bits() != b.to_bits())
                .count();
            assert_eq!(changed, if gain == 0. { 0 } else { 16 });
            assert_eq!(p.projections(), base.projections());
            for (a, b) in p.synapses().iter().zip(base.synapses()) {
                assert_eq!(a.kind(), b.kind());
                assert_eq!(a.source(), b.source());
                assert_eq!(a.target(), b.target());
            }
            let n = p.neuron_count() as usize;
            let q = TrainingSequence {
                phenotype_hash: p.phenotype_hash(),
                initial: TrainingInitialState {
                    activations: vec![0.13; n],
                    activity_ema: vec![0.11; n],
                    metabolic_load: vec![0.01; n],
                    dendrites: DendriticBranchSet::new(Vec::new())?,
                },
                ticks: vec![TrainingReplayTick {
                    encoded_inputs: vec![0.02; n],
                    projection_gain: 1.,
                    local_threshold_shift: 0.,
                    microstep_count: u32::from(p.microstep_count()),
                    enabled_routes: vec![true; p.projections().len()],
                    effective_weight_offsets: p
                        .synapses()
                        .iter()
                        .map(|s| {
                            if matches!(s.kind(), CompiledSynapseKind::Decoder(_)) {
                                0.0137
                            } else {
                                0.
                            }
                        })
                        .collect(),
                    structural_synapses: Vec::new(),
                    candidates: [
                        CandidateActionFamily::Contact,
                        CandidateActionFamily::Other,
                        CandidateActionFamily::Ingest,
                    ]
                    .iter()
                    .map(|family| {
                        let mut inputs = [0.; 54];
                        for (i, v) in inputs.iter_mut().enumerate() {
                            *v = (i as f32 - 10.) * 0.01;
                        }
                        inputs[53] = if *family == CandidateActionFamily::Ingest {
                            0.
                        } else {
                            0.9
                        };
                        TrainingReplayCandidate {
                            family: *family,
                            decoder_inputs: inputs,
                            innate_bias: 0.17,
                        }
                    })
                    .collect(),
                }],
                burn_in_ticks: 0,
                memory_candidate_gain: 12.,
            };
            let trainer = CpuFoundationTrainer::new(
                p.clone(),
                asset,
                StageTrainableMask::recurrent_only(&p)?,
                AdamWConfig::default(),
            )?;
            let before = bytes(&trainer.checkpoint())?;
            let output = trainer.evaluate_replay(&q)?;
            let recurrence = bytes(&(
                &output.final_activations,
                &output.final_activity_ema,
                &output.final_metabolic_load,
            ))?;
            if gain == 0. {
                baseline_recurrent = Some(recurrence);
            } else {
                assert_eq!(Some(recurrence), baseline_recurrent);
            }
            for i in 0..3 {
                let c = components(
                    &p,
                    trainer.weights(),
                    &q.ticks[0],
                    &output.final_activations[0],
                    i,
                )?;
                assert_eq!(c.total.to_bits(), output.candidate_logits[0][i].to_bits());
                assert_ne!(c.action, 0.);
                assert_ne!(c.memory, 0.);
                assert_ne!(c.family, 0.);
                if i < 2 {
                    assert_ne!(c.effective_coeff[2], c.inherited_coeff[2]);
                }
                cap_seen |= c.memory.abs() > 12.;
            }
            assert_eq!(bytes(&trainer.checkpoint())?, before);
        }
        assert!(cap_seen);
        Ok(())
    }
}
