# Ordinary qualification before V5 exposure

- Refreshed all1258 copied source-file metadata, verifying unchanged content hashes, before Cargo.
- Five matched tests passed: bounded probability, nonzero decomposition/effective-offset/gain identity, exact16 genes with extra-coordinate rejection, real zero-tick paired-host/own-restore identity comparator with body and forged-digest rejection, and nonidentity private-field projection rejection.
- Inherited-v12/64-coordinate adaptation guard passed separately.
- Scoped example Clippy passed.
- Common world source is bit-identical to qualified v4: SHA256 e3444b35833119cda5c990df0bc8ce4de0fab93565a244728734be3a86aca763. Its four moving/stationary/blocked/rollback Rest checks passed in v4 and were not rerun merely to repeat unchanged world evidence.
- No study preparation/action/tick was used for qualification. The full-host fixture used fixed constructor identity2026110901 with0 preparation and0 host steps; controlled checkpoint mutations existed only in that test.
- The sole fresh26xx reservation was created after the real comparator fixture passed and all active-owner checks cleared.

Final source/executable/plan bindings and Cargo artifact hashes are stored separately. This is focused qualification, not a full repository suite or behavioral validation. The real600-tick initial barrier and actual-policy replay checks still must pass during the bounded study; if they fail, close the allocation without retry.
