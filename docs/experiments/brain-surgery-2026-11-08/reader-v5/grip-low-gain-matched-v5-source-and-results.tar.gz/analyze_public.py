#!/usr/bin/env python3
"""Read only finite public scalars, preserve incomplete accounting explicitly."""
import json,pathlib,collections,hashlib
root=pathlib.Path(__file__).resolve().parent
p=root/'public/events.ndjson'
raw=p.read_bytes(); records=[]; partial=False
for line in raw.splitlines(keepends=True):
 if not line.endswith(b'\n'): partial=True;break
 records.append(json.loads(line,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x))))
result={'events_sha256':hashlib.sha256(raw).hexdigest(),'public_bytes':len(raw),'records':len(records),'partial_final_line':partial,'invocation_complete':any(r['kind']=='invocation_complete' for r in records),'failures':[r for r in records if r['kind']=='invocation_failed'],'lives':[]}
for seed in [2026112601,2026112602]:
 for arm in ['OFF','gain_1_16']:
  rows=[r for r in records if r.get('seed')==seed and r.get('arm')==arm]
  steps=[r for r in rows if r['kind']=='step']; prep=[r for r in rows if r['kind']=='preparation_progress']; returned=[r for r in rows if r['kind']=='step_returned']; attempts=[r for r in rows if r['kind']=='step_attempt']
  x={'seed':seed,'arm':arm,'attempted':any(r['kind']=='life_attempt' for r in rows),'prep_attempts':max([r['attempted'] for r in prep],default=0),'prep_returns':max([r['returned'] for r in prep],default=0),'primary_attempts':len(attempts),'primary_returns':len(returned),'public_steps':len(steps),'complete':[r for r in rows if r['kind']=='life_complete']}
  if steps:
   x.update(final_energy=steps[-1]['energy'],min_energy=min(r['energy'] for r in steps),min_health=min(r['health'] for r in steps),max_injury=max(r['injury'] for r in steps),meals_h_s=steps[-1]['meals_h_s'],alive=steps[-1]['alive'])
   operations=collections.Counter(); failures=collections.Counter(); transfers=collections.Counter(); held=collections.Counter(); bundle=collections.Counter(); swaps=0; decisions=0; nonzero=collections.Counter(); opportunity_run=0; opportunity_delays=[]; opportunity_hunger=[]
   for r in steps:
    for t in r['before_situation']['targets']:
     if t['held']: held[t['target']+':'+t['mode']]+=1
    h,s=r['before_situation']['targets']
    if h['held'] and s['active'] and s['contact_reachable']:
     held['H_held_S_contact_reachable']+=1; opportunity_hunger.append(r['before_situation']['hunger'])
    opportunity_run=opportunity_run+1 if s['active'] and s['contact_reachable'] else 0
    for d in r['decisions']:
     decisions+=1
     assert d['baseline_replay_matches_actual'] and d['preservation'] and len(d['variants'])==1
     cs=d['variants'][0]['candidates']; selected={c['action'] for c in cs if any(c['selected_motor_slots'])}
     if 3 in selected and selected & {101,102}:bundle['Rest_with_locomotion']+=1
     for c in cs:
      if c['input53']!=0: nonzero[str(c['action'])+':'+c['target']]+=1
     for receipt in d['actual_physical']:
      key=str(receipt['action'])+':'+receipt['target'];operations[key]+=1
      if not receipt['succeeded']:failures[key]+=1
      tx={(t['target'],t['kind']) for t in receipt['transfers']}
      if receipt['target']=='s' and receipt['contact_consumed']:
       opportunity_delays.append(opportunity_run); opportunity_run=0
      swaps+=int(('s','placed') in tx and ('h','acquired') in tx)
      for target,kind in tx:transfers[target+':'+kind]+=1
   x.update(decisions=decisions,actual_operations=dict(operations),failed_operations=dict(failures),transfers=dict(transfers),held_ticks=dict(held),rest_motion=dict(bundle),safe_to_harm_swaps=swaps,nonzero_operation_inputs=dict(nonzero),safe_meal_contiguous_contact_opportunity_ticks=opportunity_delays,h_held_safe_reachable_hunger_range=[min(opportunity_hunger),max(opportunity_hunger)] if opportunity_hunger else None)
  result['lives'].append(x)
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'complete':result['invocation_complete'],'lives':[{k:v for k,v in x.items() if k in ['seed','arm','primary_returns','meals_h_s','final_energy','min_health','max_injury','safe_to_harm_swaps']} for x in result['lives']]}))
