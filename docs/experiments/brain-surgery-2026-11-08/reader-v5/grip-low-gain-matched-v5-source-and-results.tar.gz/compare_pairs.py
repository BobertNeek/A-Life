#!/usr/bin/env python3
import json,pathlib,collections
r=pathlib.Path(__file__).resolve().parent
rows=[]
for line in (r/'public/events.ndjson').read_bytes().splitlines(keepends=True):
 if not line.endswith(b'\n'):break
 rows.append(json.loads(line))
summary=json.loads((r/'analysis.json').read_text());pairs=[]
def choice(step):
 if not step['decisions']:return None
 d=step['decisions'][0]['variants'][0];cs=d['candidates']
 return [(cs[i]['action'],cs[i]['target']) if i is not None else None for i in d['motor_candidates']]
for seed in [2026112601,2026112602]:
 a=next(x for x in summary['lives'] if x['seed']==seed and x['arm']=='OFF');b=next(x for x in summary['lives'] if x['seed']==seed and x['arm']=='gain_1_16')
 if not(a['complete'] and b['complete']):continue
 x={arm:{s['primary_step']:s for s in rows if s['kind']=='step' and s['seed']==seed and s['arm']==arm} for arm in ['OFF','gain_1_16']}
 diffs=[]
 for tick in sorted(x['OFF'].keys() & x['gain_1_16'].keys()):
  off,on=x['OFF'][tick],x['gain_1_16'][tick]
  if choice(off)!=choice(on):diffs.append({'step':tick,'off_choice':choice(off),'on_choice':choice(on),'off_meals_h_s':off['meals_h_s'],'on_meals_h_s':on['meals_h_s']})
 pairs.append({'seed':seed,'off_meals_h_s':a['meals_h_s'],'on_meals_h_s':b['meals_h_s'],'on_minus_off_safe_meals':b['meals_h_s'][1]-a['meals_h_s'][1],'on_minus_off_harmful_meals':b['meals_h_s'][0]-a['meals_h_s'][0],'off_final_energy':a['final_energy'],'on_final_energy':b['final_energy'],'on_minus_off_energy':b['final_energy']-a['final_energy'],'joint_choice_different_steps':len(diffs),'first_choice_difference':diffs[0] if diffs else None,'all_choice_differences':diffs,'off_failed_operation_count':sum(a['failed_operations'].values()),'on_failed_operation_count':sum(b['failed_operations'].values()),'off_transfers':a['transfers'],'on_transfers':b['transfers'],'off_held_ticks':a['held_ticks'],'on_held_ticks':b['held_ticks'],'off_safe_to_harm_swaps':a['safe_to_harm_swaps'],'on_safe_to_harm_swaps':b['safe_to_harm_swaps'],'off_rest_motion':a['rest_motion'],'on_rest_motion':b['rest_motion']})
engagement=[]
for seed in [2026112601,2026112602]:
 for arm in ['OFF','gain_1_16']:
  counts=collections.Counter();ports=[];op=[];co=[];decisions=0
  for s in rows:
   if s['kind']!='step' or s['seed']!=seed or s['arm']!=arm:continue
   for d in s['decisions']:
    decisions+=1
    for c in d['variants'][0]['candidates']:
     if c['action'] not in [2201,2202]:continue
     key=str(c['action'])+':'+c['target'];counts[key+':available']+=1
     if c['input53']!=0:
      counts[key+':nonzero']+=1
      counts[key+':known_ingest']+=int(c['source_ingest_family'] and c['source_same_tracked_target'])
      counts[key+':exact_consumed']+=int(c['source_ingest_family'] and c['source_same_tracked_target'] and c['source_exact_consumed'])
     if c['target']=='h':ports.append(c['input53']);op.append(c['operation_component']);co.append(c['effective_coeff25_26_53'][2])
  engagement.append({'seed':seed,'arm':arm,'decisions':decisions,'counts':dict(counts),'h_operation_port_range':[min(ports),max(ports)] if ports else None,'h_operation_component_range':[min(op),max(op)] if op else None,'h_operation_effective_coefficient_range':[min(co),max(co)] if co else None})
(r/'paired-analysis.json').write_text(json.dumps({'pairs':pairs,'engagement':engagement,'interpretation':'Actual alternate trajectories, not same-state counterfactuals; two seeds do not establish generalization.'},indent=2)+'\n')
print(json.dumps([{k:v for k,v in p.items() if k!='all_choice_differences'} for p in pairs]))
