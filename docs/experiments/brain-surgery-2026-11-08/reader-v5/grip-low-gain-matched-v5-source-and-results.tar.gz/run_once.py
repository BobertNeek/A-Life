#!/usr/bin/env python3
"""One invocation only; closed bounded output and exact source/executable binding."""
import hashlib,json,os,pathlib,subprocess,sys,time,selectors
root=pathlib.Path(__file__).resolve().parent
exe=pathlib.Path(sys.argv[1]).resolve()
assert exe.is_file()
assert (root/'bindings.json').is_file()
assert not (root/'public').exists()
allocation=json.loads((root/'ALLOCATION.json').read_text())
assert allocation['seeds']==[2026112601,2026112602] and allocation['attempts']==0 and allocation['status']=='reserved_no_exposure'
assert allocation['max_lives']==4
assert not (root/'RUN-STARTED.json').exists()
binding=json.loads((root/'bindings.json').read_text())
assert hashlib.sha256(exe.read_bytes()).hexdigest()==binding['executable_sha256']
assert hashlib.sha256((root/'PLAN.md').read_bytes()).hexdigest()==binding['plan_sha256']
assert hashlib.sha256((root/'source-closure.json').read_bytes()).hexdigest()==binding['source_closure_file_sha256']
for relative,expected in json.loads((root/'source-closure.json').read_text()):
 path=(root/'source'/relative).resolve();assert path.is_relative_to((root/'source').resolve())
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected

assert os.statvfs(root).f_bavail*os.statvfs(root).f_frsize>2*1024**3
assert int(next(line.split()[1] for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) >= 6*1024*1024
# No retry, including startup failure or uncertain process outcome.
with (root/'RUN-STARTED.json').open('x') as f:json.dump({'attempted':True,'native_invocations':1,'output':'public','seeds':[2026112601,2026112602],'max_lives':4,'binding':binding},f);f.flush();os.fsync(f.fileno())
p=subprocess.Popen([str(exe),str(root/'public')],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);sel.register(p.stderr,selectors.EVENT_READ)
start=time.monotonic();captured=bytearray();reason=None
while sel.get_map():
 if time.monotonic()-start>1810:reason='wallclock';p.kill();break
 for key,_ in sel.select(0.5):
  data=os.read(key.fileobj.fileno(),65536)
  if not data:sel.unregister(key.fileobj);continue
  if len(captured)+len(data)>1024*1024:reason='stdio_bound';p.kill();break
  captured.extend(data)
 if reason:break
code=p.wait()
(root/'native-stdio.txt').write_bytes(captured)
# Report only closed fields. The public native file independently preserves attempts/returns.
result={'native_returncode':code,'killed_reason':reason,'elapsed_seconds':time.monotonic()-start,'stdout_stderr_bytes':len(captured),'retry_permitted':False}
with (root/'RUN-RETURNED.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result));sys.exit(0 if code==0 and reason is None else 1)
