//! Fresh research-owner familiarity evidence only. No reward/value or neural fields.
//! The caller must derive Evidence only from the authoritative, staged world close.
//! This pure codec/kernel does not establish that a synthetic input is a real contact.
use std::mem::size_of;

pub(crate) const CAPACITY: usize = 64;
pub(crate) const RECORD_BYTES: usize = 192;
pub(crate) const HEADER_BYTES: usize = 224;
pub(crate) const MAX_WIRE_BYTES: usize = HEADER_BYTES + CAPACITY * RECORD_BYTES;
const MAGIC: &[u8; 16] = b"ALIFE-CONTACT-01";
const UNKNOWN_JOINT_VALUE: u8 = 0;
const COMPLETED: u8 = 2;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct Work {
    pub reads: u64,
    pub comparisons: u64,
    pub writes: u64,
    pub arithmetic: u64,
    pub copied_bytes: u64,
    pub digest_bytes: u64,
    pub codec_bytes: u64,
    // Explicit administrative calls/values, separate from priced semantic work.
    pub physiology_helper_calls:u64,
    pub adaptation_helper_calls:u64,
    pub basis_json_hashes:u64,
    pub payload_clone_calls:u64,
    pub payload_cloned_values:u64,
}
impl Work {
    pub fn memory_ops(self) -> u64 {
        self.reads + self.comparisons + self.writes + self.arithmetic
    }
    pub fn administrative_byte_ops(self) -> u64 {
        self.copied_bytes + self.digest_bytes + self.codec_bytes
    }
    pub fn add(&mut self, other: Self) {
        self.reads += other.reads;
        self.comparisons += other.comparisons;
        self.writes += other.writes;
        self.arithmetic += other.arithmetic;
        self.copied_bytes += other.copied_bytes;
        self.digest_bytes += other.digest_bytes;
        self.codec_bytes += other.codec_bytes;
        self.physiology_helper_calls+=other.physiology_helper_calls;
        self.adaptation_helper_calls+=other.adaptation_helper_calls;
        self.basis_json_hashes+=other.basis_json_hashes;
        self.payload_clone_calls+=other.payload_clone_calls;
        self.payload_cloned_values+=other.payload_cloned_values;
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Boundary {
    pub owner: u64,
    pub profile: [u16; 3],
    pub sequence: u64,
    pub origin_tick: u64,
    pub outcome_tick: u64,
    pub frame: [u64; 4],
    pub bundle: [u64; 4],
    pub source: [u64; 4],
    pub generation: u64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Evidence {
    pub target: u64,
    pub candidate_digest: [u64; 4],
    pub action: u32,
    pub channel: u8,
    /// 1=Touch, 2=Consumed, 3=Moved. Collision/Blocked/None are never admitted.
    pub contact: u8,
    pub kind: u8,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Error {
    Identity,
    Boundary,
    Replay,
    Capacity,
    Encoding,
    Evidence,
}
#[derive(Clone, PartialEq, Eq)]
pub(crate) struct Bank {
    // Fixed inline storage, no heap allocation, map, target counter or derived index.
    header: [u8; HEADER_BYTES],
    records: [[u8; RECORD_BYTES]; CAPACITY],
}
fn u16_at(b: &[u8], p: usize) -> u16 {
    u16::from_le_bytes(b[p..p + 2].try_into().unwrap())
}
fn u32_at(b: &[u8], p: usize) -> u32 {
    u32::from_le_bytes(b[p..p + 4].try_into().unwrap())
}
fn u64_at(b: &[u8], p: usize) -> u64 {
    u64::from_le_bytes(b[p..p + 8].try_into().unwrap())
}
fn set16(b: &mut [u8], p: usize, n: u16) {
    b[p..p + 2].copy_from_slice(&n.to_le_bytes());
}
fn set32(b: &mut [u8], p: usize, n: u32) {
    b[p..p + 4].copy_from_slice(&n.to_le_bytes());
}
fn set64(b: &mut [u8], p: usize, n: u64) {
    b[p..p + 8].copy_from_slice(&n.to_le_bytes());
}
fn set_digest(b: &mut [u8], p: usize, n: [u64; 4]) {
    for (i, v) in n.into_iter().enumerate() {
        set64(b, p + i * 8, v);
    }
}
fn digest_at(b: &[u8], p: usize) -> [u64; 4] {
    std::array::from_fn(|i| u64_at(b, p + i * 8))
}
impl Bank {
    pub fn fresh(owner: u64, profile: [u16; 3]) -> Result<Self, Error> {
        if owner == 0 || profile.iter().any(|v| *v == 0) {
            return Err(Error::Identity);
        }
        let mut result = Self {
            header: [0; HEADER_BYTES],
            records: [[0; RECORD_BYTES]; CAPACITY],
        };
        result.header[..16].copy_from_slice(MAGIC);
        set16(&mut result.header, 16, 1);
        set16(&mut result.header, 18, CAPACITY as u16);
        set64(&mut result.header, 24, owner);
        for (i, v) in profile.into_iter().enumerate() {
            set16(&mut result.header, 32 + i * 2, v);
        }
        result.reseal(&mut Work::default());
        Ok(result)
    }
    pub fn owner(&self) -> u64 {
        u64_at(&self.header, 24)
    }
    pub fn profile(&self) -> [u16; 3] {
        std::array::from_fn(|i| u16_at(&self.header, 32 + i * 2))
    }
    pub fn len(&self) -> usize {
        u16_at(&self.header, 20) as usize
    }
    pub fn last_sequence(&self) -> u64 {
        u64_at(&self.header, 40)
    }
    pub fn last_outcome(&self) -> u64 {
        u64_at(&self.header, 48)
    }
    pub fn generation(&self) -> u64 {
        u64_at(&self.header, 160)
    }
    pub fn last_boundary(&self) -> Option<Boundary> {
        (self.last_sequence() > 0).then(|| Boundary {
            owner: self.owner(),
            profile: self.profile(),
            sequence: self.last_sequence(),
            origin_tick: u64_at(&self.header, 56),
            outcome_tick: self.last_outcome(),
            frame: digest_at(&self.header, 64),
            bundle: digest_at(&self.header, 96),
            source: digest_at(&self.header, 128),
            generation: self.generation(),
        })
    }
    pub fn seal(&self) -> [u64; 4] {
        digest_at(&self.header, 168)
    }
    pub fn resident_bytes() -> usize {
        size_of::<Self>()
    }
    pub fn wire_bytes(&self) -> usize {
        HEADER_BYTES + self.len() * RECORD_BYTES
    }
    pub fn index_bytes() -> usize {
        0
    }
    pub fn clone_measured(&self, work: &mut Work) -> Self {
        work.copied_bytes += size_of::<Self>() as u64;
        self.clone()
    }
    // Deterministic corruption checksum, NOT a cryptographic authenticity proof.
    // Authority is established by the host's private construction/receipt validator.
    fn checksum(&self, work: &mut Work) -> [u64; 4] {
        let mut state = [
            0xcbf29ce484222325,
            0x84222325cbf29ce4,
            0x6c62272e07bb0142,
            0x62b821756295c58d,
        ];
        let mut offset = 0usize;
        for bytes in std::iter::once(&self.header[..])
            .chain(self.records[..self.len()].iter().map(|r| &r[..]))
        {
            for &value in bytes {
                let value = if (168..200).contains(&offset) {
                    0
                } else {
                    value
                };
                for (i, s) in state.iter_mut().enumerate() {
                    *s = (*s ^ (u64::from(value) + (i as u64) * 257)).wrapping_mul(0x100000001b3);
                }
                offset += 1;
            }
        }
        work.digest_bytes += offset as u64;
        state
    }
    fn reseal(&mut self, work: &mut Work) {
        let seal = self.checksum(work);
        set_digest(&mut self.header, 168, seal);
        work.writes += 4;
        work.copied_bytes += 32;
    }
    /// Exactly one close per source sequence, including a quiet/empty close.
    /// All checks precede mutation; the host additionally stages the whole life.
    pub fn close(
        &mut self,
        b: Boundary,
        contacts: &[Evidence],
        work: &mut Work,
    ) -> Result<usize, Error> {
        if b.owner != self.owner() || b.profile != self.profile() {
            return Err(Error::Identity);
        }
        if b.sequence != self.last_sequence().checked_add(1).ok_or(Error::Boundary)? {
            return Err(Error::Replay);
        }
        if b.generation != b.sequence
            || b.origin_tick >= b.outcome_tick
            || (self.last_sequence() > 0 && b.origin_tick < self.last_outcome())
            || b.frame == [0; 4]
            || b.bundle == [0; 4]
            || b.source == [0; 4]
        {
            return Err(Error::Boundary);
        }
        if contacts.len() > 6 {
            return Err(Error::Capacity);
        }
        let mut unique = [None::<Evidence>; 6];
        let mut masks = [0u8; 6];
        let mut count = 0usize;
        let mut channel_mask = 0u8;
        for &e in contacts {
            work.reads += 1;
            if e.target == 0
                || e.action == 0
                || e.channel >= 6
                || !(1..=3).contains(&e.contact)
                || e.candidate_digest == [0; 4]
                || !matches!(e.kind, 1 | 3 | 5 | 9)
            {
                return Err(Error::Evidence);
            }
            if channel_mask & (1 << e.channel) != 0 {
                return Err(Error::Evidence);
            }
            channel_mask |= 1 << e.channel;
            let mut found = None;
            for (i, previous) in unique[..count].iter().enumerate() {
                work.comparisons += 1;
                if previous.unwrap().target == e.target {
                    found = Some(i);
                    break;
                }
            }
            if let Some(i) = found {
                // Canonical first channel must be unique. Two receipts for one channel
                // are invalid, rather than silently accepting a duplicated world receipt.
                work.comparisons += 1;
                if masks[i] & (1 << e.channel) != 0 {
                    return Err(Error::Evidence);
                }
                masks[i] |= 1 << e.channel;
                if e.channel < unique[i].unwrap().channel {
                    unique[i] = Some(e);
                }
            } else {
                unique[count] = Some(e);
                masks[count] = 1 << e.channel;
                count += 1;
            }
        }
        // Canonical deterministic channel order independent of receipt ordering.
        for i in 0..count {
            for j in i + 1..count {
                work.comparisons += 1;
                if unique[j].unwrap().channel < unique[i].unwrap().channel {
                    unique.swap(i, j);
                    masks.swap(i, j);
                }
            }
        }
        for i in 0..count {
            let e = unique[i].unwrap();
            let mut row = [0u8; RECORD_BYTES];
            set64(&mut row, 0, b.sequence);
            set64(&mut row, 8, b.origin_tick);
            set64(&mut row, 16, b.outcome_tick);
            set64(&mut row, 24, e.target);
            set_digest(&mut row, 32, b.frame);
            set_digest(&mut row, 64, b.bundle);
            set_digest(&mut row, 96, b.source);
            set_digest(&mut row, 128, e.candidate_digest);
            set64(&mut row, 160, b.generation);
            set32(&mut row, 168, e.action);
            row[172] = e.channel;
            row[173] = masks[i];
            row[174] = e.contact;
            row[175] = COMPLETED;
            row[176] = UNKNOWN_JOINT_VALUE;
            row[177] = e.kind;
            let slot = u16_at(&self.header, 22) as usize;
            self.records[slot] = row;
            work.writes += 1;
            work.copied_bytes += (RECORD_BYTES + 178) as u64;
            work.writes += 2;
            work.copied_bytes += 4;
            let len = (self.len() + 1).min(CAPACITY);
            set16(&mut self.header, 20, len as u16);
            set16(&mut self.header, 22, ((slot + 1) % CAPACITY) as u16);
        }
        set64(&mut self.header, 40, b.sequence);
        set64(&mut self.header, 48, b.outcome_tick);
        set64(&mut self.header, 56, b.origin_tick);
        set_digest(&mut self.header, 64, b.frame);
        set_digest(&mut self.header, 96, b.bundle);
        set_digest(&mut self.header, 128, b.source);
        set64(&mut self.header, 160, b.generation);
        set64(&mut self.header, 200, b.sequence);
        set64(&mut self.header, 208, b.sequence);
        work.writes += 18;
        work.copied_bytes += 144;
        self.reseal(work);
        Ok(count)
    }
    /// One retained-bank scan for up to 16 current grounded identities. No unbounded
    /// aggregate survives eviction. Caller combines this with legacy via max, not sum.
    pub fn familiarities(
        &self,
        owner: u64,
        profile: [u16; 3],
        targets: &[u64],
        work: &mut Work,
    ) -> Result<[f32; 16], Error> {
        if owner != self.owner() || profile != self.profile() {
            return Err(Error::Identity);
        }
        if targets.len() > 16 || targets.contains(&0) {
            return Err(Error::Capacity);
        }
        let mut counts = [0u16; 16];
        for row in &self.records[..self.len()] {
            work.reads += 1;
            for (i, target) in targets.iter().enumerate() {
                work.comparisons += 1;
                if u64_at(row, 24) == *target {
                    counts[i] += 1;
                    work.arithmetic += 1;
                }
            }
        }
        let mut result = [0.; 16];
        for (i, count) in counts[..targets.len()].iter().enumerate() {
            result[i] = 1. - 1. / (1. + f32::from(*count));
            work.arithmetic += 3;
        }
        Ok(result)
    }
    pub fn count(&self, target: u64) -> usize {
        self.records[..self.len()]
            .iter()
            .filter(|r| u64_at(&r[..], 24) == target)
            .count()
    }
    pub fn encode(&self, work: &mut Work) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(self.wire_bytes());
        bytes.extend_from_slice(&self.header);
        for row in &self.records[..self.len()] {
            bytes.extend_from_slice(row);
        }
        work.codec_bytes += bytes.len() as u64;
        bytes
    }
    pub fn decode(
        bytes: &[u8],
        owner: u64,
        profile: [u16; 3],
        work: &mut Work,
    ) -> Result<Self, Error> {
        // Reject lengths/counts before allocation or per-record iteration. Decode
        // allocates no heap storage; one fixed Bank is returned.
        if bytes.len() < HEADER_BYTES
            || bytes.len() > MAX_WIRE_BYTES
            || &bytes[..16] != MAGIC
            || u16_at(bytes, 16) != 1
            || u16_at(bytes, 18) != CAPACITY as u16
        {
            return Err(Error::Encoding);
        }
        let len = u16_at(bytes, 20) as usize;
        let next = u16_at(bytes, 22) as usize;
        if len > CAPACITY
            || next >= CAPACITY
            || bytes.len() != HEADER_BYTES + len * RECORD_BYTES
            || (len < CAPACITY && next != len)
            || bytes[38..40] != [0; 2]
            || bytes[216..224] != [0; 8]
        {
            return Err(Error::Encoding);
        }
        let mut bank = Self {
            header: [0; HEADER_BYTES],
            records: [[0; RECORD_BYTES]; CAPACITY],
        };
        bank.header.copy_from_slice(&bytes[..HEADER_BYTES]);
        if owner == 0
            || profile.iter().any(|v| *v == 0)
            || bank.owner() != owner
            || bank.profile() != profile
        {
            return Err(Error::Identity);
        }
        for (i, chunk) in bytes[HEADER_BYTES..].chunks_exact(RECORD_BYTES).enumerate() {
            bank.records[i].copy_from_slice(chunk);
        }
        work.codec_bytes += bytes.len() as u64;
        if bank.checksum(work) != bank.seal() {
            return Err(Error::Encoding);
        }
        if bank.last_sequence() != bank.generation()
            || u64_at(&bank.header, 200) != bank.last_sequence()
            || u64_at(&bank.header, 208) != bank.last_sequence()
        {
            return Err(Error::Boundary);
        }
        if bank.last_sequence() == 0 {
            if len != 0 || bank.header[40..168].iter().any(|b| *b != 0) {
                return Err(Error::Boundary);
            }
        } else if u64_at(&bank.header, 56) >= bank.last_outcome()
            || digest_at(&bank.header, 64) == [0; 4]
            || digest_at(&bank.header, 96) == [0; 4]
            || digest_at(&bank.header, 128) == [0; 4]
        {
            return Err(Error::Boundary);
        }
        let mut previous = None;
        let mut previous_boundary: Option<(u64, u64, u64)> = None;
        // FIFO order is reconstructed without an allocated sort/index.
        for offset in 0..len {
            let slot = if len == CAPACITY {
                (next + offset) % CAPACITY
            } else {
                offset
            };
            let row = &bank.records[slot];
            work.reads += 1;
            let sequence = u64_at(row, 0);
            let target = u64_at(row, 24);
            if sequence == 0
                || sequence > bank.last_sequence()
                || sequence != u64_at(row, 160)
                || u64_at(row, 8) >= u64_at(row, 16)
                || u64_at(row, 16) > bank.last_outcome()
                || target == 0
                || u32_at(row, 168) == 0
                || row[172] >= 6
                || row[173] == 0
                || row[173] & !63 != 0
                || row[173].trailing_zeros() != u32::from(row[172])
                || !(1..=3).contains(&row[174])
                || row[175] != COMPLETED
                || row[176] != UNKNOWN_JOINT_VALUE
                || !matches!(row[177], 1 | 3 | 5 | 9)
                || row[178..].iter().any(|b| *b != 0)
                || (32..160).step_by(32).any(|p| digest_at(row, p) == [0; 4])
            {
                return Err(Error::Evidence);
            }
            if sequence == bank.last_sequence()
                && (row[8..16] != bank.header[56..64]
                    || row[16..24] != bank.header[48..56]
                    || row[32..128] != bank.header[64..160])
            {
                return Err(Error::Boundary);
            }
            let origin = u64_at(row, 8);
            let outcome = u64_at(row, 16);
            if sequence < bank.last_sequence() && outcome > u64_at(&bank.header, 56) {
                return Err(Error::Boundary);
            }
            if let Some((previous_sequence, previous_origin, previous_outcome)) = previous_boundary
            {
                if sequence == previous_sequence {
                    if origin != previous_origin || outcome != previous_outcome {
                        return Err(Error::Boundary);
                    }
                } else if previous_outcome > origin {
                    return Err(Error::Boundary);
                }
            }
            previous_boundary = Some((sequence, origin, outcome));
            let key = (sequence, row[172]);
            if previous.is_some_and(|p| p >= key) {
                return Err(Error::Boundary);
            }
            previous = Some(key);
            for other_offset in 0..offset {
                let other_slot = if len == CAPACITY {
                    (next + other_offset) % CAPACITY
                } else {
                    other_offset
                };
                let other = &bank.records[other_slot];
                work.comparisons += 1;
                if u64_at(other, 0) == sequence {
                    if u64_at(other, 24) == target
                        || other[173] & row[173] != 0
                        || other[8..24] != row[8..24]
                        || other[32..128] != row[32..128]
                    {
                        return Err(Error::Evidence);
                    }
                }
            }
        }
        Ok(bank)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn bank() -> Bank {
        Bank::fresh(7, [5, 1, 1]).unwrap()
    }
    fn boundary(n: u64) -> Boundary {
        Boundary {
            owner: 7,
            profile: [5, 1, 1],
            sequence: n,
            origin_tick: n - 1,
            outcome_tick: n,
            frame: [n; 4],
            bundle: [n + 1; 4],
            source: [n + 2; 4],
            generation: n,
        }
    }
    fn event(target: u64, channel: u8) -> Evidence {
        Evidence {
            target,
            candidate_digest: [5; 4],
            action: 213,
            channel,
            contact: 1,
            kind: 5,
        }
    }
    #[test]
    fn empty_and_one_contact() {
        let mut b = bank();
        let mut w = Work::default();
        assert_eq!(b.familiarities(7, [5, 1, 1], &[9], &mut w).unwrap()[0], 0.);
        b.close(boundary(1), &[event(9, 2)], &mut w).unwrap();
        assert_eq!(b.count(9), 1);
        assert_eq!(b.familiarities(7, [5, 1, 1], &[9], &mut w).unwrap()[0], 0.5);
    }
    #[test]
    fn replay_old_sequence_and_quiet_cursors() {
        let mut b = bank();
        let mut w = Work::default();
        b.close(boundary(1), &[], &mut w).unwrap();
        let saved = b.clone();
        assert_eq!(
            b.close(boundary(1), &[event(9, 2)], &mut w),
            Err(Error::Replay)
        );
        assert!(b == saved);
        assert_eq!(b.close(boundary(3), &[], &mut w), Err(Error::Replay));
        assert_eq!(b.last_sequence(), 1);
    }
    #[test]
    fn cross_owner_profile_and_target_rejection() {
        let mut b = bank();
        let mut w = Work::default();
        let mut x = boundary(1);
        x.owner = 8;
        assert_eq!(b.close(x, &[], &mut w), Err(Error::Identity));
        x = boundary(1);
        x.profile = [4, 1, 1];
        assert_eq!(b.close(x, &[], &mut w), Err(Error::Identity));
        assert_eq!(
            b.close(boundary(1), &[event(0, 2)], &mut w),
            Err(Error::Evidence)
        );
        assert_eq!(b.len(), 0);
    }
    #[test]
    fn dedup_same_object_across_channels_and_receipt_order() {
        let mut a = bank();
        let mut b = bank();
        let mut w = Work::default();
        a.close(boundary(1), &[event(9, 2), event(9, 1)], &mut w)
            .unwrap();
        b.close(boundary(1), &[event(9, 1), event(9, 2)], &mut w)
            .unwrap();
        assert!(a == b);
        assert_eq!(a.len(), 1);
        assert_eq!(a.records[0][172], 1);
        assert_eq!(a.records[0][173], 6);
    }
    #[test]
    fn distinct_objects_one_interval() {
        let mut b = bank();
        let mut w = Work::default();
        assert_eq!(
            b.close(boundary(1), &[event(9, 1), event(10, 2)], &mut w)
                .unwrap(),
            2
        );
        assert_eq!(
            b.familiarities(7, [5, 1, 1], &[9, 10], &mut w).unwrap()[..2],
            [0.5, 0.5]
        );
    }
    #[test]
    fn duplicate_receipt_rejected_before_mutation() {
        let mut b = bank();
        let saved = b.clone();
        assert_eq!(
            b.close(
                boundary(1),
                &[event(9, 2), event(9, 2)],
                &mut Work::default()
            ),
            Err(Error::Evidence)
        );
        assert!(b == saved);
    }
    #[test]
    fn invalid_evidence_atomic_rollback() {
        let mut b = bank();
        let saved = b.clone();
        let mut bad = event(10, 1);
        bad.contact = 0;
        assert!(b
            .close(boundary(1), &[event(9, 2), bad], &mut Work::default())
            .is_err());
        assert!(b == saved);
        let mut staged = b.clone();
        staged
            .close(boundary(1), &[event(9, 2)], &mut Work::default())
            .unwrap();
        drop(staged);
        assert!(b == saved);
    }
    #[test]
    fn fifo_eviction_forgets_not_cumulative() {
        let mut b = bank();
        let mut w = Work::default();
        for n in 1..=CAPACITY as u64 + 1 {
            b.close(boundary(n), &[event(100 + n, 2)], &mut w).unwrap();
        }
        assert_eq!(b.len(), CAPACITY);
        assert_eq!(b.count(101), 0);
        assert_eq!(
            b.familiarities(7, [5, 1, 1], &[101], &mut w).unwrap()[0],
            0.
        );
        let bytes = b.encode(&mut w);
        assert!(Bank::decode(&bytes, 7, [5, 1, 1], &mut w).unwrap() == b);
    }
    #[test]
    fn exact_size_and_codec_roundtrip() {
        let mut b = bank();
        let mut w = Work::default();
        assert_eq!(Bank::resident_bytes(), MAX_WIRE_BYTES);
        assert_eq!(Bank::index_bytes(), 0);
        assert_eq!(b.wire_bytes(), HEADER_BYTES);
        b.close(boundary(1), &[event(9, 2)], &mut w).unwrap();
        let bytes = b.encode(&mut w);
        assert_eq!(bytes.len(), HEADER_BYTES + RECORD_BYTES);
        assert!(Bank::decode(&bytes, 7, [5, 1, 1], &mut w).unwrap() == b);
    }
    #[test]
    fn malformed_and_oversized_decode() {
        let b = bank();
        let mut w = Work::default();
        let bytes = b.encode(&mut w);
        for n in 0..HEADER_BYTES {
            assert!(Bank::decode(&bytes[..n], 7, [5, 1, 1], &mut w).is_err());
        }
        assert!(Bank::decode(&vec![0; MAX_WIRE_BYTES + 1], 7, [5, 1, 1], &mut w).is_err());
        let mut bad = bytes.clone();
        set16(&mut bad, 20, 65);
        assert!(Bank::decode(&bad, 7, [5, 1, 1], &mut w).is_err());
        bad = bytes.clone();
        bad[168] ^= 1;
        assert!(Bank::decode(&bad, 7, [5, 1, 1], &mut w).is_err());
        assert!(Bank::decode(&bytes, 8, [5, 1, 1], &mut w).is_err());
    }
    #[test]
    fn unknown_value_only_reserved_and_phase_rejected() {
        let mut b = bank();
        let mut w = Work::default();
        b.close(boundary(1), &[event(9, 2)], &mut w).unwrap();
        for (p, v) in [(175, 1), (176, 1), (178, 1)] {
            let mut bad = b.clone();
            bad.records[0][p] = v;
            bad.reseal(&mut w);
            assert!(Bank::decode(&bad.encode(&mut w), 7, [5, 1, 1], &mut w).is_err());
        }
        assert_eq!(b.records[0][176], UNKNOWN_JOINT_VALUE);
    }
    #[test]
    fn bounded_scan_counts_are_measured() {
        let mut b = bank();
        let mut w = Work::default();
        for n in 1..=64 {
            b.close(boundary(n), &[event(n, 2)], &mut w).unwrap();
        }
        let mut scan = Work::default();
        b.familiarities(7, [5, 1, 1], &(1..=16).collect::<Vec<_>>(), &mut scan)
            .unwrap();
        assert_eq!(scan.reads, 64);
        assert_eq!(scan.comparisons, 1024);
        assert_eq!(scan.arithmetic, 64);
        assert_eq!(scan.memory_ops(), 1152);
        println!(
            "CONTACT_BANK_SIZE_V1 resident={} wire={} index={} scan_ops={} scan_comparisons={}",
            Bank::resident_bytes(),
            b.wire_bytes(),
            Bank::index_bytes(),
            scan.memory_ops(),
            scan.comparisons
        );
    }
    #[test]
    fn backward_cold_ticks_and_future_older_record_rejected() {
        let mut b = bank();
        let mut w = Work::default();
        for n in 1..=3 {
            b.close(boundary(n), &[event(10 + n, 2)], &mut w).unwrap();
        }
        let mut backward = b.clone();
        set64(&mut backward.records[0], 8, 100);
        set64(&mut backward.records[0], 16, 101);
        backward.reseal(&mut w);
        assert!(Bank::decode(&backward.encode(&mut w), 7, [5, 1, 1], &mut w).is_err());
        let mut future = b.clone();
        set64(&mut future.records[1], 16, 4);
        future.reseal(&mut w);
        assert!(Bank::decode(&future.encode(&mut w), 7, [5, 1, 1], &mut w).is_err());
    }
}
