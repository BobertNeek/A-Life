//! Host-only adapter: pure contact records are derived only after actual world close.
//! This is not a second ExperiencePatch observer and never writes value memory.
use super::*;
use crate::cpu::actual_contact_bank::{Bank, Boundary, Evidence, Work, MAX_WIRE_BYTES};
use crate::cpu::actual_contact_contract::{self as contract, Contact, Fact, Kind, Phase, Verdict};
use serde::de::Visitor;
use serde::{Deserializer, Serializer};

fn invalid_contact() -> CpuHostError {
    CpuHostError::State("actual-contact authority mismatch")
}
fn profile_bits() -> [u16; 3] {
    let p = sleep_choice_envelope::sleep_choice_profile_identity();
    [
        p.profile_id.raw(),
        p.profile_schema_version,
        p.sensory_abi_version,
    ]
}
#[derive(Clone)]
pub(super) struct ContactBankV1 {
    bank: Bank,
}
impl std::fmt::Debug for ContactBankV1 {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ContactBankV1")
            .field("retained", &self.bank.len())
            .finish_non_exhaustive()
    }
}
impl serde::Serialize for ContactBankV1 {
    fn serialize<S: Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        let bytes = self.bank.encode(&mut Work::default());
        let mut hex = String::with_capacity(bytes.len() * 2);
        const DIGITS: &[u8; 16] = b"0123456789abcdef";
        for b in bytes {
            hex.push(DIGITS[(b >> 4) as usize] as char);
            hex.push(DIGITS[(b & 15) as usize] as char);
        }
        s.serialize_str(&hex)
    }
}
impl<'de> serde::Deserialize<'de> for ContactBankV1 {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct Bounded;
        impl<'de> Visitor<'de> for Bounded {
            type Value = ContactBankV1;
            fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
                f.write_str("bounded canonical actual-contact bank hex")
            }
            fn visit_str<E: serde::de::Error>(self, value: &str) -> Result<Self::Value, E> {
                if value.len() < 2 * crate::cpu::actual_contact_bank::HEADER_BYTES
                    || value.len() > 2 * MAX_WIRE_BYTES
                    || value.len() % 2 != 0
                {
                    return Err(E::custom("actual-contact bank size"));
                }
                let mut bytes = [0u8; MAX_WIRE_BYTES];
                let digit = |b: u8| match b {
                    b'0'..=b'9' => Some(b - b'0'),
                    b'a'..=b'f' => Some(b - b'a' + 10),
                    _ => None,
                };
                for (i, c) in value.as_bytes().chunks_exact(2).enumerate() {
                    bytes[i] = (digit(c[0]).ok_or_else(|| E::custom("bank hex"))? << 4)
                        | digit(c[1]).ok_or_else(|| E::custom("bank hex"))?;
                }
                let owner = u64::from_le_bytes(bytes[24..32].try_into().unwrap());
                let bank = Bank::decode(
                    &bytes[..value.len() / 2],
                    owner,
                    profile_bits(),
                    &mut Work::default(),
                )
                .map_err(|_| E::custom("actual-contact bank contract"))?;
                Ok(ContactBankV1 { bank })
            }
        }
        d.deserialize_str(Bounded)
    }
}
#[derive(Debug, Clone)]
pub(super) struct ContactFamiliarityV1 {
    targets: [u64; 16],
    values: [f32; 16],
    len: usize,
    work: Work,
    lookup_comparisons: std::cell::Cell<u64>,
}
impl ContactFamiliarityV1 {
    pub(super) fn familiarity(&self, id: TrackedObjectId) -> f32 {
        for i in 0..self.len {
            self.lookup_comparisons
                .set(self.lookup_comparisons.get() + 1);
            if self.targets[i] == id.raw() {
                return self.values[i];
            }
        }
        0.
    }
    pub(super) fn work(&self) -> Work {
        let mut work = self.work;
        work.comparisons += self.lookup_comparisons.get();
        work
    }
}
#[derive(Debug, Clone)]
pub(super) struct ContactTargetBindingsV1 {
    owner: OrganismId,
    tick: Tick,
    sequence: ExperienceSequenceId,
    frame: [u64; 4],
    bundle: [u64; 4],
    entities: [Option<WorldEntityId>; 6],
    tracked: [u64; 6],
    work: Work,
    expected_commands:[Option<contract::CommandBits>;6],
    biology_before_digest:[u64;4],
    embodiment_basis_digest:[u64;4],
    phenotype_basis_digest:[u64;4],
}
#[derive(Debug, Clone)]
pub(super) struct ContactCloseV1 {
    pub(super) inserts: usize,
    pub(super) retained: usize,
    pub(super) work: Work,
}
fn channel_slot(channel: MotorChannel) -> Result<u8, CpuHostError> {
    Ok(match channel {
        MotorChannel::Locomotion => 0,
        MotorChannel::Orientation => 1,
        MotorChannel::Manipulation => 2,
        MotorChannel::Vocal => 3,
        MotorChannel::Posture => 4,
        MotorChannel::SpeciesSpecific(_) => 5,
    })
}
fn command_bits(command:&ChannelCommand)->Result<contract::CommandBits,CpuHostError>{
    command.validate_contract()?;
    let mut payload=[0u32;32];
    if command.payload.values.len()>32{return Err(invalid_contact());}
    payload[..command.payload.values.len()].copy_from_slice(&command.payload.values);
    let vector=|v:Vec3f|[v.x.to_bits(),v.y.to_bits(),v.z.to_bits()];
    Ok(contract::CommandBits{channel:match command.channel{MotorChannel::Locomotion=>0,MotorChannel::Orientation=>1,MotorChannel::Manipulation=>2,MotorChannel::Vocal=>3,MotorChannel::Posture=>4,MotorChannel::SpeciesSpecific(id)=>0x100+u16::from(id)},primitive:command.primitive.raw(),target:command.target.map(|t|contract::TargetBits{entity:t.entity.map(|v|v.raw()),position:t.position.map(vector)}),direction:vector(command.direction),intensity:command.intensity.raw().to_bits(),duration:command.duration_ticks.raw(),stand_off:command.stand_off_distance.to_bits(),payload_len:command.payload.values.len() as u8,payload,confidence:command.confidence.raw().to_bits(),coordination_group:command.coordination_group})
}
/// Uses the world-owned adaptation law, not an independently authored copy.
fn expected_command(command:&ChannelCommand,record:&alife_world::WorldOrganismRecord,locomotor_capacity:Option<f32>)->Result<contract::CommandBits,CpuHostError>{
    let adapted=alife_world::adapt_motor_channel_for_contact_binding_v1(command,record.embodiment(),locomotor_capacity).map_err(|_|invalid_contact())?;
    command_bits(&adapted)
}
impl ContactBankV1 {
    pub(super) fn fresh(owner: OrganismId) -> Result<Self, CpuHostError> {
        Ok(Self {
            bank: Bank::fresh(owner.raw(), profile_bits()).map_err(|_| invalid_contact())?,
        })
    }
    pub(super) fn is_fresh(&self) -> bool {
        self.bank.len() == 0 && self.bank.last_sequence() == 0
    }
    pub(super) fn retained(&self) -> usize {
        self.bank.len()
    }
    pub(super) fn count(&self, id: TrackedObjectId) -> usize {
        self.bank.count(id.raw())
    }
    pub(super) fn seal(&self) -> [u64; 4] {
        self.bank.seal()
    }
    pub(super) fn validate_boundary(
        &self,
        owner: OrganismId,
        next_sequence: u64,
        world_tick: Tick,
    ) -> Result<(), CpuHostError> {
        if self.bank.owner() != owner.raw()
            || self.bank.profile() != profile_bits()
            || self.bank.last_sequence().checked_add(1) != Some(next_sequence)
            || self.bank.generation() != self.bank.last_sequence()
            || self.bank.last_outcome() > world_tick.raw()
        {
            return Err(invalid_contact());
        }
        Ok(())
    }
    pub(super) fn validate_last(
        &self,
        sequence: u64,
        frame: [u64; 4],
        bundle: [u64; 4],
        source: [u64; 4],
        generation: u64,
        origin: Tick,
        outcome: Tick,
    ) -> Result<(), CpuHostError> {
        let b = self.bank.last_boundary().ok_or_else(invalid_contact)?;
        if b.sequence != sequence
            || b.frame != frame
            || b.bundle != bundle
            || b.source != source
            || b.generation != generation
            || b.origin_tick != origin.raw()
            || b.outcome_tick != outcome.raw()
        {
            return Err(invalid_contact());
        }
        Ok(())
    }
    pub(super) fn prepare(
        &self,
        draft: &PerceptionFrameDraft,
    ) -> Result<ContactFamiliarityV1, CpuHostError> {
        if draft.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
            || draft.tick().raw() < self.bank.last_outcome()
            || draft.grounded_object_slots().len() > 16
        {
            return Err(invalid_contact());
        }
        let mut targets = [0; 16];
        let len = draft.grounded_object_slots().len();
        let mut work = Work::default();
        for (i, s) in draft.grounded_object_slots().iter().enumerate() {
            work.reads += 1;
            for previous in &targets[..i] {
                work.comparisons += 1;
                if *previous == s.tracked_object_id.raw() {
                    return Err(invalid_contact());
                }
            }
            if s.slot_index as usize != i {
                return Err(invalid_contact());
            }
            targets[i] = s.tracked_object_id.raw();
        }
        let values = self
            .bank
            .familiarities(
                draft.organism_id().raw(),
                profile_bits(),
                &targets[..len],
                &mut work,
            )
            .map_err(|_| invalid_contact())?;
        Ok(ContactFamiliarityV1 {
            targets,
            values,
            len,
            work,
            lookup_comparisons: std::cell::Cell::new(0),
        })
    }
    /// Mint only from the immutable prephysical world used for this frame.
    /// At most six selected targets and 1,024 registry records per target.
    pub(super) fn bind_targets(
        &self,
        world: &HeadlessWorld,
        physical_world:&HeadlessWorld,
        frame: &PerceptionFrame,
        bundle: &MotorCommandBundle,
    ) -> Result<ContactTargetBindingsV1, CpuHostError> {
        if world.tick() != frame.tick()
            || frame.tick() != bundle.tick
            || frame.organism_id() != bundle.organism_id
            || self.bank.owner() != bundle.organism_id.raw()
            || world.tracked_objects().per_organism_capacity() > 1024
        {
            return Err(invalid_contact());
        }
        if physical_world.tick()!=bundle.tick{return Err(invalid_contact());}
        let record=physical_world.organism_registry().get(bundle.organism_id).ok_or_else(invalid_contact)?;
        let biology=record.biochemistry();let phenotype=record.phenotype();
        let locomotor_capacity=biology.graph_state().locomotor_capacity(&phenotype.chemistry.biochemical)?.map(|chemical|{
            let organ=biology.body.organ(OrganKind::Locomotor);
            let reserve=(organ.energy/(0.5+0.5*phenotype.body.metabolic_efficiency)).clamp(0.0,1.0);
            chemical*reserve*organ.integrity
        });
        let biology_before_digest=json_digest(b"ALIFE-CONTACT-PREPHYSICAL-BIOLOGY-V1",biology)?;
        let embodiment_basis_digest=json_digest(b"ALIFE-CONTACT-PREPHYSICAL-EMBODIMENT-V1",record.embodiment())?;
        let phenotype_basis_digest=json_digest(b"ALIFE-CONTACT-PREPHYSICAL-PHENOTYPE-V1",&(&phenotype.chemistry.biochemical,phenotype.body.metabolic_efficiency.to_bits()))?;
        let mut expected_commands=[None;6];
        let mut entities = [None; 6];
        let mut tracked = [0; 6];
        let mut work = Work::default();
        work.physiology_helper_calls=1;work.basis_json_hashes=3;
        for command in &bundle.channels {
            let slot = channel_slot(command.channel)? as usize;
            if expected_commands[slot].is_some(){return Err(invalid_contact());}
            expected_commands[slot]=Some(expected_command(command,record,locomotor_capacity)?);
            work.writes+=1;
            work.adaptation_helper_calls+=1;work.payload_clone_calls+=1;
            work.payload_cloned_values+=command.payload.values.len() as u64;
            let Some(entity) = command.target.and_then(|t| t.entity) else {
                continue;
            };
            let physical = world.entity(entity).ok_or_else(invalid_contact)?;
            let key = physical.tracking_provenance.canonical_key();
            let records = world
                .tracked_objects()
                .records_for(bundle.organism_id)
                .ok_or_else(invalid_contact)?;
            let mut found = None;
            let mut visits = 0usize;
            for record in records.take(1025) {
                visits += 1;
                work.reads += 1;
                work.comparisons += 1;
                if record.tracking_key == key {
                    if found.is_some() || record.last_seen_tick != frame.tick() {
                        return Err(invalid_contact());
                    }
                    found = Some(record.tracked_object_id.raw());
                }
            }
            if visits > 1024 {
                return Err(invalid_contact());
            }
            entities[slot] = Some(entity);
            tracked[slot] = found.ok_or_else(invalid_contact)?;
        }
        Ok(ContactTargetBindingsV1 {
            owner: bundle.organism_id,
            tick: bundle.tick,
            sequence: bundle.sequence_id,
            frame: frame.frame_digest().0,
            bundle: bundle.canonical_digest()?,
            entities,
            tracked,
            work,
            expected_commands,
            biology_before_digest,embodiment_basis_digest,phenotype_basis_digest,
        })
    }
    /// Called in the host's staged clone once, after real physics and before
    /// post-action debit/patch close. Source digest must be bound by the NEW
    /// pending owner, not accepted from a checkpoint or foreign sampled action.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn capture_close(
        &mut self,
        frame: &PerceptionFrame,
        bundle: &MotorCommandBundle,
        receipt: &alife_world::HeadlessMotorTransactionReceipt,
        motor_candidates: [Option<u16>; 6],
        generation: u64,
        source_digest: [u64; 4],
        bindings: &ContactTargetBindingsV1,
    ) -> Result<ContactCloseV1, CpuHostError> {
        frame.validate_contract()?;
        bundle.validate_contract()?;
        if frame.organism_id() != bundle.organism_id
            || frame.tick() != bundle.tick
            || frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
            || receipt.bundle != *bundle
            || receipt.outcome_tick.raw()
                != bundle
                    .tick
                    .raw()
                    .checked_add(1)
                    .ok_or_else(invalid_contact)?
            || receipt.biology_before.tick != bundle.tick
            || receipt.biology_after.tick != receipt.outcome_tick
            || bundle.channels.len() > 6
            || receipt.channel_receipts.len() != bundle.channels.len()
        {
            return Err(invalid_contact());
        }
        if bindings.owner != bundle.organism_id
            || bindings.tick != bundle.tick
            || bindings.sequence != bundle.sequence_id
            || bindings.frame != frame.frame_digest().0
            || bindings.bundle != bundle.canonical_digest()?
        {
            return Err(invalid_contact());
        }
        if bindings.biology_before_digest!=json_digest(b"ALIFE-CONTACT-PREPHYSICAL-BIOLOGY-V1",&receipt.biology_before)?||bindings.embodiment_basis_digest==[0;4]||bindings.phenotype_basis_digest==[0;4]{return Err(invalid_contact());}
        let mut work = bindings.work;
        work.basis_json_hashes+=1;
        // Canonical bundle digests deliberately normalize signed zero. Preserve
        // their old semantics, and additionally bind every raw command field.
        for (command,returned) in bundle.channels.iter().zip(&receipt.bundle.channels){
            work.comparisons+=1;
            if !contract::command_matches(&command_bits(command)?,&command_bits(returned)?) {return Err(invalid_contact());}
        }
        let mut events = [None; 6];
        let mut len = 0usize;
        let mut seen = 0u8;
        for actual in &receipt.channel_receipts {
            let slot = channel_slot(actual.command.channel)?;
            if seen & (1 << slot) != 0 {
                return Err(invalid_contact());
            }
            seen |= 1 << slot;
            let mut commanded = None;
            for command in &bundle.channels {
                work.comparisons += 1;
                if command.channel == actual.command.channel {
                    if commanded.is_some() {
                        return Err(invalid_contact());
                    }
                    commanded = Some(command);
                }
            }
            let command = commanded.ok_or_else(invalid_contact)?;
            let expected=bindings.expected_commands[slot as usize].as_ref().ok_or_else(invalid_contact)?;
            work.comparisons+=1;
            if !contract::command_matches(expected,&command_bits(&actual.command)?) {return Err(invalid_contact());}
            // Targetless intrinsic rows, NoManip and recovery channels can close
            // the sequence, but they never create target familiarity evidence.
            let Some(target) = command.target.and_then(|t| t.entity) else {
                continue;
            };
            if bindings.entities[slot as usize] != Some(target) {
                return Err(invalid_contact());
            }
            let index = motor_candidates[slot as usize].ok_or_else(invalid_contact)?;
            let candidate = frame
                .candidates()
                .get(index as usize)
                .ok_or_else(invalid_contact)?;
            let CandidateObservationRef::ObjectSlot(object_index) = candidate.observation else {
                return Err(invalid_contact());
            };
            let mut observed = None;
            for object in frame.grounded_object_slots() {
                work.comparisons += 1;
                if object.slot_index == object_index {
                    if observed.is_some() {
                        return Err(invalid_contact());
                    }
                    observed = Some(object);
                }
            }
            let observed = observed.ok_or_else(invalid_contact)?;
            if candidate.target != command.target.unwrap_or(ActionTarget::NONE) {
                return Err(invalid_contact());
            }
            let phase = match actual.phase {
                alife_world::ActionPhase::Attempt => Phase::Attempt,
                alife_world::ActionPhase::Preparation => Phase::Preparation,
                alife_world::ActionPhase::Completed => Phase::Completed,
            };
            let contact = match actual.physical.contact {
                PhysicalContactKind::None => Contact::None,
                PhysicalContactKind::Touch => Contact::Touch,
                PhysicalContactKind::Collision => Contact::Collision,
                PhysicalContactKind::Blocked => Contact::Blocked,
                PhysicalContactKind::Consumed => Contact::Consumed,
                PhysicalContactKind::Moved => Contact::Moved,
            };
            let kind = match candidate.kind {
                ActionKind::Look => Kind::Look,
                ActionKind::Inspect => Kind::Inspect,
                ActionKind::Interact => Kind::Interact,
                ActionKind::Hold => Kind::Hold,
                _ => Kind::Other,
            };
            let fact = Fact {
                candidate_action: candidate.action_id.raw(),
                command_action: command.primitive.raw(),
                receipt_action: actual.command.primitive.raw(),
                candidate_target: candidate.target.entity.map_or(0, |e| e.raw()),
                command_target: target.raw(),
                receipt_target: actual.physical.target_entity.map_or(0, |e| e.raw()),
                candidate_tracked: observed.tracked_object_id.raw(),
                observed_tracked: bindings.tracked[slot as usize],
                channel: slot,
                command_channel: channel_slot(command.channel)?,
                receipt_channel: slot,
                kind,
                phase,
                contact,
                joint_succeeded: receipt.succeeded,
                release_or_place: actual.grip_transfers.iter().any(|t| {
                    matches!(
                        t.kind,
                        alife_world::GripTransferKind::Released
                            | alife_world::GripTransferKind::Placed
                    )
                }),
            };
            work.comparisons += 1;
            match contract::qualify(fact) {
                Verdict::RejectBinding => return Err(invalid_contact()),
                Verdict::Exclude => continue,
                Verdict::Admit => {}
            }
            let digest = candidate.feature_digest()?.0;
            events[len] = Some(Evidence {
                target: observed.tracked_object_id.raw(),
                candidate_digest: [digest[0], digest[1], 0, 0],
                action: candidate.action_id.raw(),
                channel: slot,
                contact: match contact {
                    Contact::Touch => 1,
                    Contact::Consumed => 2,
                    Contact::Moved => 3,
                    _ => return Err(invalid_contact()),
                },
                kind: candidate.kind.raw(),
            });
            len += 1;
        }
        let mut evidence = [Evidence {
            target: 0,
            candidate_digest: [0; 4],
            action: 0,
            channel: 0,
            contact: 0,
            kind: 0,
        }; 6];
        for (i, e) in events[..len].iter().enumerate() {
            evidence[i] = e.ok_or_else(invalid_contact)?;
        }
        let inserts = self
            .bank
            .close(
                Boundary {
                    owner: bundle.organism_id.raw(),
                    profile: profile_bits(),
                    sequence: bundle.sequence_id.raw(),
                    origin_tick: bundle.tick.raw(),
                    outcome_tick: receipt.outcome_tick.raw(),
                    frame: frame.frame_digest().0,
                    bundle: bundle.canonical_digest()?,
                    source: source_digest,
                    generation,
                },
                &evidence[..len],
                &mut work,
            )
            .map_err(|_| invalid_contact())?;
        Ok(ContactCloseV1 {
            inserts,
            retained: self.bank.len(),
            work,
        })
    }
}
