//! Pure arithmetic for the new owner's bounded semantic memory reservation.
//! Counts are authored semantic operations, never neuron or hardware-instruction counts.
pub(crate) const POLICY: &str = "actual-contact-memory-reserve-actual-debit-v1";
pub(crate) const MAX_MEMORY_OPS: u64 = 16_384;
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Error {
    Overflow,
    Exceeded,
    Unaffordable,
    Rate,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Reservation {
    pub base_q24: u64,
    pub rate_q24: u64,
    pub reserved_q24: u64,
    pub reserved_q16: u32,
    pub available_q16: u32,
}
fn q16(q24: u64) -> Result<u32, Error> {
    u32::try_from(q24.checked_add(128).ok_or(Error::Overflow)? >> 8).map_err(|_| Error::Overflow)
}
impl Reservation {
    pub fn new(base_q24: u64, rate_q24: u64, available_q16: u32) -> Result<Self, Error> {
        // Bind the same existing class-5 memory-context rate in both policies.
        if rate_q24 != 64 {
            return Err(Error::Rate);
        }
        let reserved_q24 = base_q24
            .checked_add(
                MAX_MEMORY_OPS
                    .checked_mul(rate_q24)
                    .ok_or(Error::Overflow)?,
            )
            .ok_or(Error::Overflow)?;
        let reserved_q16 = q16(reserved_q24)?;
        if reserved_q16 > available_q16 {
            return Err(Error::Unaffordable);
        }
        Ok(Self {
            base_q24,
            rate_q24,
            reserved_q24,
            reserved_q16,
            available_q16,
        })
    }
    pub fn settle(self, actual_memory_ops: u64) -> Result<(u64, u32, u32), Error> {
        if actual_memory_ops > MAX_MEMORY_OPS {
            return Err(Error::Exceeded);
        }
        let actual_q24 = self
            .base_q24
            .checked_add(
                actual_memory_ops
                    .checked_mul(self.rate_q24)
                    .ok_or(Error::Overflow)?,
            )
            .ok_or(Error::Overflow)?;
        let actual_q16 = q16(actual_q24)?;
        if actual_q24 > self.reserved_q24 || actual_q16 > self.reserved_q16 {
            return Err(Error::Exceeded);
        }
        Ok((actual_q24, actual_q16, self.available_q16 - actual_q16))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn zero_and_max_actual_settle_under_same_reservation() {
        let r = Reservation::new(1000, 64, 65535).unwrap();
        assert_eq!(r.settle(0).unwrap().0, 1000);
        assert_eq!(r.settle(MAX_MEMORY_OPS).unwrap().0, r.reserved_q24);
    }
    #[test]
    fn above_bound_rejected_without_silent_reprice() {
        assert_eq!(
            Reservation::new(1000, 64, 65535)
                .unwrap()
                .settle(MAX_MEMORY_OPS + 1),
            Err(Error::Exceeded)
        );
    }
    #[test]
    fn insufficient_atp_rejected_before_physics() {
        assert_eq!(Reservation::new(0, 64, 4095), Err(Error::Unaffordable));
        assert!(Reservation::new(0, 64, 4096).is_ok());
    }
    #[test]
    fn malformed_rate_and_overflow_rejected() {
        assert_eq!(Reservation::new(0, 0, 65535), Err(Error::Rate));
        assert_eq!(Reservation::new(u64::MAX, 64, 65535), Err(Error::Overflow));
    }
    #[test]
    fn aggregate_half_up_rounding_is_not_sum_of_rounded_parts() {
        let r = Reservation::new(127, 64, 65535).unwrap();
        assert_eq!(r.settle(1).unwrap().1, 1);
        assert_eq!(r.settle(0).unwrap().1, 0);
    }
    #[test]
    fn every_bounded_actual_debit_is_monotonic_and_covered() {
        let r = Reservation::new(7123, 64, 65535).unwrap();
        let mut previous = 0;
        for n in 0..=MAX_MEMORY_OPS {
            let (_, actual, remaining) = r.settle(n).unwrap();
            assert!(actual >= previous);
            assert!(actual <= r.reserved_q16);
            assert_eq!(actual + remaining, r.available_q16);
            previous = actual;
        }
    }
}
