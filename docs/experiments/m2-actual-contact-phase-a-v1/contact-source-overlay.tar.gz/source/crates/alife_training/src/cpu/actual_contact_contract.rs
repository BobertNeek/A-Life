//! Portable pure admission/identity contracts. Synthetic facts are NOT world proof.
//! The host-only adapter constructs them from an actual returned world transaction.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Phase {
    Attempt,
    Preparation,
    Completed,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Contact {
    None,
    Touch,
    Collision,
    Blocked,
    Consumed,
    Moved,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Kind {
    Look,
    Inspect,
    Interact,
    Hold,
    Other,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct Fact {
    pub candidate_action: u32,
    pub command_action: u32,
    pub receipt_action: u32,
    pub candidate_target: u64,
    pub command_target: u64,
    pub receipt_target: u64,
    pub candidate_tracked: u64,
    pub observed_tracked: u64,
    pub channel: u8,
    pub command_channel: u8,
    pub receipt_channel: u8,
    pub kind: Kind,
    pub phase: Phase,
    pub contact: Contact,
    pub joint_succeeded: bool,
    pub release_or_place: bool,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Verdict {
    Admit,
    Exclude,
    RejectBinding,
}
pub(crate) fn qualify(f: Fact) -> Verdict {
    if f.candidate_action != f.command_action
        || f.command_action != f.receipt_action
        || f.candidate_target == 0
        || f.candidate_target != f.command_target
        || f.candidate_tracked == 0
        || f.candidate_tracked != f.observed_tracked
        || f.channel >= 6
        || f.channel != f.command_channel
        || f.channel != f.receipt_channel
    {
        return Verdict::RejectBinding;
    }
    // Narrow research contract: only successful joint transactions, and only
    // explicitly voluntary target-bound contact kinds. Partial joint success is
    // conservatively excluded because the current channel receipt omits success.
    if !f.joint_succeeded
        || f.phase != Phase::Completed
        || f.release_or_place
        || !matches!(
            f.kind,
            Kind::Look | Kind::Inspect | Kind::Interact | Kind::Hold
        )
        || !matches!(
            f.contact,
            Contact::Touch | Contact::Consumed | Contact::Moved
        )
        || f.command_action == 212
    {
        return Verdict::Exclude;
    }
    if f.command_target != f.receipt_target {
        return Verdict::RejectBinding;
    }
    Verdict::Admit
}

/// Exact complete command identity after the existing world adaptation.
/// All floats are compared by bits, including signed zero. No approximate match.
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub(crate) struct TargetBits {pub entity:Option<u64>,pub position:Option<[u32;3]>}
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub(crate) struct CommandBits {
    pub channel:u16,pub primitive:u32,pub target:Option<TargetBits>,
    pub direction:[u32;3],pub intensity:u32,pub duration:u32,pub stand_off:u32,
    pub payload_len:u8,pub payload:[u32;32],pub confidence:u32,pub coordination_group:u8,
}
pub(crate) fn command_matches(expected:&CommandBits,actual:&CommandBits)->bool {expected==actual}

pub(crate) const NEURAL_SCHEMA: u32 = 0x4143_0001;
pub(crate) const CANONICAL_SCHEMA: u16 = 0x4143;
pub(crate) const OUTER_MAGIC: &[u8] =
    b"ALIFE-ACTUAL-CONTACT-M2-HOST\0V1\0FRESH-ONLY\0PROFILE5\0BANK1\0WORK1\0";
pub(crate) const OWNER_DOMAIN: &str = "m2-actual-contact-fresh-owner-v1";
pub(crate) const SOURCE_DOMAIN: &str = "m2-actual-contact-forward-binding-v1";
pub(crate) const ACTION_DOMAIN: &str = "m2-actual-contact-action-v1";
pub(crate) const PROOF_DOMAIN: &str = "m2-actual-contact-draw-proof-v1";
pub(crate) const SCORE_DOMAIN: &str = "m2-actual-contact-score-v1";
pub(crate) const RNG_DOMAIN: u32 = 0x4143_5031;
pub(crate) const PENDING_DOMAIN: &str = "m2-actual-contact-pending-v1";
#[derive(Debug, Clone, Copy)]
pub(crate) struct Identity<'a> {
    pub outer: &'a [u8],
    pub canonical: u16,
    pub neural: u32,
    pub owner: &'a str,
    pub source: &'a str,
    pub action: &'a str,
    pub proof: &'a str,
    pub score: &'a str,
    pub rng: u32,
    pub pending: &'a str,
}
pub(crate) fn validate_identity(i: Identity<'_>) -> bool {
    i.outer == OUTER_MAGIC
        && i.canonical == CANONICAL_SCHEMA
        && i.neural == NEURAL_SCHEMA
        && i.owner == OWNER_DOMAIN
        && i.source == SOURCE_DOMAIN
        && i.action == ACTION_DOMAIN
        && i.proof == PROOF_DOMAIN
        && i.score == SCORE_DOMAIN
        && i.rng == RNG_DOMAIN
        && i.pending == PENDING_DOMAIN
}
/// Constructor admission only, not a checkpoint-migration helper. New inner
/// schema and pending ownership must be created at birth by their own constructor.
pub(crate) fn admit_fresh(
    i: Identity<'_>,
    generation: u64,
    next_sequence: u64,
    contacts: usize,
    has_last: bool,
) -> bool {
    validate_identity(i) && generation == 0 && next_sequence == 1 && contacts == 0 && !has_last
}
#[cfg(test)]
mod tests {
    use super::*;
    fn fact() -> Fact {
        Fact {
            candidate_action: 213,
            command_action: 213,
            receipt_action: 213,
            candidate_target: 8,
            command_target: 8,
            receipt_target: 8,
            candidate_tracked: 9,
            observed_tracked: 9,
            channel: 2,
            command_channel: 2,
            receipt_channel: 2,
            kind: Kind::Interact,
            phase: Phase::Completed,
            contact: Contact::Touch,
            joint_succeeded: true,
            release_or_place: false,
        }
    }
    fn identity() -> Identity<'static> {
        Identity {
            outer: OUTER_MAGIC,
            canonical: CANONICAL_SCHEMA,
            neural: NEURAL_SCHEMA,
            owner: OWNER_DOMAIN,
            source: SOURCE_DOMAIN,
            action: ACTION_DOMAIN,
            proof: PROOF_DOMAIN,
            score: SCORE_DOMAIN,
            rng: RNG_DOMAIN,
            pending: PENDING_DOMAIN,
        }
    }
    #[test]
    fn completed_voluntary_touch_admitted() {
        assert_eq!(qualify(fact()), Verdict::Admit);
    }
    #[test]
    fn preparation_and_attempt_excluded() {
        for phase in [Phase::Attempt, Phase::Preparation] {
            let mut f = fact();
            f.phase = phase;
            assert_eq!(qualify(f), Verdict::Exclude);
        }
    }
    #[test]
    fn failure_and_partial_joint_failure_excluded() {
        let mut f = fact();
        f.joint_succeeded = false;
        f.receipt_target = 0;
        assert_eq!(qualify(f), Verdict::Exclude);
    }
    #[test]
    fn release_place_and_no_manip_excluded() {
        let mut f = fact();
        f.release_or_place = true;
        assert_eq!(qualify(f), Verdict::Exclude);
        for a in [212] {
            let mut f = fact();
            f.candidate_action = a;
            f.command_action = a;
            f.receipt_action = a;
            assert_eq!(qualify(f), Verdict::Exclude);
        }
    }
    #[test]
    fn incidental_collision_blocked_and_no_contact_excluded() {
        for contact in [Contact::None, Contact::Collision, Contact::Blocked] {
            let mut f = fact();
            f.contact = contact;
            assert_eq!(qualify(f), Verdict::Exclude);
        }
    }
    #[test]
    fn supported_intent_and_contact_kinds_are_explicit() {
        for kind in [Kind::Look, Kind::Inspect, Kind::Interact, Kind::Hold] {
            for contact in [Contact::Touch, Contact::Consumed, Contact::Moved] {
                let mut f = fact();
                f.kind = kind;
                f.contact = contact;
                assert_eq!(qualify(f), Verdict::Admit);
            }
        }
        let mut f = fact();
        f.kind = Kind::Other;
        assert_eq!(qualify(f), Verdict::Exclude);
    }
    #[test]
    fn target_action_tracked_and_channel_mismatches_rejected() {
        for n in 0..9 {
            let mut f = fact();
            match n {
                0 => f.command_action = 214,
                1 => f.receipt_action = 214,
                2 => f.command_target = 7,
                3 => f.receipt_target = 7,
                4 => f.candidate_target = 0,
                5 => f.observed_tracked = 10,
                6 => f.candidate_tracked = 0,
                7 => f.command_channel = 1,
                _ => f.receipt_channel = 1,
            }
            assert_eq!(qualify(f), Verdict::RejectBinding);
        }
        let mut payload=[0u32;32];payload[0]=17;payload[1]=23;
        let command=CommandBits{channel:2,primitive:213,target:Some(TargetBits{entity:Some(8),position:Some([0,0,0])}),direction:[0,0,1f32.to_bits()],intensity:1f32.to_bits(),duration:1,stand_off:0.1f32.to_bits(),payload_len:2,payload,confidence:0.5f32.to_bits(),coordination_group:1};
        assert!(command_matches(&command,&command));
        // Every previously omitted field and each vector axis is independently
        // rejected; these are pure command-bit negatives, not fabricated receipts.
        for field in 0..15 {
            let mut altered=command;
            match field {
                0=>altered.direction[0]=(-0.0f32).to_bits(),
                1=>altered.direction[1]=1f32.to_bits(),
                2=>altered.direction[2]=0.5f32.to_bits(),
                3=>altered.intensity=0.5f32.to_bits(),
                4=>altered.stand_off=0.2f32.to_bits(),
                5=>altered.confidence=0.25f32.to_bits(),
                6=>altered.coordination_group=2,
                7=>altered.channel=1,
                8=>altered.primitive=211,
                9=>altered.duration=2,
                10=>altered.payload[0]^=1,
                11=>altered.payload_len=3,
                12=>altered.target=None,
                13=>altered.target.as_mut().unwrap().entity=Some(10),
                _=>altered.target.as_mut().unwrap().position.as_mut().unwrap()[0]=(-0.0f32).to_bits(),
            }
            assert!(!command_matches(&command,&altered));
        }

        // Calls the ACTUAL authoritative world adaptation helper. These bounded
        // synthetic values do not construct a world or demonstrate real contact.
        use alife_core::{EmbodimentState,WorldEntityId,Tick,MotorChannel,ActionId,ChannelCommand,Intensity,DurationTicks,Confidence,Vec3f};
        let mut body=EmbodimentState::reference(WorldEntityId(1),Tick::ZERO).unwrap();
        body.replace_calibration(Tick::new(1),vec![0.;26],vec![-1.;11],vec![-1.;16]).unwrap();
        let cases=[(MotorChannel::Locomotion,103,None,0.375f32),(MotorChannel::Locomotion,103,Some(0.25f32),0.09375f32),(MotorChannel::Orientation,606,Some(0.25f32),0.375f32),(MotorChannel::Vocal,400,Some(0.25f32),0.5f32),(MotorChannel::Manipulation,210,Some(0.25f32),0.5f32)];
        for (channel,primitive,attenuation,expected) in cases {
            let command=ChannelCommand::new(channel,ActionId(primitive),None,Vec3f::new(0.,0.,1.),Intensity::new(1.).unwrap(),DurationTicks(1),0.,Confidence::new(1.).unwrap(),0).unwrap();
            let actual=alife_world::adapt_motor_channel_for_contact_binding_v1(&command,&body,attenuation).unwrap();
            assert!(actual.intensity.raw().to_bits()==expected.to_bits());
            let mut restored=actual;restored.intensity=command.intensity;assert!(restored==command);
        }

    }
    #[test]
    fn new_identity_and_fresh_admission() {
        assert!(validate_identity(identity()));
        assert!(admit_fresh(identity(), 0, 1, 0, false));
    }
    #[test]
    fn old_outer_and_inner_neural_rejected() {
        let mut i = identity();
        i.outer = b"ALIFE-CHANNEL-NATIVE-M2-HOST\0V1\0";
        assert!(!validate_identity(i));
        i = identity();
        i.canonical = 0x434e;
        assert!(!validate_identity(i));
        i = identity();
        i.neural = 0x434e_0001;
        assert!(!validate_identity(i));
    }
    #[test]
    fn old_action_proof_source_rng_pending_rejected() {
        for n in 0..7 {
            let mut i = identity();
            match n {
                0 => i.owner = "m2-channel-native-fresh-owner-v3",
                1 => i.source = "m2-channel-native-forward-binding-v3",
                2 => i.action = "m2-channel-native-action-v3",
                3 => i.proof = "m2-channel-native-draw-proof-v3",
                4 => i.score = "m2-channel-native-score-v3",
                5 => i.rng = 0x434e_5033,
                _ => i.pending = "ChannelNative",
            }
            assert!(!validate_identity(i));
        }
    }
    #[test]
    fn empty_bank_wrapping_old_inner_is_not_birth() {
        let mut i = identity();
        i.neural = 0x434e_0001;
        assert!(!admit_fresh(i, 0, 1, 0, false));
        assert!(!admit_fresh(identity(), 1, 2, 0, true));
        assert!(!admit_fresh(identity(), 0, 1, 1, false));
    }
    #[test]
    fn owned_domains_and_schemas_are_distinct() {
        assert_ne!(NEURAL_SCHEMA, 0x434e_0001);
        assert_ne!(CANONICAL_SCHEMA, 0x434e);
        assert_ne!(RNG_DOMAIN, 0x434e_5033);
    }
}
