//! DRAFT AND UNREGISTERED. No typecheck or execution qualification claimed.
//! Do not register/run until separate reviewed qualification permit replaces the
//! existing generic fail-closed guard. Never bypass it inside this fixture.
//! Frozen inventory: recipe::build once (including its temporary seed game),
//! founder new once + sentinel founder from_checkpoint once, research new-game
//! once, blank scenario build/registration once, ONE fresh actual-contact host
//! with ONE toy, TWO successful cold restores from the same one-interval prefix.
//! Exactly FOUR observed source/world/biology intervals: prefix Play, warm Play,
//! cold Play, matched cold NoManip. No other forward, probe, update, adaptive
//! retry, extension, new resident or source execution. Each cold restore includes
//! the normal internal founder reconstruction, not an optimizer update.
//! Actual pending cross-owner staging cannot be tested after close and is deferred;
//! no synthetic action, pending state, contact or patch is fabricated.
use super::*;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
use serde_json::{json, Value};
use std::cell::RefCell;
#[allow(dead_code)]
#[path = "grouped_host_fixture.rs"]
mod recipe;
const FIXTURE_SEED: u64 = 0x0043_484e_4c48_5331;
const CONTROL_MAGIC: &[u8] = b"ALIFE-ACTUAL-CONTACT-CONTROLLED-PHYSICS\0V1\0";
const CONTROL_POLICY: &str =
    "actual-contact-controlled-physics-v1;not-autonomous;actor-credit-forbidden";
#[derive(Clone)]
struct Witness {
    tracked: TrackedObjectId,
    play_index: usize,
    count_before: usize,
    seal_before: [u64; 4],
    representative_index: u16,
    representative_action: u32,
    focal_novelty: f32,
    lane44: f32,
    lane45: f32,
    scores: ActualContactScoresV1,
}
thread_local! { static WITNESS: RefCell<Option<Witness>> = const { RefCell::new(None) }; }
struct Controlled<const PLAY: bool>;
impl<const PLAY: bool> GroupedPolicyStrategy for Controlled<PLAY> {
    type Action = ActualContactActionV1;
    const OPTIONAL: bool = false;
    const ACTUAL_CONTACT: bool = true;
    const MAGIC: &'static [u8] = CONTROL_MAGIC;
    const LINEAGE: &'static str = "fresh-actual-contact-controlled-physics-v1/no-import";
    const POLICY: &'static str = CONTROL_POLICY;
    fn select(
        f: &CpuFoundationTrainer,
        r: &mut Resident,
        frame: &PerceptionFrame,
        output: &CpuDecisionOutput,
        seed: u32,
        counter: u32,
        t: f64,
    ) -> Result<Selection<Self::Action>, CpuHostError> {
        let source = r.neural.actual_contact_source()?.clone();
        // Real new-owner pending source rejects old-policy access without a forward.
        assert!(r.neural.channel_native_source().is_err());
        assert!(r.neural.optional_vocal_source().is_err());
        let state = r
            .grouped
            .as_mut()
            .ok_or(CpuHostError::State("missing control owner"))?;
        if state.channel_native.is_some()
            || state.optional_vocal.is_some()
            || state.last_action.is_some()
            || state
                .actual_contact
                .as_ref()
                .is_none_or(|s| s.schema != CHANNEL_RESIDENT)
        {
            return Err(CpuHostError::State("control owner mismatch"));
        }
        let native = &state
            .motor
            .last_receipt
            .as_ref()
            .ok_or(CpuHostError::State("missing source"))?
            .native
            .scores;
        let scores =
            ActualContactScoresV1::bind_native(f.phenotype(), frame, native, source.clone())?;
        let action = scores.controlled_physics_fixture(PLAY, seed, counter, t)?;
        let (index, motors) = scores.physical_selection(&action)?;
        assert!(scores.native_score_gradient(&action).is_err());
        // Exact real new action bytes through old decoder/evaluator, no mutation.
        let old_scores =
            crate::cpu::ChannelNativeScoresV1::bind_native(f.phenotype(), frame, native, source)?;
        // Exactly ONE extra production-policy draw/evaluation from this same
        // observed prefix source. It is never dispatched and causes no forward.
        if counter==0 {
            let production=scores.sample_native(seed,counter,t)?;
            let old_production:crate::cpu::ChannelNativeActionV1=serde_json::from_slice(&serde_json::to_vec(&production)?)?;
            assert!(old_scores.physical_selection(&old_production).is_err());
        }
        if let Ok(old_action) = serde_json::from_slice::<crate::cpu::ChannelNativeActionV1>(
            &serde_json::to_vec(&action)?,
        ) {
            assert!(old_scores.physical_selection(&old_action).is_err());
        }
        let (play_index, play) = frame
            .candidates()
            .iter()
            .enumerate()
            .find(|(_, c)| c.action_id == HeadlessActionIds::PLAY)
            .ok_or(CpuHostError::State("missing grounded Play row"))?;
        let CandidateObservationRef::ObjectSlot(slot) = play.observation else {
            return Err(CpuHostError::State("Play not object grounded"));
        };
        let tracked = frame
            .grounded_object_slots()
            .get(slot as usize)
            .ok_or(CpuHostError::State("missing toy slot"))?
            .tracked_object_id;
        let replay = output
            .replay_tick
            .candidates
            .get(play_index)
            .ok_or(CpuHostError::State("missing actual replay row"))?;
        let owner = state.actual_contact.as_mut().unwrap();
        let witness = Witness {
            tracked,
            play_index,
            count_before: owner.contacts.count(tracked),
            seal_before: owner.contacts.seal(),
            representative_index: index,
            representative_action: frame.candidates()[index as usize].action_id.raw(),
            focal_novelty: frame.sensory().channels.novelty_signal.raw(),
            lane44: replay.decoder_inputs[44],
            lane45: replay.decoder_inputs[45],
            scores: scores.clone(),
        };
        WITNESS.with(|s| {
            let mut s = s.borrow_mut();
            assert!(s.is_none());
            *s = Some(witness);
        });
        owner.last = Some(ActualContactSelectionV1 {
            scores,
            action: action.clone(),
        });
        Ok((action, index, motors, None))
    }
    fn stage(
        r: &mut Resident,
        p: &BrainPhenotype,
        a: &Self::Action,
        b: CpuDecisionBinding,
    ) -> Result<(), CpuHostError> {
        ActualContactPolicy::stage(r, p, a, b)
    }
    fn close(
        n: &mut CpuOrganismState,
        f: &CpuFoundationTrainer,
        p: &ExperiencePatch,
        r: &NeuralReceptorFrame,
    ) -> Result<(), CpuHostError> {
        ActualContactPolicy::close(n, f, p, r)
    }
}
fn construct_one_fresh_host_with_toy() -> (CpuGroupedM2HostV1, PhenotypeCompilerInputs) {
    let recipe = recipe::build(FIXTURE_SEED, true).unwrap();
    let mut founder = CpuFoundationTrainer::new(
        recipe.phenotype.clone(),
        recipe.asset.clone(),
        StageTrainableMask::recurrent_only(&recipe.phenotype).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    let mut optimizer = founder.checkpoint();
    optimizer.optimizer_step = 23;
    optimizer.update_ages[0] = 23;
    optimizer.first_moment[0] = 0.03125;
    optimizer.second_moment[0] = 0.0625;
    founder =
        CpuFoundationTrainer::from_checkpoint(recipe.phenotype.clone(), recipe.asset, optimizer)
            .unwrap();
    assert!(founder.phenotype().synapses().iter().enumerate().filter(|(_, s)|
        matches!(s.kind(), CompiledSynapseKind::Decoder(c) if c.head() == DecoderHeadKind::SpeechPayload))
        .all(|(i, _)| founder.weights()[i].to_bits() == 0_f32.to_bits()));
    let mut game =
        create_grounded_drive_research_new_game(&recipe.config, &recipe.genotype).unwrap();
    let newborn = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    let mut blank = HeadlessScenarioBuilder::new(FIXTURE_SEED)
        .agent("learner", newborn.organism_id(), Vec3f::ZERO)
        .build()
        .unwrap();
    blank
        .register_grounded_drive_research_record(newborn)
        .unwrap();
    game.world = blank;
    let inputs = recipe.inputs;
    let (host, ()) = CpuGroupedM2HostV1::new_prepared_policy::<Controlled<true>, _, String>(
        game,
        founder,
        inputs.clone(),
        (FIXTURE_SEED ^ (FIXTURE_SEED >> 32)) as u32,
        MediationModeV1::Full,
        |world| {
            let (_, entity) = world.organism_entity_ids()[0];
            let pos = world.entity(entity).ok_or("missing fresh body")?.position;
            world
                .spawn_toy(
                    "controlled-fixed-activity-toy",
                    Vec3f::new(pos.x + 0.1, pos.y, pos.z),
                    false,
                )
                .map_err(|e| e.to_string())?;
            Ok(())
        },
    )
    .unwrap();
    (host, inputs)
}
fn wire(h: &CpuGroupedM2HostV1) -> Vec<u8> {
    let payload = h.checkpoint_payload::<Controlled<true>>().unwrap();
    let mut bytes = CONTROL_MAGIC.to_vec();
    bytes.extend(serde_json::to_vec(&payload).unwrap());
    bytes
}
fn restore_prefix(bytes: &[u8], inputs: &PhenotypeCompilerInputs) -> CpuGroupedM2HostV1 {
    let value: Value = serde_json::from_slice(bytes.strip_prefix(CONTROL_MAGIC).unwrap()).unwrap();
    assert!(value["policy"] == CONTROL_POLICY);
    assert!(value["source_lineage"] == Controlled::<true>::LINEAGE);
    let mut payload: GroupedPayloadV1 = serde_json::from_value(value).unwrap();
    payload.restore_sampler_bits().unwrap();
    CpuGroupedM2HostV1::restore_payload::<Controlled<true>>(
        payload,
        inputs,
        MediationModeV1::Full,
        bytes.to_vec(),
    )
    .unwrap()
}
fn frozen(h: &CpuGroupedM2HostV1) -> Vec<u8> {
    let r = h.host.residents.values().next().unwrap();
    let n = r.neural.checkpoint().unwrap();
    serde_json::to_vec(&(
        h.founder.checkpoint(),
        n.lifetime,
        n.fast,
        n.eligibility,
        n.weight_generation,
        n.neural.dendrites,
        r.v11.checkpoint(),
    ))
    .unwrap()
}
fn phase_name(p: ActionPhase) -> &'static str {
    match p {
        ActionPhase::Attempt => "Attempt",
        ActionPhase::Preparation => "Preparation",
        ActionPhase::Completed => "Completed",
    }
}
fn contact_name(c: PhysicalContactKind) -> &'static str {
    match c {
        PhysicalContactKind::None => "None",
        PhysicalContactKind::Touch => "Touch",
        PhysicalContactKind::Collision => "Collision",
        PhysicalContactKind::Blocked => "Blocked",
        PhysicalContactKind::Consumed => "Consumed",
        PhysicalContactKind::Moved => "Moved",
    }
}
fn memory_write_name(state: &GroupedResidentV1) -> &'static str {
    // Only an allowlisted enum label leaves this transient serialization.
    let Some(proof) = state.memory_proofs.last() else {
        return "Unavailable";
    };
    let value = serde_json::to_value(proof).unwrap();
    let kind = &value["write"]["kind"];
    for name in [
        "Inserted",
        "Evicted",
        "Merged",
        "IgnoredLowInformation",
        "IgnoredLowerRetention",
    ] {
        if kind.as_str() == Some(name) || kind.as_object().is_some_and(|v| v.contains_key(name)) {
            return name;
        }
    }
    "Unavailable"
}
fn interval<const PLAY: bool>(
    h: &mut CpuGroupedM2HostV1,
    label: &'static str,
    ordinal: u32,
) -> (Value, Vec<u8>, Witness) {
    let id = h
        .world()
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .organism_id();
    let before = *h
        .world()
        .organism_registry()
        .get(id)
        .unwrap()
        .biochemistry();
    let generation = h.host.residents[&id.raw()]
        .neural
        .checkpoint()
        .unwrap()
        .dispatch_generation;
    // This remains blocked until the separately reviewed qualification permit.
    let observed = h
        .host
        .grouped_policy_step_observed::<Controlled<PLAY>>(&h.founder, 0.73)
        .unwrap();
    let witness = WITNESS.with(|s| s.borrow_mut().take()).unwrap();
    assert!(observed.step.decisions.len() == 1 && observed.world_receipts.len() == 1);
    let d = &observed.step.decisions[0];
    let actual = &observed.world_receipts[0];
    let object_novelty=d.patch.pre_action().cognitive_context.as_ref()
        .and_then(|c|c.peripheral.summaries.iter().find(|s|s.identity==StableFocusIdentity::TrackedObject(witness.tracked)))
        .expect("missing sealed predecision toy novelty").salience.novelty.raw();
    let actual_lanes = d.actual_contact_input_lanes.as_ref().unwrap();
    assert!(witness.play_index < usize::from(actual_lanes.count));
    let [lane44_bits, lane45_bits] = actual_lanes.lane_bits[witness.play_index];
    assert!(lane44_bits == witness.lane44.to_bits() && lane45_bits == witness.lane45.to_bits());
    assert!(d.motor.native.core.source_execution_count == 1);
    assert!(d.motor.native.core.final_generation == generation + 1);
    assert!(actual.biology_before == before);
    let after = *h
        .world()
        .organism_registry()
        .get(id)
        .unwrap()
        .biochemistry();
    assert!(actual.biology_after.tick.raw() == before.tick.raw() + 1);
    assert!(after.tick == observed.step.tick_after && after.tick.raw() == before.tick.raw() + 1);
    assert!(d.physical.operation == Some(RecoveryOperationV1::AwakeRest));
    assert!(d.physical.sleep_recovery == 0. && d.physical.actual_displacement == Vec3f::ZERO);
    assert!(actual
        .bundle
        .channels
        .iter()
        .all(|c| c.channel != MotorChannel::Vocal));
    let manipulation = actual
        .channel_receipts
        .iter()
        .find(|c| c.command.channel == MotorChannel::Manipulation)
        .unwrap();
    assert!(
        manipulation.command.primitive
            == if PLAY {
                HeadlessActionIds::PLAY
            } else {
                HeadlessActionIds::NO_MANIPULATION
            }
    );
    assert!(d.patch.decision().selected_action.action_id.raw() == witness.representative_action);
    let state = h.host.residents[&id.raw()].grouped.as_ref().unwrap();
    let owner = state.actual_contact.as_ref().unwrap();
    let count_after = owner.contacts.count(witness.tracked);
    let work = owner.contact_work.as_ref().unwrap();
    assert!(
        work.memory_ops <= work.reserved_memory_ops
            && work.reserved_memory_ops == 16_384
            && work.memory_rate_q24 == 64
    );
    assert!(!work.administration_price_qualified);
    assert!(h.host.residents[&id.raw()]
        .neural
        .actual_contact_source()
        .is_err());
    let displacement = d.physical.actual_displacement;
    for value in [
        object_novelty,
        witness.focal_novelty,
        witness.lane44,
        witness.lane45,
        actual.body_event.play_stimulation,
        actual.body_event.investigation,
        actual.body_event.perceived_novelty,
        manipulation.play_stimulation,
        manipulation.investigation,
        d.physical.awake_recovery,
        d.physical.sleep_recovery,
        before.body.energy,
        after.body.energy,
        before.homeostasis.drives.extension[0],
        after.homeostasis.drives.extension[0],
        displacement.x,
        displacement.y,
        displacement.z,
    ] {
        assert!(value.is_finite());
    }
    let row = json!({"label":label,"ordinal":ordinal,"tick_before":before.tick.raw(),"tick_after":after.tick.raw(),
        "generation_before":generation,"generation_after":d.motor.native.core.final_generation,
        "representative_index":witness.representative_index,"representative_action":witness.representative_action,
        "original_memory_write":memory_write_name(state),
        "original_memory_action":state.memory_proofs.last().map(|p|p.query().action_id().raw()),
        "original_memory_action_kind":state.memory_proofs.last().map(|p|p.query().action_kind().raw()),"toy_tracked_id":witness.tracked.raw(),
        "retained_target_count_before":witness.count_before,"retained_target_count_after":count_after,
        "bank_digest_before":witness.seal_before,"bank_digest_after":owner.contacts.seal(),
        "phase":phase_name(manipulation.phase),"contact":contact_name(manipulation.physical.contact),
        "manipulation_primitive":manipulation.command.primitive.raw(),
        "command_target_entity":manipulation.command.target.and_then(|t|t.entity).map(|e|e.raw()),
        "physical_target_entity":manipulation.physical.target_entity.map(|e|e.raw()),
        "joint_succeeded":actual.succeeded,"actual_intensity":manipulation.command.intensity.raw(),
        "play_selected":PLAY,"object_novelty":object_novelty,"focal_novelty":witness.focal_novelty,
        "actual_replay_lane44":f32::from_bits(lane44_bits),"actual_replay_lane45":f32::from_bits(lane45_bits),"lanes_are_runtime_readout":true,
        "channel_stimulation":manipulation.play_stimulation,"channel_investigation":manipulation.investigation,
        "stimulation":actual.body_event.play_stimulation,"investigation":actual.body_event.investigation,
        "perceived_novelty":actual.body_event.perceived_novelty,"awake_dose":d.physical.awake_recovery,"sleep_dose":d.physical.sleep_recovery,
        "operation":"AwakeRest","sleep_phase":match d.sleep_phase {SleepPhase::Awake=>"Awake",SleepPhase::EnteringSleep=>"EnteringSleep",SleepPhase::Consolidating=>"Consolidating",SleepPhase::Waking=>"Waking",SleepPhase::ForcedRecoverySleep=>"ForcedRecoverySleep"},
        "displacement":[displacement.x,displacement.y,displacement.z],"energy_before":before.body.energy,"energy_after":after.body.energy,
        "boredom_before":before.homeostasis.drives.extension[0],"boredom_after":after.homeostasis.drives.extension[0],
        "actual_semantic_memory_ops":work.memory_ops,"reserved_semantic_memory_ops":work.reserved_memory_ops,
        "memory_rate_q24":work.memory_rate_q24,"administration_price_qualified":false,
        "source_executions":1,"world_intervals":1,"biology_intervals":1,"optimizer_updates":0});
    println!("ACTUAL_CONTACT_FIXED4_INTERVAL_V1 {}", row);
    (
        row,
        serde_json::to_vec(&(&d.action, &d.patch, &d.motor, &d.biological_emissions)).unwrap(),
        witness,
    )
}
#[test]
fn actual_contact_fixed_four_intervals_one_prefix_play_warm_cold_nomani_v1() {
    let (mut warm, inputs) = construct_one_fresh_host_with_toy();
    let frozen_initial = frozen(&warm);
    let (prefix_row, _, prefix_witness) = interval::<true>(&mut warm, "prefix_play", 0);
    assert!(frozen(&warm) == frozen_initial);
    let prefix = wire(&warm);
    assert!(CpuChannelNativeM2HostCheckpointV1::decode(&prefix).is_err());
    let mut cold_play = restore_prefix(&prefix, &inputs);
    let mut cold_no_manip = restore_prefix(&prefix, &inputs);
    assert!(wire(&cold_play) == prefix && wire(&cold_no_manip) == prefix);
    let (warm_row, warm_evidence, warm_witness) = interval::<true>(&mut warm, "warm_play", 1);
    let (cold_row, cold_evidence, cold_witness) = interval::<true>(&mut cold_play, "cold_play", 2);
    let (quiet_row, _, quiet_witness) = interval::<false>(&mut cold_no_manip, "cold_no_manip", 3);
    assert!(warm_evidence == cold_evidence && wire(&warm) == wire(&cold_play));
    for key in [
        "energy_before",
        "energy_after",
        "awake_dose",
        "sleep_dose",
        "stimulation",
        "investigation",
        "phase",
        "contact",
        "boredom_before",
        "boredom_after",
        "object_novelty",
        "focal_novelty",
        "actual_replay_lane44",
        "actual_replay_lane45",
        "retained_target_count_before",
        "retained_target_count_after",
        "bank_digest_before",
        "bank_digest_after",
        "actual_semantic_memory_ops",
        "reserved_semantic_memory_ops",
    ] {
        assert!(warm_row[key] == cold_row[key]);
    }
    assert!(
        warm_row["energy_before"] == quiet_row["energy_before"]
            && warm_row["boredom_before"] == quiet_row["boredom_before"]
    );
    assert!(
        warm_witness.tracked == cold_witness.tracked
            && warm_witness.tracked == quiet_witness.tracked
    );
    // Real different-generation source is rejected, with no probe/extra forward.
    assert!(warm_witness
        .scores
        .validate_source(prefix_witness.scores.source())
        .is_err());
    assert!(prefix_witness
        .scores
        .validate_source(warm_witness.scores.source())
        .is_err());
    assert!(
        frozen(&warm) == frozen_initial
            && frozen(&cold_play) == frozen_initial
            && frozen(&cold_no_manip) == frozen_initial
    );
    // Conditional mechanism only: retained evidence persists into each same-prefix
    // source. No asserted contact, fixed novelty, stimulation floor or benefit.
    if prefix_row["retained_target_count_after"].as_u64() == Some(1) {
        assert!(
            warm_witness.count_before == 1
                && cold_witness.count_before == 1
                && quiet_witness.count_before == 1
        );
    }
    println!(
        "ACTUAL_CONTACT_FIXED4_COMPLETE_V1 {}",
        json!({"fresh_hosts":1,"toy_spawns":1,"successful_cold_restores":2,
        "prefix_intervals":1,"treatment_intervals":3,"source_executions":4,"world_intervals":4,"biology_intervals":4,
        "optimizer_updates":0,"probe_forwards":0,"production_negative_draw_calls":1,"warm_cold_complete_equal":true,
        "pending_cross_owner_staging_negative":"deferred_no_extra_forward","contact_value_policy":"UnknownJointValue"})
    );
}
