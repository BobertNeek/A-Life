//! Unactivated actual-contact owner. Public execution fails closed until authority/work integration.
//! No old host conversion, reset, imported checkpoint, or gradient entry point.
use super::*;
type Selection<A> = (A, u16, [Option<u16>; 6], Option<SpeechMotorPayload>);
use crate::cpu::{ActualContactActionV1, ActualContactScoresV1, ACTUAL_CONTACT_POLICY_V1};
const CHANNEL_MAGIC: &[u8] = crate::cpu::actual_contact_contract::OUTER_MAGIC;
const MAX_CHECKPOINT_BYTES: usize = 128 * 1024 * 1024;
const CHANNEL_LINEAGE: &str = "fresh-actual-contact-m2-host-v1/class5/no-historical-import";
pub(super) const CHANNEL_RESIDENT: &str = crate::cpu::actual_contact_contract::OWNER_DOMAIN;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(in crate::cpu::host) struct ActualContactResidentV1 {
    pub(in crate::cpu::host) contacts: crate::cpu::host::actual_contact_bridge::ContactBankV1,
    pub(in crate::cpu::host) contact_work:
        Option<crate::cpu::host::actual_contact_work::ContactMemoryWorkReceiptV1>,
    pub(super) schema: String,
    pub(super) last: Option<ActualContactSelectionV1>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct ActualContactSelectionV1 {
    pub(super) scores: ActualContactScoresV1,
    pub(super) action: ActualContactActionV1,
}
impl ActualContactResidentV1 {
    pub(super) fn fresh(owner: OrganismId) -> Result<Self, CpuHostError> {
        Ok(Self {
            contacts: crate::cpu::host::actual_contact_bridge::ContactBankV1::fresh(owner)?,
            contact_work: None,
            schema: CHANNEL_RESIDENT.into(),
            last: None,
        })
    }
    pub(super) fn is_fresh(&self) -> bool {
        self.schema == CHANNEL_RESIDENT
            && self.last.is_none()
            && self.contacts.is_fresh()
            && self.contact_work.is_none()
    }
}
pub(super) struct ActualContactPolicy;
impl GroupedPolicyStrategy for ActualContactPolicy {
    type Action = ActualContactActionV1;
    const OPTIONAL: bool = false;
    const ACTUAL_CONTACT: bool = true;
    const MAGIC: &'static [u8] = CHANNEL_MAGIC;
    const LINEAGE: &'static str = CHANNEL_LINEAGE;
    const POLICY: &'static str = ACTUAL_CONTACT_POLICY_V1;
    fn select(
        founder: &CpuFoundationTrainer,
        r: &mut Resident,
        frame: &PerceptionFrame,
        _output: &CpuDecisionOutput,
        seed: u32,
        counter: u32,
        t: f64,
    ) -> Result<Selection<Self::Action>, CpuHostError> {
        let source = r.neural.actual_contact_source()?.clone();
        let state = r
            .grouped
            .as_mut()
            .ok_or(CpuHostError::State("missing optional controller"))?;
        // During the new forward native generation is one ahead of last sample;
        // use explicit owner checks, not the completed-boundary validator.
        if state.channel_native.is_some()
            || state.optional_vocal.is_some()
            || state.last_action.is_some()
            || state
                .actual_contact
                .as_ref()
                .is_none_or(|v| v.schema != CHANNEL_RESIDENT)
        {
            return Err(CpuHostError::State("optional sampler owner mismatch"));
        }
        let native = &state
            .motor
            .last_receipt
            .as_ref()
            .ok_or(CpuHostError::State("missing optional scores"))?
            .native
            .scores;
        let scores =
            ActualContactScoresV1::bind_native(founder.phenotype(), frame, native, source)?;
        let action = scores.sample_native(seed, counter, t)?;
        let (index, motors) = scores.physical_selection(&action)?;
        let speech = if motors[3].is_some() {
            scores.source().speech()?
        } else {
            None
        };
        state.actual_contact.as_mut().unwrap().last = Some(ActualContactSelectionV1 {
            scores,
            action: action.clone(),
        });
        Ok((action, index, motors, speech))
    }
    fn stage(
        r: &mut Resident,
        p: &BrainPhenotype,
        a: &Self::Action,
        b: CpuDecisionBinding,
    ) -> Result<(), CpuHostError> {
        let state = r
            .grouped
            .as_ref()
            .ok_or(CpuHostError::State("missing optional controller"))?;
        state.validate_policy::<Self>()?;
        let last = state
            .actual_contact
            .as_ref()
            .and_then(|v| v.last.as_ref())
            .ok_or(CpuHostError::State("missing optional sample"))?;
        if last.action != *a {
            return Err(CpuHostError::State("optional staged sample mismatch"));
        }
        last.scores
            .validate_native(&state.motor.last_receipt.as_ref().unwrap().native.scores)?;
        Ok(r.neural
            .stage_actual_contact_closed_selection(p, a, &last.scores, b)?)
    }
    fn close(
        n: &mut CpuOrganismState,
        f: &CpuFoundationTrainer,
        p: &ExperiencePatch,
        r: &NeuralReceptorFrame,
    ) -> Result<(), CpuHostError> {
        Ok(n.close_actual_contact_outcome(f, p, r)?)
    }
}

pub type CpuActualContactM2HostStepV1 = CpuGroupedM2HostStepV1<ActualContactActionV1>;
pub type CpuActualContactM2HostDecisionV1 = CpuGroupedM2HostDecisionV1<ActualContactActionV1>;
pub struct CpuActualContactM2HostV1 {
    inner: CpuGroupedM2HostV1,
}
#[derive(Debug, Clone)]
pub struct CpuActualContactM2HostCheckpointV1 {
    payload: GroupedPayloadV1,
}
impl CpuActualContactM2HostCheckpointV1 {
    pub fn encode(&self) -> Result<Vec<u8>, CpuHostError> {
        let mut bytes = CHANNEL_MAGIC.to_vec();
        bytes.extend(serde_json::to_vec(&self.payload)?);
        if bytes.len() > MAX_CHECKPOINT_BYTES {
            return Err(CpuHostError::State("actual-contact checkpoint size limit"));
        }
        Ok(bytes)
    }
    pub fn decode(bytes: &[u8]) -> Result<Self, CpuHostError> {
        if bytes.len() > MAX_CHECKPOINT_BYTES {
            return Err(CpuHostError::State("actual-contact checkpoint size limit"));
        }
        let body = bytes
            .strip_prefix(CHANNEL_MAGIC)
            .ok_or(CpuHostError::State("not fresh actual-contact M2 envelope"))?;
        let metadata: serde_json::Value = serde_json::from_slice(body)?;
        // Identity is inspected before decoding source or private acquired state.
        if metadata["schema_version"] != 1
            || metadata["source_lineage"] != CHANNEL_LINEAGE
            || metadata["policy"] != ACTUAL_CONTACT_POLICY_V1
            || metadata["runtime_profile_raw"] != 5
            || metadata["selector_tag"] != 12
            || metadata["decoder_stride"] != 55
            || metadata["recipe_digest"] != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
            || metadata["canonical"]["schema_version"] != ACTUAL_CONTACT_CANONICAL_SCHEMA
            || !metadata["canonical"]["residents"]
                .as_array()
                .is_some_and(|rows| {
                    !rows.is_empty()
                        && rows.iter().all(|r| {
                            r["neural"]["schema_version"]
                                == crate::cpu::organism::ACTUAL_CONTACT_NEURAL_SCHEMA
                        })
                })
        {
            return Err(CpuHostError::State("actual-contact outer policy mismatch"));
        }
        let mut payload: GroupedPayloadV1 = serde_json::from_value(metadata.clone())?;
        payload.restore_sampler_bits()?;
        for state in payload.controllers.values() {
            state.validate_policy::<ActualContactPolicy>()?;
        }
        if serde_json::from_slice::<serde_json::Value>(&serde_json::to_vec(&payload)?)? != metadata
        {
            return Err(CpuHostError::State(
                "actual-contact noncanonical nested state",
            ));
        }
        Ok(Self { payload })
    }
}
impl CpuActualContactM2HostV1 {
    pub fn new_prepared<T, E: std::fmt::Display>(
        game: CanonicalNewGame,
        founder: CpuFoundationTrainer,
        source_inputs: PhenotypeCompilerInputs,
        sampling_seed: u32,
        mode: MediationModeV1,
        prepare: impl FnOnce(&mut HeadlessWorld) -> Result<T, E>,
    ) -> Result<(Self, T), CpuHostError> {
        let (inner, value) = CpuGroupedM2HostV1::new_prepared_policy::<ActualContactPolicy, T, E>(
            game,
            founder,
            source_inputs,
            sampling_seed,
            mode,
            prepare,
        )?;
        Ok((Self { inner }, value))
    }
    pub fn world(&self) -> &HeadlessWorld {
        self.inner.world()
    }
    /// Read-only optional sampling evidence for this organism's last decision.
    /// The shared motor receipt contains native proposals, not this policy's
    /// selected-action distribution. Old grouped/PPO evaluation is not valid here.
    pub fn last_selection_scores(&self, organism: OrganismId) -> Option<&ActualContactScoresV1> {
        self.inner
            .host
            .residents
            .get(&organism.raw())?
            .grouped
            .as_ref()?
            .actual_contact
            .as_ref()?
            .last
            .as_ref()
            .map(|s| &s.scores)
    }
    pub fn sleep_state(&self, id: OrganismId) -> Option<alife_core::sleep::SleepState> {
        self.inner.sleep_state(id)
    }
    pub fn checkpoint(&self) -> Result<CpuActualContactM2HostCheckpointV1, CpuHostError> {
        Ok(CpuActualContactM2HostCheckpointV1 {
            payload: self.inner.checkpoint_payload::<ActualContactPolicy>()?,
        })
    }
    pub fn restore(
        c: CpuActualContactM2HostCheckpointV1,
        expected_source: &PhenotypeCompilerInputs,
        mode: MediationModeV1,
    ) -> Result<Self, CpuHostError> {
        let wire = c.encode()?;
        let inner = CpuGroupedM2HostV1::restore_payload::<ActualContactPolicy>(
            c.payload,
            expected_source,
            mode,
            wire,
        )?;
        Ok(Self { inner })
    }
    pub fn step_research_observed(
        &mut self,
        temperature: f32,
    ) -> Result<CpuGroupedM2ResearchStepV1<ActualContactActionV1>, CpuHostError> {
        let _ = temperature;
        Err(CpuHostError::State(
            "actual-contact native authority/work qualification pending; source-only owner",
        ))
    }
    pub fn step(&mut self, temperature: f32) -> Result<CpuActualContactM2HostStepV1, CpuHostError> {
        let _ = temperature;
        Err(CpuHostError::State(
            "actual-contact native authority/work qualification pending; source-only owner",
        ))
    }
    pub fn actor_optimization(&mut self) -> Result<(), CpuHostError> {
        Err(CpuHostError::State(
            "actual-contact synaptic learning is closed",
        ))
    }
    pub fn waking_synaptic_plasticity(&mut self) -> Result<(), CpuHostError> {
        Err(CpuHostError::State(
            "actual-contact synaptic learning is closed",
        ))
    }
    pub fn synaptic_sleep_consolidation(&mut self) -> Result<(), CpuHostError> {
        Err(CpuHostError::State(
            "actual-contact synaptic learning is closed",
        ))
    }
}

#[cfg(test)]
#[path = "actual_contact_owner_negative_tests.rs"]
mod owner_negative_tests;
