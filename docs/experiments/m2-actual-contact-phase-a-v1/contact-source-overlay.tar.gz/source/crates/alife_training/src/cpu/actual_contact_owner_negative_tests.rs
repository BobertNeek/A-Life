//! SOURCE ONLY: this fixture is authored, not executed by its author.
//!
//! Frozen constructor inventory for this ONE exact test:
//! - recipe::build(FIXTURE_SEED, true) once, including its one temporary canonical
//!   seed game and inherited phenotype/asset construction; no archived life input.
//! - CpuFoundationTrainer::new once, then from_checkpoint once solely to install
//!   the same disposable optimizer sentinels as V5 build_with_toy; zero updates.
//! - create_grounded_drive_research_new_game once; HeadlessScenarioBuilder::build
//!   once; register_grounded_drive_research_record once; zero toys.
//! - CpuActualContactM2HostV1::new_prepared once (one fresh research host/resident).
//!   Its existing internal fresh-host/neural constructors are not extra trials.
//! - Nine host restore calls, all deliberately rejected by schema admission BEFORE
//!   phenotype compilation/founder reconstruction/world restore. Zero successful
//!   cold-host restores and zero replacement neural owners.
//! - Six neural restore admission calls, all rejected before private bank validation.
//! Zero source advances/forwards, steps, world intervals, gradients, optimizer
//! updates, synthetic actions, archived checkpoints or successful host restores.
//! Authentic sampled-action/pending cross-owner negatives require a real source
//! decision and are DEFERRED to the separately frozen four-interval fixture.
//! Run only this exact test in an assembly excluding inherited test registrations.
use super::*;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
#[allow(dead_code)]
#[path = "grouped_host_fixture.rs"]
mod recipe;
const FIXTURE_SEED: u64 = 0x0043_484e_4c48_5331;
use std::sync::atomic::{AtomicU32,Ordering};
use std::io::Write;
static RECIPE:AtomicU32=AtomicU32::new(0);
static FOUNDER:AtomicU32=AtomicU32::new(0);
static SENTINEL:AtomicU32=AtomicU32::new(0);
static RESEARCH:AtomicU32=AtomicU32::new(0);
static BLANK:AtomicU32=AtomicU32::new(0);
static REGISTER:AtomicU32=AtomicU32::new(0);
static HOST:AtomicU32=AtomicU32::new(0);
static HOST_READY:AtomicU32=AtomicU32::new(0);
static HOST_RESTORE:AtomicU32=AtomicU32::new(0);
static HOST_REJECT:AtomicU32=AtomicU32::new(0);
static NEURAL_RESTORE:AtomicU32=AtomicU32::new(0);
static NEURAL_REJECT:AtomicU32=AtomicU32::new(0);
static UNEXPECTED_RESTORE:AtomicU32=AtomicU32::new(0);
fn phase(name:&str){
    println!("\nACTUAL_CONTACT_OWNER_A_V1 {}",serde_json::json!({"phase":name,"recipe_builds":RECIPE.load(Ordering::SeqCst),"founder_new":FOUNDER.load(Ordering::SeqCst),"sentinel_from_checkpoint":SENTINEL.load(Ordering::SeqCst),"research_new_games":RESEARCH.load(Ordering::SeqCst),"blank_builds":BLANK.load(Ordering::SeqCst),"record_registrations":REGISTER.load(Ordering::SeqCst),"host_admissions":HOST.load(Ordering::SeqCst),"host_ready":HOST_READY.load(Ordering::SeqCst),"host_restore_calls":HOST_RESTORE.load(Ordering::SeqCst),"host_restore_rejected":HOST_REJECT.load(Ordering::SeqCst),"neural_restore_calls":NEURAL_RESTORE.load(Ordering::SeqCst),"neural_restore_rejected":NEURAL_REJECT.load(Ordering::SeqCst),"unexpected_restore_successes":UNEXPECTED_RESTORE.load(Ordering::SeqCst)}));
    std::io::stdout().flush().unwrap();
}
fn rejected_host(f:impl FnOnce()->Result<CpuActualContactM2HostV1,CpuHostError>){
    HOST_RESTORE.fetch_add(1,Ordering::SeqCst);phase("host_restore_started");let result=f();
    if result.is_ok(){UNEXPECTED_RESTORE.fetch_add(1,Ordering::SeqCst);phase("unexpected_restore");}
    assert!(result.is_err());HOST_REJECT.fetch_add(1,Ordering::SeqCst);phase("host_restore_rejected");
}
fn rejected_neural(f:impl FnOnce()->Result<CpuOrganismState,crate::TrainingError>){
    NEURAL_RESTORE.fetch_add(1,Ordering::SeqCst);phase("neural_restore_started");let result=f();
    if result.is_ok(){UNEXPECTED_RESTORE.fetch_add(1,Ordering::SeqCst);phase("unexpected_restore");}
    assert!(result.is_err());NEURAL_REJECT.fetch_add(1,Ordering::SeqCst);phase("neural_restore_rejected");
}

fn construct_one_fresh_host() -> (CpuActualContactM2HostV1, PhenotypeCompilerInputs) {
    RECIPE.fetch_add(1,Ordering::SeqCst);phase("recipe_started");
    let recipe = recipe::build(FIXTURE_SEED, true).unwrap();
    FOUNDER.fetch_add(1,Ordering::SeqCst);phase("founder_started");
    let mut founder = CpuFoundationTrainer::new(
        recipe.phenotype.clone(),
        recipe.asset.clone(),
        StageTrainableMask::recurrent_only(&recipe.phenotype).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    let mut optimizer = founder.checkpoint();
    optimizer.optimizer_step = 23;
    optimizer.update_ages[0] = 23;
    optimizer.first_moment[0] = 0.03125;
    optimizer.second_moment[0] = 0.0625;
    SENTINEL.fetch_add(1,Ordering::SeqCst);phase("sentinel_started");
    founder =
        CpuFoundationTrainer::from_checkpoint(recipe.phenotype.clone(), recipe.asset, optimizer)
            .unwrap();
    assert!(founder.phenotype().synapses().iter().enumerate().filter(|(_, s)|
        matches!(s.kind(), CompiledSynapseKind::Decoder(c) if c.head() == DecoderHeadKind::SpeechPayload))
        .all(|(i, _)| founder.weights()[i].to_bits() == 0_f32.to_bits()));
    RESEARCH.fetch_add(1,Ordering::SeqCst);phase("research_started");
    let mut game =
        create_grounded_drive_research_new_game(&recipe.config, &recipe.genotype).unwrap();
    let newborn = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    BLANK.fetch_add(1,Ordering::SeqCst);phase("blank_started");
    let mut blank = HeadlessScenarioBuilder::new(FIXTURE_SEED)
        .agent("learner", newborn.organism_id(), Vec3f::ZERO)
        .build()
        .unwrap();
    REGISTER.fetch_add(1,Ordering::SeqCst);phase("registration_started");
    blank
        .register_grounded_drive_research_record(newborn)
        .unwrap();
    game.world = blank;
    let inputs = recipe.inputs;
    HOST.fetch_add(1,Ordering::SeqCst);phase("host_started");
    let (host, ()) = CpuActualContactM2HostV1::new_prepared(
        game,
        founder,
        inputs.clone(),
        (FIXTURE_SEED ^ (FIXTURE_SEED >> 32)) as u32,
        MediationModeV1::Full,
        |_| Ok::<(), String>(()),
    )
    .unwrap();
    HOST_READY.fetch_add(1,Ordering::SeqCst);phase("host_ready");
    (host, inputs)
}

#[test]
fn actual_contact_one_birth_zero_forward_owner_negative_qualification_v1() {
    phase("test_started");
    let (host, inputs) = construct_one_fresh_host();
    assert!(host.inner.host.residents.len() == 1);
    let checkpoint = host.checkpoint().unwrap();
    let wire = checkpoint.encode().unwrap();
    let decoded = CpuActualContactM2HostCheckpointV1::decode(&wire).unwrap();
    assert!(decoded.encode().unwrap() == wire);phase("codec_roundtrip");
    let resident = host.inner.host.residents.values().next().unwrap();
    let neural = resident.neural.checkpoint().unwrap();
    let p = host.inner.founder.phenotype();
    assert!(neural.schema_version == crate::cpu::organism::ACTUAL_CONTACT_NEURAL_SCHEMA);
    assert!(
        neural.dispatch_generation == 0
            && neural.last_decision_tick.is_none()
            && neural.last_outcome_tick.is_none()
    );
    assert!(resident.next_sequence == 1);
    assert!(resident
        .grouped
        .as_ref()
        .unwrap()
        .actual_contact
        .as_ref()
        .unwrap()
        .is_fresh());
    // These are real source-access APIs with no pending decision, not forged actions.
    assert!(resident.neural.actual_contact_source().is_err());
    assert!(resident.neural.channel_native_source().is_err());
    assert!(resident.neural.optional_vocal_source().is_err());
    // Old decoders reject the genuine fresh new envelope without constructing a host.
    assert!(CpuChannelNativeM2HostCheckpointV1::decode(&wire).is_err());
    assert!(CpuOptionalVocalM2HostCheckpointV1::decode(&wire).is_err());
    assert!(CpuGroupedM2HostCheckpointV1::decode(&wire).is_err());
    // Old prefix fixtures are only envelope markers around this NEW payload, not
    // old-life inputs. Each prefix is the exact existing decoder discriminator.
    for old_magic in [
        b"ALIFE-CHANNEL-NATIVE-M2-HOST\0V1\0IDLE-QUIET\0SOURCE-PAYLOAD\0SYNAPTIC-CLOSED\0PROFILE5\0BITS1\0".as_slice(),
        b"ALIFE-OPTIONAL-VOCAL-M2-HOST\0V1\0IDLE-QUIET\0SOURCE-PAYLOAD\0SYNAPTIC-CLOSED\0PROFILE5\0BITS1\0".as_slice(),
        b"ALIFE-GROUPED-M2-HOST\0V1\0CONFIDENCE-V2\0SYNAPTIC-CLOSED\0PROFILE5\0SAMPLER-BITS1\0".as_slice(),
    ] {
        let mut foreign = old_magic.to_vec();
        foreign.extend_from_slice(wire.strip_prefix(CHANNEL_MAGIC).unwrap());
        assert!(CpuActualContactM2HostCheckpointV1::decode(&foreign).is_err());
    }
    // Three old-owner families, three early-rejection variants each. The bank
    // remains this birth's real empty bank throughout; wrapping cannot migrate it.
    for (old_canonical, old_neural) in [(2u16, 2u32), (0x4f56, 0x4f56_0001), (0x434e, 0x434e_0001)]
    {
        for variant in 0..3 {
            let mut foreign = checkpoint.clone();
            if variant != 1 {
                foreign.payload.canonical.schema_version = old_canonical;
            }
            if variant != 0 {
                foreign.payload.canonical.residents[0].neural.schema_version = old_neural;
            }
            assert!(foreign.payload.controllers.values().all(|s| s
                .actual_contact
                .as_ref()
                .unwrap()
                .is_fresh()));
            assert!(
                CpuActualContactM2HostCheckpointV1::decode(&foreign.encode().unwrap()).is_err()
            );
            rejected_host(||CpuActualContactM2HostV1::restore(foreign,&inputs,MediationModeV1::Full));
        }
        let mut foreign_neural = neural.clone();
        foreign_neural.schema_version = old_neural;
        rejected_neural(||CpuOrganismState::from_actual_contact_checkpoint(p,foreign_neural));
    }
    rejected_neural(||CpuOrganismState::from_checkpoint(p,neural.clone()));
    rejected_neural(||CpuOrganismState::from_optional_vocal_checkpoint(p,neural.clone()));
    rejected_neural(||CpuOrganismState::from_channel_native_checkpoint(p,neural));
    // Immutable original remains byte-identical after every negative admission.
    assert!(host.checkpoint().unwrap().encode().unwrap() == wire);
    assert!(HOST_RESTORE.load(Ordering::SeqCst)==9&&HOST_REJECT.load(Ordering::SeqCst)==9);
    assert!(NEURAL_RESTORE.load(Ordering::SeqCst)==6&&NEURAL_REJECT.load(Ordering::SeqCst)==6);
    assert!(UNEXPECTED_RESTORE.load(Ordering::SeqCst)==0);
    phase("complete");
}
