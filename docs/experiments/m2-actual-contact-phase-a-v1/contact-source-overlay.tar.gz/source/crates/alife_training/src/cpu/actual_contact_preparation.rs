//! New-owner preparation only. Ordinary canonical preparation remains unchanged.
//! No sensory/receptor/candidate lane is added by this familiarity routing.
use super::*;
use alife_world::grounded_peripheral_summaries;
fn elapsed_ns(start: std::time::Instant) -> u64 {
    start.elapsed().as_nanos().min(u64::MAX as u128) as u64
}
pub(super) fn prepare_actual_contact_frame(
    input: &CanonicalPreparationInput,
    memory: &MemorySidecarState,
    topology: &TopologySidecar,
    predictor: &GroundedSuccessorPredictor,
    contacts: &super::actual_contact_bridge::ContactFamiliarityV1,
    measure: bool,
) -> CanonicalPreparationOutcome {
    let draft = &input.draft;
    let receptor_effects = input.receptor_effects;
    let tick_before = draft.tick();
    let mut preparation_stage = "baseline recall";
    let mut hysteresis = None;
    let mut timing = CanonicalPreparationTiming::default();
    let result = (|| {
        input.neural_receptors.validate_contract()?;
        receptor_effects.validate_contract()?;
        if input.neural_receptors.source_tick != draft.tick()
            || receptor_effects.source_tick != draft.tick()
            || input.homeostasis.tick != draft.tick()
            || input.neural_receptors.source_chemistry_version
                != receptor_effects.source_chemistry_version
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        let episodic_retrieval_started = measure.then(std::time::Instant::now);
        let sequence_id = input.sequence_id;
        sequence_id.validate()?;
        preparation_stage = "baseline recall";
        let leaf_started = measure.then(std::time::Instant::now);
        let prepared_recall = memory.recall_frame(draft)?;
        let baseline_recall_ns = leaf_started.map_or(0, elapsed_ns);
        let leaf_started = measure.then(std::time::Instant::now);
        let baseline_context = cognitive_context_for_recall(
            input.draft.organism_id(),
            sequence_id,
            &prepared_recall,
            topology,
        )?;
        let baseline_context_ns = leaf_started.map_or(0, elapsed_ns);
        preparation_stage = "baseline attention evidence";
        let leaf_started = measure.then(std::time::Instant::now);
        let baseline_prepared = prepared_recall.with_cognitive_context(baseline_context.clone())?;
        let memory_evidence = baseline_prepared.attention_evidence_for_draft(draft)?;
        if measure {
            timing.baseline_recall_wall_ns = baseline_recall_ns;
            timing.baseline_context_wall_ns = baseline_context_ns;
            timing.baseline_attention_evidence_wall_ns = leaf_started.map_or(0, elapsed_ns);
        }
        timing.episodic_retrieval_wall_ns = timing
            .episodic_retrieval_wall_ns
            .saturating_add(episodic_retrieval_started.map_or(0, elapsed_ns));
        let attention_context_started = measure.then(std::time::Instant::now);
        let mut peripheral_summaries =
            grounded_peripheral_summaries(draft.grounded_object_slots())?;
        let topology_evidence = topology_evidence_for_draft(draft, topology)?;
        let body_need = input
            .homeostasis
            .drives
            .to_array()
            .iter()
            .copied()
            .fold(0.0, f32::max);
        apply_predecision_attention_evidence(
            &mut peripheral_summaries,
            body_need,
            &memory_evidence,
            &topology_evidence,
            receptor_effects,
        )?;
        preparation_stage = "attention selection";
        for summary in &mut peripheral_summaries {
            if let alife_core::StableFocusIdentity::TrackedObject(id) = summary.identity {
                let legacy = memory.bank().object_familiarity(
                    input.draft.organism_id(),
                    id,
                    memory.profile(),
                );
                // Conservative overlap-safe maximum. No sum/union or migration.
                summary.salience.novelty =
                    NormalizedScalar::new(1.0 - legacy.max(contacts.familiarity(id)))?;
            }
        }
        let attention = select_focal_targets(
            input.draft.organism_id(),
            sequence_id,
            tick_before,
            &peripheral_summaries,
            input.hysteresis,
            input.policy,
        )?;
        hysteresis = Some(attention.hysteresis);
        preparation_stage = "focal routing";
        let routed_draft =
            route_observed_focal_candidates(draft, &attention, input.candidate_binding.as_ref())?;
        let novelty = selected_focal_novelty(&attention);
        let routed_draft = routed_draft.with_remembered_novelty(novelty)?;
        timing.attention_context_wall_ns = timing
            .attention_context_wall_ns
            .saturating_add(attention_context_started.map_or(0, elapsed_ns));
        let topology_concept_started = measure.then(std::time::Instant::now);
        preparation_stage = "routed recall";
        let leaf_started = measure.then(std::time::Instant::now);
        let routed_recall = memory.recall_frame(&routed_draft)?;
        let routed_recall_ns = leaf_started.map_or(0, elapsed_ns);
        let leaf_started = measure.then(std::time::Instant::now);
        let mut cognitive_context = cognitive_memory_context_for_recall(
            input.draft.organism_id(),
            sequence_id,
            &routed_recall,
        )?;
        // Topology is immutable during preparation. Focal routing changes
        // candidate recall, while the sorted concepts and gaps remain identical.
        cognitive_context.concept = baseline_context.concept;
        cognitive_context.gap = baseline_context.gap;
        let cognitive_context = cognitive_context_with_attention(cognitive_context, attention)?;
        let routed_context_ns = leaf_started.map_or(0, elapsed_ns);
        preparation_stage = "cognitive projection";
        let leaf_started = measure.then(std::time::Instant::now);
        let cognitive_projection = cognitive_projection_for_draft(
            &routed_draft,
            &routed_recall,
            sequence_id,
            predictor,
            &topology_evidence,
        )?;
        let cognitive_context =
            cognitive_context_with_projection(cognitive_context, cognitive_projection)?;
        let cognitive_projection_ns = leaf_started.map_or(0, elapsed_ns);
        preparation_stage = "routed finalization";
        let leaf_started = measure.then(std::time::Instant::now);
        let prepared_recall = routed_recall.with_cognitive_context(cognitive_context)?;
        let (frame, memory_recall) = prepared_recall.finalize(routed_draft)?;
        let routed_finalize_ns = leaf_started.map_or(0, elapsed_ns);
        let leaf_started = measure.then(std::time::Instant::now);
        memory_recall.validate_for_frame(&frame)?;
        if measure {
            timing.routed_recall_wall_ns = routed_recall_ns;
            timing.routed_context_wall_ns = routed_context_ns;
            timing.cognitive_projection_wall_ns = cognitive_projection_ns;
            timing.routed_finalize_wall_ns = routed_finalize_ns;
            timing.routed_validate_wall_ns = leaf_started.map_or(0, elapsed_ns);
        }
        timing.topology_concept_wall_ns = timing
            .topology_concept_wall_ns
            .saturating_add(topology_concept_started.map_or(0, elapsed_ns));

        Ok(CanonicalPreparedFrame {
            frame,
            memory_recall,
        })
    })();
    CanonicalPreparationOutcome {
        result,
        stage: preparation_stage,
        hysteresis,
        timing,
    }
}
