//! New semantic memory operations use the existing class-5 memory-context ATP
//! rate and existing 1e-6 body-work policy. Byte/codec/hash administration stays
//! separately reported and unqualified, as does inherited sampler administration.
use super::*;
use crate::cpu::actual_contact_bank::Work;
use crate::cpu::actual_contact_budget::{self as budget, Reservation};
use serde::{Deserialize, Serialize};
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct ContactMemoryWorkReceiptV1 {
    pub(super) policy: String,
    pub(super) sequence: u64,
    pub(super) frame: [u64; 4],
    pub(super) bundle: [u64; 4],
    pub(super) memory_ops: u64,
    pub(super) record_reads:u64,
    pub(super) semantic_comparisons:u64,
    pub(super) semantic_writes:u64,
    pub(super) familiarity_arithmetic:u64,
    pub(super) reserved_memory_ops: u64,
    pub(super) memory_rate_q24: u64,
    pub(super) base_q24: u64,
    pub(super) reserved_total_q24: u64,
    pub(super) reserved_total_q16: u32,
    pub(super) actual_total_q24: u64,
    pub(super) actual_total_q16: u32,
    pub(super) available_q16: u32,
    pub(super) copied_bytes: u64,
    pub(super) checksum_input_bytes: u64,
    pub(super) codec_bytes: u64,
    pub(super) administration_price_qualified: bool,
    pub(super) physiology_helper_calls:u64,
    pub(super) adaptation_helper_calls:u64,
    pub(super) basis_json_hashes:u64,
    pub(super) payload_clone_calls:u64,
    pub(super) payload_cloned_values:u64,
    /// Unknown: hashes/validation/hex serialization are not fully instrumented.
    pub(super) other_administrative_ops:Option<u64>,
}
pub(super) fn reserve_q24(p: &BrainPhenotype) -> Result<u64, CpuHostError> {
    let rate = BrainActivityPolicyV1::for_phenotype(p)
        .cost
        .memory_context_op_q24;
    if rate != 64 {
        return Err(CpuHostError::State("actual-contact memory rate mismatch"));
    }
    budget::MAX_MEMORY_OPS
        .checked_mul(rate)
        .ok_or(CpuHostError::State("actual-contact reserve overflow"))
}
impl ContactMemoryWorkReceiptV1 {
    pub(super) fn settle(
        p: &BrainPhenotype,
        sequence: ExperienceSequenceId,
        frame: PerceptionFrameDigest,
        bundle: &MotorCommandBundle,
        work: Work,
        reserved_total_q24: u64,
        available_q16: u32,
    ) -> Result<(Self, u32), CpuHostError> {
        let reserve = reserve_q24(p)?;
        let base_q24 = reserved_total_q24
            .checked_sub(reserve)
            .ok_or(CpuHostError::State("actual-contact reserve omitted"))?;
        let rate = BrainActivityPolicyV1::for_phenotype(p)
            .cost
            .memory_context_op_q24;
        let reservation = Reservation::new(base_q24, rate, available_q16)
            .map_err(|_| CpuHostError::State("actual-contact reservation invalid"))?;
        let (actual_q24, actual_q16, remaining) = reservation
            .settle(work.memory_ops())
            .map_err(|_| CpuHostError::State("actual-contact actual work exceeds reservation"))?;
        Ok((
            Self {
                policy: budget::POLICY.into(),
                sequence: sequence.raw(),
                frame: frame.0,
                bundle: bundle.canonical_digest()?,
                memory_ops: work.memory_ops(),
                record_reads:work.reads,semantic_comparisons:work.comparisons,
                semantic_writes:work.writes,familiarity_arithmetic:work.arithmetic,
                reserved_memory_ops: budget::MAX_MEMORY_OPS,
                memory_rate_q24: rate,
                base_q24,
                reserved_total_q24,
                reserved_total_q16: reservation.reserved_q16,
                actual_total_q24: actual_q24,
                actual_total_q16: actual_q16,
                available_q16,
                copied_bytes: work.copied_bytes,
                checksum_input_bytes: work.digest_bytes,
                codec_bytes: work.codec_bytes,
                administration_price_qualified: false,
                physiology_helper_calls:work.physiology_helper_calls,
                adaptation_helper_calls:work.adaptation_helper_calls,
                basis_json_hashes:work.basis_json_hashes,
                payload_clone_calls:work.payload_clone_calls,
                payload_cloned_values:work.payload_cloned_values,
                other_administrative_ops:None,
            },
            remaining,
        ))
    }
    pub(super) fn validate(
        &self,
        sequence: u64,
        frame: [u64; 4],
        bundle: [u64; 4],
        motor: &crate::cpu::GroupedMotorReceiptV1,
    ) -> Result<(), CpuHostError> {
        let measured=self.record_reads.checked_add(self.semantic_comparisons)
            .and_then(|n|n.checked_add(self.semantic_writes))
            .and_then(|n|n.checked_add(self.familiarity_arithmetic));
        if measured!=Some(self.memory_ops){return Err(CpuHostError::State("actual-contact saved memory components mismatch"));}
        let reservation = Reservation::new(self.base_q24, self.memory_rate_q24, self.available_q16)
            .map_err(|_| CpuHostError::State("actual-contact saved reserve invalid"))?;
        let (actual_q24, actual_q16, _) = reservation
            .settle(self.memory_ops)
            .map_err(|_| CpuHostError::State("actual-contact saved debit invalid"))?;
        if self.policy != budget::POLICY
            || self.sequence != sequence
            || self.frame != frame
            || self.bundle != bundle
            || self.reserved_memory_ops != budget::MAX_MEMORY_OPS
            || self.reserved_total_q24 != reservation.reserved_q24
            || self.reserved_total_q16 != reservation.reserved_q16
            || self.actual_total_q24 != actual_q24
            || self.actual_total_q16 != actual_q16
            || self.administration_price_qualified
            || self.physiology_helper_calls!=1||self.adaptation_helper_calls>6
            || self.basis_json_hashes!=4||self.payload_clone_calls!=self.adaptation_helper_calls
            || self.payload_cloned_values>192||self.other_administrative_ops.is_some()
            || motor.reservation_q24 != self.reserved_total_q24
            || motor.reservation_q16 != self.reserved_total_q16
            || motor.available_atp_q16 != self.available_q16
        {
            return Err(CpuHostError::State(
                "actual-contact saved work binding mismatch",
            ));
        }
        Ok(())
    }
}
