//! Separate typed grouped world loop. The legacy flat-policy collector is untouched.
use super::*;
impl CpuCanonicalHost {
    pub(super) fn grouped_step(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
    ) -> Result<CpuGroupedM2HostStepV1, CpuHostError> {
        self.grouped_policy_step::<LegacyGroupedPolicy>(founder, temperature)
    }
    pub(super) fn grouped_policy_step<P: GroupedPolicyStrategy>(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
    ) -> Result<CpuGroupedM2HostStepV1<P::Action>, CpuHostError> {
        self.grouped_policy_step_with_receipts::<P>(founder, temperature, None)
    }
    pub(super) fn grouped_policy_step_observed<P: GroupedPolicyStrategy>(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
    ) -> Result<CpuGroupedM2ResearchStepV1<P::Action>, CpuHostError> {
        let mut world_receipts = Vec::new();
        let step = self.grouped_policy_step_with_receipts::<P>(
            founder,
            temperature,
            Some(&mut world_receipts),
        )?;
        Ok(CpuGroupedM2ResearchStepV1 {
            step,
            world_receipts,
        })
    }
    fn grouped_policy_step_with_receipts<P: GroupedPolicyStrategy>(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
        receipts: Option<&mut Vec<alife_world::HeadlessMotorTransactionReceipt>>,
    ) -> Result<CpuGroupedM2HostStepV1<P::Action>, CpuHostError> {
        // New owner stays closed until separately sealed constructor, restore,
        // action and semantic-memory qualification. Administration is reported
        // separately; no total compute or body-price qualification is claimed.
        if P::ACTUAL_CONTACT {
            return Err(CpuHostError::State("actual-contact native authority/work qualification pending; activation blocked"));
        }
        self.validate_founder(founder)?;
        for (&id, r) in &self.residents {
            super::grouped_host_envelope::validate_grouped_sleep_boundary(r)?;
            if r.grouped
                .as_ref()
                .is_none_or(|g| g.validate_policy::<P>().is_err())
                || r.motor.is_some()
                || r.sleep_choice.is_some()
            {
                return Err(CpuHostError::State("not a grouped M2 resident"));
            }
            let record = self
                .world
                .organism_registry()
                .get(OrganismId(id))
                .ok_or(CpuHostError::State("missing grouped canonical organism"))?;
            validate_resident_authority(record, r, self.sampling_seed, self.sampling_counter)?;
        }
        let mut next = self.clone();
        for r in next.residents.values_mut() {
            r.sealed_authority = None;
        }
        let result = next.grouped_policy_step_inner_with_receipts::<P>(
            founder,
            temperature,
            &mut |draft, _| Ok(draft),
            receipts,
        )?;
        *self = next;
        Ok(result)
    }
    // Retained internal legacy test hook; production uses the shared typed loop.
    #[allow(dead_code)]
    pub(super) fn grouped_step_inner(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
        prepare: &mut impl FnMut(
            PerceptionFrameDraft,
            ExperienceSequenceId,
        ) -> Result<PerceptionFrameDraft, ScaffoldContractError>,
    ) -> Result<CpuGroupedM2HostStepV1, CpuHostError> {
        self.grouped_policy_step_inner::<LegacyGroupedPolicy>(founder, temperature, prepare)
    }
    pub(super) fn grouped_policy_step_inner<P: GroupedPolicyStrategy>(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
        prepare: &mut impl FnMut(
            PerceptionFrameDraft,
            ExperienceSequenceId,
        ) -> Result<PerceptionFrameDraft, ScaffoldContractError>,
    ) -> Result<CpuGroupedM2HostStepV1<P::Action>, CpuHostError> {
        self.grouped_policy_step_inner_with_receipts::<P>(founder, temperature, prepare, None)
    }
    fn grouped_policy_step_inner_with_receipts<P: GroupedPolicyStrategy>(
        &mut self,
        founder: &CpuFoundationTrainer,
        temperature: f32,
        prepare: &mut impl FnMut(
            PerceptionFrameDraft,
            ExperienceSequenceId,
        ) -> Result<PerceptionFrameDraft, ScaffoldContractError>,
        mut receipts: Option<&mut Vec<alife_world::HeadlessMotorTransactionReceipt>>,
    ) -> Result<CpuGroupedM2HostStepV1<P::Action>, CpuHostError> {
        if P::ACTUAL_CONTACT {return Err(CpuHostError::State("actual-contact host qualification pending; private dispatch blocked"));}
        let p = founder.phenotype();
        let tick = self.world.tick();
        let mut decisions = Vec::new();
        let mut sleeping = 0;
        let mut consolidations = 0;
        let mut body_events = BTreeMap::new();
        let mut perception_world = self.world.clone();
        let ids = self
            .world
            .organism_registry()
            .iter()
            .filter(|r| r.lifecycle().is_alive())
            .map(|r| r.organism_id())
            .collect::<Vec<_>>();
        for id in ids {
            let mut record = self
                .world
                .organism_registry()
                .get(id)
                .cloned()
                .ok_or(CpuHostError::State("missing organism"))?;
            let r = self
                .residents
                .get_mut(&id.raw())
                .ok_or(CpuHostError::State("new organism requires brain admission"))?;
            let phase_before = r.sleep.state().phase;
            if r.activity
                .last_world_tick
                .is_some_and(|last| last.checked_add(1) != Some(tick.raw()))
            {
                return Err(CpuHostError::State("CPU activity world clock mismatch"));
            }
            r.activity.last_world_tick = Some(tick.raw());
            r.activity.remaining_atp_q16 =
                (f64::from(record.biochemistry().homeostasis.drives.brain_atp)
                    * f64::from(BRAIN_ATP_Q16_MAX))
                .floor() as u32;
            let neural_boundary = r.neural.checkpoint()?;
            let activity_anchor = CpuActivityAnchor {
                organism_id: id,
                tick,
                sequence_cursor: r.next_sequence,
                previous_dispatch_generation: neural_boundary.dispatch_generation,
                source_frame_digest: r.activity.source_frame_digest,
                frame_digest: p.phenotype_hash().0,
            };
            let capacity = host_capacity(p)?;
            let lookahead = cpu_activity_budget(
                p,
                activity_anchor,
                record.biochemistry().homeostasis.drives.brain_atp,
                u32::from(capacity.execution().max_candidates()),
                u32::from(capacity.execution().max_memory_context_records()),
            )?;
            // Source and appendage share one admission. A resource-limited
            // living body takes the existing recovery fallback, not a repeated
            // rollback stall and not a forged voluntary BodySleep receipt.
            let (_, _, grouped_affordable) = GroupedMotorStateV1::work(
                p,
                &lookahead.work,
                grouped_dynamic_work(p, r, &lookahead)?.checked_add(if P::ACTUAL_CONTACT {super::actual_contact_work::reserve_q24(p)?}else{0}).ok_or(CpuHostError::State("actual-contact lookahead overflow"))?,
                lookahead.available_atp_q16,
            )?;
            if phase_before == SleepPhase::Awake && !grouped_affordable {
                r.sleep
                    .force_sleep(tick, alife_core::SleepTrigger::RecoveryProtocol)?;
            }

            let config = sleep_consolidation_config_for(p)?;
            if phase_before == SleepPhase::Awake {
                {
                    r.sleep.evaluate_emergency_only(
                        &record.biochemistry().homeostasis,
                        HomeostaticParameters::reference(),
                        tick,
                    )?;
                }
            } else if phase_before != SleepPhase::Waking
                || (record.biochemistry().homeostasis.drives.fatigue
                    < config.fatigue_threshold.raw()
                    && record.biochemistry().homeostasis.hormones.sleep_pressure
                        < config.sleep_pressure_threshold.raw())
            {
                r.sleep.advance(tick)?;
            }
            let mut sleep_work_units = 0;
            if r.sleep.state().phase == SleepPhase::Consolidating
                && matches!(r.sleep.state().consolidation, ConsolidationState::None)
            {
                let evidence = replay_evidence(p, &r.replay)?;
                if !evidence.batch.events.is_empty() {
                    // Same scheduled-work pressure projection used by the native
                    // scheduler; this is work admission, never reward/chemistry.
                    let mut due_homeostasis = record.biochemistry().homeostasis;
                    due_homeostasis.drives.fatigue = due_homeostasis
                        .drives
                        .fatigue
                        .max(config.fatigue_threshold.raw());
                    due_homeostasis.hormones.sleep_pressure = due_homeostasis
                        .hormones
                        .sleep_pressure
                        .max(config.sleep_pressure_threshold.raw());
                    let work = {
                        let state = r
                            .grouped
                            .as_ref()
                            .ok_or(CpuHostError::State("missing grouped replay owner"))?;
                        state.validate_replay(&r.replay)?;
                        r.memory.run_bounded_sleep_transaction_scoped_v1(
                            &SleepConsolidator::new(config)?,
                            &due_homeostasis,
                            tick,
                            &evidence,
                            &state.memory_proofs,
                            &mut r.predictor,
                            &mut r.topology,
                        )?
                    };
                    if let Some(work) = work {
                        sleep_work_units = work.work_units;
                        let receipt = CognitiveWorkCounters::new(
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            u64::from(work.predictor_update_count),
                            u64::from(work.replay_event_count)
                                + u64::from(work.replay_eligibility_sample_count),
                            0,
                            0,
                            work.work_units,
                        )?
                        .into_receipt()?;
                        record.account_cognitive_work(
                            receipt,
                            CognitiveWorkCostPolicy::enabled(1.0e-6)?,
                        )?;
                    }
                }
                r.replay.clear();
                if let Some(state) = &mut r.grouped {
                    state.memory_proofs.clear();
                }
                // Closed synapses have no new weight generation. The committed
                // output here is the actual memory/predictor/topology cycle,
                // with the frozen source included, under a distinct identity.
                let digest = super::grouped_host_envelope::grouped_sleep_output_digest(r)?;
                let mut state = r.sleep.state();
                state.consolidation = ConsolidationState::Committed {
                    cycle_id: state.active_cycle_id,
                    output_generation: state.active_cycle_id,
                    output_digest: digest,
                };
                r.sleep = SleepController::restore(config, state)?;
                consolidations += 1;
            }
            let state = r.sleep.state();
            record.seal_sleep_phase(
                state.phase,
                state.active_cycle_id.max(state.last_consolidated_cycle_id),
                tick,
                sleep_work_units,
            )?;
            self.world.replace_organism_record_exact(record.clone())?;
            if phase_before != SleepPhase::Awake {
                body_events.insert(
                    id.raw(),
                    BodyEventDelta {
                        sleep_recovery: 1.,
                        ..BodyEventDelta::zero()
                    },
                );
            }
            if phase_before != SleepPhase::Awake || state.phase != SleepPhase::Awake {
                sleeping += 1;
                continue;
            }
            let sequence = ExperienceSequenceId(r.next_sequence);
            let receptors = record
                .biochemistry()
                .neural_receptor_frame(record.phenotype())?;
            let effects = NeuralReceptorEffects::from_frame(
                &receptors,
                &NeuralReceptorPhenotype::compile(p)?,
            )?;
            let (draft, candidate_binding) = {
                let admission =
                    alife_world::SleepChoiceWorldAdmissionV1::for_organism(&perception_world, id)?;
                perception_world.perception_sleep_choice_draft_with_bindings(
                    &admission,
                    tick,
                    record.biochemistry().homeostasis,
                )?
            };
            let ordinary = draft.clone().with_semantic_context(None)?;
            let draft = prepare(draft, sequence)?;
            if draft.clone().with_semantic_context(None)? != ordinary {
                return Err(CpuHostError::State(
                    "semantic preparation changed ordinary perception",
                ));
            }
            let contact_preparation = if P::ACTUAL_CONTACT {
                Some(r.grouped.as_ref().and_then(|g|g.actual_contact.as_ref())
                    .ok_or(CpuHostError::State("missing actual-contact memory owner"))?
                    .contacts.prepare(&draft)?)
            } else {None};
            let preparation_input = CanonicalPreparationInput {
                    draft,
                    candidate_binding,
                    sequence_id: sequence,
                    homeostasis: record.biochemistry().homeostasis,
                    hysteresis: r.hysteresis,
                    policy: attention_selection_policy_for(p),
                    neural_receptors: receptors.clone(),
                    receptor_effects: effects,
                };
            let preparation = if let Some(contacts)=&contact_preparation {
                super::actual_contact_preparation::prepare_actual_contact_frame(
                    &preparation_input,&r.memory,&r.topology,&r.predictor,contacts,false)
            } else {
                prepare_canonical_frame(&preparation_input,&r.memory,&r.topology,&r.predictor,false)
            };
            let prepared = preparation.result?;
            if let Some(h) = preparation.hysteresis {
                r.hysteresis = h;
            }
            let frame = prepared.frame;
            let recall = prepared.memory_recall;
            let mut activity = cpu_activity_budget(
                p,
                CpuActivityAnchor {
                    frame_digest: frame.frame_digest().0,
                    ..activity_anchor
                },
                record.biochemistry().homeostasis.drives.brain_atp,
                frame.candidates().len() as u32,
                recall.context().candidates.len() as u32,
            )?;
            let motor_reservation_q24;
            {
                let dynamic = grouped_dynamic_work(p, r, &activity)?.checked_add(if P::ACTUAL_CONTACT {super::actual_contact_work::reserve_q24(p)?}else{0}).ok_or(CpuHostError::State("actual-contact reservation overflow"))?;
                let (total, debit, affordable) = GroupedMotorStateV1::work(
                    p,
                    &activity.work,
                    dynamic,
                    activity.available_atp_q16,
                )?;
                motor_reservation_q24 = total;
                activity.debit_atp_q16 = debit;
                activity.affordable = affordable;
                let extra = GroupedMotorStateV1::append_work(p)?;
                activity.work.neuron_updates += extra.neuron_updates;
                activity.work.synapse_ops += extra.synapse_products;
            }
            if !activity.affordable {
                return Err(CpuHostError::State(
                    "CPU neural work exceeds canonical ATP availability",
                ));
            }
            let encode = super::super::input::encode_cpu_sleep_choice_frame;
            let mut context = encode(
                p,
                &frame,
                &recall,
                &effects,
                activity.enabled_routes.clone(),
                r.v11
                    .sparse_spans()
                    .iter()
                    .flat_map(|s| {
                        s.edges.iter().map(|e| crate::TrainingFrozenSynapse {
                            source: e.source,
                            target: e.target,
                            route: e.route,
                            cadence: u32::from(
                                p.projections()[e.route as usize].update_cadence().raw(),
                            ),
                            effective_weight: e.weight,
                        })
                    })
                    .collect(),
            )?;
            context.microstep_count = u32::from(activity.microsteps);
            let channels = p.candidate_decoder().factorized_motor_channels(p)?;
            let mut capabilities = [false; 6];
            for channel in &channels {
                let slot = match channel {
                    MotorChannel::Locomotion => 0,
                    MotorChannel::Orientation => 1,
                    MotorChannel::Manipulation => 2,
                    MotorChannel::Vocal => 3,
                    MotorChannel::Posture => 4,
                    MotorChannel::SpeciesSpecific(_) => 5,
                };
                let effector = match channel {
                    MotorChannel::Locomotion => Some(EffectorCapability::Translation),
                    MotorChannel::Orientation => Some(EffectorCapability::Rotation),
                    MotorChannel::Manipulation => Some(EffectorCapability::Manipulation),
                    MotorChannel::Vocal => Some(EffectorCapability::Vocalization),
                    MotorChannel::Posture => Some(EffectorCapability::Rest),
                    MotorChannel::SpeciesSpecific(_) => None,
                };
                capabilities[slot] = record.lifecycle().is_alive()
                    && effector.is_some_and(|e| record.embodiment().effector_gain(e) > 0.);
            }
            let n = frame.candidates().len();
            if n == 0 || n > 32 {
                return Err(CpuHostError::State("grouped candidate count"));
            }
            let attempt_mask = if n == 32 { u32::MAX } else { (1u32 << n) - 1 };
            let state = r
                .grouped
                .as_mut()
                .ok_or(CpuHostError::State("missing grouped controller"))?;
            state.validate_policy::<P>()?;
            let output = if P::ACTUAL_CONTACT {
                r.neural.advance_actual_contact(
                    founder,
                    context,
                    &effects,
                    &mut state.motor,
                    &frame,
                    &receptors,
                    capabilities,
                    attempt_mask,
                )?
            } else if P::CHANNEL_NATIVE {
                r.neural.advance_channel_native(
                    founder,
                    context,
                    &effects,
                    &mut state.motor,
                    &frame,
                    &receptors,
                    capabilities,
                    attempt_mask,
                )?
            } else if P::OPTIONAL {
                r.neural.advance_optional_vocal(
                    founder,
                    context,
                    &effects,
                    &mut state.motor,
                    &frame,
                    &receptors,
                    capabilities,
                    attempt_mask,
                )?
            } else {
                r.neural.advance_grouped(
                    founder,
                    context,
                    &effects,
                    &mut state.motor,
                    &frame,
                    &receptors,
                    capabilities,
                    attempt_mask,
                )?
            };
            let actual_contact_input_lanes=if P::ACTUAL_CONTACT {
                if output.replay_tick.candidates.len()>32 {return Err(CpuHostError::State("actual-contact diagnostic row cap"));}
                let mut lane_bits=[[0u32;2];32];
                for (i,candidate) in output.replay_tick.candidates.iter().enumerate() {
                    lane_bits[i]=[candidate.decoder_inputs[44].to_bits(),candidate.decoder_inputs[45].to_bits()];
                }
                Some(CpuActualContactInputLanesV1{count:output.replay_tick.candidates.len() as u16,lane_bits})
            }else{None};
            let motor = state
                .motor
                .last_receipt
                .as_mut()
                .ok_or(CpuHostError::State("missing grouped neural receipt"))?;
            motor.reservation_q24 = motor_reservation_q24;
            motor.reservation_q16 = activity.debit_atp_q16;
            motor.available_atp_q16 = activity.available_atp_q16;
            r.activity.remaining_atp_q16 = activity.available_atp_q16 - activity.debit_atp_q16;
            r.activity.source_frame_digest = frame.frame_digest().0;
            let sampling_counter = self.sampling_counter;
            let (action, index, motor_candidates, speech) = P::select(
                founder,
                r,
                &frame,
                &output,
                self.sampling_seed,
                sampling_counter,
                f64::from(temperature),
            )?;
            self.sampling_counter = self
                .sampling_counter
                .checked_add(1)
                .ok_or(CpuHostError::State("sampling counter overflow"))?;
            let candidate = &frame.candidates()[index as usize];
            let confidence =
                if P::ACTUAL_CONTACT || P::CHANNEL_NATIVE {candidate.sensor_confidence} else {Confidence::new((candidate.sensor_confidence.raw() * 65535.).round() / 65535.)?};
            let command = candidate.to_command(id, confidence)?;
            let channels = p.candidate_decoder().factorized_motor_channels(p)?;
            let slots = motor_candidates.map(|i| i.map_or(0, |i| i + 1));
            let prompted = frame
                .sensory()
                .language_context
                .heard_tokens
                .iter()
                .flatten()
                .any(|t| t.source_kind == UtteranceSourceKind::Player);
            let bundle = factorized_motor_bundle_for_candidates(
                id,
                sequence,
                tick,
                &frame,
                slots,
                &channels,
                &command,
                index,
                speech.as_ref(),
                prompted,
            )?;
            let joint = JointActionSelectionV1::new(slots, &bundle)?;
            let development = record.phenotype().development_state_at(tick)?;
            let pre = PreActionSnapshot::from_cpu_neural_frame(
                sequence,
                p.brain_class_id(),
                p.phenotype_hash(),
                record.phenotype().brain_genome.id,
                record.phenotype().brain_genome.schema_version,
                development.clone(),
                frame.clone(),
            )?;
            let work_neurons = activity.work.neuron_updates;
            let work_synapses = activity.work.synapse_ops;
            let decision = DecisionSnapshot::from_cpu_neural_selection(
                sequence,
                p.phenotype_hash(),
                output.dispatch_generation,
                output.active_activation_side,
                &frame,
                NeuralActionSelection {
                    candidate_index: index,
                    // Source physical-row signal also drives RegionalArousal.
                    // It is not a flat grouped logit or sampling probability.
                    logit: output.candidate_logits[index as usize],
                    confidence,
                    active_tiles: u32::try_from(activity.work.tile_visits)
                        .map_err(|_| CpuHostError::State("CPU tile work overflow"))?,
                    active_synapses: u32::try_from(work_synapses)
                        .map_err(|_| CpuHostError::State("CPU synapse work overflow"))?,
                },
                command,
            )?
            .with_finalized_memory_recall(&frame, &recall, index)?;
            P::stage(
                r,
                p,
                &action,
                CpuDecisionBinding {
                    sequence_id: sequence,
                    frame_digest: frame.frame_digest(),
                    action_id: candidate.action_id,
                    candidate_feature_digest: candidate.feature_digest()?,
                    dispatch_generation: output.dispatch_generation,
                    active_activation_side: output.active_activation_side,
                    joint_selection: joint,
                },
            )?;
            let mut cognitive = recall
                .cognitive_context()
                .cloned()
                .ok_or(CpuHostError::State("missing canonical cognitive context"))?;
            let pre_context = cognitive.clone();
            let source = grounded_semantic_state_from_frame(&frame)?;
            let motor_condition = JointMotorCondition::from_bundle(&bundle)?;
            let mut forecast = r.predictor.predict(&source, &motor_condition)?;
            forecast.source_digest = frame.frame_digest().0;
            // New owner derives physical emissions from all actually drawn rows.
            // Metadata index has no causal influence on this policy's emissions.
            let (arousal,commitment)=if P::ACTUAL_CONTACT || P::CHANNEL_NATIVE {
                let selected:Vec<usize>=motor_candidates.iter().flatten().map(|i|*i as usize).collect();
                let count=selected.len().max(1) as f32;
                (selected.iter().map(|i|output.candidate_logits[*i].abs().tanh()).sum::<f32>()/count,
                 selected.iter().map(|i|frame.candidates()[*i].sensor_confidence.raw()).sum::<f32>()/count)
            } else {(output.candidate_logits[index as usize].abs().tanh(),confidence.raw())};
            let mut neural_emissions = vec![
                NeuralEmission::new(
                    NeuralEmissionClass::RegionalArousal,
                    // Versioned source-driven biological arousal, deliberately
                    // distinct from the hierarchical grouped sampling scores.
                    arousal,
                    commitment,
                )?,
                NeuralEmission::new(
                    NeuralEmissionClass::MotorCommitment,
                    commitment,
                    commitment,
                )?,
                NeuralEmission::new(NeuralEmissionClass::ExecutiveSustain, commitment, 1.)?,
            ];
            neural_emissions.extend(recall.recognized_social_emission());
            let emissions =
                NeuralEmissionFrame::new(tick, output.dispatch_generation, neural_emissions)?;
            let object_novelty = bundle
                .channels
                .iter()
                .filter_map(|c| c.target.and_then(|t| t.entity))
                .filter_map(|entity| {
                    let key = perception_world
                        .entity(entity)?
                        .tracking_provenance
                        .canonical_key();
                    let tracked = perception_world
                        .tracked_objects()
                        .records_for(id)?
                        .find(|r| r.tracking_key == key)?;
                    pre_context
                        .peripheral
                        .summaries
                        .iter()
                        .find(|s| {
                            s.identity
                                == StableFocusIdentity::TrackedObject(tracked.tracked_object_id)
                        })
                        .map(|s| (entity, s.salience.novelty.raw()))
                })
                .collect::<Vec<_>>();
            let contact_bindings=if P::ACTUAL_CONTACT {
                Some(r.grouped.as_ref().and_then(|g|g.actual_contact.as_ref())
                    .ok_or(CpuHostError::State("missing actual-contact binding owner"))?
                    .contacts.bind_targets(&perception_world,&self.world,&frame,&bundle)?)
            }else{None};
            let receipt = {
                let state = r
                    .grouped
                    .as_mut()
                    .ok_or(CpuHostError::State("missing grouped physical owner"))?;
                let admission =
                    alife_world::SleepChoiceWorldAdmissionV1::for_organism(&self.world, id)?;
                let request = alife_world::RecoveryRequestV1::new(&admission, &frame, &bundle)?;
                let physical = self
                    .world
                    .apply_sleep_choice_motor_bundle_in_staged_tick(
                        &request,
                        &emissions,
                        frame.sensory().channels.novelty_signal.raw(),
                        &object_novelty,
                    )
                    .map_err(|_| {
                        CpuHostError::State("grouped M2 recovery motor transaction rejected")
                    })?;
                state.observe_physical(&frame, &bundle, &physical, &mut r.sleep)?;
                if physical.successful_stationary_body_sleep {
                    let phase = r.sleep.state();
                    let mut actual = self
                        .world
                        .organism_registry()
                        .get(id)
                        .cloned()
                        .ok_or(CpuHostError::State("grouped M2 sleep organism missing"))?;
                    actual.seal_sleep_phase(
                        phase.phase,
                        phase.active_cycle_id,
                        physical.motor.outcome_tick,
                        0,
                    )?;
                    self.world.replace_organism_record_exact(actual)?;
                }
                physical.motor
            };
            let contact_close = if P::ACTUAL_CONTACT {
                let source_digest=json_digest(b"ALIFE-ACTUAL-CONTACT-PENDING-V1",r.neural.actual_contact_source()?)?;
                Some(r.grouped.as_mut().and_then(|g|g.actual_contact.as_mut())
                    .ok_or(CpuHostError::State("missing actual-contact close owner"))?
                    .contacts.capture_close(&frame,&bundle,&receipt,motor_candidates,
                        output.dispatch_generation,source_digest,contact_bindings.as_ref()
                            .ok_or(CpuHostError::State("missing prephysical actual-contact bindings"))?)?)
            } else {None};
            let mut contact_work=crate::cpu::actual_contact_bank::Work::default();
            if let Some(prepared)=&contact_preparation {contact_work.add(prepared.work());}
            if let Some(closed)=&contact_close {contact_work.add(closed.work);}
            if P::ACTUAL_CONTACT {
                let (work_receipt,remaining)=super::actual_contact_work::ContactMemoryWorkReceiptV1::settle(
                    p,sequence,frame.frame_digest(),&bundle,contact_work,motor_reservation_q24,activity.available_atp_q16)?;
                r.activity.remaining_atp_q16=remaining;
                r.grouped.as_mut().and_then(|g|g.actual_contact.as_mut())
                    .ok_or(CpuHostError::State("missing actual-contact work owner"))?.contact_work=Some(work_receipt);
            }
            // The new semantic-memory policy is authored above. Byte-copy,
            // digest/codec and inherited administration remain separately
            // unpriced. Native qualification, not total compute parity, is pending.
            // The transaction already completed on staged state. Copies are output only.
            // On any later error the observed entry point returns no receipt or step.
            if let Some(out) = receipts.as_deref_mut() {
                out.push(receipt.clone());
            }
            let successor = grounded_successor_state(
                &self.world,
                record.world_entity_id(),
                &receipt.biology_after,
                frame.sensor_profile(),
            )?;
            let target = PredictionTargetReceipt::for_successor(
                id,
                sequence,
                candidate.action_id,
                tick,
                frame.frame_digest().0,
                source,
                motor_condition,
                successor,
            )?;
            let prediction = r.predictor.observe_frozen(&target, &forecast)?;
            let error = apply_prediction_evidence(
                &mut cognitive,
                &target,
                &prediction.error,
                prediction.prediction.category_coverage,
            )?;
            let memory = recall.receipt();
            let mut dendritic_work = r
                .v11
                .dendritic_branches()
                .branches()
                .iter()
                .map(|b| 1 + b.inputs.len() as u64)
                .sum::<u64>()
                * u64::from(activity.microsteps);
            dendritic_work += GroupedMotorStateV1::append_work(p)?.other_work
                + p.sensor_encoder().assignments().len() as u64;
            let structural_work = r
                .v11
                .sparse_spans()
                .iter()
                .flat_map(|s| &s.edges)
                .map(|e| {
                    if !activity.enabled_routes[e.route as usize] {
                        return 0;
                    }
                    (0..activity.microsteps as usize)
                        .filter(|&step| {
                            super::super::replay::route_fires(
                                p.projections()[e.route as usize].update_cadence().raw(),
                                step,
                            )
                        })
                        .count() as u64
                })
                .sum::<u64>();
            let work = CognitiveWorkCounters::new(
                work_neurons,
                work_synapses,
                dendritic_work,
                // Existing semantic attention work; unpriced machine bookkeeping
                // is deliberately absent from biological work counters.
                cognitive.attention.budget_receipt.work_units,
                u64::from(memory.exact_bucket_reads)
                    + u64::from(memory.neighbor_bucket_reads)
                    + u64::from(memory.similarity_evaluations)
                    + contact_work.memory_ops(),
                cognitive.concept.active_concepts.len() as u64,
                cognitive.gap.active_gaps.len() as u64,
                prediction.error.len() as u64,
                0,
                structural_work,
                0,
                0,
            )?
            .into_receipt()?;
            let mut after = self
                .world
                .organism_registry()
                .get(id)
                .cloned()
                .ok_or(CpuHostError::State("missing post-action organism"))?;
            let body_debit =
                after.account_cognitive_work(work, CognitiveWorkCostPolicy::enabled(1.0e-6)?)?;
            r.grouped
                .as_mut()
                .unwrap()
                .motor
                .last_receipt
                .as_mut()
                .unwrap()
                .applied_body_energy_debit = body_debit;
            after.stage_prediction_residual_pulse(
                sequence,
                output.dispatch_generation,
                error,
                1.,
            )?;
            self.world.replace_organism_record_exact(after.clone())?;
            let physiology =
                MeasuredPhysiologyTransition::new(receipt.biology_before, *after.biochemistry())?;
            let mut outcome = PostActionOutcome::new(
                id,
                sequence,
                receipt.outcome_tick,
                receipt.succeeded,
                receipt.joint.execution,
                physiology.homeostatic_delta,
                SignedValence::ZERO,
                NormalizedScalar::new(if receipt.succeeded { 0. } else { 1. })?,
                NormalizedScalar::new(physiology.aversive_harm())?,
                physiology.energy_delta,
                NormalizedScalar::new(error)?,
            )?
            .with_measured_physiology(physiology)?;
            outcome.contradiction_observed = !receipt.succeeded;
            outcome = outcome.with_v12_joint(receipt.joint, work)?;
            let patch = ExperiencePatch::new_v12_with_decision(
                pre,
                decision,
                bundle,
                outcome,
                target.clone(),
                work,
                pre_context,
            )?;
            let credit_receptors = receptors;
            P::close(&mut r.neural, founder, &patch, &credit_receptors)?;
            r.language_grounding.observe_sealed(&patch)?;
            let memory_write = r.memory.observe_sealed_patch(&patch)?;
            let topology_receipt = r.topology.observe_sealed_patch(&patch);
            if topology_receipt.rejected_invalid || topology_receipt.replay_rejected {
                return Err(CpuHostError::State("sealed topology observation rejected"));
            }
            r.topology.advance_lifecycle(receipt.outcome_tick)?;
            let checkpoint = r.neural.checkpoint()?;
            let credit = OutcomeCreditPacket::from_sealed_patch(&patch)?
                .with_biochemical_receptors(&credit_receptors)?;
            let selected = patch.decision().neural_evidence()?;
            r.replay.push(CpuReplayEvent {
                event: SleepReplayEvent {
                    sequence_id: sequence,
                    originating_tick: tick,
                    frame_digest: frame.frame_digest(),
                    candidate_feature_digest: candidate.feature_digest()?,
                    action_id: candidate.action_id,
                    family: selected.action_family,
                    modulator: credit.modulator(),
                },
                eligibility: p
                    .replay_capture_plan()
                    .global_synapse_ids()
                    .iter()
                    .map(|&id| {
                        let synapse = &p.synapses()[id as usize];
                        let decay = p.plasticity_receptors()[synapse.receptor_index() as usize]
                            .eligibility_decay();
                        let elapsed = (receipt.outcome_tick.raw() - tick.raw())
                            .min(u64::from(u32::MAX)) as f32;
                        (checkpoint.eligibility[id as usize] * decay.powf(elapsed))
                            .clamp(-1., 1.)
                            .mul_add(32767., 0.)
                            .round() as i16
                    })
                    .collect(),
                target,
            });
            if let Some(state) = &mut r.grouped {
                let event = r
                    .replay
                    .last()
                    .ok_or(CpuHostError::State("missing grouped replay event"))?;
                state.memory_proofs.push(SleepMemorySourceProofV1::capture(
                    &patch,
                    event.event,
                    &event.target,
                    memory_write,
                )?);
            }
            if r.replay.len() > p.replay_capture_plan().event_capacity() as usize {
                r.replay.remove(0);
                if let Some(state) = &mut r.grouped {
                    state.memory_proofs.remove(0);
                }
            }
            after.seal_cognitive_subsystems(
                receipt.outcome_tick,
                json_digest(b"ALIFE-CPU-NEURAL-STATE-V1", &checkpoint)?,
                r.memory.export_active_bank()?.active_bank_digest,
            )?;
            let parameters = after.phenotype().brain_genome.plasticity_parameters();
            let profile = parameters
                .action_candidate_credit_profile()
                .map_or_else(|| parameters.receptor_profile(), |p| p.receptor_profile());
            let _biological_reward = profile.project(&credit.modulator().frame())?;
            self.world.replace_organism_record_exact(after)?;
            r.next_sequence = r
                .next_sequence
                .checked_add(1)
                .ok_or(CpuHostError::State("sequence overflow"))?;
            let grouped = r.grouped.as_ref().unwrap();
            decisions.push(CpuGroupedM2HostDecisionV1 {
                organism_id: id,
                sampling_counter,
                action,
                administrative_work: P::administrative_receipt(r)?,
                actual_contact_input_lanes,
                source_diagnostic_logits: output.candidate_logits,
                biological_emissions: emissions,
                brain_work: activity.work,
                patch,
                motor: grouped
                    .motor
                    .last_receipt
                    .clone()
                    .ok_or(CpuHostError::State("missing grouped receipt"))?,
                physical: grouped
                    .last_physical
                    .clone()
                    .ok_or(CpuHostError::State("missing grouped physical receipt"))?,
                sleep_phase: r.sleep.state().phase,
                sleep_trigger: r.sleep.state().last_trigger,
            });
        }
        // The batch uses one pre-action scene. Commit the identities actually
        // observed there along with its decisions; priming stays read-only.
        let tracked_objects = self
            .residents
            .keys()
            .map(|&id| {
                perception_world
                    .tracked_objects()
                    .save_state(OrganismId(id))
            })
            .collect::<Result<Vec<_>, _>>()?;
        self.world.restore_tracked_object_states(tracked_objects)?;
        let tick_after = self
            .world
            .try_advance_tick_with_body_events_in_staged_tick(&body_events)?;
        self.seal_all_residents()?;
        Ok(CpuGroupedM2HostStepV1 {
            tick_before: tick,
            tick_after,
            decisions,
            sleeping_organisms: sleeping,
            sleep_consolidations: consolidations,
        })
    }
}

fn grouped_dynamic_work(
    p: &BrainPhenotype,
    r: &Resident,
    activity: &CpuActivityBudget,
) -> Result<u64, CpuHostError> {
    // The existing generic policy omits dynamic branches/spans and
    // encoder assignments. V1 prices their actual executed work too.
    let source_dynamic_q24 = r
        .v11
        .dendritic_branches()
        .branches()
        .iter()
        .try_fold(0_u64, |sum, b| {
            sum.checked_add(16 + 4 * b.inputs.len() as u64)
        })
        .and_then(|n| n.checked_mul(u64::from(activity.microsteps)))
        .and_then(|n| n.checked_add(4 * p.sensor_encoder().assignments().len() as u64))
        .ok_or(CpuHostError::State("source dynamic work overflow"))?;
    let structural_ops = r
        .v11
        .sparse_spans()
        .iter()
        .flat_map(|s| &s.edges)
        .try_fold(0_u64, |sum, e| {
            if e.source >= 2048 || e.target >= 2048 || e.route as usize >= p.projections().len() {
                return Err(CpuHostError::State("dynamic edge enters fixed controller"));
            }
            let visits = if activity.enabled_routes[e.route as usize] {
                (0..activity.microsteps as usize)
                    .filter(|&step| {
                        super::super::replay::route_fires(
                            p.projections()[e.route as usize].update_cadence().raw(),
                            step,
                        )
                    })
                    .count() as u64
            } else {
                0
            };
            sum.checked_add(visits)
                .ok_or(CpuHostError::State("source structural work overflow"))
        })?;
    let dynamic = source_dynamic_q24
        .checked_add(
            structural_ops
                .checked_mul(4)
                .ok_or(CpuHostError::State("structural price overflow"))?,
        )
        .ok_or(CpuHostError::State("source dynamic price overflow"))?;
    Ok(dynamic)
}
