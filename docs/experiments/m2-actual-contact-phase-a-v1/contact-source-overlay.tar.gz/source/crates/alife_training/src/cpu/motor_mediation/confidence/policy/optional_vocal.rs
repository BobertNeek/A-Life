//! Closed optional Vocal factor. Quiet is a policy choice, never a world primitive.
//! The native confidence-V2 circuit supplies scores, not V2 sampling ownership.
use super::*;
use alife_core::{LanguageTokenId, SpeechActKind, SpeechMotorPayload};

pub const OPTIONAL_VOCAL_POLICY_V1: &str = "m2-optional-vocal-v1;closed;idle-mediated-quiet;source-payload-removal;cooldown-physical;no-gradient";
const RNG_DOMAIN: u32 = 0x4f56_4331;

/// Exact source-output evidence. Only the resident's pending forward constructs it.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OptionalVocalSourceV1 {
    policy: String,
    owner: OrganismId,
    tick: Tick,
    source: PhenotypeHash,
    frame: PerceptionFrameDigest,
    dispatch_generation: u64,
    activation_side: u8,
    output_digest: [u8; 32],
    payload: Option<PayloadBits>,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PayloadBits {
    act: u8,
    tokens: Vec<u16>,
    confidence: u32,
}
impl OptionalVocalSourceV1 {
    #[allow(clippy::too_many_arguments)]
    pub(in crate::cpu) fn from_forward(
        owner: OrganismId,
        tick: Tick,
        source: PhenotypeHash,
        frame: PerceptionFrameDigest,
        dispatch_generation: u64,
        activation_side: u8,
        activations: &[f32],
        offsets: &[f32],
        speech: Option<SpeechMotorPayload>,
    ) -> Result<Self, TrainingError> {
        finite(activations)?;
        finite(offsets)?;
        let payload = speech.map(|p| PayloadBits {
            act: p.speech_act.raw(),
            tokens: p.tokens.iter().map(|t| t.raw()).collect(),
            confidence: p.confidence.raw().to_bits(),
        });
        let mut hasher = Sha256::new();
        hasher.update(OPTIONAL_VOCAL_POLICY_V1.as_bytes());
        for bank in [activations, offsets] {
            hasher.update((bank.len() as u64).to_le_bytes());
            for x in bank {
                hasher.update(x.to_bits().to_le_bytes());
            }
        }
        let result = Self {
            policy: OPTIONAL_VOCAL_POLICY_V1.into(),
            owner,
            tick,
            source,
            frame,
            dispatch_generation,
            activation_side,
            output_digest: hasher.finalize().into(),
            payload,
        };
        result.validate()?;
        Ok(result)
    }
    fn validate(&self) -> Result<(), TrainingError> {
        if self.policy != OPTIONAL_VOCAL_POLICY_V1
            || self.dispatch_generation == 0
            || self.activation_side > 1
        {
            return Err(invalid());
        }
        self.owner.validate()?;
        self.speech()?;
        Ok(())
    }
    pub fn speech(&self) -> Result<Option<SpeechMotorPayload>, TrainingError> {
        self.payload
            .as_ref()
            .map(|p| {
                Ok(SpeechMotorPayload::try_new(
                    SpeechActKind::try_from_raw(p.act)?,
                    p.tokens
                        .iter()
                        .map(|&t| LanguageTokenId::new(t))
                        .collect::<Result<_, _>>()?,
                    Confidence::new(f32::from_bits(p.confidence))?,
                )?)
            })
            .transpose()
    }
    pub fn payload_present(&self) -> bool {
        self.payload.is_some()
    }
    pub(in crate::cpu) fn validate_identity(
        &self,
        owner: OrganismId,
        tick: Tick,
        source: PhenotypeHash,
        frame: PerceptionFrameDigest,
        generation: u64,
        side: u8,
    ) -> Result<(), TrainingError> {
        self.validate()?;
        if (
            self.owner,
            self.tick,
            self.source,
            self.frame,
            self.dispatch_generation,
            self.activation_side,
        ) != (owner, tick, source, frame, generation, side)
        {
            return Err(invalid());
        }
        Ok(())
    }
}

/// Closed sampler input. All floating sampling values are persisted as IEEE bits.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OptionalVocalScoresV1 {
    policy: String,
    source: OptionalVocalSourceV1,
    native_binding: RecoveryGroupBindingV2,
    ordinary_bits: Vec<u64>,
    group_bits: u64,
    operation_bits: [u64; 2],
    idle: u16,
    idle_feature_digest: CandidateFeatureDigest,
    vocal_mask: u32,
    eligible_mask: u32,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OptionalVocalChoiceV1 {
    NoOp,
    Candidate(u16),
    RestGroup,
    Quiet,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OptionalVocalActionV1 {
    policy: String,
    binding_digest: [u8; 32],
    representative: OptionalVocalChoiceV1,
    motors: [OptionalVocalChoiceV1; 6],
    operation: Option<u8>,
    temperature_bits: u64,
    joint_log_probability_bits: u64,
    seed: u32,
    counter: u32,
    draw_factors: Vec<u32>,
}
impl OptionalVocalActionV1 {
    pub fn representative(&self) -> OptionalVocalChoiceV1 {
        self.representative
    }
    pub fn motors(&self) -> [OptionalVocalChoiceV1; 6] {
        self.motors
    }
    pub fn operation(&self) -> Option<u8> {
        self.operation
    }
    pub fn seed(&self) -> u32 {
        self.seed
    }
    pub fn counter(&self) -> u32 {
        self.counter
    }
    pub fn temperature(&self) -> f64 {
        f64::from_bits(self.temperature_bits)
    }
    pub fn joint_log_probability(&self) -> f64 {
        f64::from_bits(self.joint_log_probability_bits)
    }
    pub fn draw_factors(&self) -> &[u32] {
        &self.draw_factors
    }
}
#[derive(Debug, Clone, Serialize)]
pub struct OptionalVocalFactorV1 {
    pub outcomes: Vec<OptionalVocalChoiceV1>,
    pub probabilities: Vec<f64>,
    pub log_probabilities: Vec<f64>,
}
impl OptionalVocalFactorV1 {
    fn canonical_idle(index: u16) -> Result<ActionCandidate, TrainingError> {
        Ok(ActionCandidate::new(
            index,
            ActionKind::Idle.canonical_id(),
            ActionKind::Idle,
            CandidateActionFamily::Idle,
            CandidateObservationRef::None,
            ActionTarget::NONE,
            CandidateFeatureVector::zero().with_intrinsic_action_basis(ActionKind::Idle),
            Confidence::new(1.)?,
            NormalizedScalar::new(0.)?,
            DurationTicks::new(1),
            DurationTicks::new(1),
        )?)
    }
    fn from_native(d: RecoveryGroupFactorV2) -> Self {
        Self {
            outcomes: d.outcomes.into_iter().map(from_native).collect(),
            probabilities: d.probabilities,
            log_probabilities: d.log_probabilities,
        }
    }
    fn new(
        outcomes: Vec<OptionalVocalChoiceV1>,
        logits: Vec<f64>,
        t: f64,
    ) -> Result<Self, TrainingError> {
        valid_temperature(t)?;
        if outcomes.len() != logits.len()
            || logits.is_empty()
            || logits.iter().any(|x| !x.is_finite() || x.abs() > 1e30)
        {
            return Err(invalid());
        }
        let max = logits.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let sum = logits.iter().map(|x| ((x - max) / t).exp()).sum::<f64>();
        if !sum.is_finite() || sum <= 0. {
            return Err(invalid());
        }
        let log_probabilities: Vec<_> = logits.iter().map(|x| (x - max) / t - sum.ln()).collect();
        let probabilities = log_probabilities.iter().map(|x| x.exp()).collect();
        Ok(Self {
            outcomes,
            probabilities,
            log_probabilities,
        })
    }
    fn sample(&self, u: f64) -> OptionalVocalChoiceV1 {
        let mut sum = 0.;
        for (&o, p) in self.outcomes.iter().zip(&self.probabilities) {
            sum += p;
            if u < sum {
                return o;
            }
        }
        *self.outcomes.last().expect("validated nonempty factor")
    }
    fn logp(&self, o: OptionalVocalChoiceV1) -> Result<f64, TrainingError> {
        self.outcomes
            .iter()
            .position(|x| *x == o)
            .map(|i| self.log_probabilities[i])
            .ok_or_else(invalid)
    }
    pub fn probability(&self, o: OptionalVocalChoiceV1) -> f64 {
        self.outcomes
            .iter()
            .position(|x| *x == o)
            .map_or(0., |i| self.probabilities[i])
    }
}
#[derive(Debug, Clone, Serialize)]
pub struct OptionalVocalProbabilitiesV1 {
    pub representative: OptionalVocalFactorV1,
    pub channels: [Option<OptionalVocalFactorV1>; 6],
    pub conditional_operation: [f64; 2],
    pub conditional_log_probability: [Option<f64>; 2],
    /// Marginal after representative forcing, not merely the independent factor.
    pub actual_quiet_probability: f64,
    pub actual_vocal_probability: f64,
}
#[derive(Debug, Clone, Serialize)]
pub struct OptionalVocalEvaluationV1 {
    pub joint_log_probability: f64,
    pub joint_probability: f64,
    pub factor_log_probabilities: Vec<f64>,
    pub selected_physical_candidates_once: Vec<u16>,
}
fn from_native(c: RecoveryGroupChoiceV2) -> OptionalVocalChoiceV1 {
    match c {
        RecoveryGroupChoiceV2::NoOp => OptionalVocalChoiceV1::NoOp,
        RecoveryGroupChoiceV2::Candidate(i) => OptionalVocalChoiceV1::Candidate(i),
        RecoveryGroupChoiceV2::RestGroup => OptionalVocalChoiceV1::RestGroup,
    }
}
impl OptionalVocalScoresV1 {
    /// Host-only admission; no caller-supplied readiness Boolean or virtual ID.
    pub(in crate::cpu) fn bind(
        p: &BrainPhenotype,
        frame: &PerceptionFrame,
        native: &RecoveryGroupScoresV2,
        source: OptionalVocalSourceV1,
    ) -> Result<Self, TrainingError> {
        native.validate_context(
            p,
            frame,
            native.binding.attempt_mask,
            native.binding.enabled,
            native.binding.generation,
        )?;
        source.validate_identity(
            frame.organism_id(),
            frame.tick(),
            p.phenotype_hash(),
            frame.frame_digest(),
            native
                .binding
                .generation
                .checked_add(1)
                .ok_or_else(invalid)?,
            source.activation_side,
        )?;
        let mut idle = None;
        let mut vocal_mask = 0;
        for (i, c) in frame.candidates().iter().enumerate() {
            // Any row claiming the canonical identity or either Idle semantic
            // field must be this one exact source row. Reject ambiguous aliases.
            if c.action_id == ActionKind::Idle.canonical_id()
                || c.kind == ActionKind::Idle
                || c.family == CandidateActionFamily::Idle
            {
                if idle.is_some()
                    || c.action_id != ActionKind::Idle.canonical_id()
                    || c.kind != ActionKind::Idle
                    || c.family != CandidateActionFamily::Idle
                    || c.target != ActionTarget::NONE
                    || c.observation != CandidateObservationRef::None
                    || c.features
                        != CandidateFeatureVector::zero()
                            .with_intrinsic_action_basis(ActionKind::Idle)
                    || c.candidate_index as usize != i
                    || c.sensor_confidence.raw().to_bits() != 1_f32.to_bits()
                    || c.required_effort.raw().to_bits() != 0_f32.to_bits()
                    || c.min_duration.raw() != 1
                    || c.max_duration.raw() != 1
                    || c.feature_digest()?
                        != OptionalVocalFactorV1::canonical_idle(i as u16)?.feature_digest()?
                {
                    return Err(invalid());
                }
                idle = Some(i as u16);
            }
            if c.kind == ActionKind::Vocalize {
                vocal_mask |= 1u32 << i;
            }
        }
        let idle = idle.ok_or_else(invalid)?;
        let eligible_mask = native.binding.eligible_mask
            & if source.payload_present() {
                u32::MAX
            } else {
                !vocal_mask
            };
        let result = Self {
            policy: OPTIONAL_VOCAL_POLICY_V1.into(),
            source,
            native_binding: native.binding.clone(),
            ordinary_bits: native.ordinary.iter().map(|x| x.to_bits()).collect(),
            group_bits: native.group.to_bits(),
            operation_bits: native.operations.map(f64::to_bits),
            idle,
            idle_feature_digest: OptionalVocalFactorV1::canonical_idle(idle)?.feature_digest()?,
            vocal_mask,
            eligible_mask,
        };
        result.validate()?;
        Ok(result)
    }
    fn native(&self) -> RecoveryGroupScoresV2 {
        RecoveryGroupScoresV2 {
            binding: self.native_binding.clone(),
            ordinary: self
                .ordinary_bits
                .iter()
                .map(|&x| f64::from_bits(x))
                .collect(),
            group: f64::from_bits(self.group_bits),
            operations: self.operation_bits.map(f64::from_bits),
        }
    }
    fn validate(&self) -> Result<(), TrainingError> {
        self.source.validate()?;
        let native = self.native();
        native.validate()?;
        let n = native.ordinary.len();
        let mut canonical_idle = None;
        for (i, identity) in native.binding.identities.iter().enumerate() {
            let (id, target, kind, family): (
                ActionId,
                ActionTarget,
                ActionKind,
                CandidateActionFamily,
            ) = serde_json::from_str(identity).map_err(|_| invalid())?;
            if id == ActionKind::Idle.canonical_id()
                || kind == ActionKind::Idle
                || family == CandidateActionFamily::Idle
            {
                if canonical_idle.is_some()
                    || id != ActionKind::Idle.canonical_id()
                    || target != ActionTarget::NONE
                    || kind != ActionKind::Idle
                    || family != CandidateActionFamily::Idle
                {
                    return Err(invalid());
                }
                canonical_idle = Some(i as u16);
            }
        }
        if canonical_idle != Some(self.idle)
            || self.idle_feature_digest
                != OptionalVocalFactorV1::canonical_idle(self.idle)?.feature_digest()?
        {
            return Err(invalid());
        }
        let expected_vocal = (0..n)
            .filter(|&i| native.binding.forced[i] == Some(3))
            .fold(0, |mask, i| mask | (1u32 << i));
        if self.policy != OPTIONAL_VOCAL_POLICY_V1
            || usize::from(self.idle) >= n
            || native.binding.forced[self.idle as usize] != Some(4)
            || native.binding.channel_members[self.idle as usize]
            || native.binding.is_recovery(self.idle as usize)
            || self.vocal_mask != expected_vocal
            || self.eligible_mask
                != (native.binding.eligible_mask
                    & if self.source.payload_present() {
                        u32::MAX
                    } else {
                        !self.vocal_mask
                    })
            || self.eligible_mask == 0
            || native.binding.source_hash != self.source.source
            || native.binding.frame_digest != self.source.frame
            || native.binding.generation.checked_add(1) != Some(self.source.dispatch_generation)
        {
            return Err(invalid());
        }
        Ok(())
    }
    pub(in crate::cpu) fn validate_native(
        &self,
        native: &RecoveryGroupScoresV2,
    ) -> Result<(), TrainingError> {
        self.validate()?;
        native.validate()?;
        if self.native_binding != native.binding
            || self.ordinary_bits
                != native
                    .ordinary
                    .iter()
                    .map(|x| x.to_bits())
                    .collect::<Vec<_>>()
            || self.group_bits != native.group.to_bits()
            || self.operation_bits != native.operations.map(f64::to_bits)
        {
            return Err(invalid());
        }
        Ok(())
    }
    pub(in crate::cpu) fn validate_source(
        &self,
        source: &OptionalVocalSourceV1,
    ) -> Result<(), TrainingError> {
        self.validate()?;
        if self.source != *source {
            return Err(invalid());
        }
        Ok(())
    }
    pub fn source(&self) -> &OptionalVocalSourceV1 {
        &self.source
    }
    pub fn eligible_mask(&self) -> u32 {
        self.eligible_mask
    }
    pub fn quiet_score(&self) -> f64 {
        f64::from_bits(self.ordinary_bits[self.idle as usize])
    }
    fn digest(&self) -> Result<[u8; 32], TrainingError> {
        Ok(Sha256::digest(serde_json::to_vec(self).map_err(|_| invalid())?).into())
    }
    pub fn probabilities(&self, t: f64) -> Result<OptionalVocalProbabilitiesV1, TrainingError> {
        self.validate()?;
        valid_temperature(t)?;
        let mut masked = self.native();
        masked.binding.eligible_mask = self.eligible_mask;
        let legacy = masked.probabilities(t)?;
        let representative = OptionalVocalFactorV1::from_native(legacy.representative);
        let mut channels = legacy
            .channels
            .map(|f| f.map(OptionalVocalFactorV1::from_native));
        if self.native_binding.enabled[3] {
            let mut outcomes = vec![OptionalVocalChoiceV1::Quiet];
            let mut logits = vec![self.quiet_score()];
            for &i in &self.native_binding.order {
                if self.eligible_mask & self.vocal_mask & (1u32 << i) != 0 {
                    outcomes.push(OptionalVocalChoiceV1::Candidate(i as u16));
                    logits.push(f64::from_bits(self.ordinary_bits[i]));
                }
            }
            channels[3] = Some(OptionalVocalFactorV1::new(outcomes, logits, t)?);
        }
        let forced_vocal = representative
            .outcomes
            .iter()
            .zip(&representative.probabilities)
            .filter(|(o, _)| self.forced(**o) == Some(3))
            .map(|(_, p)| p)
            .sum::<f64>();
        let non_forced = representative
            .outcomes
            .iter()
            .zip(&representative.probabilities)
            .filter(|(o, _)| self.forced(**o) != Some(3))
            .map(|(_, p)| p)
            .sum::<f64>();
        let quiet = channels[3]
            .as_ref()
            .map_or(1., |f| f.probability(OptionalVocalChoiceV1::Quiet));
        let speech = channels[3].as_ref().map_or(0., |f| {
            f.outcomes
                .iter()
                .zip(&f.probabilities)
                .filter(|(o, _)| matches!(o, OptionalVocalChoiceV1::Candidate(_)))
                .map(|(_, p)| p)
                .sum::<f64>()
        });
        Ok(OptionalVocalProbabilitiesV1 {
            representative,
            channels,
            conditional_operation: legacy.conditional_operation,
            conditional_log_probability: legacy.conditional_log_probability,
            actual_quiet_probability: non_forced * quiet,
            actual_vocal_probability: forced_vocal + non_forced * speech,
        })
    }
    fn forced(&self, c: OptionalVocalChoiceV1) -> Option<usize> {
        match c {
            OptionalVocalChoiceV1::Candidate(i) => self
                .native_binding
                .forced
                .get(i as usize)
                .copied()
                .flatten(),
            OptionalVocalChoiceV1::RestGroup => Some(4),
            _ => None,
        }
    }
    pub fn sample(
        &self,
        seed: u32,
        counter: u32,
        t: f64,
    ) -> Result<OptionalVocalActionV1, TrainingError> {
        let d = self.probabilities(t)?;
        let mut draws = vec![0];
        let representative = d.representative.sample(optional_draw(seed, counter, 0));
        let mut motors = [OptionalVocalChoiceV1::NoOp; 6];
        let mut op_factor = if representative == OptionalVocalChoiceV1::RestGroup {
            Some(1)
        } else {
            None
        };
        let mut lp = d.representative.logp(representative)?;
        for (s, motor) in motors.iter_mut().enumerate() {
            if self.forced(representative) == Some(s) {
                *motor = representative;
            } else if let Some(f) = &d.channels[s] {
                *motor = if f.outcomes == [OptionalVocalChoiceV1::NoOp] {
                    OptionalVocalChoiceV1::NoOp
                } else {
                    let id = 2 + s as u32;
                    draws.push(id);
                    f.sample(optional_draw(seed, counter, id))
                };
                lp += f.logp(*motor)?;
                if *motor == OptionalVocalChoiceV1::RestGroup {
                    op_factor = Some(8);
                }
            }
        }
        let operation = if let Some(f) = op_factor {
            draws.push(f);
            let mask = self.native_binding.operation_mask();
            let o = if mask[0]
                && (!mask[1] || optional_draw(seed, counter, f) < d.conditional_operation[0])
            {
                0
            } else {
                1
            };
            lp += d.conditional_log_probability[o].ok_or_else(invalid)?;
            Some(o as u8)
        } else {
            None
        };
        Ok(OptionalVocalActionV1 {
            policy: OPTIONAL_VOCAL_POLICY_V1.into(),
            binding_digest: self.digest()?,
            representative,
            motors,
            operation,
            temperature_bits: t.to_bits(),
            joint_log_probability_bits: lp.to_bits(),
            seed,
            counter,
            draw_factors: draws,
        })
    }
    /// Closed evaluation verifies the actual RNG draw, not merely shape or logp.
    /// No gradient is exposed. Future learning needs its own typed composition.
    pub fn evaluate(
        &self,
        action: &OptionalVocalActionV1,
    ) -> Result<OptionalVocalEvaluationV1, TrainingError> {
        if *action != self.sample(action.seed, action.counter, action.temperature())? {
            return Err(invalid());
        }
        let d = self.probabilities(action.temperature())?;
        let mut factors = vec![d.representative.logp(action.representative)?];
        for s in 0..6 {
            if self.forced(action.representative) != Some(s) {
                if let Some(f) = &d.channels[s] {
                    factors.push(f.logp(action.motors[s])?);
                }
            }
        }
        if let Some(o) = action.operation {
            factors.push(d.conditional_log_probability[o as usize].ok_or_else(invalid)?);
        }
        let mut physical = vec![];
        for c in std::iter::once(action.representative).chain(action.motors) {
            if let Some(i) = self.resolve(c, action.operation)? {
                if !physical.contains(&i) {
                    physical.push(i);
                }
            }
        }
        Ok(OptionalVocalEvaluationV1 {
            joint_log_probability: action.joint_log_probability(),
            joint_probability: action.joint_log_probability().exp(),
            factor_log_probabilities: factors,
            selected_physical_candidates_once: physical,
        })
    }
    fn resolve(
        &self,
        c: OptionalVocalChoiceV1,
        operation: Option<u8>,
    ) -> Result<Option<u16>, TrainingError> {
        match c {
            OptionalVocalChoiceV1::Candidate(i) => Ok(Some(i)),
            OptionalVocalChoiceV1::NoOp | OptionalVocalChoiceV1::Quiet => Ok(None),
            OptionalVocalChoiceV1::RestGroup => operation
                .and_then(|o| {
                    self.native_binding
                        .operations
                        .get(o as usize)
                        .copied()
                        .flatten()
                })
                .map(|i| Some(i as u16))
                .ok_or_else(invalid),
        }
    }
    pub fn validate_sampling_context(
        &self,
        action: &OptionalVocalActionV1,
        seed: u32,
        counter: u32,
        temperature: f64,
    ) -> Result<(), TrainingError> {
        if action.seed != seed
            || action.counter != counter
            || action.temperature_bits != temperature.to_bits()
        {
            return Err(invalid());
        }
        self.evaluate(action)?;
        Ok(())
    }
    pub fn physical_selection(
        &self,
        action: &OptionalVocalActionV1,
    ) -> Result<(u16, [Option<u16>; 6]), TrainingError> {
        self.evaluate(action)?;
        let representative = self
            .resolve(action.representative, action.operation)?
            .ok_or_else(invalid)?;
        let mut motors = [None; 6];
        for (m, c) in motors.iter_mut().zip(action.motors) {
            *m = self.resolve(c, action.operation)?;
        }
        Ok((representative, motors))
    }
}
fn optional_draw(seed: u32, counter: u32, factor: u32) -> f64 {
    let mut v =
        seed ^ RNG_DOMAIN ^ counter.wrapping_mul(0x9e3779b9) ^ factor.wrapping_mul(0x85ebca6b);
    v = (v ^ (v >> 16)).wrapping_mul(0x7feb352d);
    v = (v ^ (v >> 15)).wrapping_mul(0x846ca68b);
    v ^= v >> 16;
    (f64::from(v >> 9) + 0.5) / 8388608.
}

#[cfg(test)]
mod tests;

// Source-only channel-native experiment. No resident/host registration or export.
#[allow(dead_code)]
mod channel_native;

pub use channel_native::{ChannelScores as ChannelNativeScoresV1, BundleAction as ChannelNativeActionV1, Choice as ChannelNativeChoiceV1, CHANNEL_NATIVE_POLICY_V1};
pub use channel_native::ChannelNativeAdministrativeReceiptV1;

mod actual_contact;
pub use actual_contact::{ChannelScores as ActualContactScoresV1, BundleAction as ActualContactActionV1, Choice as ActualContactChoiceV1, ACTUAL_CONTACT_POLICY_V1, ActualContactAdministrativeReceiptV1};
