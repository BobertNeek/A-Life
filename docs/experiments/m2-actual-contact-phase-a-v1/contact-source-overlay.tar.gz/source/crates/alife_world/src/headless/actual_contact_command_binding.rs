//! Narrow read-only binding seam for the separate fresh contact owner.
//! Uses the existing authoritative law; no command is executed here.
use super::*;
pub fn adapt_motor_channel_for_contact_binding_v1(
    command:&ChannelCommand,
    embodiment:&EmbodimentState,
    locomotor_capacity:Option<f32>,
)->Result<ChannelCommand,HeadlessMotorTransactionError>{
    adapt_motor_channel_to_embodiment(command,embodiment,locomotor_capacity)
}
