//! Explicit fresh CPU experiment. No old-life import, automatic retry or upload.
#[path = "support/grouped_m2_journal_v1.rs"]
mod journal;
#[path = "support/object_rich_host_v1.rs"]
mod policy_host;
#[path = "support/object_rich_qualification_v1.rs"]
mod qualification;
#[path = "support/grouped_m2_raw_v1.rs"]
mod raw;
#[allow(dead_code)]
#[path = "support/recovery_sleep_recipe_v1.rs"]
mod recipe;
#[path = "support/object_rich_scene_v1.rs"]
mod scene;
use alife_core::*;
use alife_training::{cpu::*, AdamWConfig, StageTrainableMask};
use alife_world::*;
use policy_host::{Host, Step};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
const STUDY: &str = "m2-object-rich-optional-vocal-v1";
const RESERVATION_PATH: &str =
    "/workspace/shared/m2-object-rich-optional-vocal-v1-seed-reservation.json";
// Pure source/admission preflight: no genome, host, world, body or sampler is constructed.
fn seed_admission_preflight(seed: u64, founder_count: u16) -> Result<u64> {
    CanonicalNewGameConfig::phase3(seed, founder_count)
        .map_err(|e| format!("pre-claim seed/config admission: {e}"))?;
    seed.checked_mul(16)
        .and_then(|base| base.checked_add(u64::from(founder_count)))
        .ok_or_else(|| format!(
            "pre-claim seed-domain overflow: seed {seed:#018x}, founder_count {founder_count}, maximum seed {:#018x}",
            (u64::MAX - u64::from(founder_count)) / 16
        ).into())
}
fn canonical_reservation(path: &Path) -> Result<()> {
    if path.canonicalize()? != Path::new(RESERVATION_PATH)
        || fs::symlink_metadata(path)?.file_type().is_symlink()
    {
        return Err("not the authoritative primary reservation path".into());
    }
    Ok(())
}
const ACTIVATION_PATH: &str =
    "/workspace/shared/m2-object-rich-optional-vocal-v1-seed-reservation.json.activation.json";
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct ActivationClaim {
    schema: String,
    study: String,
    root: PathBuf,
    freeze_sha256: String,
    reservation_sha256: String,
    claim_implies_preparation_attempt: bool,
    claim_implies_world_step: bool,
}
fn validate_activation(
    claim: &ActivationClaim,
    root: &Path,
    freeze_sha256: &str,
    reservation_sha256: &str,
) -> Result<()> {
    if claim.schema != "object-rich-optional-vocal-preparation-claim-v1"
        || claim.study != STUDY
        || claim.root != root.canonicalize()?
        || claim.freeze_sha256 != freeze_sha256
        || claim.reservation_sha256 != reservation_sha256
        || !claim.claim_implies_preparation_attempt
        || claim.claim_implies_world_step
    {
        return Err("authoritative activation root or identity differs".into());
    }
    Ok(())
}
const SEED: u64 = 0x034F_4256_4F43_0901;
const FIXTURE_SEED: u64 = 0x0347_5250_484F_5354; // existing qualified host unit fixture
const PREPARATION: u64 = 240;
const HORIZON: u64 = 64;
const TEMPERATURE: f32 = 1.;
const HOST_COMMIT: &str = "fbf2a517f93098b5d936878a3d26bbb8d0391c38";
const HOST_TREE: &str = "020d7a4b036d0309a4ffdd762536c36e945f7496";
const DRIVER_COMMIT: &str = match option_env!("ALIFE_GROUPED_M2_DRIVER_SOURCE_COMMIT") {
    Some(s) => s,
    None => "unqualified-development-build",
};
const PROTOCOL: &[u8] = include_bytes!("../../../PROTOCOL.md");
fn hash(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn code_hash() -> String {
    let mut h = Sha256::new();
    for bytes in [
        include_bytes!("probe_object_rich_optional_vocal_v1.rs").as_slice(),
        include_bytes!("support/grouped_m2_journal_v1.rs").as_slice(),
        include_bytes!("support/grouped_m2_raw_v1.rs").as_slice(),
        include_bytes!("support/object_rich_qualification_v1.rs").as_slice(),
        include_bytes!("support/recovery_sleep_recipe_v1.rs").as_slice(),
        include_bytes!("support/grounded_r0_dedicated_fatigue.rs").as_slice(),
        include_bytes!("support/multidrive_frozen.rs").as_slice(),
        include_bytes!("support/grounded_r0_motor_operating_point.rs").as_slice(),
        include_bytes!("support/object_rich_scene_v1.rs").as_slice(),
        include_bytes!("support/object_rich_host_v1.rs").as_slice(),
        include_bytes!("../../../RUNTIME-SOURCE.json").as_slice(),
        PROTOCOL,
    ] {
        h.update((bytes.len() as u64).to_le_bytes());
        h.update(bytes);
    }
    format!("{:x}", h.finalize())
}
fn executable_hash() -> Result<String> {
    Ok(hash(&journal::bounded_read(
        &std::env::current_exe()?,
        512 * 1024 * 1024,
    )?))
}
fn sampling_seed(seed: u64) -> u32 {
    (seed ^ (seed >> 32)) as u32
}
fn mode(arm: usize) -> Result<MediationModeV1> {
    if arm > 1 {
        return Err("only two policies exist".into());
    }
    Ok(MediationModeV1::Full)
}
fn mode_name(arm: usize) -> Result<&'static str> {
    match arm {
        0 => Ok("LegacyGroupedM2/Full"),
        1 => Ok("OptionalVocalM2/Full"),
        _ => Err("only two policies exist".into()),
    }
}
fn cp(host: &Host) -> Result<Vec<u8>> {
    host.wire()
}

fn write_new<T: Serialize>(dir: &Path, name: &str, value: &T) -> Result<()> {
    journal::publish_artifact(dir, name, &serde_json::to_vec(value)?, journal::MAX_PACKET)
}
fn read_typed<T: serde::de::DeserializeOwned>(path: &Path, max: u64) -> Result<(T, Vec<u8>)> {
    let bytes = journal::bounded_read(path, max)?;
    Ok((serde_json::from_slice(&bytes)?, bytes))
}
fn closure_hash(cp: &[u8]) -> Result<String> {
    Ok(hash(&serde_json::to_vec(&raw::closure(cp)?)?))
}
fn validate_cp(bytes: &[u8], tick: u64, expected_closure: &str) -> Result<()> {
    let roundtrip = if bytes.starts_with(raw::MAGIC) {
        CpuGroupedM2HostCheckpointV1::decode(bytes)?.encode()?
    } else {
        CpuOptionalVocalM2HostCheckpointV1::decode(bytes)?.encode()?
    };
    if roundtrip != bytes
        || raw::payload(bytes)?
            .path(&["canonical", "world", "world", "tick"])?
            .value::<u64>()?
            != tick
        || closure_hash(bytes)? != expected_closure
    {
        return Err("checkpoint tick/roundtrip/closed banks differ".into());
    }
    Ok(())
}
fn restore(
    bytes: &[u8],
    inputs: &PhenotypeCompilerInputs,
    arm: usize,
    tick: u64,
    closure: &str,
) -> Result<Host> {
    validate_cp(bytes, tick, closure)?;
    let host = match arm {
        0 => Host::Legacy(CpuGroupedM2HostV1::restore(
            CpuGroupedM2HostCheckpointV1::decode(bytes)?,
            inputs,
            mode(arm)?,
        )?),
        1 => Host::Optional(CpuOptionalVocalM2HostV1::restore(
            CpuOptionalVocalM2HostCheckpointV1::decode(bytes)?,
            inputs,
            mode(arm)?,
        )?),
        _ => return Err("invalid policy".into()),
    };
    if host.world().tick().raw() != tick || cp(&host)? != bytes {
        return Err("cold restore changed bytes".into());
    }
    Ok(host)
}

fn source_contract(r: &recipe::Recipe) -> Result<Value> {
    let rows=r.phenotype.synapses().iter().enumerate().filter(|(_,s)|matches!(s.kind(),CompiledSynapseKind::Decoder(c) if c.head()==DecoderHeadKind::MemoryContext&&c.family()==CandidateActionFamily::Rest)).collect::<Vec<_>>();
    if rows.len() != 512
        || rows
            .iter()
            .any(|(i, s)| s.genetic_weight().to_bits() != 0 || r.asset.weights()[*i].to_bits() != 0)
        || r.metadata["pressure_value"] != 0.
    {
        return Err("closed B1 Rest-reader/pressure source contract differs".into());
    }
    Ok(
        json!({"rest_reader_count":512,"rest_reader_genetic_and_asset_nonzero":0,"index_basis":"actual compiled Decoder MemoryContext/Rest coordinates, not PAM ordinal labels","pressure_value":0.,"synaptic_learning":"closed"}),
    )
}
fn trainer(r: &recipe::Recipe, sentinel: bool) -> Result<CpuFoundationTrainer> {
    let mut trainer = CpuFoundationTrainer::new(
        r.phenotype.clone(),
        r.asset.clone(),
        StageTrainableMask::recurrent_only(&r.phenotype)?,
        AdamWConfig::default(),
    )?;
    if sentinel {
        let mut c = trainer.checkpoint();
        c.optimizer_step = 23;
        c.update_ages[0] = 23;
        c.first_moment[0] = 0.03125;
        c.second_moment[0] = 0.0625;
        trainer = CpuFoundationTrainer::from_checkpoint(r.phenotype.clone(), r.asset.clone(), c)?;
    }
    Ok(trainer)
}
fn newborn(r: &recipe::Recipe) -> Result<CanonicalNewGame> {
    let mut game = create_grounded_drive_research_new_game(&r.config, &r.genotype)?;
    let born = game
        .world
        .organism_registry()
        .iter()
        .next()
        .ok_or("newborn absent")?
        .clone();
    let mut world = scene::scene(r.config.world_seed, born.organism_id())?;
    world.register_grounded_drive_research_record(born)?;
    game.world = world;
    Ok(game)
}
/// Admission remains newborn-first. Only the first closure advances biology;
/// the second clones that newly prepared, neurologically inexperienced world.
fn fresh_pair(
    r: &recipe::Recipe,
    preparation: u64,
    sentinel: bool,
    actual: &mut u64,
    attempts: &Path,
) -> Result<[Host; 2]> {
    let seed = r.config.world_seed;
    let game = newborn(r)?;
    let second = game.clone();
    let (full, template) = CpuGroupedM2HostV1::new_prepared(
        game,
        trainer(r, sentinel)?,
        r.inputs.clone(),
        sampling_seed(seed),
        mode(0)?,
        |world| -> Result<HeadlessWorld> {
            for offset in 0..preparation {
                write_new(
                    attempts,
                    &format!("BODY-ATTEMPT-{offset:06}.json"),
                    &json!({"offset":offset,"next_tick":world.tick().raw()+1,"attempt_before_call":true,"no_retry":true}),
                )?;
                world.try_advance_tick()?;
                *actual += 1;
            }
            if world.age_death_disabled()
                || world.tick().raw() != preparation
                || !world
                    .organism_registry()
                    .iter()
                    .next()
                    .ok_or("prepared body absent")?
                    .lifecycle()
                    .is_alive()
            {
                return Err("normal fresh preparation failed".into());
            }
            let evidence = scene::initial_audit(world)?;
            write_new(attempts, "PREPARED-SCENE.json", &evidence)?;
            Ok(world.clone())
        },
    )?;
    let (sham, ()) = CpuOptionalVocalM2HostV1::new_prepared(
        second,
        trainer(r, sentinel)?,
        r.inputs.clone(),
        sampling_seed(seed),
        mode(1)?,
        |world| -> Result<()> {
            *world = template;
            Ok(())
        },
    )?;
    let full = Host::Legacy(full);
    let sham = Host::Optional(sham);
    let a = cp(&full)?;
    let b = cp(&sham)?;
    raw::fresh(&a, preparation, sampling_seed(seed))?;
    raw::fresh(&b, preparation, sampling_seed(seed))?;
    if raw::matched_initial(&a, mode_name(0)?)? != raw::matched_initial(&b, mode_name(1)?)?
        || *actual != preparation
    {
        return Err("fresh matched pair/preparation accounting differs".into());
    }
    Ok([full, sham])
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Observation {
    tick: u64,
    body: BodyState,
    homeostasis: HomeostaticSnapshot,
    age: u64,
    phase: SleepPhase,
    cycle: u64,
    sleep: alife_core::sleep::SleepState,
    alive: bool,
    work: CognitiveWorkReceipt,
    cognitive_body_energy_debit: f32,
    food_context: String,
    scene: Value,
    memory: Value,
}
fn observe(h: &Host) -> Result<Observation> {
    let r = h
        .world()
        .organism_registry()
        .iter()
        .next()
        .ok_or("resident absent")?;
    if h.world().age_death_disabled() {
        return Err("normal lifetime disabled".into());
    }
    Ok(Observation {
        tick: h.world().tick().raw(),
        body: r.biochemistry().body,
        homeostasis: r.biochemistry().homeostasis,
        age: r.biochemistry().development.age_ticks.raw(),
        phase: r.sleep_phase(),
        cycle: r.sleep_cycle_id(),
        sleep: h
            .sleep_state(r.organism_id())
            .ok_or("sleep controller absent")?,
        alive: r.lifecycle().is_alive(),
        work: *r.cognitive_work(),
        cognitive_body_energy_debit: r.cognitive_energy_debit(),
        food_context:
            "ordinary Root and Fruit, stationary ActivityToy, obstacle; no peer or renewal".into(),
        scene: scene::snapshot(h.world())?,
        memory: raw::payload(&cp(h)?)?
            .path(&["canonical", "residents"])?
            .one()?
            .field("memory")?
            .value::<Value>()?,
    })
}
#[derive(Serialize)]
struct NoopReceipt {
    channel: MotorChannel,
    primitive: u32,
    measured: Option<MeasuredChannelObservation>,
}
fn applied_recovery(p: &SleepChoicePhysicalReceiptV1) -> Option<RecoveryOperationV1> {
    if p.operation == Some(RecoveryOperationV1::AwakeRest) && p.awake_recovery > 0. {
        Some(RecoveryOperationV1::AwakeRest)
    } else if p.successful_stationary_body_sleep {
        Some(RecoveryOperationV1::BodySleep)
    } else {
        None
    }
}
#[derive(Serialize)]
struct ObservationRow<'a> {
    schema: &'static str,
    status: &'static str,
    offset: u64,
    before: &'a Observation,
    after: &'a Observation,
    net_change_not_causal_benefit: [f32; 5],
    fatigue_reference_bits: u32,
    pressure_reference_bits: u32,
}
fn science(
    before: &Observation,
    after: &Observation,
    step: &Step,
    offset: u64,
    bytes: &[u8],
    closure: &str,
    pressure_reference: f32,
) -> Result<Vec<u8>> {
    if step.tick_before.raw() != before.tick
        || step.tick_after.raw() != after.tick
        || after.tick != before.tick + 1
    {
        return Err("science clock differs".into());
    }
    let mut out = serde_json::to_vec(
        &json!({"schema":"object-rich-optional-vocal-commit-v1","status":"committed","offset":offset,"tick_before":before.tick,"tick_after":after.tick,"decisions":step.decisions,"sleeping_organisms":step.sleeping_organisms,"consolidations":step.sleep_consolidations,"checkpoint_sha256":hash(bytes),"closed_source_sha256":closure}),
    )?;
    out.push(b'\n');
    out.extend(serde_json::to_vec(&ObservationRow {
        schema: "object-rich-optional-vocal-observation-v1",
        status: "observed",
        offset,
        before,
        after,
        net_change_not_causal_benefit: [
            after.homeostasis.drives.fatigue - before.homeostasis.drives.fatigue,
            after.homeostasis.hormones.sleep_pressure - before.homeostasis.hormones.sleep_pressure,
            after.homeostasis.drives.brain_atp - before.homeostasis.drives.brain_atp,
            after.body.health - before.body.health,
            after.body.energy - before.body.energy,
        ],
        fatigue_reference_bits: 0.35_f32.to_bits(),
        pressure_reference_bits: pressure_reference.to_bits(),
    })?);
    out.push(b'\n');
    Ok(out)
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Freeze {
    schema: String,
    host_commit: String,
    host_tree: String,
    driver_commit: String,
    driver_code_sha256: String,
    executable_sha256: String,
    protocol_sha256: String,
    qualification_sha256: String,
    qualification_json: String,
    reservation_sha256: String,
    seed: u64,
    preparation: u64,
    horizon: u64,
    temperature_bits: u32,
    projected_pair_bytes: u64,
    headroom_bytes: u64,
}
fn check_freeze(f: &Freeze) -> Result<()> {
    if f.schema != "object-rich-optional-vocal-source-build-freeze-v1"
        || f.host_commit != HOST_COMMIT
        || f.host_tree != HOST_TREE
        || f.driver_commit != DRIVER_COMMIT
        || f.driver_commit.len() != 40
        || !f.driver_commit.bytes().all(|b| b.is_ascii_hexdigit())
        || f.driver_code_sha256 != code_hash()
        || f.executable_sha256 != executable_hash()?
        || f.protocol_sha256 != hash(PROTOCOL)
        || f.seed != SEED
        || f.preparation != PREPARATION
        || f.horizon != HORIZON
        || f.temperature_bits != TEMPERATURE.to_bits()
    {
        return Err("source/executable/protocol freeze differs".into());
    }
    let q: Value = serde_json::from_str(&f.qualification_json)?;
    if hash(f.qualification_json.as_bytes()) != f.qualification_sha256
        || q["complete"] != true
        || q["schema"] != "object-rich-optional-vocal-driver-qualification-v1"
        || q["driver_code_sha256"] != code_hash()
        || q["executable_sha256"] != f.executable_sha256
        || q["protocol_sha256"] != hash(PROTOCOL)
        || q["actual_native_calls"] != 16
        || q["actual_preparation_intervals"] != 240
        || q["primary_seed_executed"] != false
        || q["observer_inertness_and_cold_exact"] != true
    {
        return Err("exact qualification missing or changed".into());
    }
    let max = q["maximum_packet_bytes"]
        .as_u64()
        .ok_or("qualification packet maximum absent")?;
    if max
        .checked_add(262144)
        .is_none_or(|n| n > journal::MAX_PACKET)
        || f.projected_pair_bytes != 2 * HORIZON * journal::MAX_PACKET
        || f.headroom_bytes != 2 * journal::MAX_PACKET + 64 * 1024 * 1024
    {
        return Err("fixed whole-packet or allocation budget differs".into());
    }
    Ok(())
}
fn freeze(qualification_root: &Path, reservation: &Path, out: &Path) -> Result<()> {
    seed_admission_preflight(SEED, 1)?;
    canonical_reservation(reservation)?;
    let (q, qbytes): (Value, _) = read_typed(
        &qualification_root.join("QUALIFICATION_COMPLETE.json"),
        1024 * 1024,
    )?;
    if q["schema"] != "object-rich-optional-vocal-driver-qualification-v1"
        || q["complete"] != true
        || q["driver_code_sha256"] != code_hash()
        || q["executable_sha256"] != executable_hash()?
        || q["driver_commit"] != DRIVER_COMMIT
        || q["protocol_sha256"] != hash(PROTOCOL)
        || q["primary_seed_executed"] != false
    {
        return Err("missing exact qualified driver evidence".into());
    }
    let (r, rbytes): (Value, _) = read_typed(reservation, 1024 * 1024)?;
    if r["study"] != STUDY
        || r["seed_decimal"] != SEED
        || r["preparation_attempted"] != false
        || r["source_constructed"] != false
        || r["native_calls"] != 0
    {
        return Err("reservation is not the untouched primary seed".into());
    }
    let f = Freeze {
        schema: "object-rich-optional-vocal-source-build-freeze-v1".into(),
        host_commit: HOST_COMMIT.into(),
        host_tree: HOST_TREE.into(),
        driver_commit: DRIVER_COMMIT.into(),
        driver_code_sha256: code_hash(),
        executable_sha256: executable_hash()?,
        protocol_sha256: hash(PROTOCOL),
        qualification_sha256: hash(&qbytes),
        qualification_json: String::from_utf8(qbytes.clone())?,
        reservation_sha256: hash(&rbytes),
        seed: SEED,
        preparation: PREPARATION,
        horizon: HORIZON,
        temperature_bits: TEMPERATURE.to_bits(),
        projected_pair_bytes: q["projected_pair_physical_bytes"]
            .as_u64()
            .ok_or("qualified projection absent")?,
        headroom_bytes: q["metadata_initial_export_headroom"]
            .as_u64()
            .ok_or("qualified headroom absent")?,
    };
    check_freeze(&f)?;
    if journal::free_bytes(out.parent().ok_or("freeze parent absent")?)?
        < journal::MIN_FREE_BYTES
            .checked_add(f.projected_pair_bytes)
            .and_then(|n| n.checked_add(f.headroom_bytes))
            .ok_or("freeze budget overflow")?
    {
        return Err("freeze filesystem below guard".into());
    }
    journal::publish_artifact(
        out.parent().ok_or("freeze parent absent")?,
        out.file_name()
            .and_then(|v| v.to_str())
            .ok_or("freeze filename invalid")?,
        &serde_json::to_vec(&f)?,
        64 * 1024,
    )
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PreparedArm {
    arm: usize,
    mode: String,
    initial_sha256: String,
    closure_sha256: String,
    source_headers: BTreeMap<String, String>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Prepared {
    schema: String,
    activation_sha256: String,
    pre_preparation_source_sha256: String,
    freeze_sha256: String,
    source_manifest_sha256: String,
    inputs_sha256: String,
    initial_matched_sha256: String,
    actual_preparation_intervals: u64,
    initial_tick: u64,
    initial_neural_decisions: u64,
    sampling_seed: u32,
    pressure_reference_bits: u32,
    arms: Vec<PreparedArm>,
}
fn binding(f: &Freeze, p: &Prepared, p_hash: &str, arm: usize) -> Result<journal::Binding> {
    let a = p.arms.get(arm).ok_or("prepared arm absent")?;
    if a.arm != arm || a.mode != mode_name(arm)? {
        return Err("prepared arm identity differs".into());
    }
    Ok(journal::Binding {
        schema: "object-rich-optional-vocal-durable-v1".into(),
        study_id: STUDY.into(),
        arm,
        mode: a.mode.clone(),
        seed: SEED,
        sampling_seed: p.sampling_seed,
        initial_tick: p.initial_tick,
        horizon: HORIZON,
        temperature_bits: TEMPERATURE.to_bits(),
        host_source_commit: HOST_COMMIT.into(),
        host_source_tree: HOST_TREE.into(),
        driver_source_commit: DRIVER_COMMIT.into(),
        driver_source_sha256: code_hash(),
        executable_sha256: f.executable_sha256.clone(),
        protocol_sha256: f.protocol_sha256.clone(),
        qualification_sha256: f.qualification_sha256.clone(),
        preparation_sha256: p_hash.into(),
        source_manifest_sha256: p.source_manifest_sha256.clone(),
        inputs_sha256: p.inputs_sha256.clone(),
        initial_sha256: a.initial_sha256.clone(),
        initial_matched_sha256: p.initial_matched_sha256.clone(),
        closure_sha256: a.closure_sha256.clone(),
        source_headers: a.source_headers.clone(),
        max_packet_bytes: journal::MAX_PACKET,
        max_arm_bytes: journal::MAX_ARM_BYTES,
        min_free_bytes: journal::MIN_FREE_BYTES,
    })
}
// Publication must succeed before the closure can advance any body or native state.
fn bind_then_prepare<T>(
    root: &Path,
    source: &[u8],
    inputs: &[u8],
    source_bound: &[u8],
    prepare_once: impl FnOnce() -> Result<T>,
) -> Result<T> {
    journal::publish_artifact(root, "SOURCE.json", source, journal::MAX_PACKET)?;
    journal::publish_artifact(root, "INPUTS.private.json", inputs, journal::MAX_PACKET)?;
    journal::publish_artifact(
        root,
        "SOURCE_BOUND_BEFORE_PREPARATION.json",
        source_bound,
        64 * 1024,
    )?;
    prepare_once()
}
fn counted_call<T, E>(
    attempted: &mut u64,
    call: impl FnOnce() -> std::result::Result<T, E>,
) -> std::result::Result<T, E> {
    *attempted += 1;
    call()
}
fn prepare(root: &Path, freeze_path: &Path, reservation: &Path) -> Result<()> {
    seed_admission_preflight(SEED, 1)?;
    canonical_reservation(reservation)?;
    let (f, fbytes): (Freeze, _) = read_typed(freeze_path, 64 * 1024)?;
    check_freeze(&f)?;
    let rbytes = journal::bounded_read(reservation, 1024 * 1024)?;
    if hash(&rbytes) != f.reservation_sha256 {
        return Err("reserved seed changed before preparation".into());
    }
    let parent = root.parent().ok_or("root parent absent")?.canonicalize()?;
    if root.exists() || root.is_symlink() {
        return Err("preparation root already exists; never recreate".into());
    }
    if journal::free_bytes(&parent)?
        < journal::MIN_FREE_BYTES
            .checked_add(f.projected_pair_bytes)
            .and_then(|n| n.checked_add(f.headroom_bytes))
            .ok_or("preparation budget overflow")?
    {
        return Err("preparation storage guard".into());
    }
    let absolute = parent.join(root.file_name().ok_or("root filename absent")?);
    // One reservation can admit only one attempted preparation, even at another root.
    let claim_name = format!(
        "{}.activation.json",
        reservation
            .file_name()
            .and_then(|v| v.to_str())
            .ok_or("reservation filename invalid")?
    );
    let claim = ActivationClaim {
        schema: "object-rich-optional-vocal-preparation-claim-v1".into(),
        study: STUDY.into(),
        root: absolute,
        freeze_sha256: hash(&fbytes),
        reservation_sha256: f.reservation_sha256.clone(),
        claim_implies_preparation_attempt: true,
        claim_implies_world_step: false,
    };
    let claim_bytes = serde_json::to_vec(&claim)?;
    journal::publish_artifact(
        reservation.parent().ok_or("reservation parent absent")?,
        &claim_name,
        &claim_bytes,
        64 * 1024,
    )?;
    fs::create_dir(root)?;
    validate_activation(&claim, root, &hash(&fbytes), &f.reservation_sha256)?;
    journal::publish_artifact(root, "FREEZE.json", &fbytes, 64 * 1024)?;
    journal::publish_artifact(root, "RESERVATION.json", &rbytes, 1024 * 1024)?;
    write_new(
        root,
        "PREPARATION_ATTEMPT.json",
        &json!({"schema":"object-rich-optional-vocal-preparation-attempt-v1","source":DRIVER_COMMIT,"seed":SEED,"actual_steps_known_at_claim":0,"automatic_retry":false}),
    )?;
    let mut actual = 0;
    let mut stage = "source_construction";
    let mut source_completed = false;
    let result = (|| -> Result<()> {
        // Exactly one candidate is constructed, durably bound before any body step.
        let r = recipe::build(SEED, true)?;
        source_completed = true;
        stage = "source_contract_before_biology";
        let source_contract = source_contract(&r)?;
        write_new(root, "SOURCE-CONTRACT.json", &source_contract)?;
        source_completed = true;
        stage = "source_binding_before_biology";
        let source = serde_json::to_vec(&r.metadata)?;
        let inputs = serde_json::to_vec(&r.inputs)?;
        let source_bound = serde_json::to_vec(&json!({
            "schema":"object-rich-optional-vocal-pre-preparation-source-v1",
            "freeze_sha256":hash(&fbytes),"activation_sha256":hash(&claim_bytes),
            "source_manifest_sha256":hash(&source),"inputs_sha256":hash(&inputs),
            "genotype_sha256":r.metadata["genotype_sha256"],
            "foundation_asset":r.metadata["target_asset"],
            "actual_preparation_intervals":0,"native_calls":0,
            "single_constructed_source_candidate":true
        }))?;
        let hosts = bind_then_prepare(root, &source, &inputs, &source_bound, || {
            stage = "newborn_admission_and_shared_world_preparation";
            fresh_pair(&r, PREPARATION, false, &mut actual, root)
        })?;
        stage = "initial_matched_pair_publication";
        let mut arms = Vec::new();
        let mut matched = None;
        for (arm, h) in hosts.iter().enumerate() {
            let bytes = cp(h)?;
            let m = hash(&raw::matched_initial(&bytes, mode_name(arm)?)?);
            if matched.as_ref().is_some_and(|old| old != &m) {
                return Err("pair mismatch at publication".into());
            }
            matched = Some(m);
            let d = root.join(format!("arm-{arm}"));
            fs::create_dir(&d)?;
            journal::publish_artifact(&d, "initial.private.m2", &bytes, journal::MAX_PACKET)?;
            arms.push(PreparedArm {
                arm,
                mode: mode_name(arm)?.into(),
                initial_sha256: hash(&bytes),
                closure_sha256: closure_hash(&bytes)?,
                source_headers: raw::source_headers(&bytes)?,
            });
        }
        let p = Prepared {
            schema: "object-rich-optional-vocal-preparation-v1".into(),
            activation_sha256: hash(&claim_bytes),
            pre_preparation_source_sha256: hash(&source_bound),
            freeze_sha256: hash(&fbytes),
            source_manifest_sha256: hash(&source),
            inputs_sha256: hash(&inputs),
            initial_matched_sha256: matched.ok_or("matched pair absent")?,
            actual_preparation_intervals: actual,
            initial_tick: PREPARATION,
            initial_neural_decisions: 0,
            sampling_seed: sampling_seed(SEED),
            pressure_reference_bits: r
                .phenotype
                .cognitive_architecture()
                .sleep_trigger_threshold()
                .to_bits(),
            arms,
        };
        let pbytes = serde_json::to_vec(&p)?;
        // Complete preparation receipt is last; a partial tree cannot be run.
        for arm in 0..2 {
            journal::init_journal(
                &root.join(format!("arm-{arm}/JOURNAL-M2-V1")),
                &binding(&f, &p, &hash(&pbytes), arm)?,
            )?;
        }
        journal::publish_artifact(root, "PREPARATION_COMPLETE.json", &pbytes, 64 * 1024)?;
        Ok(())
    })();
    if let Err(e) = &result {
        let _ = write_new(
            root,
            "PREPARATION_FAILED.json",
            &json!({"error":e.to_string(),"failure_stage":stage,"source_construction_attempted":true,"source_construction_completed":source_completed,"actual_preparation_intervals":actual,"native_calls":0,"no_retry":true,"seed_consumed":actual>0}),
        );
    }
    result
}
struct Loaded {
    binding: journal::Binding,
    inputs: PhenotypeCompilerInputs,
    initial: Vec<u8>,
    pressure_reference: f32,
    journal: PathBuf,
}
fn load(root: &Path, arm: usize) -> Result<Loaded> {
    mode(arm)?;
    let (f, fbytes): (Freeze, _) = read_typed(&root.join("FREEZE.json"), 64 * 1024)?;
    check_freeze(&f)?;
    canonical_reservation(Path::new(RESERVATION_PATH))?;
    let (claim, claim_bytes): (ActivationClaim, _) =
        read_typed(Path::new(ACTIVATION_PATH), 64 * 1024)?;
    validate_activation(&claim, root, &hash(&fbytes), &f.reservation_sha256)?;
    if hash(&journal::bounded_read(
        Path::new(RESERVATION_PATH),
        1024 * 1024,
    )?) != f.reservation_sha256
    {
        return Err("authoritative reserved source identity changed".into());
    }
    let (p, pbytes): (Prepared, _) =
        read_typed(&root.join("PREPARATION_COMPLETE.json"), 64 * 1024)?;
    if p.schema != "object-rich-optional-vocal-preparation-v1"
        || p.activation_sha256 != hash(&claim_bytes)
        || p.freeze_sha256 != hash(&fbytes)
        || p.actual_preparation_intervals != PREPARATION
        || p.initial_tick != PREPARATION
        || p.initial_neural_decisions != 0
        || p.sampling_seed != sampling_seed(SEED)
        || p.arms.len() != 2
        || root.join("PREPARATION_FAILED.json").exists()
    {
        return Err("incomplete or changed preparation".into());
    }
    let (source_bound, source_bound_bytes): (Value, _) = read_typed(
        &root.join("SOURCE_BOUND_BEFORE_PREPARATION.json"),
        64 * 1024,
    )?;
    if hash(&source_bound_bytes) != p.pre_preparation_source_sha256
        || source_bound["schema"] != "object-rich-optional-vocal-pre-preparation-source-v1"
        || source_bound["freeze_sha256"] != p.freeze_sha256
        || source_bound["activation_sha256"] != p.activation_sha256
        || source_bound["source_manifest_sha256"] != p.source_manifest_sha256
        || source_bound["inputs_sha256"] != p.inputs_sha256
        || source_bound["actual_preparation_intervals"] != 0
        || source_bound["native_calls"] != 0
        || source_bound["single_constructed_source_candidate"] != true
    {
        return Err("pre-preparation source identity differs".into());
    }
    if hash(&journal::bounded_read(
        &root.join("SOURCE.json"),
        journal::MAX_PACKET,
    )?) != p.source_manifest_sha256
    {
        return Err("source metadata changed".into());
    }
    let (inputs, ibytes): (PhenotypeCompilerInputs, _) =
        read_typed(&root.join("INPUTS.private.json"), journal::MAX_PACKET)?;
    if hash(&ibytes) != p.inputs_sha256 {
        return Err("source input bytes changed".into());
    }
    let b = binding(&f, &p, &hash(&pbytes), arm)?;
    let initial = journal::bounded_read(
        &root.join(format!("arm-{arm}/initial.private.m2")),
        journal::MAX_PACKET,
    )?;
    if hash(&initial) != b.initial_sha256
        || hash(&raw::matched_initial(&initial, mode_name(arm)?)?) != b.initial_matched_sha256
        || raw::source_headers(&initial)? != b.source_headers
    {
        return Err("initial source/matched bytes changed".into());
    }
    raw::fresh(&initial, PREPARATION, b.sampling_seed)?;
    validate_cp(&initial, b.initial_tick, &b.closure_sha256)?;
    let pressure = inputs
        .genome()
        .cognitive_architecture()
        .sleep_trigger_threshold();
    if pressure.to_bits() != p.pressure_reference_bits {
        return Err("compiled pressure reference changed".into());
    }
    Ok(Loaded {
        binding: b,
        inputs,
        initial,
        pressure_reference: pressure,
        journal: root
            .canonicalize()?
            .join(format!("arm-{arm}/JOURNAL-M2-V1")),
    })
}
fn run(root: &Path, arm: usize) -> Result<()> {
    let a = load(root, arm)?;
    let b = &a.binding;
    let _lock = journal::lock(&a.journal)?;
    let mut r = journal::recover_without_trace(&a.journal, b, &a.initial, |bytes, tick| {
        validate_cp(bytes, tick, &b.closure_sha256)
    })?;
    if a.journal.join("BLOCKED-PUBLICATION").exists() {
        return Err("known failure blocks continuation".into());
    }
    if a.journal.join("TERMINAL.json").exists() {
        println!("terminal no-op; {} committed intervals", r.next);
        return Ok(());
    }
    let result = (|| -> Result<()> {
        let mut h = restore(
            &r.checkpoint,
            &a.inputs,
            arm,
            b.initial_tick + r.next,
            &b.closure_sha256,
        )?;
        if r.trace_bytes
            .checked_add(b.max_packet_bytes)
            .is_none_or(|n| n > journal::MAX_TRACE_BYTES)
            || journal::resource_stop(b, r.storage_bytes, journal::free_bytes(&a.journal)?)
        {
            journal::terminal(
                &a.journal,
                b,
                &r,
                "pre-step storage or science-trace ceiling",
            )?;
            return Ok(());
        }
        write_new(
            &a.journal,
            &format!(
                "PROCESS-{}-{}.json",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)?
                    .as_nanos()
            ),
            &json!({"schema":"object-rich-optional-vocal-process-v1","arm":arm,"next_offset":r.next,"previous_commit_sha256":r.previous,"process_id":std::process::id(),"retained_temp_entries":r.ignored_temps,"unpublished_inflight_work_is_uncertain":true,"published_intervals_replayed":0}),
        )?;
        r.storage_bytes = fs::read_dir(&a.journal)?.try_fold(0_u64, |sum, e| -> Result<u64> {
            sum.checked_add(e?.metadata()?.len())
                .ok_or_else(|| "storage overflow".into())
        })?;
        while r.next < b.horizon {
            if r.trace_bytes
                .checked_add(b.max_packet_bytes)
                .is_none_or(|n| n > journal::MAX_TRACE_BYTES)
                || journal::resource_stop(b, r.storage_bytes, journal::free_bytes(&a.journal)?)
            {
                journal::terminal(
                    &a.journal,
                    b,
                    &r,
                    "pre-step storage or science-trace ceiling",
                )?;
                return Ok(());
            }
            let before = observe(&h)?;
            if !before.alive
                || before.body.health < 0.5
                || before.body.energy < 0.05
                || before.body.injury > 0.
                || !before.body.health.is_finite()
                || !before.body.energy.is_finite()
                || !before.body.injury.is_finite()
            {
                journal::terminal(&a.journal, b, &r, "health/energy/death")?;
                return Ok(());
            }
            let attempt_name = format!("ATTEMPT-{:06}.json", r.next);
            if a.journal.join(&attempt_name).exists() {
                return Err("unresolved attempted interval cannot replay".into());
            }
            write_new(
                &a.journal,
                &attempt_name,
                &json!({"offset":r.next,"tick":before.tick,"previous_commit_sha256":r.previous,"attempt_before_call":true,"no_retry":true}),
            )?;
            r.storage_bytes = r
                .storage_bytes
                .checked_add(2 * fs::metadata(a.journal.join(&attempt_name))?.len())
                .ok_or("attempt storage overflow")?;
            let produced = (|| -> Result<(Vec<u8>, Vec<u8>, u64, bool)> {
                let step = h.step(f32::from_bits(b.temperature_bits))?;
                let bytes = cp(&h)?;
                validate_cp(&bytes, b.initial_tick + r.next + 1, &b.closure_sha256)?;
                let rows = science(
                    &before,
                    &observe(&h)?,
                    &step,
                    r.next,
                    &bytes,
                    &b.closure_sha256,
                    a.pressure_reference,
                )?;
                let packet = journal::make_packet(b, r.next, &r.previous, &bytes, &rows)?;
                journal::decode_packet(&packet, b, r.next, &r.previous)?;
                let fresh_harm = step.decisions.iter().any(|d| {
                    d["research_world_receipt"]["body_event"]["damage"]
                        .as_f64()
                        .is_some_and(|v| v > 0.)
                });
                Ok((bytes, packet, rows.len() as u64, fresh_harm))
            })();
            let (bytes, packet, trace_bytes, fresh_harm) = match produced {
                Ok(v) => v,
                Err(e) => {
                    journal::stop_after_failure(
                        &a.journal,
                        b,
                        &r,
                        &format!("step/audit/serialization failure: {e}"),
                    );
                    return Err(e);
                }
            };
            if let Err(e) = journal::publish(&a.journal, &format!("{:06}.packet", r.next), &packet)
            {
                let reason = format!("known publication/storage failure: {e}");
                journal::record_publication_failure(
                    &a.journal, b, &mut r, &bytes, &packet, &reason,
                )?;
                return Err(reason.into());
            }
            r.trace_bytes = r
                .trace_bytes
                .checked_add(trace_bytes)
                .ok_or("trace accounting overflow")?;
            r.next += 1;
            r.previous = hash(&packet);
            r.checkpoint = bytes;
            r.storage_bytes = r
                .storage_bytes
                .checked_add(2 * packet.len() as u64)
                .ok_or("storage overflow after commit")?;
            if fresh_harm {
                journal::terminal(&a.journal, b, &r, "new measured physical damage")?;
                return Ok(());
            }
            if r.next.is_multiple_of(16) {
                println!("arm {arm}: {} atomically committed intervals", r.next);
            }
        }
        journal::terminal(&a.journal, b, &r, "horizon")
    })();
    if let Err(error) = &result {
        if !a.journal.join("TERMINAL.json").exists()
            && !a.journal.join("BLOCKED-PUBLICATION").exists()
        {
            journal::stop_after_failure(
                &a.journal,
                b,
                &r,
                &format!("known driver/storage failure: {error}"),
            );
        }
    }
    result
}
fn export(root: &Path, arm: usize, out: &Path) -> Result<()> {
    let a = load(root, arm)?;
    let _lock = journal::lock(&a.journal)?;
    let b = &a.binding;
    let r = journal::recover(&a.journal, b, &a.initial, |bytes, tick| {
        validate_cp(bytes, tick, &b.closure_sha256)
    })?;
    let h = restore(
        &r.checkpoint,
        &a.inputs,
        arm,
        b.initial_tick + r.next,
        &b.closure_sha256,
    )?;
    let terminal = if a.journal.join("TERMINAL.json").is_file() {
        Some(read_typed::<Value>(&a.journal.join("TERMINAL.json"), 64 * 1024)?.0)
    } else {
        None
    };
    let summary = summarize(
        &r.trace,
        &observe(&h)?,
        r.next,
        terminal.as_ref(),
        &r.previous,
    )?;
    fs::create_dir(out)?;
    journal::publish_artifact(out, "TRACE.private.jsonl", &r.trace, journal::MAX_ARM_BYTES)?;
    journal::publish_artifact(out, "final.private.m2", &r.checkpoint, journal::MAX_PACKET)?;
    let result = serde_json::to_vec(&summary)?;
    journal::publish_artifact(out, "RESULT.json", &result, journal::MAX_PACKET)?;
    write_new(
        out,
        "EXPORT_COMPLETE.json",
        &json!({"schema":"object-rich-optional-vocal-export-v1","binding":b,"committed_intervals":r.next,"terminal":terminal.is_some(),"last_commit_sha256":r.previous,"trace_sha256":hash(&r.trace),"checkpoint_sha256":hash(&r.checkpoint),"result_sha256":hash(&result),"private_raw_data_not_for_upload":true}),
    )
}
#[derive(Debug, Serialize)]
struct CycleProgress {
    start_tick: u64,
    entering_tick: Option<u64>,
    consolidating_tick: Option<u64>,
    waking_tick: Option<u64>,
    ordered: bool,
}
impl CycleProgress {
    fn new(start_tick: u64, first_phase: SleepPhase, observed_tick: u64) -> Self {
        Self {
            start_tick,
            entering_tick: (first_phase == SleepPhase::EnteringSleep).then_some(observed_tick),
            consolidating_tick: None,
            waking_tick: None,
            ordered: first_phase == SleepPhase::EnteringSleep,
        }
    }
    fn observe(&mut self, phase: SleepPhase, tick: u64) {
        match phase {
            SleepPhase::EnteringSleep
                if self.consolidating_tick.is_none() && self.waking_tick.is_none() => {}
            SleepPhase::Consolidating
                if self.entering_tick.is_some() && self.waking_tick.is_none() =>
            {
                self.consolidating_tick.get_or_insert(tick);
            }
            SleepPhase::Waking if self.consolidating_tick.is_some() => {
                self.waking_tick.get_or_insert(tick);
            }
            _ => self.ordered = false,
        }
    }
    fn complete(&self) -> bool {
        self.ordered
            && self.entering_tick.is_some()
            && self.consolidating_tick.is_some()
            && self.waking_tick.is_some()
    }
}
fn summarize(
    trace: &[u8],
    final_state: &Observation,
    count: u64,
    terminal: Option<&Value>,
    last: &str,
) -> Result<Value> {
    let mut decisions = 0_u64;
    let mut physical = [0_u64; 3];
    let mut attempted = [0_u64; 3];
    let mut executed_noops = 0_u64;
    let mut no_decision = 0_u64;
    let mut consolidations = 0_u64;
    let mut phase_counts = BTreeMap::<String, u64>::new();
    let mut crosses = [[0_u64; 2]; 2];
    let mut observed = 0;
    let mut started_cycles = BTreeMap::<u64, CycleProgress>::new();
    let mut completed_cycles = Vec::new();
    let mut sleep_starts = Vec::new();
    let mut crossing_events = Vec::new();
    let mut first_up = [None, None];
    let mut maxima = [f32::NEG_INFINITY; 2];
    let mut minimum_health = f32::INFINITY;
    let mut minimum_energy = f32::INFINITY;
    let mut initially_at_or_above_reference = None;
    for line in trace.split(|b| *b == b'\n').filter(|l| !l.is_empty()) {
        let v: Value = serde_json::from_slice(line)?;
        if v["status"] == "committed" {
            let rows = v["decisions"].as_array().ok_or("decisions missing")?;
            decisions += rows.len() as u64;
            if rows.is_empty() {
                no_decision += 1;
            }
            consolidations += v["consolidations"]
                .as_u64()
                .ok_or("consolidations missing")?;
            for d in rows {
                for (value, counts) in [
                    (&d["physical"]["operation"], &mut attempted),
                    (&d["applied_recovery"], &mut physical),
                ] {
                    match value.as_str() {
                        Some("AwakeRest") => counts[0] += 1,
                        Some("BodySleep") => counts[1] += 1,
                        None => counts[2] += 1,
                        _ => return Err("unknown recovery operation".into()),
                    }
                }
                for noop in d["real_noop_receipts"]
                    .as_array()
                    .ok_or("no-op receipts absent")?
                {
                    if noop["measured"]["executed"] == true {
                        executed_noops += 1;
                    }
                }
            }
        } else if v["status"] == "observed" {
            observed += 1;
            let before: Observation = serde_json::from_value(v["before"].clone())?;
            let after: Observation = serde_json::from_value(v["after"].clone())?;
            if before.phase == SleepPhase::Awake && after.phase != SleepPhase::Awake {
                let cycle = after.sleep.active_cycle_id;
                started_cycles.insert(
                    cycle,
                    CycleProgress::new(before.tick, after.phase, after.tick),
                );
                sleep_starts.push(json!({"cycle":cycle,"tick":before.tick,"trigger":after.sleep.last_trigger,"phase":after.phase}));
            }
            if let Some(progress) = started_cycles.get_mut(&after.sleep.active_cycle_id) {
                progress.observe(after.phase, after.tick);
            }
            if before.phase == SleepPhase::Waking && after.phase == SleepPhase::Awake {
                let cycle = before.sleep.active_cycle_id;
                if started_cycles
                    .get(&cycle)
                    .is_some_and(CycleProgress::complete)
                {
                    let progress = started_cycles.remove(&cycle).ok_or("cycle disappeared")?;
                    completed_cycles.push(json!({"cycle":cycle,"start_tick":progress.start_tick,"entering_observed_tick":progress.entering_tick,"consolidating_observed_tick":progress.consolidating_tick,"waking_observed_tick":progress.waking_tick,"returned_awake_tick":after.tick}));
                }
            }
            *phase_counts
                .entry(format!("{:?}", after.phase))
                .or_default() += 1;
            let pressure = f32::from_bits(
                v["pressure_reference_bits"]
                    .as_u64()
                    .ok_or("pressure bits absent")? as u32,
            );
            minimum_health = minimum_health
                .min(before.body.health)
                .min(after.body.health);
            minimum_energy = minimum_energy
                .min(before.body.energy)
                .min(after.body.energy);
            if initially_at_or_above_reference.is_none() {
                initially_at_or_above_reference = Some([
                    before.homeostasis.drives.fatigue >= 0.35,
                    before.homeostasis.hormones.sleep_pressure >= pressure,
                ]);
            }
            for (axis, (pre, post, threshold)) in [
                (
                    before.homeostasis.drives.fatigue,
                    after.homeostasis.drives.fatigue,
                    0.35_f32,
                ),
                (
                    before.homeostasis.hormones.sleep_pressure,
                    after.homeostasis.hormones.sleep_pressure,
                    pressure,
                ),
            ]
            .into_iter()
            .enumerate()
            {
                maxima[axis] = maxima[axis].max(pre).max(post);
                if pre < threshold && post >= threshold {
                    crosses[axis][0] += 1;
                    first_up[axis].get_or_insert(after.tick);
                    crossing_events.push(json!({"axis":if axis==0{"fatigue"}else{"sleep_pressure"},"direction":"up","tick":after.tick,"before":pre,"after":post,"reference_bits":threshold.to_bits()}));
                }
                if pre >= threshold && post < threshold {
                    crosses[axis][1] += 1;
                    crossing_events.push(json!({"axis":if axis==0{"fatigue"}else{"sleep_pressure"},"direction":"down","tick":after.tick,"before":pre,"after":post,"reference_bits":threshold.to_bits()}));
                }
            }
        } else {
            return Err("unknown science row".into());
        }
    }
    if observed != count {
        return Err("summary interval count differs".into());
    }
    if count == 0 {
        maxima = [
            final_state.homeostasis.drives.fatigue,
            final_state.homeostasis.hormones.sleep_pressure,
        ];
        minimum_health = final_state.body.health;
        minimum_energy = final_state.body.energy;
    }
    Ok(
        json!({"schema":"object-rich-optional-vocal-summary-v1","committed_intervals":count,"decisions":decisions,"intervals_without_decision":no_decision,"physical_awake_rest":physical[0],"physical_body_sleep":physical[1],"physical_none":physical[2],"requested_awake_rest_body_sleep_none":attempted,"executed_noop_primitives":executed_noops,"physical_count_basis":"AwakeRest actual positive recovery dose; BodySleep successful stationary physical receipt; none means no applied recovery operation, not necessarily no other action","closed_memory_consolidations":consolidations,"sleep_controller_cycles_completed":final_state.sleep.cycles_completed,"observed_sleep_starts":sleep_starts,"fully_observed_complete_cycles":completed_cycles,"partial_observed_cycle_starts":started_cycles,"phase_intervals":phase_counts,"fatigue_reference_crossings_up_down":crosses[0],"pressure_reference_crossings_up_down":crosses[1],"reference_crossing_events":crossing_events,"first_up_crossing_ticks_F_P":first_up,"initially_at_or_above_reference_F_P":initially_at_or_above_reference,"maxima_F_P":maxima,"minimum_health":minimum_health,"minimum_body_energy":minimum_energy,"final_state":final_state,"terminal":terminal,"horizon_complete":terminal.is_some_and(|t|t["stop"]=="horizon")&&count==HORIZON,"last_commit_sha256":last,"source_and_optimizer_closed":true,"scope":"one source/body, two policies with different RNG domains/support; no synaptic learning or generalized ecological competence","raw_checkpoint_and_science_bytes_preserved":true}),
    )
}
fn compare_prefix(root: &Path, out: &Path) -> Result<()> {
    let a = load(root, 0)?;
    let b = load(root, 1)?;
    let _guard_a = journal::lock(&a.journal)?;
    let _guard_b = journal::lock(&b.journal)?;
    let ra = journal::recover(&a.journal, &a.binding, &a.initial, |bytes, tick| {
        validate_cp(bytes, tick, &a.binding.closure_sha256)
    })?;
    let rb = journal::recover(&b.journal, &b.binding, &b.initial, |bytes, tick| {
        validate_cp(bytes, tick, &b.binding.closure_sha256)
    })?;
    let common = ra.next.min(rb.next);
    let mut summaries = Vec::new();
    for (loaded, recovered) in [(&a, &ra), (&b, &rb)] {
        let mut end = 0;
        let mut lines = 0;
        if common > 0 {
            for (i, byte) in recovered.trace.iter().enumerate() {
                if *byte == b'\n' {
                    lines += 1;
                    if lines == 2 * common {
                        end = i + 1;
                        break;
                    }
                }
            }
        }
        if common > 0 && lines != 2 * common {
            return Err("common prefix rows missing".into());
        }
        let prefix = &recovered.trace[..end];
        let initial_host = restore(
            &loaded.initial,
            &loaded.inputs,
            loaded.binding.arm,
            loaded.binding.initial_tick,
            &loaded.binding.closure_sha256,
        )?;
        let mut last_state = observe(&initial_host)?;
        for row in prefix.split(|b| *b == b'\n').filter(|r| !r.is_empty()) {
            let value: Value = serde_json::from_slice(row)?;
            if value["status"] == "observed" {
                last_state = serde_json::from_value(value["after"].clone())?;
            }
        }
        let last = if common == 0 {
            hash(&loaded.initial)
        } else {
            hash(&journal::bounded_read(
                &loaded.journal.join(format!("{:06}.packet", common - 1)),
                journal::MAX_PACKET,
            )?)
        };
        summaries.push(summarize(prefix, &last_state, common, None, &last)?);
    }
    fs::create_dir(out)?;
    write_new(
        out,
        "COMMON_OBSERVED_PREFIX.json",
        &json!({"schema":"object-rich-optional-vocal-common-prefix-v1","common_committed_intervals":common,"full_observed_intervals":[ra.next,rb.next],"selection_rule":"minimum of both complete committed prefixes, no favorable window selection","arms":summaries,"single_seed_not_generalization":true}),
    )
}
fn main() -> Result<()> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    match args.as_slice(){
        [cmd,out] if cmd=="--qualify"=>qualification::qualify(Path::new(out)),
        [cmd,dir] if cmd=="--lock-child"=>{let result=journal::lock(Path::new(dir));std::process::exit(if result.is_ok(){0}else{7});},
        [cmd,q,res,out] if cmd=="--freeze"=>freeze(Path::new(q),Path::new(res),Path::new(out)),
        [cmd,root,f,res] if cmd=="--prepare"=>prepare(Path::new(root),Path::new(f),Path::new(res)),
        [cmd,root,arm] if cmd=="--run"=>run(Path::new(root),arm.parse()?),
        [cmd,root,arm,out] if cmd=="--export"=>export(Path::new(root),arm.parse()?,Path::new(out)),
        [cmd,root,out] if cmd=="--compare-prefix"=>compare_prefix(Path::new(root),Path::new(out)),
        _=>Err("explicit commands only: --qualify OUT | --freeze QUALIFICATION RESERVATION OUT | --prepare ROOT FREEZE RESERVATION | --run ROOT ARM | --export ROOT ARM OUT | --compare-prefix ROOT OUT".into()),
    }
}

#[cfg(test)]
mod driver_tests {
    use super::*;
    #[test]
    fn seed_domain_max_next_overflow_and_fixed_cases_are_pure() {
        let max = (u64::MAX - 1) / 16;
        assert_eq!(max, 0x0FFF_FFFF_FFFF_FFFF);
        assert_eq!(
            seed_admission_preflight(max, 1).unwrap(),
            0xFFFF_FFFF_FFFF_FFF1
        );
        assert_eq!(
            seed_admission_preflight(max, 8).unwrap(),
            0xFFFF_FFFF_FFFF_FFF8
        );
        assert!(seed_admission_preflight(max + 1, 1).is_err());
        assert!(seed_admission_preflight(u64::MAX, 1).is_err());
        assert!(seed_admission_preflight(0, 1).is_err());
        assert!(seed_admission_preflight(1, 0).is_err());
        assert!(seed_admission_preflight(1, 9).is_err());
        assert!(seed_admission_preflight(0x4D32_424C_0009_0001, 1).is_err());
        assert_eq!(
            seed_admission_preflight(SEED, 1).unwrap(),
            0x34F4_2564_F430_9011
        );
        assert!(seed_admission_preflight(FIXTURE_SEED, 1).is_ok());
    }
    #[test]
    fn activation_rejects_completed_root_copy_and_changed_identity() -> Result<()> {
        let temp = std::env::temp_dir().join(format!("m2-activation-{}", journal::unique()?));
        fs::create_dir(&temp)?;
        let original = temp.join("original");
        let copied = temp.join("copy");
        fs::create_dir(&original)?;
        fs::create_dir(&copied)?;
        let claim = ActivationClaim {
            schema: "object-rich-optional-vocal-preparation-claim-v1".into(),
            study: STUDY.into(),
            root: original.canonicalize()?,
            freeze_sha256: "freeze".into(),
            reservation_sha256: "reservation".into(),
            claim_implies_preparation_attempt: true,
            claim_implies_world_step: false,
        };
        validate_activation(&claim, &original, "freeze", "reservation")?;
        assert!(validate_activation(&claim, &copied, "freeze", "reservation").is_err());
        assert!(validate_activation(&claim, &original, "changed", "reservation").is_err());
        assert!(validate_activation(&claim, &original, "freeze", "changed").is_err());
        // Retain disposable test evidence under task allocation.
        Ok(())
    }
    #[test]
    fn source_binding_publication_precedes_preparation_and_failure_blocks_it() -> Result<()> {
        let temp = std::env::temp_dir().join(format!("m2-source-binding-{}", journal::unique()?));
        fs::create_dir(&temp)?;
        let mut calls = 0;
        bind_then_prepare(&temp, b"source", b"inputs", b"binding", || {
            assert_eq!(fs::read(temp.join("SOURCE.json"))?, b"source");
            assert_eq!(fs::read(temp.join("INPUTS.private.json"))?, b"inputs");
            assert_eq!(
                fs::read(temp.join("SOURCE_BOUND_BEFORE_PREPARATION.json"))?,
                b"binding"
            );
            calls += 1;
            Ok(())
        })?;
        assert_eq!(calls, 1);
        assert!(
            bind_then_prepare(&temp, b"source", b"inputs", b"binding", || {
                calls += 1;
                Ok(())
            })
            .is_err()
        );
        assert_eq!(calls, 1);
        let failed = temp.join("failed");
        fs::create_dir(&failed)?;
        fs::write(
            failed.join("SOURCE_BOUND_BEFORE_PREPARATION.json"),
            b"existing",
        )?;
        assert!(
            bind_then_prepare(&failed, b"source", b"inputs", b"binding", || {
                calls += 1;
                Ok(())
            })
            .is_err()
        );
        assert_eq!(calls, 1);
        // Retain disposable test evidence under task allocation.
        Ok(())
    }
    #[test]
    fn failed_native_invocation_is_counted_before_returning_error() {
        let mut calls = 0;
        let failed: std::result::Result<(), &str> =
            counted_call(&mut calls, || Err("fixed failure"));
        assert!(failed.is_err());
        assert_eq!(calls, 1);
        let success: std::result::Result<(), &str> = counted_call(&mut calls, || Ok(()));
        assert!(success.is_ok());
        assert_eq!(calls, 2);
    }
    #[test]
    fn complete_cycle_requires_ordered_entering_consolidating_waking() {
        let mut full = CycleProgress::new(0, SleepPhase::EnteringSleep, 1);
        full.observe(SleepPhase::Consolidating, 3);
        assert!(!full.complete());
        full.observe(SleepPhase::Waking, 7);
        assert!(full.complete());
        let mut skipped = CycleProgress::new(0, SleepPhase::EnteringSleep, 1);
        skipped.observe(SleepPhase::Waking, 7);
        assert!(!skipped.complete());
        let mut partial = CycleProgress::new(0, SleepPhase::ForcedRecoverySleep, 1);
        partial.observe(SleepPhase::Consolidating, 3);
        partial.observe(SleepPhase::Waking, 7);
        assert!(!partial.complete());
        let mut wrong_order = CycleProgress::new(0, SleepPhase::EnteringSleep, 1);
        wrong_order.observe(SleepPhase::Waking, 2);
        wrong_order.observe(SleepPhase::Consolidating, 3);
        wrong_order.observe(SleepPhase::Waking, 7);
        assert!(!wrong_order.complete());
    }
}
