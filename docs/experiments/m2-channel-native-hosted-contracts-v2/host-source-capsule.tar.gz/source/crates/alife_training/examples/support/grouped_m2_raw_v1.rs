//! Read-only raw JSON slicing. Never deserialize/re-emit authoritative M2 bytes.
use super::{hash, Result};
use std::collections::BTreeMap;

pub const MAGIC: &[u8] =
    b"ALIFE-GROUPED-M2-HOST\0V1\0CONFIDENCE-V2\0SYNAPTIC-CLOSED\0PROFILE5\0SAMPLER-BITS1\0";
#[derive(Clone, Copy)]
pub struct Raw<'a>(pub &'a [u8]);
impl<'a> Raw<'a> {
    pub fn object(self) -> Result<BTreeMap<String, Self>> {
        let bytes = self.0;
        if bytes.first() != Some(&b'{') {
            return Err("raw object expected".into());
        }
        let mut pos = 1;
        let mut out = BTreeMap::new();
        loop {
            ws(bytes, &mut pos);
            if bytes.get(pos) == Some(&b'}') {
                pos += 1;
                break;
            }
            let (key, end) = read::<String>(&bytes[pos..])?;
            pos += end;
            ws(bytes, &mut pos);
            if bytes.get(pos) != Some(&b':') {
                return Err("raw colon expected".into());
            }
            pos += 1;
            ws(bytes, &mut pos);
            let start = pos;
            let (_, len) = read::<serde::de::IgnoredAny>(&bytes[pos..])?;
            pos += len;
            if out.insert(key, Raw(&bytes[start..pos])).is_some() {
                return Err("duplicate raw key".into());
            }
            ws(bytes, &mut pos);
            match bytes.get(pos) {
                Some(b',') => pos += 1,
                Some(b'}') => {
                    pos += 1;
                    break;
                }
                _ => return Err("raw object delimiter".into()),
            }
        }
        ws(bytes, &mut pos);
        if pos != bytes.len() {
            return Err("raw object trailing bytes".into());
        }
        Ok(out)
    }
    pub fn array(self) -> Result<Vec<Self>> {
        let bytes = self.0;
        if bytes.first() != Some(&b'[') {
            return Err("raw array expected".into());
        }
        let mut pos = 1;
        let mut out = Vec::new();
        loop {
            ws(bytes, &mut pos);
            if bytes.get(pos) == Some(&b']') {
                pos += 1;
                break;
            }
            let start = pos;
            let (_, len) = read::<serde::de::IgnoredAny>(&bytes[pos..])?;
            pos += len;
            out.push(Raw(&bytes[start..pos]));
            ws(bytes, &mut pos);
            match bytes.get(pos) {
                Some(b',') => pos += 1,
                Some(b']') => {
                    pos += 1;
                    break;
                }
                _ => return Err("raw array delimiter".into()),
            }
        }
        ws(bytes, &mut pos);
        if pos != bytes.len() {
            return Err("raw array trailing bytes".into());
        }
        Ok(out)
    }
    pub fn field(self, name: &str) -> Result<Self> {
        self.object()?
            .remove(name)
            .ok_or_else(|| format!("missing raw field {name}").into())
    }
    pub fn path(self, path: &[&str]) -> Result<Self> {
        path.iter().try_fold(self, |v, key| v.field(key))
    }
    pub fn one(self) -> Result<Self> {
        let values = self.array()?;
        if values.len() != 1 {
            return Err("exactly one raw resident expected".into());
        }
        Ok(values[0])
    }
    pub fn value<T: serde::de::DeserializeOwned>(self) -> Result<T> {
        Ok(serde_json::from_slice(self.0)?)
    }
}
fn ws(bytes: &[u8], pos: &mut usize) {
    while bytes.get(*pos).is_some_and(u8::is_ascii_whitespace) {
        *pos += 1;
    }
}
fn read<T: serde::de::DeserializeOwned>(bytes: &[u8]) -> Result<(T, usize)> {
    let mut stream = serde_json::Deserializer::from_slice(bytes).into_iter::<T>();
    let value = stream.next().ok_or("missing raw JSON value")??;
    Ok((value, stream.byte_offset()))
}
pub const OPTIONAL_MAGIC: &[u8] = b"ALIFE-OPTIONAL-VOCAL-M2-HOST\0V1\0IDLE-QUIET\0SOURCE-PAYLOAD\0SYNAPTIC-CLOSED\0PROFILE5\0BITS1\0";
const LEGACY_LINEAGE: &str = "fresh-grouped-m2-host-v1/confidence-v2/class5/no-historical-import";
const OPTIONAL_LINEAGE: &str = "fresh-optional-vocal-m2-host-v1/class5/no-historical-import";
const LEGACY_POLICY: &str = "synaptic-learning-closed;source-once;typed-grouped-sampling;profile5;canonical-memory-predictor-body;no-structural-sleep;one-cognitive-debit;source-logit-regional-arousal;memory-sleep-output-generation-is-cycle-id";
const OPTIONAL_POLICY: &str = "m2-optional-vocal-v1;closed;idle-mediated-quiet;source-payload-removal;cooldown-physical;no-gradient";
const OPTIONAL_OWNER: &str = "optional-vocal-m2-resident-v1";

/// Slicing is not validation. The caller must decode/restore with the matching
/// typed policy loader before using these raw-only comparisons as evidence.
pub fn payload(cp: &[u8]) -> Result<Raw<'_>> {
    Ok(Raw(cp
        .strip_prefix(MAGIC)
        .or_else(|| cp.strip_prefix(OPTIONAL_MAGIC))
        .ok_or("not M2 raw wire")?))
}

fn exact_string(raw: Raw<'_>, expected: &str) -> Result<()> {
    if raw.value::<String>()? != expected {
        return Err("wrong initial policy owner marker".into());
    }
    Ok(())
}

// A path is a vector, not a dotted string: controller keys cannot impersonate
// nested fields. Only these validated, explicit locations can be omitted.
fn path(parts: &[&str]) -> Vec<String> {
    parts.iter().map(|s| (*s).to_owned()).collect()
}

/// The only differing bytes allowed are envelope identity, exact outer policy
/// markers, the two exact schema markers, the fresh optional owner object and
/// the policy-derived organism brain digest. Full mode is NOT masked.
/// Every other subtree is included, even fields unknown to this helper. Scalar
/// tokens are copied verbatim, never deserialized as floats or re-emitted.
/// Object keys are sorted; arrays retain order and length. Length framing avoids
/// ambiguous concatenation. This is a comparison encoding, NOT a checkpoint.
pub fn matched_initial(cp: &[u8], policy_name: &str) -> Result<Vec<u8>> {
    let optional = match policy_name {
        "LegacyGroupedM2/Full" => false,
        "OptionalVocalM2/Full" => true,
        _ => return Err("unknown initial policy name".into()),
    };
    if cp.starts_with(OPTIONAL_MAGIC) != optional {
        return Err("initial envelope policy mismatch".into());
    }
    let p = payload(cp)?;
    exact_string(
        p.field("source_lineage")?,
        if optional {
            OPTIONAL_LINEAGE
        } else {
            LEGACY_LINEAGE
        },
    )?;
    exact_string(
        p.field("policy")?,
        if optional {
            OPTIONAL_POLICY
        } else {
            LEGACY_POLICY
        },
    )?;
    exact_string(p.field("mode")?, "Full")?;
    if p.field("schema_version")?.value::<u16>()? != 1 {
        return Err("wrong outer schema".into());
    }
    let canonical = p.field("canonical")?;
    if canonical.field("schema_version")?.value::<u16>()? != if optional { 0x4f56 } else { 2 } {
        return Err("wrong canonical policy schema".into());
    }
    let neural = canonical.field("residents")?.one()?.field("neural")?;
    if neural.field("schema_version")?.value::<u32>()? != if optional { 0x4f56_0001 } else { 2 } {
        return Err("wrong neural policy schema".into());
    }
    let controllers = p.field("controllers")?.object()?;
    if controllers.len() != 1 {
        return Err("initial controller roster differs".into());
    }
    let (owner, controller) = controllers.iter().next().ok_or("missing controller")?;
    // Exact resident ownership is also enforced by typed restore; reject any
    // controller key not naming the one neural resident in this projection.
    if owner != &neural.field("organism_id")?.value::<u64>()?.to_string() {
        return Err("initial controller owner differs".into());
    }
    exact_string(controller.path(&["motor", "mode"])?, "Full")?;
    let fields = controller.object()?;
    match (optional, fields.get("optional_vocal")) {
        (false, None) => (),
        (true, Some(marker)) => {
            let marker = marker.object()?;
            if marker.len() != 2 || !marker.contains_key("schema") || !marker.contains_key("last") {
                return Err("unexpected optional owner fields".into());
            }
            exact_string(marker["schema"], OPTIONAL_OWNER)?;
            if marker["last"].0 != b"null" {
                return Err("optional owner is not fresh".into());
            }
        }
        _ => return Err("initial optional owner presence differs".into()),
    }
    let record = p
        .path(&["canonical", "world", "world", "organism_records"])?
        .one()?;
    record.path(&["state_graph", "brain", "content_digest"])?;
    let mut omit = vec![
        path(&["source_lineage"]),
        path(&["policy"]),
        path(&["canonical", "schema_version"]),
        path(&["canonical", "residents", "0", "neural", "schema_version"]),
        path(&[
            "canonical",
            "world",
            "world",
            "organism_records",
            "0",
            "state_graph",
            "brain",
            "content_digest",
        ]),
    ];
    omit.push(path(&["controllers", owner, "optional_vocal"]));
    let mut out = b"M2-INITIAL-RAW-PROJECTION-V1\0".to_vec();
    project(p, &mut Vec::new(), &omit, &mut out)?;
    Ok(out)
}
fn framed(bytes: &[u8], out: &mut Vec<u8>) {
    out.extend_from_slice(&(bytes.len() as u64).to_le_bytes());
    out.extend_from_slice(bytes);
}
fn project(
    raw: Raw<'_>,
    here: &mut Vec<String>,
    omit: &[Vec<String>],
    out: &mut Vec<u8>,
) -> Result<()> {
    // Preserve entire unaffected subtrees verbatim. Only containers on an exact
    // exemption path need structural encoding, including the two resident arrays.
    if !omit.iter().any(|p| p.starts_with(here.as_slice())) {
        out.push(b'R');
        framed(raw.0, out);
        return Ok(());
    }
    match raw.0.first() {
        Some(b'{') => {
            out.push(b'O');
            for (key, value) in raw.object()? {
                here.push(key.clone());
                if !omit.contains(here) {
                    out.push(b'K');
                    framed(key.as_bytes(), out);
                    project(value, here, omit, out)?;
                }
                here.pop();
            }
            out.push(b'E');
        }
        Some(b'[') => {
            out.push(b'A');
            let items = raw.array()?;
            out.extend_from_slice(&(items.len() as u64).to_le_bytes());
            for (i, item) in items.into_iter().enumerate() {
                here.push(i.to_string());
                project(item, here, omit, out)?;
                here.pop();
            }
        }
        _ => return Err("projection path does not reach container".into()),
    }
    Ok(())
}
/// Exact hashes of every prohibited write bank and immutable source field.
/// Dynamic activation, memory/predictor, sleep and biology are deliberately not frozen.
pub fn closure(cp: &[u8]) -> Result<BTreeMap<String, String>> {
    let p = payload(cp)?;
    let mut out = BTreeMap::new();
    for key in [
        "schema_version",
        "source_lineage",
        "policy",
        "runtime_profile_raw",
        "selector_tag",
        "decoder_stride",
        "mode",
        "source_inputs",
        "recipe_digest",
        "source_asset",
        "founder",
    ] {
        out.insert(key.into(), hash(p.field(key)?.0));
    }
    out.insert(
        "canonical.schema_version".into(),
        hash(p.path(&["canonical", "schema_version"])?.0),
    );
    let resident = p.path(&["canonical", "residents"])?.one()?;
    let neural = resident.field("neural")?;
    for key in [
        "schema_version",
        "organism_id",
        "phenotype_hash",
        "fast",
        "lifetime",
        "eligibility",
        "weight_generation",
    ] {
        out.insert(format!("resident.neural.{key}"), hash(neural.field(key)?.0));
    }
    out.insert(
        "resident.neural.dendrites".into(),
        hash(neural.path(&["neural", "dendrites"])?.0),
    );
    out.insert(
        "resident.neural_topology".into(),
        hash(resident.field("neural_topology")?.0),
    );
    let record = p
        .path(&["canonical", "world", "world", "organism_records"])?
        .one()?;
    for key in [
        "genome",
        "phenotype",
        "birth_tick",
        "organism_id",
        "world_entity_id",
    ] {
        out.insert(format!("record.{key}"), hash(record.field(key)?.0));
    }
    for (owner, c) in p.field("controllers")?.object()? {
        // Freeze optional ownership/schema, not its legitimate evolving last selection.
        out.insert(
            format!("controller.{owner}.optional_owner"),
            match c.object()?.get("optional_vocal") {
                Some(v) => hash(v.field("schema")?.0),
                None => hash(b"absent"),
            },
        );
        let motor = c.field("motor")?;
        for key in [
            "schema",
            "source_inputs",
            "source_hash",
            "mode",
            "m2_recipe",
            "group_recipe",
            "work_policy",
        ] {
            out.insert(
                format!("controller.{owner}.{key}"),
                hash(motor.field(key)?.0),
            );
        }
    }
    Ok(out)
}
pub fn source_headers(cp: &[u8]) -> Result<BTreeMap<String, String>> {
    let p = payload(cp)?;
    let mut result = BTreeMap::new();
    result.insert(
        "canonical.schema_version".into(),
        hash(p.path(&["canonical", "schema_version"])?.0),
    );
    result.insert(
        "resident.neural.schema_version".into(),
        hash(
            p.path(&["canonical", "residents"])?
                .one()?
                .path(&["neural", "schema_version"])?
                .0,
        ),
    );
    for (owner, c) in p.field("controllers")?.object()? {
        result.insert(
            format!("controller.{owner}.optional_owner"),
            match c.object()?.get("optional_vocal") {
                Some(v) => hash(v.field("schema")?.0),
                None => hash(b"absent"),
            },
        );
    }
    for key in [
        "source_lineage",
        "policy",
        "runtime_profile_raw",
        "selector_tag",
        "decoder_stride",
        "recipe_digest",
        "source_inputs",
        "source_asset",
        "founder",
    ] {
        result.insert(key.into(), hash(p.field(key)?.0));
    }
    for (owner, c) in p.field("controllers")?.object()? {
        for key in ["schema", "m2_recipe", "group_recipe", "work_policy"] {
            result.insert(
                format!("controller.{owner}.{key}"),
                hash(c.path(&["motor", key])?.0),
            );
        }
    }
    let record = p
        .path(&["canonical", "world", "world", "organism_records"])?
        .one()?;
    // The record genotype is checked by the native restore and the complete
    // prepared-pair comparison; source_inputs/source_asset seal its compiled source.
    result.insert("initial_record_sha256".into(), hash(record.0));
    Ok(result)
}
pub fn fresh(cp: &[u8], preparation: u64, sampler: u32) -> Result<()> {
    // Both policies are Full in this research pair. Also proves the optional
    // owner has exactly its fresh schema and null last-selection state.
    matched_initial(
        cp,
        if cp.starts_with(OPTIONAL_MAGIC) {
            "OptionalVocalM2/Full"
        } else {
            "LegacyGroupedM2/Full"
        },
    )?;
    let p = payload(cp)?;
    let canonical = p.field("canonical")?;
    if canonical.field("sampling_seed")?.value::<u32>()? != sampler
        || canonical.field("sampling_counter")?.value::<u32>()? != 0
    {
        return Err("fresh sampler differs".into());
    }
    let r = canonical.field("residents")?.one()?;
    let n = r.field("neural")?;
    if r.field("next_sequence")?.value::<u64>()? != 1
        || !r.field("replay")?.array()?.is_empty()
        || n.field("last_decision_tick")?.0 != b"null"
        || n.field("last_outcome_tick")?.0 != b"null"
        || n.field("dispatch_generation")?.value::<u64>()? != 0
    {
        return Err("fresh neural history differs".into());
    }
    for key in ["fast", "lifetime", "eligibility"] {
        if n.field(key)?
            .value::<Vec<f32>>()?
            .iter()
            .any(|v| v.to_bits() != 0)
        {
            return Err("fresh acquired bank is nonzero".into());
        }
    }
    if canonical
        .path(&["world", "world", "tick"])?
        .value::<u64>()?
        != preparation
    {
        return Err("fresh prepared tick differs".into());
    }
    Ok(())
}

#[cfg(test)]
mod projection_tests {
    use super::*;
    // Deliberately synthetic JSON, not a usable host/world/seed/checkpoint.
    // Tests exercise the projection boundary only; typed loader validation is
    // a separate required caller obligation.
    fn packet(optional: bool) -> Vec<u8> {
        let mut value = serde_json::json!({
            "schema_version": 1,
            "source_lineage": if optional { OPTIONAL_LINEAGE } else { LEGACY_LINEAGE },
            "policy": if optional { OPTIONAL_POLICY } else { LEGACY_POLICY },
            "mode": "Full",
            "source_inputs": {"synthetic_source": [7, 9]},
            "source_asset": {"weights": [11]},
            "founder": {"optimizer": {"ages": [9007199254740993u64], "moments": [0]}},
            "canonical": {
                "schema_version": if optional { 0x4f56u32 } else { 2 },
                "sampling_seed": 42, "sampling_counter": 0,
                "tracked_objects": [{"id": 3, "position": [1, 2]}],
                "residents": [{"neural": {
                    "schema_version": if optional { 0x4f56_0001u32 } else { 2 },
                    "organism_id": 7, "neural": {"activations": [0, 1], "dendrites": [2]},
                    "inactive_activations": [0], "eligibility": [0], "dispatch_generation": 0
                }, "memory": [4], "sleep": {"clock": 8}}],
                "world": {"world": {"tick": 10, "rng": [5, 6], "scene": [{"id": 3}],
                    "organism_records": [{"body": {"chemicals": [4, 5]},
                        "state_graph": {"brain": {"content_digest": if optional { 20 } else { 10 }, "other": 17}}}]
                }}
            },
            "controllers": {"7": {"motor": {"mode": "Full", "source_hash": [8], "last_receipt": null},
                "last_action": null, "memory_proofs": []}},
            "sampler_bits": {"7": {"ordinary": null, "group": null, "operations": null, "action": null}}
        });
        if optional {
            value["controllers"]["7"]["optional_vocal"] =
                serde_json::json!({"schema": OPTIONAL_OWNER, "last": null});
        }
        let mut result = if optional { OPTIONAL_MAGIC } else { MAGIC }.to_vec();
        result.extend(serde_json::to_vec(&value).unwrap());
        result
    }
    fn edit(optional: bool, pointer: &str, value: serde_json::Value) -> Vec<u8> {
        let bytes = packet(optional);
        let mut json: serde_json::Value =
            serde_json::from_slice(payload(&bytes).unwrap().0).unwrap();
        *json.pointer_mut(pointer).unwrap() = value;
        let mut result = if optional { OPTIONAL_MAGIC } else { MAGIC }.to_vec();
        result.extend(serde_json::to_vec(&json).unwrap());
        result
    }
    fn projection(bytes: &[u8], optional: bool) -> Result<Vec<u8>> {
        matched_initial(
            bytes,
            if optional {
                "OptionalVocalM2/Full"
            } else {
                "LegacyGroupedM2/Full"
            },
        )
    }
    #[test]
    fn exact_known_policy_differences_compare_equal() {
        assert_eq!(
            projection(&packet(false), false).unwrap(),
            projection(&packet(true), true).unwrap()
        );
    }
    #[test]
    fn every_retained_bank_is_compared() {
        let expected = projection(&packet(false), false).unwrap();
        for pointer in [
            "/canonical/world/world/organism_records/0/body/chemicals/1",
            "/canonical/world/world/rng/0",
            "/canonical/world/world/tick",
            "/canonical/sampling_counter",
            "/canonical/tracked_objects/0/position/0",
            "/canonical/world/world/scene/0/id",
            "/founder/optimizer/ages/0",
            "/founder/optimizer/moments/0",
            "/canonical/residents/0/neural/neural/activations/1",
            "/canonical/residents/0/neural/neural/dendrites/0",
            "/canonical/residents/0/neural/inactive_activations/0",
            "/canonical/residents/0/neural/eligibility/0",
            "/canonical/residents/0/memory/0",
            "/canonical/residents/0/sleep/clock",
            "/controllers/7/motor/source_hash/0",
            "/controllers/7/memory_proofs",
            "/source_inputs/synthetic_source/0",
            "/source_asset/weights/0",
            "/sampler_bits/7/ordinary",
            "/canonical/world/world/organism_records/0/state_graph/brain/other",
        ] {
            assert_ne!(
                expected,
                projection(&edit(true, pointer, serde_json::json!(99)), true).unwrap(),
                "{pointer}"
            );
        }
    }
    #[test]
    fn owner_schema_and_optional_state_are_not_wildcards() {
        for pointer in [
            "/source_lineage",
            "/policy",
            "/mode",
            "/controllers/7/motor/mode",
            "/controllers/7/optional_vocal/schema",
        ] {
            assert!(projection(&edit(true, pointer, serde_json::json!("unknown")), true).is_err());
        }
        for pointer in [
            "/schema_version",
            "/canonical/schema_version",
            "/canonical/residents/0/neural/schema_version",
            "/canonical/residents/0/neural/organism_id",
        ] {
            assert!(projection(&edit(true, pointer, serde_json::json!(999)), true).is_err());
        }
        for marker in [
            serde_json::json!(null),
            serde_json::json!({"schema": OPTIONAL_OWNER}),
            serde_json::json!({"schema": OPTIONAL_OWNER, "last": {"state": 1}}),
            serde_json::json!({"schema": OPTIONAL_OWNER, "last": null, "extra_schema": 1}),
        ] {
            assert!(
                projection(&edit(true, "/controllers/7/optional_vocal", marker), true).is_err()
            );
        }
        // Legacy cannot carry even a null optional field; optional cannot omit it.
        assert!(projection(
            &edit(
                false,
                "/controllers/7",
                serde_json::json!({
                    "motor": {"mode": "Full"}, "optional_vocal": null
                })
            ),
            false
        )
        .is_err());
        assert!(projection(
            &edit(
                true,
                "/controllers/7",
                serde_json::json!({
                    "motor": {"mode": "Full"}
                })
            ),
            true
        )
        .is_err());
        assert!(matched_initial(&packet(false), "Full").is_err());
        assert!(projection(&packet(true), false).is_err());
        assert!(projection(&packet(false), true).is_err());
    }
    #[test]
    fn unrecognized_schema_fields_are_retained_not_exempted() {
        let original = packet(true);
        let mut value: serde_json::Value =
            serde_json::from_slice(payload(&original).unwrap().0).unwrap();
        value["canonical"]["extra_schema"] = serde_json::json!(1);
        value["controllers"]["7"]["motor"]["schema_version"] = serde_json::json!(27);
        let mut changed = OPTIONAL_MAGIC.to_vec();
        changed.extend(serde_json::to_vec(&value).unwrap());
        assert_ne!(
            projection(&original, true).unwrap(),
            projection(&changed, true).unwrap()
        );
    }
    #[test]
    fn exact_decimal_tokens_and_array_order_survive() {
        // Tokens that a float round trip could conflate remain distinct.
        let original = String::from_utf8(packet(true)).unwrap();
        for token in ["1.00000000000000001", "1.00000000000000002", "-0.0"] {
            let changed = original.replace("9007199254740993", token);
            assert_ne!(
                projection(original.as_bytes(), true).unwrap(),
                projection(changed.as_bytes(), true).unwrap()
            );
        }
        let a = original.replace("9007199254740993", "1.00000000000000001");
        let b = original.replace("9007199254740993", "1.00000000000000002");
        assert_ne!(
            projection(a.as_bytes(), true).unwrap(),
            projection(b.as_bytes(), true).unwrap()
        );
        assert_ne!(
            projection(&packet(true), true).unwrap(),
            projection(
                &edit(
                    true,
                    "/canonical/world/world/rng",
                    serde_json::json!([6, 5])
                ),
                true
            )
            .unwrap()
        );
        assert_ne!(
            projection(&packet(true), true).unwrap(),
            projection(
                &edit(
                    true,
                    "/canonical/world/world/rng",
                    serde_json::json!([5, 6, 0])
                ),
                true
            )
            .unwrap()
        );
    }
}
