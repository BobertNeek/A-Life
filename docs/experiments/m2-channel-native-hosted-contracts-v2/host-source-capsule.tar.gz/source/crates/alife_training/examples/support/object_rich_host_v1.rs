//! Typed routing and separately named passive output. No checkpoint conversion.
use super::*;
pub enum Host {
    Legacy(CpuGroupedM2HostV1),
    Optional(CpuOptionalVocalM2HostV1),
}
pub struct Step {
    pub tick_before: Tick,
    pub tick_after: Tick,
    pub decisions: Vec<Value>,
    pub sleeping_organisms: usize,
    pub sleep_consolidations: usize,
}
fn transfer(t: &GripTransfer) -> Value {
    json!({"object":t.object,"kind":format!("{:?}",t.kind),"previous_owner":t.previous_owner,"new_owner":t.new_owner,"previous_position":t.previous_position,"new_position":t.new_position})
}
fn world_receipt(r: &HeadlessMotorTransactionReceipt) -> Value {
    let channels=r.channel_receipts.iter().map(|c|json!({"command":c.command,"phase":format!("{:?}",c.phase),"grip_transfers":c.grip_transfers.iter().map(transfer).collect::<Vec<_>>(),"play_stimulation":c.play_stimulation,"investigation":c.investigation,"observation":c.observation,"physical":c.physical})).collect::<Vec<_>>();
    json!({"bundle":r.bundle,"outcome_tick":r.outcome_tick,"succeeded":r.succeeded,"joint":r.joint,"channels":channels,"grip_transfers":r.grip_transfers.iter().map(transfer).collect::<Vec<_>>(),"body_event":r.body_event,"biology_before":r.biology_before,"biology_after":r.biology_after})
}
fn common<A: Serialize>(
    d: &CpuGroupedM2HostDecisionV1<A>,
    probability: Value,
    evaluation: Value,
    observer: Option<&HeadlessMotorTransactionReceipt>,
    optional: Option<&OptionalVocalScoresV1>,
) -> Result<Value> {
    if d.motor.native.core.source_execution_count != 1 {
        return Err("source did not run exactly once".into());
    }
    let noops=d.patch.selected_bundle().map(|b|b.channels.iter().filter(|c|matches!(c.primitive.raw(),103|104|212)).map(|c|json!({"channel":c.channel,"primitive":c.primitive.raw(),"measured":d.patch.outcome().joint.as_ref().and_then(|j|j.channel_observations.iter().find(|o|o.channel==c.channel))})).collect::<Vec<_>>()).unwrap_or_default();
    if let Some(r) = observer {
        if d.patch.selected_bundle() != Some(&r.bundle)
            || d.physical.outcome_tick != r.outcome_tick
            || d.patch.outcome().joint.as_ref() != Some(&r.joint)
        {
            return Err("passive world receipt does not match sealed decision".into());
        }
    }
    Ok(
        json!({"organism_id":d.organism_id,"action":d.action,"probabilities":probability,"evaluation":evaluation,"sampling_counter":d.sampling_counter,"source_diagnostic_logits":d.source_diagnostic_logits,"biological_emissions":d.biological_emissions,"brain_work":d.brain_work,"motor":d.motor,"physical":d.physical,"applied_recovery":applied_recovery(&d.physical),"real_noop_receipts":noops,"patch":d.patch,"sleep_phase":d.sleep_phase,"sleep_trigger":d.sleep_trigger,"research_world_receipt":observer.map(world_receipt),"optional_scores":optional,"payload_present":optional.map(|s|s.source().payload_present()),"same_context_legacy_probabilities":null}),
    )
}
impl Host {
    pub fn world(&self) -> &HeadlessWorld {
        match self {
            Self::Legacy(h) => h.world(),
            Self::Optional(h) => h.world(),
        }
    }
    pub fn sleep_state(&self, id: OrganismId) -> Option<alife_core::sleep::SleepState> {
        match self {
            Self::Legacy(h) => h.sleep_state(id),
            Self::Optional(h) => h.sleep_state(id),
        }
    }
    pub fn wire(&self) -> Result<Vec<u8>> {
        Ok(match self {
            Self::Legacy(h) => h.checkpoint()?.encode()?,
            Self::Optional(h) => h.checkpoint()?.encode()?,
        })
    }
    pub fn advance(&mut self, t: f32, observe: bool) -> Result<Step> {
        match self {
            Self::Legacy(h) => {
                let (s, receipts) = if observe {
                    let r = h.step_research_observed(t)?;
                    (r.step, r.world_receipts)
                } else {
                    (h.step(t)?, vec![])
                };
                if observe && receipts.len() != s.decisions.len() {
                    return Err("observer decision count differs".into());
                }
                let mut decisions = Vec::new();
                for (i, d) in s.decisions.iter().enumerate() {
                    let eval = d.motor.native.scores.evaluate(&d.action)?;
                    if eval.joint_log_probability.to_bits()
                        != d.action.old_joint_log_probability.to_bits()
                        || d.action.counter != d.sampling_counter
                    {
                        return Err("legacy probability/counter differs".into());
                    }
                    decisions.push(common(
                        d,
                        serde_json::to_value(
                            d.motor.native.scores.probabilities(d.action.temperature)?,
                        )?,
                        serde_json::to_value(eval)?,
                        receipts.get(i),
                        None,
                    )?);
                }
                Ok(Step {
                    tick_before: s.tick_before,
                    tick_after: s.tick_after,
                    decisions,
                    sleeping_organisms: s.sleeping_organisms,
                    sleep_consolidations: s.sleep_consolidations,
                })
            }
            Self::Optional(h) => {
                let (s, receipts) = if observe {
                    let r = h.step_research_observed(t)?;
                    (r.step, r.world_receipts)
                } else {
                    (h.step(t)?, vec![])
                };
                if observe && receipts.len() != s.decisions.len() {
                    return Err("observer decision count differs".into());
                }
                let mut decisions = Vec::new();
                for (i, d) in s.decisions.iter().enumerate() {
                    let scores = h
                        .last_selection_scores(d.organism_id)
                        .ok_or("optional scores absent")?;
                    let eval = scores.evaluate(&d.action)?;
                    if eval.joint_log_probability.to_bits()
                        != d.action.joint_log_probability().to_bits()
                        || d.action.counter() != d.sampling_counter
                    {
                        return Err("optional probability/counter differs".into());
                    }
                    let mut row = common(
                        d,
                        serde_json::to_value(scores.probabilities(d.action.temperature())?)?,
                        serde_json::to_value(eval)?,
                        receipts.get(i),
                        Some(scores),
                    )?;
                    row["same_context_legacy_probabilities"] = serde_json::to_value(
                        d.motor
                            .native
                            .scores
                            .probabilities(d.action.temperature())?,
                    )?;
                    decisions.push(row);
                }
                Ok(Step {
                    tick_before: s.tick_before,
                    tick_after: s.tick_after,
                    decisions,
                    sleeping_organisms: s.sleeping_organisms,
                    sleep_consolidations: s.sleep_consolidations,
                })
            }
        }
    }
    pub fn step(&mut self, t: f32) -> Result<Step> {
        self.advance(t, true)
    }
}
