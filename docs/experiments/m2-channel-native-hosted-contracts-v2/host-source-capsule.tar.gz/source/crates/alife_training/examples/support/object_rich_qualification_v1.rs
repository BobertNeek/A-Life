//! One bounded fresh fixture. Existing old public step output and state must match
//! observed warm versus ordinary-entry-point cold continuation, at every boundary.
use super::*;
const INTERVALS: u64 = 4;
fn binding(arm: usize, r: &recipe::Recipe, initial: &[u8]) -> Result<journal::Binding> {
    Ok(journal::Binding {
        schema: "object-rich-optional-vocal-durable-v1".into(),
        study_id: "object-rich-optional-vocal-fixed-fixture-v1".into(),
        arm,
        mode: mode_name(arm)?.into(),
        seed: FIXTURE_SEED,
        sampling_seed: sampling_seed(FIXTURE_SEED),
        initial_tick: 240,
        horizon: INTERVALS,
        temperature_bits: 1_f32.to_bits(),
        host_source_commit: HOST_COMMIT.into(),
        host_source_tree: HOST_TREE.into(),
        driver_source_commit: DRIVER_COMMIT.into(),
        driver_source_sha256: code_hash(),
        executable_sha256: executable_hash()?,
        protocol_sha256: hash(PROTOCOL),
        qualification_sha256: "fixed-fixture-not-primary".into(),
        preparation_sha256: hash(b"one 240-tick fresh pre-neural template; no primary seed"),
        source_manifest_sha256: hash(&serde_json::to_vec(&r.metadata)?),
        inputs_sha256: hash(&serde_json::to_vec(&r.inputs)?),
        initial_sha256: hash(initial),
        initial_matched_sha256: hash(&raw::matched_initial(initial, mode_name(arm)?)?),
        closure_sha256: closure_hash(initial)?,
        source_headers: raw::source_headers(initial)?,
        max_packet_bytes: journal::MAX_PACKET,
        max_arm_bytes: journal::MAX_ARM_BYTES,
        min_free_bytes: journal::MIN_FREE_BYTES,
    })
}
fn original_science(rows: &[u8]) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    for line in rows.split(|c| *c == b'\n').filter(|l| !l.is_empty()) {
        let mut v: Value = serde_json::from_slice(line)?;
        if let Some(decisions) = v["decisions"].as_array_mut() {
            for d in decisions {
                d["research_world_receipt"] = Value::Null;
            }
        }
        out.extend(serde_json::to_vec(&v)?);
        out.push(b'\n');
    }
    Ok(out)
}
pub fn qualify(out: &Path) -> Result<()> {
    seed_admission_preflight(FIXTURE_SEED, 1)?;
    if out.exists() {
        return Err("fixed qualification directory exists; no retry".into());
    }
    fs::create_dir(out)?;
    write_new(
        out,
        "QUALIFICATION_ATTEMPT.json",
        &json!({"seed":FIXTURE_SEED,"primary_seed_executed":false,"maximum_native_calls":16,"maximum_body_calls":240,"source_candidates":1,"automatic_retry":false,"executable_sha256":executable_hash()?,"driver_code_sha256":code_hash()}),
    )?;
    let mut actual = 0;
    let mut native = 0_u64;
    let mut max_packet = 0_u64;
    let mut max_initial = 0_u64;
    let mut max_science = 0_u64;
    let mut max_positive_growth = 0_u64;
    let mut details = Vec::new();
    let result = (|| -> Result<()> {
        let r = recipe::build(FIXTURE_SEED, true)?;
        write_new(out, "SOURCE-CONTRACT.json", &source_contract(&r)?)?;
        write_new(out, "SOURCE.json", &r.metadata)?;
        write_new(
            out,
            "SOURCE_BOUND_BEFORE_PREPARATION.json",
            &json!({"genotype":r.metadata["genotype_sha256"],"inputs":r.inputs.canonical_digest(),"native_calls":0,"body_calls":0}),
        )?;
        let hosts = fresh_pair(&r, 240, true, &mut actual, out)?;
        let reference = r
            .phenotype
            .cognitive_architecture()
            .sleep_trigger_threshold();
        for (arm, mut warm) in hosts.into_iter().enumerate() {
            let d = out.join(format!("arm-{arm}"));
            fs::create_dir(&d)?;
            let initial = cp(&warm)?;
            max_initial = max_initial.max(initial.len() as u64);
            journal::publish_artifact(&d, "initial.private.m2", &initial, journal::MAX_PACKET)?;
            let b = binding(arm, &r, &initial)?;
            let warm_dir = d.join("warm");
            let cold_dir = d.join("cold");
            journal::init_journal(&warm_dir, &b)?;
            journal::init_journal(&cold_dir, &b)?;
            let mut warm_previous = hash(&initial);
            let mut cold_previous = hash(&initial);
            let mut cold_bytes =
                journal::bounded_read(&d.join("initial.private.m2"), journal::MAX_PACKET)?;
            let mut arm_decisions = 0_u64;
            let mut actual_transfers = 0_u64;
            let mut previous_warm_size = None;
            for offset in 0..INTERVALS {
                let before = observe(&warm)?;
                write_new(
                    &warm_dir,
                    &format!("ATTEMPT-{offset:06}.json"),
                    &json!({"offset":offset,"observer":true,"attempt_before_call":true}),
                )?;
                let step = counted_call(&mut native, || warm.advance(1., true))?;
                let after = observe(&warm)?;
                let bytes = cp(&warm)?;
                validate_cp(&bytes, 241 + offset, &b.closure_sha256)?;
                let rows = science(
                    &before,
                    &after,
                    &step,
                    offset,
                    &bytes,
                    &b.closure_sha256,
                    reference,
                )?;
                arm_decisions += step.decisions.len() as u64;
                for row in &step.decisions {
                    let receipt = &row["research_world_receipt"];
                    if !receipt.is_object() {
                        return Err("observed decision missing real receipt".into());
                    }
                    actual_transfers += receipt["grip_transfers"]
                        .as_array()
                        .ok_or("grip array missing")?
                        .len() as u64;
                }
                let packet = journal::make_packet(&b, offset, &warm_previous, &bytes, &rows)?;
                journal::publish(&warm_dir, &format!("{offset:06}.packet"), &packet)?;
                warm_previous = hash(&packet);
                if let Some(previous) = previous_warm_size {
                    max_positive_growth =
                        max_positive_growth.max((packet.len() as u64).saturating_sub(previous));
                }
                previous_warm_size = Some(packet.len() as u64);
                max_packet = max_packet.max(packet.len() as u64);
                max_science = max_science.max(rows.len() as u64);
                // Load only this fixture's own cold published prefix. Never use warm
                // acquired state to initialize the cold trajectory.
                let mut cold =
                    restore(&cold_bytes, &r.inputs, arm, 240 + offset, &b.closure_sha256)?;
                let cold_before = observe(&cold)?;
                write_new(
                    &cold_dir,
                    &format!("ATTEMPT-{offset:06}.json"),
                    &json!({"offset":offset,"observer":false,"attempt_before_call":true}),
                )?;
                let cold_step = counted_call(&mut native, || cold.advance(1., false))?;
                let cold_wire = cp(&cold)?;
                let cold_rows = science(
                    &cold_before,
                    &observe(&cold)?,
                    &cold_step,
                    offset,
                    &cold_wire,
                    &b.closure_sha256,
                    reference,
                )?;
                if cold_wire != bytes || original_science(&cold_rows)? != original_science(&rows)? {
                    return Err(
                        "observer changed old output/state or cold continuation differs".into(),
                    );
                }
                let cold_packet =
                    journal::make_packet(&b, offset, &cold_previous, &cold_wire, &cold_rows)?;
                journal::publish(&cold_dir, &format!("{offset:06}.packet"), &cold_packet)?;
                let loaded = journal::bounded_read(
                    &cold_dir.join(format!("{offset:06}.packet")),
                    journal::MAX_PACKET,
                )?;
                let decoded = journal::decode_packet(&loaded, &b, offset, &cold_previous)?;
                if decoded.checkpoint != cold_wire || decoded.trace != cold_rows {
                    return Err("cold packet roundtrip differs".into());
                }
                cold_previous = decoded.digest;
                cold_bytes = decoded.checkpoint;
                max_packet = max_packet.max(cold_packet.len() as u64);
                max_science = max_science.max(cold_rows.len() as u64);
            }
            // Exercise the actual durable recovery/export path, including attempt
            // records and their retained atomic aliases, without further native calls.
            for dir in [&warm_dir, &cold_dir] {
                let recovered = journal::recover_without_trace(dir, &b, &initial, |wire, tick| {
                    validate_cp(wire, tick, &b.closure_sha256)
                })?;
                if recovered.next != INTERVALS || recovered.checkpoint != cold_bytes {
                    return Err("qualified durable recovery does not match final state".into());
                }
            }
            details.push(json!({"arm":arm,"policy":mode_name(arm)?,"warm_calls":4,"cold_calls":4,"decisions_per_trajectory":arm_decisions,"authoritative_grip_transfers_observed":actual_transfers,"every_original_output_and_checkpoint_exact":true,"observer_only_fields_excluded_from_original_output_comparison":["research_world_receipt"],"closed_source_optimizer_sentinels":true,"final_checkpoint_sha256":hash(&cold_bytes)}));
        }
        if actual != 240
            || native != 16
            || max_packet
                .checked_add(262144 + (max_positive_growth * HORIZON).max(1024 * 1024))
                .is_none_or(|v| v > journal::MAX_PACKET)
        {
            return Err("fixed dose or whole-packet forecast failed".into());
        }
        write_new(
            out,
            "QUALIFICATION_COMPLETE.json",
            &json!({"schema":"object-rich-optional-vocal-driver-qualification-v1","complete":true,"driver_commit":DRIVER_COMMIT,"driver_code_sha256":code_hash(),"executable_sha256":executable_hash()?,"protocol_sha256":hash(PROTOCOL),"actual_native_calls":native,"actual_preparation_intervals":actual,"primary_seed_executed":false,"observer_inertness_and_cold_exact":true,"maximum_packet_bytes":max_packet,"maximum_positive_packet_growth_per_interval":max_positive_growth,"projected_packet_bytes":max_packet+262144+(max_positive_growth*HORIZON).max(1024*1024),"projection_is_not_a_growth_guarantee":true,"maximum_initial_checkpoint_bytes":max_initial,"maximum_science_row_pair_bytes":max_science,"projected_pair_physical_bytes":2*HORIZON*journal::MAX_PACKET,"metadata_initial_export_headroom":2*journal::MAX_PACKET+64*1024*1024,"arms":details,"no_behavioral_benefit_claim":true,"no_extra_calls_for_event_coverage":true}),
        )?;
        Ok(())
    })();
    if let Err(e) = &result {
        let _ = write_new(
            out,
            "QUALIFICATION_FAILED.json",
            &json!({"error":e.to_string(),"actual_native_calls_attempted":native,"actual_preparation_intervals_completed":actual,"no_retry":true}),
        );
    }
    result
}
