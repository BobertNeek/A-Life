//! Fixed ordinary object recipes and read-only scene/candidate evidence.
//! No actions, physiology edits, priming or object renewal occur here.
use super::*;
pub fn scene(seed: u64, id: OrganismId) -> Result<HeadlessWorld> {
    let mut w = HeadlessScenarioBuilder::new(seed)
        .agent("learner", id, Vec3f::ZERO)
        .food("near-root", Vec3f::new(1., 0., -0.5), 0.65)
        .food("far-fruit", Vec3f::new(2.75, 0., 1.75), 0.45)
        .toy("activity-toy", Vec3f::new(0.8, 0., 2.1), false)
        .obstacle("obstacle", Vec3f::new(1.8, 0., 0.65), 0.35)
        .build()?;
    w.set_food_variety(
        w.entity_id("near-root").ok_or("near root missing")?,
        FoodVariety::Root,
    )?;
    w.set_food_variety(
        w.entity_id("far-fruit").ok_or("fruit missing")?,
        FoodVariety::Fruit,
    )?;
    Ok(w)
}
fn point(v: Vec3f) -> [f64; 3] {
    [f64::from(v.x), f64::from(v.y), f64::from(v.z)]
}
fn distance(a: Vec3f, b: Vec3f) -> f64 {
    point(a)
        .into_iter()
        .zip(point(b))
        .map(|(a, b)| (a - b).powi(2))
        .sum::<f64>()
        .sqrt()
}
fn segment_distance(a: Vec3f, b: Vec3f, p: Vec3f) -> f64 {
    let a = point(a);
    let b = point(b);
    let p = point(p);
    let v = std::array::from_fn::<_, 3, _>(|i| b[i] - a[i]);
    let denom = v.iter().map(|v| v * v).sum::<f64>();
    let t = if denom == 0. {
        0.
    } else {
        ((0..3).map(|i| (p[i] - a[i]) * v[i]).sum::<f64>() / denom).clamp(0., 1.)
    };
    (0..3)
        .map(|i| (a[i] + t * v[i] - p[i]).powi(2))
        .sum::<f64>()
        .sqrt()
}
pub fn snapshot(w: &HeadlessWorld) -> Result<Value> {
    let r = w
        .organism_registry()
        .iter()
        .next()
        .ok_or("resident absent")?;
    let actor = w.entity(r.world_entity_id()).ok_or("body entity absent")?;
    let obstacle = w
        .entity(w.entity_id("obstacle").ok_or("obstacle absent")?)
        .ok_or("obstacle record absent")?;
    let grip = Vec3f::new(
        actor.position.x + actor.body_yaw.cos() * 0.5,
        actor.position.y,
        actor.position.z + actor.body_yaw.sin() * 0.5,
    );
    let objects=w.object_snapshots().iter().map(|o| {
        let p=o.grounded_physical;
        json!({"id":o.id,"label":o.label,"kind":format!("{:?}",o.kind),"position":o.position,
          "body_yaw":o.body_yaw,"head_yaw":o.head_yaw,"radius":o.radius,"nutrition":o.nutrition,
          "hazard_pain":o.hazard_pain,"consumed":o.consumed,"carried_by":o.carried_by,"activity_hold":o.activity_hold,
          "tracking_key":format!("{:?}",o.tracking_key),"distance":distance(actor.position,o.position),
          "within_center_manipulation_reach":distance(actor.position,o.position)<=1.25,
          "actor_target_obstacle_clearance":segment_distance(actor.position,o.position,obstacle.position)-f64::from(obstacle.radius),
          "target_grip_obstacle_clearance":segment_distance(o.position,grip,obstacle.position)-f64::from(obstacle.radius),
          "properties":{"velocity":p.velocity,"color":p.color,"material":p.material,"shape":p.shape,"chemical":p.chemical,"surface_temperature":p.surface_temperature,"terrain":p.terrain}})
    }).collect::<Vec<_>>();
    if !r.lifecycle().is_alive() {
        return Ok(
            json!({"tick":w.tick(),"objects":objects,"candidate_count":null,"candidates":[],"grounded_slots":[],"perception_unavailable_reason":"dead lifecycle; no candidate admission attempted","utterances":w.audible_utterances()}),
        );
    }
    let mut perception = w.clone();
    let admission = SleepChoiceWorldAdmissionV1::for_organism(&perception, r.organism_id())?;
    let (draft, _) = perception.perception_sleep_choice_draft_with_bindings(
        &admission,
        w.tick(),
        r.biochemistry().homeostasis,
    )?;
    Ok(
        json!({"tick":w.tick(),"objects":objects,"candidate_count":draft.candidates().len(),"candidates":draft.candidates(),
       "grounded_slots":draft.grounded_object_slots(),"manipulation_effector_gain":r.embodiment().effector_gain(EffectorCapability::Manipulation),
       "locomotion_body_radius":LocomotionLimits::default().body_radius,"actor_obstacle_clearance":distance(actor.position,obstacle.position)-f64::from(obstacle.radius+LocomotionLimits::default().body_radius),
       "actor_grip_obstacle_clearance":segment_distance(actor.position,grip,obstacle.position)-f64::from(obstacle.radius),
       "ordinary_contact_radius":0.75,"ordinary_manipulation_radius":1.25,"terrain_present":w.terrain().is_some(),
       "read_only_perception_clone":true,"utterances":w.audible_utterances()}),
    )
}
pub fn initial_audit(w: &HeadlessWorld) -> Result<Value> {
    let evidence = snapshot(w)?;
    if w.terrain().is_some()
        || w.object_count() != 5
        || evidence["candidate_count"] != 31
        || evidence["actor_obstacle_clearance"]
            .as_f64()
            .is_none_or(|v| v <= 0.)
        || evidence["actor_grip_obstacle_clearance"]
            .as_f64()
            .is_none_or(|v| v <= 0.)
        || evidence["manipulation_effector_gain"]
            .as_f64()
            .is_none_or(|v| v <= 0.)
    {
        return Err("fixed scene capacity/body/effector check failed".into());
    }
    let actual = w.object_snapshots();
    for o in &actual {
        if o.consumed || o.carried_by.is_some() || o.activity_hold || o.hazard_pain != 0. {
            return Err("fixed scene is not fresh harmless unheld objects".into());
        }
    }
    let r = w
        .organism_registry()
        .iter()
        .next()
        .ok_or("resident absent")?;
    let actor = w.entity(r.world_entity_id()).ok_or("actor absent")?;
    let expected: [(&str, Vec3f, f32, Option<[f32; 3]>); 4] = [
        (
            "near-root",
            Vec3f::new(1., 0., -0.5),
            0.75,
            Some([0.8, 0.25, 0.35]),
        ),
        (
            "far-fruit",
            Vec3f::new(2.75, 0., 1.75),
            0.75,
            Some([0.85, 0.65, 0.8]),
        ),
        (
            "activity-toy",
            Vec3f::new(0.8, 0., 2.1),
            0.5,
            Some([0., 0., 0.]),
        ),
        ("obstacle", Vec3f::new(1.8, 0., 0.65), 0.35, None),
    ];
    let candidates = evidence["candidates"]
        .as_array()
        .ok_or("candidate evidence absent")?;
    for (label, position, radius, chemistry) in expected {
        let id = w.entity_id(label).ok_or("fixed object absent")?;
        let o = w.entity(id).ok_or("fixed object record absent")?;
        if o.position != position
            || o.radius.to_bits() != radius.to_bits()
            || chemistry.is_some_and(|c| o.grounded_physical.chemical != c)
        {
            return Err("fixed object geometry/recipe changed".into());
        }
        let n = candidates
            .iter()
            .filter(|c| c["target"]["entity"] == json!(id))
            .count();
        if n != 6 {
            return Err(format!(
                "fixed target {label} lacks all six canonical candidates (got {n})"
            )
            .into());
        }
    }
    let near = w.entity(w.entity_id("near-root").unwrap()).unwrap();
    if distance(actor.position, near.position) > 1.25 || near.nutrition != 0.65 {
        return Err("ordinary near food not in center reach".into());
    }
    let near_row = evidence["objects"]
        .as_array()
        .unwrap()
        .iter()
        .find(|o| o["label"] == "near-root")
        .unwrap();
    for field in [
        "actor_target_obstacle_clearance",
        "target_grip_obstacle_clearance",
    ] {
        if near_row[field].as_f64().is_none_or(|v| v <= 0.) {
            return Err("ordinary near-food grip segment obstructed".into());
        }
    }
    for i in 1..actual.len() {
        for j in i + 1..actual.len() {
            if distance(actual[i].position, actual[j].position)
                <= f64::from(actual[i].radius + actual[j].radius)
            {
                return Err("non-agent object bounds overlap".into());
            }
        }
    }
    Ok(evidence)
}
