//! Experimental unpriced, learning-closed channel-native host identity and a shared-loop policy strategy.
//! No old host conversion, reset, imported checkpoint, or gradient entry point.
use super::*;
type Selection<A> = (A, u16, [Option<u16>; 6], Option<SpeechMotorPayload>);
use crate::cpu::{
    ChannelNativeActionV1, ChannelNativeScoresV1, CHANNEL_NATIVE_POLICY_V1,
};
const CHANNEL_MAGIC: &[u8] = b"ALIFE-CHANNEL-NATIVE-M2-HOST\0V1\0IDLE-QUIET\0SOURCE-PAYLOAD\0SYNAPTIC-CLOSED\0PROFILE5\0BITS1\0";
const CHANNEL_LINEAGE: &str = "fresh-channel-native-m2-host-v1/class5/no-historical-import";
pub(super) const CHANNEL_RESIDENT: &str = "channel-native-m2-resident-v1";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(in crate::cpu::host) struct ChannelNativeResidentV1 {
    pub(super) schema: String,
    pub(super) last: Option<ChannelNativeSelectionV1>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct ChannelNativeSelectionV1 {
    pub(super) scores: ChannelNativeScoresV1,
    pub(super) action: ChannelNativeActionV1,
}
impl ChannelNativeResidentV1 {
    pub(super) fn fresh() -> Self {
        Self {
            schema: CHANNEL_RESIDENT.into(),
            last: None,
        }
    }
    pub(super) fn is_fresh(&self) -> bool {
        self.schema == CHANNEL_RESIDENT && self.last.is_none()
    }
}
pub(super) struct ChannelNativePolicy;
impl GroupedPolicyStrategy for ChannelNativePolicy {
    type Action = ChannelNativeActionV1;
    const OPTIONAL: bool = false;
    const CHANNEL_NATIVE: bool = true;
    fn administrative_receipt(r:&Resident)->Result<Option<crate::cpu::ChannelNativeAdministrativeReceiptV1>,CpuHostError> {
        let last=r.grouped.as_ref().and_then(|g|g.channel_native.as_ref()).and_then(|v|v.last.as_ref()).ok_or(CpuHostError::State("missing administrative source"))?;
        Ok(Some(last.scores.administrative_receipt(&last.action)?))
    }
    const MAGIC: &'static [u8] = CHANNEL_MAGIC;
    const LINEAGE: &'static str = CHANNEL_LINEAGE;
    const POLICY: &'static str = CHANNEL_NATIVE_POLICY_V1;
    fn select(
        founder: &CpuFoundationTrainer,
        r: &mut Resident,
        frame: &PerceptionFrame,
        _output: &CpuDecisionOutput,
        seed: u32,
        counter: u32,
        t: f64,
    ) -> Result<Selection<Self::Action>, CpuHostError> {
        let source = r.neural.channel_native_source()?.clone();
        let state = r
            .grouped
            .as_mut()
            .ok_or(CpuHostError::State("missing optional controller"))?;
        // During the new forward native generation is one ahead of last sample;
        // use explicit owner checks, not the completed-boundary validator.
        if state.optional_vocal.is_some() || state.last_action.is_some()
            || state
                .channel_native
                .as_ref()
                .is_none_or(|v| v.schema != CHANNEL_RESIDENT)
        {
            return Err(CpuHostError::State("optional sampler owner mismatch"));
        }
        let native = &state
            .motor
            .last_receipt
            .as_ref()
            .ok_or(CpuHostError::State("missing optional scores"))?
            .native
            .scores;
        let scores = ChannelNativeScoresV1::bind_native(founder.phenotype(), frame, native, source)?;
        let action = scores.sample_native(seed, counter, t)?;
        let (index, motors) = scores.physical_selection(&action)?;
        let speech = if motors[3].is_some() {
            scores.source().speech()?
        } else {
            None
        };
        state.channel_native.as_mut().unwrap().last = Some(ChannelNativeSelectionV1 {
            scores,
            action: action.clone(),
        });
        Ok((action, index, motors, speech))
    }
    fn stage(
        r: &mut Resident,
        p: &BrainPhenotype,
        a: &Self::Action,
        b: CpuDecisionBinding,
    ) -> Result<(), CpuHostError> {
        let state = r
            .grouped
            .as_ref()
            .ok_or(CpuHostError::State("missing optional controller"))?;
        state.validate_policy::<Self>()?;
        let last = state
            .channel_native
            .as_ref()
            .and_then(|v| v.last.as_ref())
            .ok_or(CpuHostError::State("missing optional sample"))?;
        if last.action != *a {
            return Err(CpuHostError::State("optional staged sample mismatch"));
        }
        last.scores
            .validate_native(&state.motor.last_receipt.as_ref().unwrap().native.scores)?;
        Ok(r.neural
            .stage_channel_native_closed_selection(p, a, &last.scores, b)?)
    }
    fn close(
        n: &mut CpuOrganismState,
        f: &CpuFoundationTrainer,
        p: &ExperiencePatch,
        r: &NeuralReceptorFrame,
    ) -> Result<(), CpuHostError> {
        Ok(n.close_channel_native_outcome(f, p, r)?)
    }
}

pub type CpuChannelNativeM2HostStepV1 = CpuGroupedM2HostStepV1<ChannelNativeActionV1>;
pub type CpuChannelNativeM2HostDecisionV1 = CpuGroupedM2HostDecisionV1<ChannelNativeActionV1>;
pub struct CpuChannelNativeM2HostV1 {
    inner: CpuGroupedM2HostV1,
}
#[derive(Debug, Clone)]
pub struct CpuChannelNativeM2HostCheckpointV1 {
    payload: GroupedPayloadV1,
}
impl CpuChannelNativeM2HostCheckpointV1 {
    pub fn encode(&self) -> Result<Vec<u8>, CpuHostError> {
        let mut bytes = CHANNEL_MAGIC.to_vec();
        bytes.extend(serde_json::to_vec(&self.payload)?);
        Ok(bytes)
    }
    pub fn decode(bytes: &[u8]) -> Result<Self, CpuHostError> {
        let body = bytes
            .strip_prefix(CHANNEL_MAGIC)
            .ok_or(CpuHostError::State("not fresh channel-native M2 envelope"))?;
        let metadata: serde_json::Value = serde_json::from_slice(body)?;
        // Identity is inspected before decoding source or private acquired state.
        if metadata["schema_version"] != 1
            || metadata["source_lineage"] != CHANNEL_LINEAGE
            || metadata["policy"] != CHANNEL_NATIVE_POLICY_V1
            || metadata["runtime_profile_raw"] != 5
            || metadata["selector_tag"] != 12
            || metadata["decoder_stride"] != 55
            || metadata["recipe_digest"] != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
            || metadata["canonical"]["schema_version"] != CHANNEL_NATIVE_CANONICAL_SCHEMA
            || !metadata["canonical"]["residents"]
                .as_array()
                .is_some_and(|rows| {
                    !rows.is_empty()
                        && rows.iter().all(|r| {
                            r["neural"]["schema_version"]
                                == crate::cpu::organism::CHANNEL_NATIVE_NEURAL_SCHEMA
                        })
                })
        {
            return Err(CpuHostError::State("channel-native outer policy mismatch"));
        }
        let mut payload: GroupedPayloadV1 = serde_json::from_value(metadata.clone())?;
        payload.restore_sampler_bits()?;
        for state in payload.controllers.values() {
            state.validate_policy::<ChannelNativePolicy>()?;
        }
        if serde_json::from_slice::<serde_json::Value>(&serde_json::to_vec(&payload)?)? != metadata
        {
            return Err(CpuHostError::State(
                "channel-native noncanonical nested state",
            ));
        }
        Ok(Self { payload })
    }
}
impl CpuChannelNativeM2HostV1 {
    pub fn new_prepared<T, E: std::fmt::Display>(
        game: CanonicalNewGame,
        founder: CpuFoundationTrainer,
        source_inputs: PhenotypeCompilerInputs,
        sampling_seed: u32,
        mode: MediationModeV1,
        prepare: impl FnOnce(&mut HeadlessWorld) -> Result<T, E>,
    ) -> Result<(Self, T), CpuHostError> {
        let (inner, value) = CpuGroupedM2HostV1::new_prepared_policy::<ChannelNativePolicy, T, E>(
            game,
            founder,
            source_inputs,
            sampling_seed,
            mode,
            prepare,
        )?;
        Ok((Self { inner }, value))
    }
    pub fn world(&self) -> &HeadlessWorld {
        self.inner.world()
    }
    /// Read-only optional sampling evidence for this organism's last decision.
    /// The shared motor receipt contains native proposals, not this policy's
    /// selected-action distribution. Old grouped/PPO evaluation is not valid here.
    pub fn last_selection_scores(&self, organism: OrganismId) -> Option<&ChannelNativeScoresV1> {
        self.inner
            .host
            .residents
            .get(&organism.raw())?
            .grouped
            .as_ref()?
            .channel_native
            .as_ref()?
            .last
            .as_ref()
            .map(|s| &s.scores)
    }
    pub fn sleep_state(&self, id: OrganismId) -> Option<alife_core::sleep::SleepState> {
        self.inner.sleep_state(id)
    }
    pub fn checkpoint(&self) -> Result<CpuChannelNativeM2HostCheckpointV1, CpuHostError> {
        Ok(CpuChannelNativeM2HostCheckpointV1 {
            payload: self.inner.checkpoint_payload::<ChannelNativePolicy>()?,
        })
    }
    pub fn restore(
        c: CpuChannelNativeM2HostCheckpointV1,
        expected_source: &PhenotypeCompilerInputs,
        mode: MediationModeV1,
    ) -> Result<Self, CpuHostError> {
        let wire = c.encode()?;
        let inner = CpuGroupedM2HostV1::restore_payload::<ChannelNativePolicy>(
            c.payload,
            expected_source,
            mode,
            wire,
        )?;
        Ok(Self { inner })
    }
    pub fn step_research_observed(
        &mut self,
        temperature: f32,
    ) -> Result<CpuGroupedM2ResearchStepV1<ChannelNativeActionV1>, CpuHostError> {
        self.inner
            .host
            .grouped_policy_step_observed::<ChannelNativePolicy>(&self.inner.founder, temperature)
    }
    pub fn step(&mut self, temperature: f32) -> Result<CpuChannelNativeM2HostStepV1, CpuHostError> {
        self.inner
            .host
            .grouped_policy_step::<ChannelNativePolicy>(&self.inner.founder, temperature)
    }
    pub fn actor_optimization(&mut self) -> Result<(), CpuHostError> {
        Err(CpuHostError::State(
            "channel-native synaptic learning is closed",
        ))
    }
    pub fn waking_synaptic_plasticity(&mut self) -> Result<(), CpuHostError> {
        Err(CpuHostError::State(
            "channel-native synaptic learning is closed",
        ))
    }
    pub fn synaptic_sleep_consolidation(&mut self) -> Result<(), CpuHostError> {
        Err(CpuHostError::State(
            "channel-native synaptic learning is closed",
        ))
    }
}

#[cfg(test)]
#[path = "channel_native_host_tests.rs"]
mod tests;
