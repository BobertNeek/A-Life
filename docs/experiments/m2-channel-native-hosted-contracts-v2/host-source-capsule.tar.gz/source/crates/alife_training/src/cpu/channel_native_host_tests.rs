//! Authored bounded native/world controls, NOT executed in source-only preparation.
//! Fixed disposable fixtures are not autonomous learning or scientific life evidence.
use super::*;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
#[allow(dead_code)]
#[path = "grouped_host_fixture.rs"]
mod recipe;
// Fixed mnemonic control seed, declared before any execution. No seed search.
const FIXTURE_SEED: u64 = 0x0043_484e_4c48_5331;
fn build<P: GroupedPolicyStrategy>() -> (CpuGroupedM2HostV1, PhenotypeCompilerInputs) {
    let recipe = recipe::build(FIXTURE_SEED, true).unwrap();
    let mut founder = CpuFoundationTrainer::new(
        recipe.phenotype.clone(),
        recipe.asset.clone(),
        StageTrainableMask::recurrent_only(&recipe.phenotype).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    // Disposable optimizer sentinels, not trained or imported acquired state.
    let mut optimizer = founder.checkpoint();
    optimizer.optimizer_step = 23;
    optimizer.update_ages[0] = 23;
    optimizer.first_moment[0] = 0.03125;
    optimizer.second_moment[0] = 0.0625;
    founder =
        CpuFoundationTrainer::from_checkpoint(recipe.phenotype.clone(), recipe.asset, optimizer)
            .unwrap();
    // This fixture must retain the audited zero payload head; no token seeding.
    assert!(founder.phenotype().synapses().iter().enumerate().filter(|(_,s)|
        matches!(s.kind(),CompiledSynapseKind::Decoder(c) if c.head()==DecoderHeadKind::SpeechPayload))
        .all(|(i,_)|founder.weights()[i].to_bits()==0_f32.to_bits()));
    let mut game =
        create_grounded_drive_research_new_game(&recipe.config, &recipe.genotype).unwrap();
    let newborn = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    let mut blank = HeadlessScenarioBuilder::new(FIXTURE_SEED)
        .agent("learner", newborn.organism_id(), Vec3f::ZERO)
        .build()
        .unwrap();
    blank
        .register_grounded_drive_research_record(newborn)
        .unwrap();
    game.world = blank;
    let inputs = recipe.inputs;
    let (host, ()) = CpuGroupedM2HostV1::new_prepared_policy::<P, _, String>(
        game,
        founder,
        inputs.clone(),
        (FIXTURE_SEED ^ (FIXTURE_SEED >> 32)) as u32,
        MediationModeV1::Full,
        |_| Ok(()),
    )
    .unwrap();
    (host, inputs)
}
fn fresh() -> (CpuChannelNativeM2HostV1, PhenotypeCompilerInputs) {
    let (inner, inputs) = build::<ChannelNativePolicy>();
    (CpuChannelNativeM2HostV1 { inner }, inputs)
}
fn frozen(host: &CpuChannelNativeM2HostV1) -> Vec<u8> {
    let r = host.inner.host.residents.values().next().unwrap();
    let n = r.neural.checkpoint().unwrap();
    serde_json::to_vec(&(
        host.inner.founder.checkpoint(),
        n.lifetime,
        n.fast,
        n.eligibility,
        n.weight_generation,
        n.neural.dendrites,
        r.v11.checkpoint(),
    ))
    .unwrap()
}
#[test]
fn channel_native_host_source_once_quiet_physics_and_exact_next_boundary() {
    let (mut warm, inputs) = fresh();
    let frozen_before = frozen(&warm);
    let first = warm.step(0.73).unwrap();
    assert_eq!(first.decisions.len(), 1);
    let d = &first.decisions[0];
    assert_eq!(first.tick_after.raw(), first.tick_before.raw() + 1);
    assert_eq!(d.motor.native.core.source_execution_count, 1);
    assert_eq!(d.motor.native.core.final_generation, 1);
    assert_eq!(d.action.counter(), d.sampling_counter);
    let admin=d.administrative_work.as_ref().unwrap();
    assert_eq!(admin.channel_factors,6);assert!(!admin.body_price_qualified);
    let scores = warm.last_selection_scores(d.organism_id).unwrap();
    let drawn=scores.physical_selection(&d.action).unwrap().1;
    // Record actual movement/manipulation independently of Rest posture.
    eprintln!("channel_native_physical: posture={:?}, locomotion={:?}, manipulation={:?}, outcome_tick={:?}, recovery={:?}",d.action.motors()[4],drawn[0],drawn[2],d.physical.outcome_tick,d.physical);
    assert!(!scores.source().payload_present());
    scores
        .validate_sampling_context(
            &d.action,
            d.action.seed(),
            d.sampling_counter,
            f64::from(0.73_f32),
        )
        .unwrap();
    assert_eq!(scores.physical_selection(&d.action).unwrap().1[3], None);
    assert_eq!(
        d.action.motors()[3],
        crate::cpu::ChannelNativeChoiceV1::Quiet
    );
    assert!(d
        .patch
        .selected_bundle()
        .unwrap()
        .channels
        .iter()
        .all(|c| c.channel != MotorChannel::Vocal));
    assert_eq!(d.physical.outcome_tick.raw(), first.tick_after.raw());
    assert_eq!(
        warm.world()
            .organism_registry()
            .get(d.organism_id)
            .unwrap()
            .biochemistry()
            .tick,
        first.tick_after
    );
    assert_eq!(warm.world().audible_utterances().len(), 0);
    let charged = d.patch.decision().cognitive_work.as_ref().unwrap();
    assert_eq!(charged.learning_ops, 0);
    assert_eq!(charged.neural_updates, d.brain_work.neuron_updates);
    assert_eq!(charged.synapses_evaluated, d.brain_work.synapse_ops);
    let extra = GroupedMotorStateV1::append_work(warm.inner.founder.phenotype()).unwrap();
    assert_eq!(
        charged.neural_updates,
        2048 * u64::from(d.brain_work.microsteps) + extra.neuron_updates
    );
    assert!(d.motor.applied_body_energy_debit > 0.);
    assert_eq!(frozen(&warm), frozen_before);
    let wire = warm.checkpoint().unwrap().encode().unwrap();
    let mut cold = CpuChannelNativeM2HostV1::restore(
        CpuChannelNativeM2HostCheckpointV1::decode(&wire).unwrap(),
        &inputs,
        MediationModeV1::Full,
    )
    .unwrap();
    assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), wire);
    let a = warm.step(0.73).unwrap();
    let b = cold.step(0.73).unwrap();
    assert_eq!(a.decisions.len(), b.decisions.len());
    for (x, y) in a.decisions.iter().zip(&b.decisions) {
        assert_eq!(
            serde_json::to_vec(&x.action).unwrap(),
            serde_json::to_vec(&y.action).unwrap()
        );
        assert_eq!(
            serde_json::to_vec(&x.patch).unwrap(),
            serde_json::to_vec(&y.patch).unwrap()
        );
        assert_eq!(
            serde_json::to_vec(&x.motor).unwrap(),
            serde_json::to_vec(&y.motor).unwrap()
        );
    }
    assert_eq!(
        warm.checkpoint().unwrap().encode().unwrap(),
        cold.checkpoint().unwrap().encode().unwrap()
    );
    assert_eq!(frozen(&warm), frozen_before);
    assert_eq!(frozen(&cold), frozen_before);
}
#[test]
fn channel_native_host_rejects_opposite_policy_and_bad_temperature_transactionally() {
    let (mut new, _) = fresh();
    let (old, _) = build::<LegacyGroupedPolicy>();
    let new_wire = new.checkpoint().unwrap().encode().unwrap();
    let old_wire = old.checkpoint().unwrap().encode().unwrap();
    assert!(CpuGroupedM2HostCheckpointV1::decode(&new_wire).is_err());
    assert!(CpuChannelNativeM2HostCheckpointV1::decode(&old_wire).is_err());
    assert!(new.inner.checkpoint().is_err());
    assert!(new
        .inner
        .host
        .grouped_step(&new.inner.founder, 0.73)
        .is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(), new_wire);
    // One staged physical transaction must roll back, including its actual
    // source forward and biological effects. The original host remains untouched.
    assert!(new.inner.host.grouped_policy_step::<FailAfterPhysical>(&new.inner.founder,0.73).is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(),new_wire);
    assert!(new.step(f32::NAN).is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(), new_wire);
    assert!(new.actor_optimization().is_err());
    assert!(new.waking_synaptic_plasticity().is_err());
    assert!(new.synaptic_sleep_consolidation().is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(), new_wire);
    let old_json: serde_json::Value =
        serde_json::from_slice(&old_wire[super::super::MAGIC.len()..]).unwrap();
    assert!(old_json["controllers"]
        .as_object()
        .unwrap()
        .values()
        .all(|r| r.get("channel_native").is_none() && r.get("optional_vocal").is_none()));
}

// Fixed post-physical fault: generic staged host must discard source, body,
// counter, memory and private-bank changes together. No old validator is changed.
struct FailAfterPhysical;
impl GroupedPolicyStrategy for FailAfterPhysical {
    type Action=ChannelNativeActionV1;
    const OPTIONAL:bool=false;
    const CHANNEL_NATIVE:bool=true;
    const MAGIC:&'static [u8]=CHANNEL_MAGIC;
    const LINEAGE:&'static str=CHANNEL_LINEAGE;
    const POLICY:&'static str=CHANNEL_NATIVE_POLICY_V1;
    fn select(f:&CpuFoundationTrainer,r:&mut Resident,frame:&PerceptionFrame,o:&CpuDecisionOutput,s:u32,c:u32,t:f64)->Result<Selection<Self::Action>,CpuHostError> {
        ChannelNativePolicy::select(f,r,frame,o,s,c,t)
    }
    fn stage(r:&mut Resident,p:&BrainPhenotype,a:&Self::Action,b:CpuDecisionBinding)->Result<(),CpuHostError> {ChannelNativePolicy::stage(r,p,a,b)}
    fn close(_n:&mut CpuOrganismState,_f:&CpuFoundationTrainer,_p:&ExperiencePatch,_r:&NeuralReceptorFrame)->Result<(),CpuHostError> {
        Err(CpuHostError::State("fixed channel-native fault after physical transaction"))
    }
}
