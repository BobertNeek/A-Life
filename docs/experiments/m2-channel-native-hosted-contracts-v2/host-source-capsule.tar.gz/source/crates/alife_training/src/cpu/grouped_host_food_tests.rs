//! Two fixed, matched harmless-Food fixtures. Link as a child of
//! grouped_host_tests.rs so its existing fixture(240) is the only constructor.
//! No source/body edits, forced actions, hazard legality confound, seed search,
//! coefficient tuning, checkpoint import, or concentration patch is used.
//!
//! Sensing limitation: profile5 wraps GroundedObjectSlotsV1, not TerrainVision.
//! Its object slots expose raw chemical[0] before ingestion and even at distance.
//! These are regressions of that existing interface, not contact-only tasting,
//! learned food preference, poisoned-food avoidance, or ecological qualification.
use super::*;

const FOOD_POSITION: Vec3f = Vec3f {
    x: 0.6,
    y: 0.,
    z: 0.,
};
const FOOD_NUTRITION: f32 = 0.6;
const TASTE_MAGNITUDE: f32 = 0.8;
const INTERVAL_LIMIT: usize = 24;
const TEMPERATURE: f32 = 0.73;

fn add_harmless_food(host: &mut CpuGroupedM2HostV1, taste: f32) -> WorldEntityId {
    let id = host
        .host
        .world
        .editor_spawn_object(WorldEditorSpawnSpec {
            label: "matched-harmless-food".into(),
            kind: WorldObjectKind::Food,
            organism_id: None,
            position: FOOD_POSITION,
            nutrition: FOOD_NUTRITION,
            hazard_pain: 0.,
            radius: 0.25,
            token_id: None,
        })
        .unwrap();
    let mut properties = host.world().entity(id).unwrap().grounded_physical;
    // Existing public physical-property provider validates signed chemistry.
    // Only the taste coordinate differs; smell, nutrition, and hazard stay fixed.
    properties.chemical[0] = taste;
    host.host
        .world
        .set_grounded_physical_properties(id, properties)
        .unwrap();
    id
}
fn draft(host: &CpuGroupedM2HostV1) -> PerceptionFrameDraft {
    let mut world = host.host.world.clone();
    let record = world.organism_registry().iter().next().unwrap();
    let id = record.organism_id();
    let homeostasis = record.biochemistry().homeostasis;
    let admission = SleepChoiceWorldAdmissionV1::for_organism(&world, id).unwrap();
    let tick = world.tick();
    world
        .perception_sleep_choice_draft_with_bindings(&admission, tick, homeostasis)
        .unwrap()
        .0
}
fn matched_food_pair() -> (CpuGroupedM2HostV1, CpuGroupedM2HostV1, WorldEntityId) {
    let (mut positive, _) = super::fixture(240);
    let (mut negative, _) = super::fixture(240);
    assert!(
        positive.checkpoint().unwrap().encode().unwrap()
            == negative.checkpoint().unwrap().encode().unwrap(),
        "matched initial state differs"
    );
    let food = add_harmless_food(&mut positive, TASTE_MAGNITUDE);
    assert_eq!(add_harmless_food(&mut negative, -TASTE_MAGNITUDE), food);
    let p = positive.world().entity(food).unwrap();
    let mut n = negative.world().entity(food).unwrap().clone();
    assert_eq!(p.kind, WorldObjectKind::Food);
    assert_eq!(p.hazard_pain, 0.);
    assert_eq!(n.hazard_pain, 0.);
    assert_eq!(p.nutrition, n.nutrition);
    assert_eq!(p.position, n.position);
    assert!(!p.consumed && p.carried_by.is_none());
    n.grounded_physical.chemical[0] = p.grounded_physical.chemical[0];
    assert_eq!(p, &n, "only raw taste coordinate may differ");
    let p = draft(&positive);
    let n = draft(&negative);
    assert_eq!(p.homeostasis(), n.homeostasis());
    assert_eq!(p.body(), n.body());
    // Compare the entire offered action/target list, not only a food affordance.
    // Chemical features may differ; world-owned identity and legality must not.
    let identities = |d: &PerceptionFrameDraft| {
        d.candidates()
            .iter()
            .map(|c| (c.action_id, c.kind, c.family, c.target))
            .collect::<Vec<_>>()
    };
    assert_eq!(identities(&p), identities(&n));
    assert!(
        p.candidates()
            .iter()
            .any(|c| c.action_id == HeadlessActionIds::EAT && c.target.entity == Some(food)),
        "fixture must offer real reachable ingestion, not a hazard or unreachable target"
    );
    assert!(p
        .grounded_object_slots()
        .iter()
        .any(|s| s.chemical[0] == TASTE_MAGNITUDE));
    assert!(n
        .grounded_object_slots()
        .iter()
        .any(|s| s.chemical[0] == -TASTE_MAGNITUDE));
    for (draft, taste) in [(p, TASTE_MAGNITUDE), (n, -TASTE_MAGNITUDE)] {
        let frame = draft.finalize(PerceptionContextBlock::empty()).unwrap();
        let derived = prepare_sleep_choice_grounded_drive_features_v1(&frame).unwrap();
        for (index, candidate) in frame.candidates().iter().enumerate() {
            if candidate.target.entity == Some(food) {
                assert_eq!(
                    candidate.features.0[15], taste,
                    "primary observed taste lane15"
                );
                assert_eq!(derived[index][1], taste.max(0.), "positive taste lane37");
                assert_eq!(derived[index][2], (-taste).max(0.), "negative taste lane38");
            }
        }
    }
    (positive, negative, food)
}
#[derive(Debug, Default)]
struct FoodTrace {
    decisions: usize,
    offered_ingestion: usize,
    selected_ingestion: usize,
    physical_ingestions: usize,
    consumed: bool,
}
/// Read-only witnesses on an already executed actual frame. No neural rerun,
/// replacement sample, counter advance, or physical dispatch is performed here.
fn log_food_policy_witness(
    phenotype: &BrainPhenotype,
    decision: &CpuGroupedM2HostDecisionV1,
    label: &str,
    ordinal: usize,
) {
    let frame = decision.patch.pre_action().perception();
    let action = &decision.action;
    let scores = &decision.motor.native.scores;
    let probabilities = scores.probabilities(action.temperature).unwrap();
    let (representative, motors) = scores.physical_selection(action).unwrap();
    let action_id = |index: u16| frame.candidates()[index as usize].action_id.raw();
    let choice_id = |choice: RecoveryGroupChoiceV2| match choice {
        RecoveryGroupChoiceV2::Candidate(index) => Some(action_id(index)),
        RecoveryGroupChoiceV2::NoOp | RecoveryGroupChoiceV2::RestGroup => None,
    };
    let derived = prepare_sleep_choice_grounded_drive_features_v1(frame).unwrap();
    let rows = frame
        .candidates()
        .iter()
        .enumerate()
        .filter(|(_, candidate)| {
            matches!(
                candidate.family,
                CandidateActionFamily::Ingest | CandidateActionFamily::Avoid
            ) || candidate.action_id == HeadlessActionIds::NO_MANIPULATION
        })
        .map(|(index, candidate)| {
            serde_json::json!({
                "index": index,
                "action_id": candidate.action_id.raw(),
                "family": candidate.family,
                "observed_primary_taste_lane15": candidate.features.0[15],
                "derived_positive_taste_lane37": derived[index][1],
                "derived_negative_taste_lane38": derived[index][2],
                "source_logit": decision.source_diagnostic_logits[index],
                "native_components_S_I_M_C_D": decision.motor.native.core.components[index],
                "native_ordinary_score": scores.ordinary[index],
            })
        })
        .collect::<Vec<_>>();
    // This matches the native policy's representative-to-channel mapping.
    // A representative Interact/Write forces Manip and contributes no second
    // categorical draw or log probability for that forced motor slot.
    let forced_manip = match action.representative {
        RecoveryGroupChoiceV2::Candidate(index) => matches!(
            frame.candidates()[index as usize].kind,
            ActionKind::Interact | ActionKind::Write
        ),
        RecoveryGroupChoiceV2::NoOp | RecoveryGroupChoiceV2::RestGroup => false,
    };
    let manip = probabilities.channels[2].as_ref();
    let unforced_distribution = manip.map(|factor| {
        factor
            .outcomes
            .iter()
            .enumerate()
            .map(|(index, choice)| {
                serde_json::json!({
                    "choice": choice,
                    "action_id": choice_id(*choice),
                    "p": factor.probabilities[index],
                    "logp": factor.log_probabilities[index],
                })
            })
            .collect::<Vec<_>>()
    });
    let (actual_manip_p, actual_manip_logp) = if let (false, Some(factor)) = (forced_manip, manip) {
        let index = factor
            .outcomes
            .iter()
            .position(|choice| *choice == action.motors[2])
            .unwrap();
        (factor.probabilities[index], factor.log_probabilities[index])
    } else {
        (1., 0.)
    };
    let representative_index = probabilities
        .representative
        .outcomes
        .iter()
        .position(|choice| *choice == action.representative)
        .unwrap();
    let oldsource = crate::cpu::input::sample_cpu_sleep_choice_joint_action(
        phenotype,
        frame,
        &decision.source_diagnostic_logits,
        action.seed,
        action.counter,
        TEMPERATURE,
    )
    .unwrap();
    eprintln!(
        "GROUPED_FOOD_POLICY_WITNESS {}",
        serde_json::json!({
            "arm": label,
            "actual_decision_ordinal": ordinal,
            "tick": frame.tick().raw(),
            "frame_digest": frame.frame_digest(),
            "seed": action.seed,
            "counter": action.counter,
            "temperature": action.temperature,
            "rows": rows,
            "native": {
                "representative_choice": action.representative,
                "physical_representative_action_id": action_id(representative),
                "representative_p": probabilities.representative.probabilities[representative_index],
                "representative_logp": probabilities.representative.log_probabilities[representative_index],
                "selected_manip_action_id": motors[2].map(action_id),
                "representative_forces_manip": forced_manip,
                "manip_channel_enabled": manip.is_some(),
                "actual_conditional_manip_p": actual_manip_p,
                "actual_conditional_manip_logp": actual_manip_logp,
                "unforced_manip_distribution_diagnostic_only": unforced_distribution,
                "joint_logp": action.old_joint_log_probability,
                "draw_factors": action.draw_factors,
                "accounting": "forced Manip has p=1/logp=0; unforced distribution not added again to joint logp"
            },
            "oldsource_same_frame_witness": {
                "representative_action_id": action_id(oldsource.representative),
                "selected_manip_action_id": oldsource.motor_candidates[2].map(action_id),
                "all_motor_action_ids": oldsource.motor_candidates.map(|index|index.map(action_id)),
                "joint_logp": oldsource.old_joint_log_probability,
                "scope": "same actual frame/logits/seed/counter; different policy RNG domain; no source rerun or world effect; NOT an alternate world trajectory"
            },
            "objective_status": "Corrected primary chemical[0] control. Prior chemical[2] trace did not test taste discrimination and cannot establish a brain regression. No pre-attribution of this outcome."
        })
    );
}
fn run_food(mut host: CpuGroupedM2HostV1, food: WorldEntityId, label: &str) -> FoodTrace {
    let before = frozen(&host);
    let mut trace = FoodTrace::default();
    for interval in 0..INTERVAL_LIMIT {
        let step = host.step(TEMPERATURE).unwrap();
        for d in step.decisions {
            trace.decisions += 1;
            let frame = d.patch.pre_action().perception();
            trace.offered_ingestion +=
                usize::from(frame.candidates().iter().any(|c| {
                    c.action_id == HeadlessActionIds::EAT && c.target.entity == Some(food)
                }));
            let bundle = d
                .patch
                .selected_bundle()
                .expect("native canonical physical bundle");
            trace.selected_ingestion += usize::from(bundle.channels.iter().any(|c| {
                c.primitive == HeadlessActionIds::EAT
                    && c.target.is_some_and(|t| t.entity == Some(food))
            }));
            let outcome = d.patch.outcome();
            let ingested = outcome.joint.as_ref().is_some_and(|j| {
                j.channel_outcomes.iter().any(|c| {
                    c.physical.contact == PhysicalContactKind::Consumed
                        && c.physical.target_entity == Some(food)
                })
            }) || (outcome.physical.contact == PhysicalContactKind::Consumed
                && outcome.physical.target_entity == Some(food));
            if ingested {
                trace.physical_ingestions += 1;
                assert!(host.world().entity(food).unwrap().consumed);
                assert!(outcome.measured_physiology.is_some());
                eprintln!("GROUPED_FOOD_INGESTION arm={label} interval={interval} tick={} receipt={} bundle={} sampled_action={}",
                    step.tick_before.raw(),String::from_utf8(bytes(outcome)).unwrap(),
                    String::from_utf8(bytes(bundle)).unwrap(),String::from_utf8(bytes(&d.action)).unwrap());
            }
            if trace.decisions <= 2 {
                log_food_policy_witness(host.founder.phenotype(), &d, label, trace.decisions);
            }
        }
        assert!(
            frozen(&host) == before,
            "food changes may not open synaptic learning"
        );
        trace.consumed = host.world().entity(food).unwrap().consumed;
        if trace.consumed {
            break;
        }
    }
    assert!(trace.decisions > 0 && trace.offered_ingestion > 0);
    assert_eq!(
        trace.consumed,
        trace.physical_ingestions > 0,
        "a consumed food without an actual ingestion receipt is not acceptable evidence"
    );
    assert!(
        trace.physical_ingestions <= 1,
        "one food cannot be ingested twice"
    );
    eprintln!("GROUPED_FOOD_BOUND arm={label} bound={INTERVAL_LIMIT} trace={trace:?}; raw object-slot taste-at-distance; no learned-preference or toxicity claim");
    trace
}
#[test]
fn grouped_host_reachable_positive_food_requires_real_native_ingestion() {
    let (positive, _, food) = matched_food_pair();
    let trace = run_food(positive, food, "positive-taste");
    // This is an explicit qualification gate, not assumed success. If the fixed
    // source fails it, retain/report failure; do not tune, sweep, or force Eat.
    assert_eq!(trace.physical_ingestions,1,
        "UNQUALIFIED: fixed positive-food fixture produced no actual ingestion in its 24-interval bound");
}
#[test]
fn grouped_host_reachable_negative_food_reports_actual_native_outcome() {
    let (_, negative, food) = matched_food_pair();
    let trace = run_food(negative, food, "negative-taste");
    // Avoidance is not fabricated as a green assertion. This arm reports whether
    // the same harmless food was actually consumed, never a hazardous rejection.
    eprintln!("GROUPED_FOOD_NEGATIVE consumed={} physical_ingestions={}; compare with positive arm, do not interpret a bounded non-ingestion alone as learned avoidance",trace.consumed,trace.physical_ingestions);
}
