//! Disposable fresh source/body fixtures. No archived life and no seed sweep.
use super::*;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
#[allow(dead_code)]
#[path = "grouped_host_fixture.rs"]
mod recipe;
// Fixed distinct mnemonic "GRPHOST", declared before the first test run.
const SEED: u64 = 0x0347_5250_484F_5354;
fn fixture(preparation: u64) -> (CpuGroupedM2HostV1, PhenotypeCompilerInputs) {
    let recipe = recipe::build(SEED, true).unwrap();
    let mut trainer = CpuFoundationTrainer::new(
        recipe.phenotype.clone(),
        recipe.asset.clone(),
        StageTrainableMask::recurrent_only(&recipe.phenotype).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    // Explicit disposable optimizer sentinel, never imported life or training.
    let mut state = trainer.checkpoint();
    state.optimizer_step = 23;
    state.update_ages[0] = 23;
    state.first_moment[0] = 0.03125;
    state.second_moment[0] = 0.0625;
    trainer = CpuFoundationTrainer::from_checkpoint(recipe.phenotype, recipe.asset, state).unwrap();
    let mut game =
        create_grounded_drive_research_new_game(&recipe.config, &recipe.genotype).unwrap();
    let newborn = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    let mut world = HeadlessScenarioBuilder::new(SEED)
        .agent("learner", newborn.organism_id(), Vec3f::ZERO)
        .build()
        .unwrap();
    world
        .register_grounded_drive_research_record(newborn)
        .unwrap();
    game.world = world;
    let inputs = recipe.inputs;
    let (host, ()) = CpuGroupedM2HostV1::new_prepared(
        game,
        trainer,
        inputs.clone(),
        (SEED ^ (SEED >> 32)) as u32,
        MediationModeV1::Full,
        |world| -> Result<(), String> {
            for _ in 0..preparation {
                world.try_advance_tick().map_err(|e| e.to_string())?;
            }
            assert!(!world.age_death_disabled());
            assert!(world
                .organism_registry()
                .iter()
                .next()
                .unwrap()
                .lifecycle()
                .is_alive());
            Ok(())
        },
    )
    .unwrap();
    (host, inputs)
}
fn bytes<T: serde::Serialize>(v: &T) -> Vec<u8> {
    serde_json::to_vec(v).unwrap()
}
fn decode_exact(checkpoint: &CpuGroupedM2HostCheckpointV1) -> CpuGroupedM2HostCheckpointV1 {
    let wire = checkpoint.encode().unwrap();
    let raw: GroupedPayloadV1 = serde_json::from_value(
        serde_json::from_slice::<serde_json::Value>(&wire[MAGIC.len()..]).unwrap(),
    )
    .unwrap();
    let raw_bits = grouped_sampler_bits(&raw.controllers);
    if raw_bits != checkpoint.payload.sampler_bits {
        eprintln!(
            "GROUPED_EXACT_SAMPLER repaired_decimal_rounding raw={raw_bits:?} exact={:?}",
            checkpoint.payload.sampler_bits
        );
    }
    let decoded = CpuGroupedM2HostCheckpointV1::decode(&wire).unwrap();
    assert!(
        bytes(&decoded.payload) == bytes(&checkpoint.payload),
        "exact envelope decode changed source/controller state"
    );
    decoded
}
fn frozen(host: &CpuGroupedM2HostV1) -> Vec<u8> {
    let r = host.host.residents.values().next().unwrap();
    let n = r.neural.checkpoint().unwrap();
    bytes(&(
        host.founder.checkpoint(),
        n.fast,
        n.lifetime,
        n.eligibility,
        n.weight_generation,
        n.neural.dendrites,
        r.v11.checkpoint(),
    ))
}
#[test]
fn grouped_host_fresh_native_sample_and_exact_full_cold_continuation() {
    let (mut warm, inputs) = fixture(240);
    let before = frozen(&warm);
    let first = warm.step(0.73).unwrap();
    assert_eq!(first.decisions.len(), 1);
    let d = &first.decisions[0];
    assert_eq!(d.action.temperature.to_bits(), (0.73_f32 as f64).to_bits());
    assert_eq!(d.action.counter, d.sampling_counter);
    assert_eq!(d.motor.native.core.source_execution_count, 1);
    let physical = d.patch.decision().neural_evidence().unwrap();
    assert_eq!(
        physical.logit.to_bits(),
        d.source_diagnostic_logits[physical.candidate_index as usize].to_bits()
    );
    let arousal = d
        .biological_emissions
        .emissions
        .iter()
        .find(|e| e.class == NeuralEmissionClass::RegionalArousal)
        .unwrap();
    assert_eq!(
        arousal.activity.to_bits(),
        physical.logit.abs().tanh().to_bits()
    );
    assert_eq!(d.biological_emissions.source_tick, first.tick_before);
    assert_eq!(
        d.biological_emissions.graph_epoch,
        physical.dispatch_generation
    );

    let evaluated = d.motor.native.scores.evaluate(&d.action).unwrap();
    assert_eq!(
        evaluated.joint_log_probability.to_bits(),
        d.action.old_joint_log_probability.to_bits()
    );
    assert!(d.motor.reservation_q24 > 30_536);
    assert!(d.motor.applied_body_energy_debit > 0.);
    let charged = d.patch.decision().cognitive_work.as_ref().unwrap();
    let extra = GroupedMotorStateV1::append_work(warm.founder.phenotype()).unwrap();
    assert_eq!(charged.neural_updates, d.brain_work.neuron_updates);
    assert_eq!(charged.synapses_evaluated, d.brain_work.synapse_ops);
    assert_eq!(charged.learning_ops, 0);
    assert_eq!(
        charged.neural_updates,
        2048 * u64::from(d.brain_work.microsteps) + extra.neuron_updates
    );
    let source = cpu_activity_budget(
        warm.founder.phenotype(),
        CpuActivityAnchor {
            organism_id: d.organism_id,
            tick: first.tick_before,
            sequence_cursor: 1,
            previous_dispatch_generation: 0,
            source_frame_digest: [0; 4],
            frame_digest: d.patch.pre_action().perception().frame_digest().0,
        },
        d.patch
            .pre_action()
            .perception()
            .homeostasis()
            .drives
            .brain_atp,
        d.patch.pre_action().perception().candidates().len() as u32,
        d.brain_work.memory_context_ops as u32,
    )
    .unwrap();
    assert_eq!(
        charged.synapses_evaluated,
        source.work.synapse_ops + extra.synapse_products
    );

    assert!(d.motor.available_atp_q16 >= d.motor.reservation_q16);
    assert!(frozen(&warm) == before, "frozen source state changed");
    let checkpoint = warm.checkpoint().unwrap();
    let wire = checkpoint.encode().unwrap();
    let mut cold = CpuGroupedM2HostV1::restore(
        CpuGroupedM2HostCheckpointV1::decode(&wire).unwrap(),
        &inputs,
        MediationModeV1::Full,
    )
    .unwrap();
    assert!(
        cold.checkpoint().unwrap().encode().unwrap() == wire,
        "initial cold bytes differ"
    );
    for _ in 0..3 {
        let a = warm.step(0.73).unwrap();
        let b = cold.step(0.73).unwrap();
        assert_eq!(
            (
                a.tick_before,
                a.tick_after,
                a.sleeping_organisms,
                a.sleep_consolidations
            ),
            (
                b.tick_before,
                b.tick_after,
                b.sleeping_organisms,
                b.sleep_consolidations
            )
        );
        assert_eq!(a.decisions.len(), b.decisions.len());
        for (a, b) in a.decisions.iter().zip(&b.decisions) {
            assert_eq!(bytes(&a.action), bytes(&b.action));
            assert_eq!(bytes(&a.patch), bytes(&b.patch));
            assert_eq!(bytes(&a.motor), bytes(&b.motor));
            assert_eq!(bytes(&a.physical), bytes(&b.physical));
            assert_eq!(a.source_diagnostic_logits, b.source_diagnostic_logits);
        }
        assert!(
            warm.checkpoint().unwrap().encode().unwrap()
                == cold.checkpoint().unwrap().encode().unwrap(),
            "next canonical bytes differ"
        );
        assert!(frozen(&warm) == before, "frozen source state changed");
    }
}
#[test]
fn grouped_host_envelope_rejects_cross_mode_recipe_missing_and_extra_state() {
    let (mut host, inputs) = fixture(240);
    host.step(0.73).unwrap();
    let c = host.checkpoint().unwrap();
    let wire = c.encode().unwrap();
    assert!(CpuGroupedM2HostCheckpointV1::decode(&wire[MAGIC.len()..]).is_err());
    assert!(CpuSleepChoiceHostCheckpointV1::decode(&wire).is_err());
    assert!(CpuGroupedM2HostV1::restore(c.clone(), &inputs, MediationModeV1::DriveSham).is_err());
    assert!(host
        .host
        .grounded_drive_research_checkpoint(&host.founder)
        .is_err());
    assert!(host.host.step(&host.founder, 1.).is_err());
    for field in [
        "recipe_digest",
        "policy",
        "source_lineage",
        "selector_tag",
        "runtime_profile_raw",
    ] {
        let mut value = serde_json::to_value(&c.payload).unwrap();
        value[field] = serde_json::Value::Null;
        let mut wire = MAGIC.to_vec();
        wire.extend(bytes(&value));
        assert!(
            CpuGroupedM2HostCheckpointV1::decode(&wire).is_err(),
            "{field}"
        );
    }
    host.step(0.73).unwrap();
    let mut mixed = host.checkpoint().unwrap();
    mixed.payload.controllers = c.payload.controllers.clone();
    mixed.payload.sampler_bits = c.payload.sampler_bits.clone();
    let error = CpuGroupedM2HostV1::restore(mixed, &inputs, MediationModeV1::Full)
        .err()
        .expect("mixed source/append boundaries must reject");
    assert!(
        error
            .to_string()
            .contains("grouped/source generation mismatch"),
        "{error}"
    );
    for field in ["clock", "frame"] {
        let mut wrong = c.clone();
        let resident = &mut wrong.payload.canonical.residents[0];
        if field == "clock" {
            resident.neural.last_decision_tick = Some(239);
        } else {
            resident.activity.source_frame_digest = [7; 4];
        }
        let error = CpuGroupedM2HostV1::restore(wrong, &inputs, MediationModeV1::Full)
            .err()
            .expect("source boundary differs");
        assert!(
            error
                .to_string()
                .contains("grouped/source frame or clock mismatch"),
            "{error}"
        );
    }
    let mut bit_corrupt = c.clone();
    *bit_corrupt
        .payload
        .sampler_bits
        .values_mut()
        .next()
        .unwrap()
        .group
        .as_mut()
        .unwrap() ^= 1;
    assert!(CpuGroupedM2HostV1::restore(bit_corrupt, &inputs, MediationModeV1::Full).is_err());
    // Numeric mirrors and IEEE identity are both mandatory, not alternate
    // sources of truth. Neither may be silently overwritten after tampering.
    for mutate_bits in [false, true] {
        let mut value: serde_json::Value = serde_json::from_slice(&wire[MAGIC.len()..]).unwrap();
        let owner = c.payload.controllers.keys().next().unwrap().to_string();
        if mutate_bits {
            value["sampler_bits"][&owner]["action"][0] = (1.5_f64.to_bits()).into();
        } else {
            value["controllers"][&owner]["last_action"]["temperature"] = 1.5.into();
        }
        let mut corrupt = MAGIC.to_vec();
        corrupt.extend(bytes(&value));
        assert!(CpuGroupedM2HostCheckpointV1::decode(&corrupt).is_err());
    }
    for invalid in [f64::NAN.to_bits(), f64::INFINITY.to_bits()] {
        let mut value: serde_json::Value = serde_json::from_slice(&wire[MAGIC.len()..]).unwrap();
        let owner = c.payload.controllers.keys().next().unwrap().to_string();
        value["sampler_bits"][&owner]["action"][0] = invalid.into();
        let mut corrupt = MAGIC.to_vec();
        corrupt.extend(bytes(&value));
        assert!(CpuGroupedM2HostCheckpointV1::decode(&corrupt).is_err());
    }
    let mut missing = c.clone();
    missing.payload.controllers.clear();
    assert!(CpuGroupedM2HostV1::restore(missing, &inputs, MediationModeV1::Full).is_err());
    let mut extra = c.clone();
    let controller = extra.payload.controllers.values().next().unwrap().clone();
    extra.payload.controllers.insert(u64::MAX, controller);
    assert!(CpuGroupedM2HostV1::restore(extra, &inputs, MediationModeV1::Full).is_err());
    let mut wrong = c.clone();
    wrong
        .payload
        .controllers
        .values_mut()
        .next()
        .unwrap()
        .last_action
        .as_mut()
        .unwrap()
        .counter += 1;
    assert!(CpuGroupedM2HostV1::restore(wrong, &inputs, MediationModeV1::Full).is_err());
    let mut unknown = serde_json::to_value(&c.payload).unwrap();
    unknown["unknown"] = true.into();
    let mut wire = MAGIC.to_vec();
    wire.extend(bytes(&unknown));
    assert!(CpuGroupedM2HostCheckpointV1::decode(&wire).is_err());
}
#[test]
fn grouped_host_failed_late_sampler_rolls_back_all_private_and_world_state() {
    let (mut host, _) = fixture(240);
    let before = host.checkpoint().unwrap().encode().unwrap();
    // Failure occurs after actual source/appendage execution, before dispatch.
    assert!(host.step(f32::NAN).is_err());
    assert!(
        host.checkpoint().unwrap().encode().unwrap() == before,
        "rollback bytes differ"
    );
    let (cost, debit, affordable) = GroupedMotorStateV1::work(
        host.founder.phenotype(),
        &BrainWorkCounters::default(),
        0,
        0,
    )
    .unwrap();
    assert!(cost > 0 && debit > 0 && !affordable);
}
#[test]
fn grouped_host_high_pressure_bounded_real_sleep_trace_preserves_synapses() {
    let (mut host, inputs) = fixture(1200);
    let record = host.world().organism_registry().iter().next().unwrap();
    let pressure = record.biochemistry().homeostasis.hormones.sleep_pressure;
    eprintln!("GROUPED_HOST_HIGH_PRESSURE ticks=1200 pressure={pressure}; timer genes, ordinary world preparation, no concentration or age override");
    let mut before = frozen(&host);
    let mut injected = false;
    let mut body_sleep = false;
    let mut resumed = false;
    let mut native = 0;
    let mut consolidated = 0;
    let mut saw_waking = false;
    for _ in 0..24 {
        let step = host.step(0.73).unwrap();
        if saw_waking && !step.decisions.is_empty() {
            resumed = true;
        }
        body_sleep |= step
            .decisions
            .iter()
            .any(|d| d.physical.successful_stationary_body_sleep);
        if body_sleep && !injected {
            inject_frozen_sentinels(&mut host);
            before = frozen(&host);
            injected = true;
        }
        native += step.decisions.len();
        consolidated += step.sleep_consolidations;
        if step.sleep_consolidations > 0 {
            let resident = host.host.residents.values().next().unwrap();
            validate_grouped_sleep_boundary(resident).unwrap();
            let config = sleep_consolidation_config_for(host.founder.phenotype()).unwrap();
            for variant in 0..3 {
                let mut wrong = resident.clone();
                let mut state = wrong.sleep.state();
                if let ConsolidationState::Committed {
                    cycle_id,
                    output_generation,
                    output_digest,
                } = state.consolidation
                {
                    state.consolidation = match variant {
                        0 => ConsolidationState::Committed {
                            cycle_id,
                            output_generation: output_generation + 1,
                            output_digest,
                        },
                        1 => ConsolidationState::Committed {
                            cycle_id,
                            output_generation,
                            output_digest: [1; 4],
                        },
                        _ => ConsolidationState::Pending {
                            intent: ConsolidationIntent { cycle_id },
                            replay_digest: [1; 4],
                            replay_event_count: 0,
                            replay_eligibility_sample_count: 0,
                        },
                    };
                    wrong.sleep = SleepController::restore(config, state).unwrap();
                    assert!(validate_grouped_sleep_boundary(&wrong).is_err());
                } else {
                    panic!("closed memory transaction was not committed");
                }
            }
        }

        saw_waking |= host
            .host
            .residents
            .values()
            .any(|r| r.sleep.state().phase == SleepPhase::Waking);
        for d in &step.decisions {
            eprintln!(
                "GROUPED_HOST_PHYSICAL tick={} operation={:?} phase={:?} debit={}",
                step.tick_before.raw(),
                d.physical.operation,
                d.sleep_phase,
                d.motor.applied_body_energy_debit
            );
        }
        assert!(frozen(&host) == before, "frozen source state changed");
        let checkpoint = host.checkpoint().unwrap();
        let wire = checkpoint.encode().unwrap();
        host =
            CpuGroupedM2HostV1::restore(decode_exact(&checkpoint), &inputs, MediationModeV1::Full)
                .unwrap();
        assert!(
            host.checkpoint().unwrap().encode().unwrap() == wire,
            "cold bytes differ"
        );
        if consolidated > 0 && saw_waking && resumed {
            break;
        }
    }
    assert!(native > 0);
    assert!(
        body_sleep && injected,
        "fixed highP fixture never physically slept"
    );
    assert_eq!(
        consolidated, 1,
        "exactly one closed-memory consolidation expected"
    );
    assert!(
        saw_waking && resumed,
        "fixed highP fixture did not wake and resume"
    );
    eprintln!("GROUPED_HOST_BOUNDED native={native} consolidations={consolidated} waking={saw_waking}; no action forced and no sleep success inferred if absent");
}

#[test]
fn grouped_host_pending_export_is_rejected() {
    let (mut host, _) = fixture(240);
    // Deliberately bypass the public clone transaction only in this disposable
    // fixture, leaving the actual source decision pending at sampler failure.
    assert!(host
        .host
        .grouped_step_inner(&host.founder, f32::NAN, &mut |draft, _| Ok(draft))
        .is_err());
    assert!(host
        .host
        .residents
        .values()
        .next()
        .unwrap()
        .neural
        .checkpoint()
        .is_err());
    assert!(host.checkpoint().is_err());
}
fn inject_frozen_sentinels(host: &mut CpuGroupedM2HostV1) {
    let p = host.founder.phenotype();
    let (index, synapse) = p
        .synapses()
        .iter()
        .enumerate()
        .find(|(_, s)| s.kind() == CompiledSynapseKind::Recurrent && s.alpha() != 0.)
        .unwrap();
    let r = host.host.residents.values_mut().next().unwrap();
    let mut n = r.neural.checkpoint().unwrap();
    n.fast[index] = 0.03125;
    n.lifetime[index] = 0.0625;
    n.eligibility[index] = 0.125;
    let mut branches = n.neural.dendrites.branches().to_vec();
    let old = branches[0].clone();
    branches[0] = DendriticBranch::new(old.target, 0.03125, 0.875, old.inputs).unwrap();
    n.neural.dendrites = DendriticBranchSet::new(branches).unwrap();
    let mut v = r.v11.checkpoint();
    v.dendritic_branches = n.neural.dendrites.clone();
    v.sparse_spans = vec![alife_gpu_backend::GpuV11SparseSpan {
        target: synapse.target(),
        edges: vec![alife_gpu_backend::GpuV11SparseEdge {
            source: synapse.source(),
            target: synapse.target(),
            route: u32::from(synapse.route_index()),
            weight: 0.875,
        }],
    }];
    r.v11 = GpuV11CausalState::restore(v).unwrap();
    r.neural = CpuOrganismState::from_checkpoint(p, n).unwrap();
    // Explicit synthetic test sentinel and self-consistent reseal, not learning.
    host.host.seal_all_residents().unwrap();
}
#[test]
fn grouped_host_nonzero_private_sentinels_survive_real_step_and_restore() {
    let (mut host, inputs) = fixture(240);
    host.step(0.73).unwrap();
    inject_frozen_sentinels(&mut host);
    let before = frozen(&host);
    let wire = host.checkpoint().unwrap().encode().unwrap();
    let mut cold = CpuGroupedM2HostV1::restore(
        CpuGroupedM2HostCheckpointV1::decode(&wire).unwrap(),
        &inputs,
        MediationModeV1::Full,
    )
    .unwrap();
    let a = host.step(0.73).unwrap();
    let b = cold.step(0.73).unwrap();
    assert_eq!(a.decisions.len(), 1);
    assert_eq!(b.decisions.len(), 1);
    assert!(frozen(&host) == before, "frozen source state changed");
    assert_eq!(frozen(&cold), before);
    assert_eq!(
        host.checkpoint().unwrap().encode().unwrap(),
        cold.checkpoint().unwrap().encode().unwrap()
    );
}
#[test]
fn grouped_host_terminal_cold_restore_keeps_private_state_without_actions() {
    let (mut host, inputs) = fixture(240);
    host.step(0.73).unwrap();
    let mut record = host
        .world()
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    record.mark_dead(host.world().tick()).unwrap();
    host.host
        .world
        .replace_organism_record_exact(record)
        .unwrap();
    host.host.seal_all_residents().unwrap();
    let wire = host.checkpoint().unwrap().encode().unwrap();
    let mut cold = CpuGroupedM2HostV1::restore(
        CpuGroupedM2HostCheckpointV1::decode(&wire).unwrap(),
        &inputs,
        MediationModeV1::Full,
    )
    .unwrap();
    assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), wire);
    assert!(cold.step(0.73).unwrap().decisions.is_empty());
}
#[test]
fn grouped_host_synthetic_atp_budget_safely_advances_emergency_without_dispatch() {
    let (mut host, _) = fixture(240);
    let mut probe = CpuGroupedM2HostV1 {
        host: host.host.clone(),
        founder: CpuFoundationTrainer::from_checkpoint(
            host.founder.phenotype().clone(),
            host.founder.source_foundation.clone(),
            host.founder.checkpoint(),
        )
        .unwrap(),
        source_inputs: host.source_inputs.clone(),
        mode: host.mode,
    };
    // First fix the throttle level at a low but non-emergency ATP context.
    let id = probe
        .world()
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .organism_id();
    let mut registry = probe.world().organism_registry().clone();
    registry
        .with_biology_mut(id, |bio| {
            bio.homeostasis.drives.brain_atp = 0.1;
            Ok(())
        })
        .unwrap();
    probe
        .host
        .world
        .replace_organism_record_exact(registry.get(id).unwrap().clone())
        .unwrap();
    probe.host.seal_all_residents().unwrap();
    let observed = probe.step(0.73).unwrap();
    let total = observed.decisions[0].motor.reservation_q16;
    let record = host.world().organism_registry().iter().next().unwrap();
    let id = record.organism_id();
    let r = host.host.residents.values().next().unwrap();
    let p = host.founder.phenotype();
    let capacity = host_capacity(p).unwrap();
    let lookahead = cpu_activity_budget(
        p,
        CpuActivityAnchor {
            organism_id: id,
            tick: host.world().tick(),
            sequence_cursor: r.next_sequence,
            previous_dispatch_generation: r.neural.checkpoint().unwrap().dispatch_generation,
            source_frame_digest: r.activity.source_frame_digest,
            frame_digest: p.phenotype_hash().0,
        },
        0.1,
        u32::from(capacity.execution().max_candidates()),
        u32::from(capacity.execution().max_memory_context_records()),
    )
    .unwrap();
    eprintln!(
        "GROUPED_BUDGET total={total} lookahead={}",
        lookahead.debit_atp_q16
    );
    assert!(total > lookahead.debit_atp_q16 + 2);
    let available = (total + lookahead.debit_atp_q16) / 2;
    // Deliberately synthetic budget boundary, separate from behavioral fixtures.
    // Canonical registry mutation reseals biology; no behavioral conclusion.
    let mut registry = host.world().organism_registry().clone();
    registry
        .with_biology_mut(id, |bio| {
            bio.homeostasis.drives.brain_atp = available as f32 / BRAIN_ATP_Q16_MAX as f32;
            Ok(())
        })
        .unwrap();
    host.host
        .world
        .replace_organism_record_exact(registry.get(id).unwrap().clone())
        .unwrap();
    host.host.seal_all_residents().unwrap();
    let before = frozen(&host);
    let tick = host.world().tick();
    let counter = host.host.sampling_counter;
    let result = host.step(0.73).unwrap();
    assert!(result.decisions.is_empty());
    assert_eq!(result.sleeping_organisms, 1);
    assert_eq!(result.tick_after.raw(), tick.raw() + 1);
    assert_eq!(host.host.sampling_counter, counter);
    assert!(frozen(&host) == before);
    assert_eq!(
        host.host
            .residents
            .values()
            .next()
            .unwrap()
            .sleep
            .state()
            .phase,
        SleepPhase::ForcedRecoverySleep
    );
    eprintln!("GROUPED_BUDGET_FALLBACK source_lookahead={} sampled_full={} injected_available={} phase=ForcedRecoverySleep; actual world advance, not an error rollback",lookahead.debit_atp_q16,total,available);
}

#[test]
fn grouped_host_synaptic_entrypoints_reject_without_resetting_state() {
    let (mut host, _) = fixture(240);
    let before = host.checkpoint().unwrap().encode().unwrap();
    assert!(host.actor_optimization().is_err());
    assert!(host.waking_synaptic_plasticity().is_err());
    assert!(host.synaptic_sleep_consolidation().is_err());
    assert!(host.checkpoint().unwrap().encode().unwrap() == before);
}

#[test]
fn grouped_host_low_pressure_executes_awake_rest_without_body_sleep() {
    let (mut host, _) = fixture(240);
    let initial_pressure = host
        .world()
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .biochemistry()
        .homeostasis
        .hormones
        .sleep_pressure;
    let mut awake_rest = false;
    for _ in 0..24 {
        let step = host.step(0.73).unwrap();
        for d in &step.decisions {
            eprintln!(
                "GROUPED_HOST_LOW tick={} pressure={} operation={:?}",
                step.tick_before.raw(),
                initial_pressure,
                d.physical.operation
            );
            if d.physical.operation == Some(RecoveryOperationV1::AwakeRest) {
                assert!(!d.physical.body_sleeping);
                assert_eq!(d.physical.sleep_recovery, 0.);
                assert_eq!(d.sleep_phase, SleepPhase::Awake);
                awake_rest = true;
            }
        }
        if awake_rest {
            break;
        }
    }
    assert!(
        awake_rest,
        "fixed lowP fixture did not physically execute AwakeRest"
    );
}

#[path = "grouped_host_food_tests.rs"]
mod food_tests;
