//! Fresh-only research envelope. There is deliberately no conversion to an
//! ordinary host, mutable world, training batch, GPU save, or breeding API.
use super::*;

/// Composite wrapper, not a class-6 biological organism or inherited genome.
pub struct CpuMotorLobeHostV1 {
    host: CpuCanonicalHost,
    founder: CpuFoundationTrainer,
    source_inputs: PhenotypeCompilerInputs,
    mode: MotorHostModeV1,
}
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CpuMotorLobeHostCheckpointV1 {
    schema_version: u16,
    policy: String,
    mode: MotorHostModeV1,
    source_inputs: PhenotypeCompilerInputs,
    recipe_digest: [u64; 4],
    source_asset: FoundationWeightAsset,
    founder: crate::FoundationTrainerCheckpoint,
    canonical: CpuCanonicalCheckpoint,
    controllers: BTreeMap<u64, MotorHostStateV1>,
}
pub struct CpuMotorLobeHostStepV1 {
    pub tick_before: Tick,
    pub tick_after: Tick,
    pub decisions: Vec<CpuMotorLobeHostDecisionV1>,
    pub sleeping_organisms: usize,
    pub sleep_consolidations: usize,
}
pub struct CpuMotorLobeHostDecisionV1 {
    pub organism_id: OrganismId,
    pub action: crate::PpoJointAction,
    pub patch: ExperiencePatch,
    pub motor: MotorHostFrameReceiptV1,
}
const POLICY: &str =
    "class5-body+sealed-m0-native-composite-v1;construction-cadence;single-metabolic-debit";
impl CpuMotorLobeHostV1 {
    /// Admission happens at a true newborn boundary, before world-only
    /// preparation. The callback cannot access private neural or sampling state.
    pub fn new_prepared<T, E: std::fmt::Display>(
        game: CanonicalNewGame,
        founder: CpuFoundationTrainer,
        source_inputs: PhenotypeCompilerInputs,
        sampling_seed: u32,
        mode: MotorHostModeV1,
        prepare: impl FnOnce(&mut HeadlessWorld) -> Result<T, E>,
    ) -> Result<(Self, T), CpuHostError> {
        let motor = MotorHostStateV1::fresh(&source_inputs, mode)?;
        motor.validate(founder.phenotype())?;
        let (mut host, prepared) = CpuCanonicalHost::new_prepared_grounded_drive_research_cohort(
            game,
            &founder,
            sampling_seed,
            prepare,
        )?;
        for resident in host.residents.values_mut() {
            if resident.neural.checkpoint()?.last_decision_tick.is_some()
                || resident.next_sequence != 1
            {
                return Err(CpuHostError::State(
                    "motor host construction cannot reset a resident",
                ));
            }
            resident.motor = Some(motor.clone());
        }
        host.seal_all_residents()?;
        Ok((
            Self {
                host,
                founder,
                source_inputs,
                mode,
            },
            prepared,
        ))
    }
    pub fn world(&self) -> &HeadlessWorld {
        self.host.world()
    }
    pub fn checkpoint(&self) -> Result<CpuMotorLobeHostCheckpointV1, CpuHostError> {
        Ok(CpuMotorLobeHostCheckpointV1 {
            schema_version: 1,
            policy: POLICY.into(),
            mode: self.mode,
            source_inputs: self.source_inputs.clone(),
            recipe_digest: MotorLobeM0V1::recipe_digest(),
            source_asset: self.founder.source_foundation.clone(),
            founder: self.founder.checkpoint(),
            canonical: self.host.checkpoint_inner(&self.founder)?,
            controllers: self
                .host
                .residents
                .iter()
                .map(|(&id, r)| {
                    Ok((
                        id,
                        r.motor
                            .clone()
                            .ok_or(CpuHostError::State("missing composite controller"))?,
                    ))
                })
                .collect::<Result<_, CpuHostError>>()?,
        })
    }
    /// Expected source and mode are explicit caller inputs. No mode-changing,
    /// partial-state, acquired-production or detached checkpoint import exists.
    pub fn restore(
        checkpoint: CpuMotorLobeHostCheckpointV1,
        expected_source: &PhenotypeCompilerInputs,
        expected_mode: MotorHostModeV1,
    ) -> Result<Self, CpuHostError> {
        let wire = serde_json::to_vec(&checkpoint)?;
        if checkpoint.schema_version != 1
            || checkpoint.policy != POLICY
            || checkpoint.mode != expected_mode
            || &checkpoint.source_inputs != expected_source
            || checkpoint.recipe_digest != MotorLobeM0V1::recipe_digest()
        {
            return Err(CpuHostError::State(
                "motor composite source, mode, policy or recipe mismatch",
            ));
        }
        let p = PhenotypeCompiler::compile_validated(
            expected_source,
            &BrainCapacityClass::n2048_grounded_drive_research(),
        )?;
        let founder =
            CpuFoundationTrainer::from_checkpoint(p, checkpoint.source_asset, checkpoint.founder)?;
        let host = CpuCanonicalHost::from_checkpoint_inner(
            checkpoint.canonical,
            &founder,
            true,
            Some(checkpoint.controllers),
            None,
        )?;
        if host.residents.values().any(|r| {
            !r.motor
                .as_ref()
                .is_some_and(|m| m.matches(expected_source, expected_mode))
        }) {
            return Err(CpuHostError::State(
                "resident composite mode/source differs from envelope",
            ));
        }
        let result = Self {
            host,
            founder,
            source_inputs: checkpoint.source_inputs,
            mode: checkpoint.mode,
        };
        if serde_json::to_vec(&result.checkpoint()?)? != wire {
            return Err(CpuHostError::State(
                "motor composite restore would discard or reinterpret state",
            ));
        }
        Ok(result)
    }
    pub fn step(&mut self, temperature: f32) -> Result<CpuMotorLobeHostStepV1, CpuHostError> {
        let step = self.host.step(&self.founder, temperature)?;
        let decisions = step
            .decisions
            .into_iter()
            .map(|d| {
                let receipt = self
                    .host
                    .residents
                    .get(&d.organism_id.raw())
                    .and_then(|r| r.motor.as_ref())
                    .and_then(|m| m.last_receipt.clone())
                    .ok_or(CpuHostError::State("missing motor composite receipt"))?;
                Ok(CpuMotorLobeHostDecisionV1 {
                    organism_id: d.organism_id,
                    action: d.action,
                    patch: d.patch,
                    motor: receipt,
                })
            })
            .collect::<Result<_, CpuHostError>>()?;
        Ok(CpuMotorLobeHostStepV1 {
            tick_before: step.tick_before,
            tick_after: step.tick_after,
            decisions,
            sleeping_organisms: step.sleeping_organisms,
            sleep_consolidations: step.sleep_consolidations,
        })
    }
}
