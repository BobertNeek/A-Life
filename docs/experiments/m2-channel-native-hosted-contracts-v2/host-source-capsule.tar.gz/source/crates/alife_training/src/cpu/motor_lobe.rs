//! Detached mechanism qualification of the actual compiled class-6 phenotype.
//! Uses the ordinary CPU SparseGraph::forward implementation, not a second
//! neuron simulator. No world, mutation API, checkpoint restore or optimizer.
use super::{invalid, replay::SparseGraph};
use crate::{
    TrainingError, TrainingInitialState, TrainingReplayCandidate, TrainingReplayEvaluation,
    TrainingReplayTick, TrainingSequence,
};
use alife_core::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MotorLobeProbeControl {
    Full,
    SourceCut,
    ControllerRecurrenceCut,
    MotorMediationCut,
    ReadoutCut,
    EqualWorkSham,
    /// Deliberately broken common reference, only a labelled negative control.
    ReferenceMismatch,
}
#[derive(Debug, Clone, Copy)]
pub struct MotorLobeProbeModulation {
    pub interoceptive_gain: f32,
    pub regional_gain: f32,
    pub afferent_offset: f32,
    pub projection_gain: f32,
    pub local_threshold: f32,
}
impl Default for MotorLobeProbeModulation {
    fn default() -> Self {
        Self {
            interoceptive_gain: 1.,
            regional_gain: 1.,
            afferent_offset: 0.,
            projection_gain: 0.5,
            local_threshold: 0.25,
        }
    }
}
impl MotorLobeProbeModulation {
    fn validate(self) -> bool {
        [
            self.interoceptive_gain,
            self.regional_gain,
            self.afferent_offset,
            self.projection_gain,
            self.local_threshold,
        ]
        .iter()
        .all(|v| v.is_finite())
            && [
                self.interoceptive_gain,
                self.regional_gain,
                self.projection_gain,
            ]
            .iter()
            .all(|v| (0. ..=4.).contains(v))
            && self.afferent_offset.abs() <= 4.
            && self.local_threshold.abs() <= 4.
    }
}

pub struct MotorLobeDetachedCpu {
    phenotype: BrainPhenotype,
    graph: SparseGraph,
    weights: Vec<f32>,
    initial: TrainingInitialState,
    control: MotorLobeProbeControl,
}
#[derive(Debug, Clone)]
pub struct MotorLobeProbeResult {
    pub evaluation: TrainingReplayEvaluation,
    pub incremental_work: MotorLobeWorkV1,
    pub incremental_cost_q24: u64,
    pub control: MotorLobeProbeControl,
}
impl MotorLobeDetachedCpu {
    /// Starts a fresh zero state. There is deliberately no from-checkpoint or
    /// mutable-weights constructor. A baseline snapshot cannot be relabelled.
    pub fn fresh(
        phenotype: BrainPhenotype,
        control: MotorLobeProbeControl,
    ) -> Result<Self, TrainingError> {
        phenotype.validate_against(&BrainCapacityClass::n2144_motor_lobe_research())?;
        let recipe = phenotype
            .foundation_abi()
            .motor_lobe_m0()
            .ok_or_else(invalid)?;
        let mut branches = Vec::new();
        let motor = phenotype.candidate_decoder().motor_start();
        // Preserve the source's 64 existing bounded branches byte-for-byte.
        for index in 0..64 {
            branches.push(DendriticBranch::new(
                motor + index,
                0.1,
                0.25,
                vec![
                    DendriticInputRef::new(motor + index, 1.)?,
                    DendriticInputRef::new(motor + index + 1, 1.)?,
                ],
            )?);
        }
        let mut new = recipe.fixed_branches()?.branches().to_vec();
        for branch in &mut new {
            for input in &mut branch.inputs {
                if (control == MotorLobeProbeControl::ControllerRecurrenceCut
                    && (2094..2100).contains(&branch.target)
                    && (2094..2100).contains(&input.source))
                    || (control == MotorLobeProbeControl::MotorMediationCut
                        && branch.target >= 2100)
                {
                    input.weight = 0.;
                }
            }
        }
        branches.extend(new);
        let mut weights = phenotype
            .synapses()
            .iter()
            .map(|s| s.genetic_weight())
            .collect::<Vec<_>>();
        if control == MotorLobeProbeControl::ReadoutCut {
            weights[MotorLobeM0V1::BASE_SYNAPSES..].fill(0.);
        }
        let n = phenotype.neuron_count() as usize;
        let initial = TrainingInitialState {
            activations: vec![0.; n],
            activity_ema: vec![0.; n],
            metabolic_load: vec![0.; n],
            dendrites: DendriticBranchSet::new(branches)?,
        };
        Ok(Self {
            graph: SparseGraph::new(&phenotype),
            phenotype,
            weights,
            initial,
            control,
        })
    }
    pub fn phenotype(&self) -> &BrainPhenotype {
        &self.phenotype
    }
    pub fn state(&self) -> &TrainingInitialState {
        &self.initial
    }
    /// Synthetic mechanism input only: non-homeostatic source lanes are zero.
    /// Every old encoder, route, branch and readout still executes unchanged.
    /// New pair affine transforms precede shared interoceptive/regional gains;
    /// both then receive identical offset and native [-1,1] clamp.
    pub fn step(
        &mut self,
        drives: [f32; 11],
        modulation: MotorLobeProbeModulation,
        candidates: &[TrainingReplayCandidate],
        microsteps: u8,
    ) -> Result<MotorLobeProbeResult, TrainingError> {
        if !modulation.validate()
            || microsteps == 0
            || microsteps > self.phenotype.microstep_count()
            || !drives
                .iter()
                .all(|d| d.is_finite() && (0. ..=1.).contains(d))
            || candidates.is_empty()
            || candidates.len()
                > usize::from(
                    BrainCapacityClass::n2144_motor_lobe_research()
                        .execution()
                        .max_candidates(),
                )
            || candidates.iter().any(|c| {
                !c.innate_bias.is_finite()
                    || !c
                        .decoder_inputs
                        .iter()
                        .all(|v| v.is_finite() && (-1. ..=1.).contains(v))
            })
        {
            return Err(invalid());
        }
        let mut encoded = vec![0.; self.phenotype.neuron_count() as usize];
        for assignment in self.phenotype.sensor_encoder().assignments() {
            let target = assignment.target_neuron() as usize;
            let is_home = assignment.source_group() == SensorEncoderSourceGroup::Homeostasis;
            let mut source = if is_home {
                drives
                    .get(assignment.source_index() as usize)
                    .copied()
                    .unwrap_or(0.)
            } else {
                0.
            };
            let (low, high) = assignment.clamp_range();
            if target >= MOTOR_LOBE_START as usize {
                if matches!(
                    self.control,
                    MotorLobeProbeControl::SourceCut | MotorLobeProbeControl::EqualWorkSham
                ) {
                    source = MotorLobeM0V1::SETPOINTS[(target - MOTOR_LOBE_START as usize) / 2];
                }
                let mut affine = source * assignment.scale() + assignment.bias();
                if self.control == MotorLobeProbeControl::ReferenceMismatch
                    && (target - MOTOR_LOBE_START as usize) % 2 == 1
                {
                    affine *= 1.5;
                }
                encoded[target] += affine.clamp(low, high) * modulation.interoceptive_gain;
            } else {
                if is_home {
                    source *= modulation.interoceptive_gain;
                }
                encoded[target] +=
                    (source * assignment.scale() + assignment.bias()).clamp(low, high);
            }
        }
        for value in &mut encoded {
            *value =
                (*value * modulation.regional_gain + modulation.afferent_offset).clamp(-1., 1.);
        }
        let tick = TrainingReplayTick {
            encoded_inputs: encoded,
            projection_gain: modulation.projection_gain,
            local_threshold_shift: modulation.local_threshold,
            microstep_count: u32::from(microsteps),
            enabled_routes: vec![true; self.phenotype.projections().len()],
            effective_weight_offsets: vec![0.; self.weights.len()],
            structural_synapses: Vec::new(),
            candidates: candidates.to_vec(),
        };
        let q = TrainingSequence {
            phenotype_hash: self.phenotype.phenotype_hash(),
            initial: self.initial.clone(),
            ticks: vec![tick],
            burn_in_ticks: 0,
            memory_candidate_gain: self
                .phenotype
                .candidate_decoder()
                .memory_channel()
                .map_or(0., |p| p.max_candidate_gain()),
        };
        // Ordinary TrainingSequence::validate_for intentionally rejects class6.
        // This closed evaluator constructs all writable context internally.
        let result = self
            .graph
            .forward(&self.phenotype, &self.weights, &q)?
            .evaluation;
        self.initial
            .activations
            .clone_from(&result.final_activations[0]);
        self.initial
            .activity_ema
            .clone_from(&result.final_activity_ema[0]);
        self.initial
            .metabolic_load
            .clone_from(&result.final_metabolic_load[0]);
        let products = candidates
            .iter()
            .map(|c| MotorLobeM0V1::readout_count(c.family) as u64)
            .sum();
        let work = MotorLobeWorkV1::checked(u64::from(microsteps), 1, products)?;
        Ok(MotorLobeProbeResult {
            incremental_cost_q24: work.cost_q24()?,
            incremental_work: work,
            evaluation: result,
            control: self.control,
        })
    }
}

#[cfg(test)]
mod tests;
