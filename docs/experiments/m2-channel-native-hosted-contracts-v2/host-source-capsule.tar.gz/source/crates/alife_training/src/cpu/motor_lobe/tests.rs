use super::*;
use std::sync::OnceLock;
fn phenotype() -> BrainPhenotype {
    static P: OnceLock<BrainPhenotype> = OnceLock::new();
    P.get_or_init(|| {
        let g = BrainGenome::scaffold(
            0x2048_2026,
            BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID,
        );
        let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
        let (_, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
            g,
            d,
            SensorProfile::GroundedObjectSlotsV1,
        )
        .unwrap();
        PhenotypeCompiler::compile_motor_lobe_m0(&i).unwrap().0
    })
    .clone()
}
fn evaluator(control: MotorLobeProbeControl) -> MotorLobeDetachedCpu {
    MotorLobeDetachedCpu::fresh(phenotype(), control).unwrap()
}
fn candidate(family: u8, lane: usize) -> TrainingReplayCandidate {
    let mut inputs = [0.; 54];
    inputs[lane] = 1.;
    TrainingReplayCandidate {
        family: CandidateActionFamily::try_from_raw(family).unwrap(),
        decoder_inputs: inputs,
        innate_bias: 0.,
    }
}
fn candidates() -> Vec<TrainingReplayCandidate> {
    // Native capacity is 32; one row per family executes all 50 fixed weights.
    (0..8).map(|f| candidate(f, 23)).collect()
}
fn delta(e: &MotorLobeDetachedCpu, family: u8, lane: usize) -> f32 {
    e.phenotype.synapses()[34048..]
        .iter()
        .filter_map(|s| {
            let CompiledSynapseKind::Decoder(c) = s.kind() else {
                return None;
            };
            (c.family().raw() == family && usize::from(c.input_lane()) == lane)
                .then(|| e.initial.activations[s.source() as usize] * s.genetic_weight())
        })
        .sum()
}
fn run(control: MotorLobeProbeControl, drives: [f32; 11], steps: usize) -> MotorLobeDetachedCpu {
    let mut e = evaluator(control);
    for _ in 0..steps / 4 {
        e.step(
            drives,
            MotorLobeProbeModulation::default(),
            &candidates(),
            4,
        )
        .unwrap();
    }
    e
}
#[test]
fn compiled_native_onset_third_for_hunger_fourth_for_recovery() {
    let mut drives = MotorLobeM0V1::SETPOINTS;
    drives[0] = 0.9;
    drives[1] = 0.9;
    let mut full = evaluator(MotorLobeProbeControl::Full);
    let mut sham = evaluator(MotorLobeProbeControl::EqualWorkSham);
    let cs = [candidate(6, 37), candidate(1, 23)];
    for step in 1..=4 {
        let a = full
            .step(drives, MotorLobeProbeModulation::default(), &cs, 1)
            .unwrap();
        let b = sham
            .step(drives, MotorLobeProbeModulation::default(), &cs, 1)
            .unwrap();
        assert_eq!(
            &full.state().activations[..2048],
            &sham.state().activations[..2048]
        );
        assert_eq!(a.incremental_work, b.incremental_work);
        assert_eq!(a.incremental_work.microsteps, 1);
        if step < 3 {
            assert_eq!(delta(&full, 6, 37), 0.);
        } else {
            assert!(delta(&full, 6, 37) > 0.);
        }
        if step < 4 {
            assert_eq!(delta(&full, 1, 23), 0.);
        }
        let observed = a.evaluation.candidate_logits[0][0] - b.evaluation.candidate_logits[0][0];
        assert!((observed - delta(&full, 6, 37)).abs() < 2e-5);
    }
    // Hunger competes with recovery, so use isolated fatigue for its onset.
    let mut drives = MotorLobeM0V1::SETPOINTS;
    drives[1] = 0.9;
    let mut e = evaluator(MotorLobeProbeControl::Full);
    for step in 1..=4 {
        e.step(drives, MotorLobeProbeModulation::default(), &cs, 1)
            .unwrap();
        if step < 4 {
            assert_eq!(delta(&e, 1, 23), 0.);
        } else {
            assert!(delta(&e, 1, 23) > 0.);
        }
    }
}
#[test]
fn all_eleven_pairs_and_gain_offset_threshold_envelope() {
    let cases = [
        (0., 1., 0., 0.25),
        (0.1, 0.5, -0.2, 0.9),
        (1., 1., 0., 0.25),
        (2., 0.5, 0.2, -0.75),
        (4., 4., 4., 4.),
        (1., 1., -4., -4.),
    ];
    for (intero, regional, offset, threshold) in cases {
        for drive in 0..11 {
            let mut e = evaluator(MotorLobeProbeControl::Full);
            let mut drives = MotorLobeM0V1::SETPOINTS;
            drives[drive] = (drives[drive] + 0.2).min(1.);
            let m = MotorLobeProbeModulation {
                interoceptive_gain: intero,
                regional_gain: regional,
                afferent_offset: offset,
                local_threshold: threshold,
                ..Default::default()
            };
            for _ in 0..4 {
                e.step(drives, m, &[candidate(0, 23)], 4).unwrap();
                for d in 0..11 {
                    assert!(
                        e.state().activations[2070 + 2 * d] - e.state().activations[2071 + 2 * d]
                            >= -2e-7
                    );
                }
            }
            if intero == 1. && offset == 0. {
                assert!(
                    e.state().activations[2070 + 2 * drive]
                        - e.state().activations[2071 + 2 * drive]
                        > 1e-5
                );
            }
        }
    }
}
#[test]
fn all_drive_signs_truthful_nulls_and_no_locomotion() {
    let base = MotorLobeM0V1::SETPOINTS;
    let mut d = base;
    d[0] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 6, 37) > 0.);
    assert!(delta(&e, 6, 38) < 0.);
    assert_eq!(delta(&e, 6, 36), 0.);
    let mut d = base;
    d[1] = 0.9;
    d[6] = 0.1;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 1, 23) > 0.);
    assert!(delta(&e, 3, 36) < 0.);
    assert_eq!(delta(&e, 6, 37), 0.);
    let mut d = base;
    d[6] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert_eq!(delta(&e, 1, 23), 0.);
    let mut d = base;
    d[2] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 4, 36) > 0.);
    assert!(delta(&e, 1, 23) < 0.);
    let mut d = base;
    d[3] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 1, 23) > 0.);
    let mut d = base;
    d[4] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 3, 41) > 0.);
    assert!(delta(&e, 7, 42) > 0.);
    assert_eq!(delta(&e, 5, 41), 0.);
    for drive in [5, 9] {
        let mut d = base;
        d[drive] = 0.9;
        let e = run(MotorLobeProbeControl::Full, d, 64);
        assert!(delta(&e, 2, 36) > 0.);
    }
    let mut d = base;
    d[7] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 4, 39) > 0.);
    assert!(delta(&e, 4, 40) > 0.);
    assert!(delta(&e, 1, 43) < 0.);
    let mut d = base;
    d[8] = 0.9;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    assert!(delta(&e, 3, 41) > 0.);
    assert_eq!(delta(&e, 5, 41), 0.);
    let mut d = base;
    d[10] = 1.;
    let e = run(MotorLobeProbeControl::Full, d, 64);
    for f in 0..8 {
        for l in [23, 36, 37, 38, 39, 40, 41, 42, 43] {
            assert_eq!(delta(&e, f, l), 0.);
        }
    }
    let mut no_move = candidate(3, 36);
    no_move.decoder_inputs.fill(0.);
    d[1] = 0.9;
    let mut no_move_sham = evaluator(MotorLobeProbeControl::EqualWorkSham);
    // Candidate features are all zero, so the fixed head contributes exactly
    // zero even when the recovery controller is active.
    let mut no_move_full = evaluator(MotorLobeProbeControl::Full);
    for _ in 0..16 {
        let full = no_move_full
            .step(d, Default::default(), &[no_move.clone()], 4)
            .unwrap();
        let sham = no_move_sham
            .step(d, Default::default(), &[no_move.clone()], 4)
            .unwrap();
        assert_eq!(
            full.evaluation.candidate_logits,
            sham.evaluation.candidate_logits
        );
    }
}
#[test]
fn fixed_pair_null_background_tracks_real_metabolism_and_cost() {
    let mut e = run(MotorLobeProbeControl::Full, MotorLobeM0V1::SETPOINTS, 64);
    for f in 0..8 {
        for l in [23, 36, 37, 38, 39, 40, 41, 42, 43] {
            assert_eq!(delta(&e, f, l), 0.);
        }
    }
    assert!(e.state().activations[2048..].iter().any(|x| *x != 0.));
    assert!(e.state().metabolic_load[2048..].iter().any(|x| *x > 0.));
    let all = (0..8).map(|f| candidate(f, 23)).collect::<Vec<_>>();
    let r = e
        .step(MotorLobeM0V1::SETPOINTS, Default::default(), &all, 3)
        .unwrap();
    assert_eq!(
        r.incremental_work,
        MotorLobeWorkV1::checked(3, 1, 50).unwrap()
    );
    assert_eq!(r.incremental_cost_q24, 15072);
}
#[test]
fn native_lesions_sham_washout_and_reference_mismatch() {
    let mut d = MotorLobeM0V1::SETPOINTS;
    d[1] = 0.9;
    let mut full = run(MotorLobeProbeControl::Full, d, 64);
    let mut sham = run(MotorLobeProbeControl::EqualWorkSham, d, 64);
    assert!(delta(&full, 1, 23) > 0.);
    assert_eq!(delta(&sham, 1, 23), 0.);
    assert_eq!(
        &full.state().activations[..2048],
        &sham.state().activations[..2048]
    );
    let cs = candidates();
    let a = full.step(d, Default::default(), &cs, 4).unwrap();
    let b = sham.step(d, Default::default(), &cs, 4).unwrap();
    assert_eq!(a.incremental_work, b.incremental_work);
    for _ in 0..32 {
        full.step(MotorLobeM0V1::SETPOINTS, Default::default(), &cs, 4)
            .unwrap();
    }
    assert!(delta(&full, 1, 23).abs() < 1e-6);
    let motor = run(MotorLobeProbeControl::MotorMediationCut, d, 64);
    assert_eq!(delta(&motor, 1, 23), 0.);
    let mut mixed = d;
    mixed[0] = 0.6;
    mixed[2] = 0.6;
    let reconciled = run(MotorLobeProbeControl::Full, mixed, 64);
    let recurrence_cut = run(MotorLobeProbeControl::ControllerRecurrenceCut, mixed, 64);
    assert!(reconciled.state().activations[2094..2100]
        .iter()
        .zip(&recurrence_cut.state().activations[2094..2100])
        .any(|(a, b)| (a - b).abs() > 1e-5));
    let mut readout = run(MotorLobeProbeControl::ReadoutCut, d, 64);
    let mut source = run(MotorLobeProbeControl::SourceCut, d, 64);
    let r = readout.step(d, Default::default(), &cs, 4).unwrap();
    let s = source.step(d, Default::default(), &cs, 4).unwrap();
    assert_eq!(r.evaluation.candidate_logits, s.evaluation.candidate_logits);
    let mut d = MotorLobeM0V1::SETPOINTS;
    d[6] = 0.6;
    let good = run(MotorLobeProbeControl::Full, d, 64);
    let wrong = run(MotorLobeProbeControl::ReferenceMismatch, d, 64);
    assert_eq!(
        good.state().activations[2092] - good.state().activations[2093],
        0.
    );
    assert!(wrong.state().activations[2092] - wrong.state().activations[2093] > 0.);
}
#[test]
fn ordinary_upload_training_and_replay_reject_class_six() {
    let p = phenotype();
    assert!(crate::StageTrainableMask::from_synapse_indices(&p, &[34048]).is_err());
    assert!(alife_gpu_backend::GpuClassBucketPlan::for_phenotype(&p).is_err());
    assert!(alife_gpu_backend::GpuPhenotypeUpload::try_from(&p).is_err());
    assert!(alife_gpu_backend::GpuV11CausalState::for_phenotype(&p).is_err());
    assert!(alife_gpu_backend::GpuV11Checkpoint::canonical_for_phenotype(&p).is_err());
    let e = evaluator(MotorLobeProbeControl::Full);
    assert!(crate::cpu::CpuOrganismState::new(&p, OrganismId(1), e.initial.clone()).is_err());
    let q = TrainingSequence {
        phenotype_hash: p.phenotype_hash(),
        initial: e.initial.clone(),
        ticks: vec![],
        burn_in_ticks: 0,
        memory_candidate_gain: 0.,
    };
    assert!(q.validate_for(&p).is_err());
}
#[test]
fn invalid_input_is_atomic_and_three_step_frame_does_not_hide_settling() {
    let mut e = evaluator(MotorLobeProbeControl::Full);
    let before = e.state().clone();
    let mut d = MotorLobeM0V1::SETPOINTS;
    d[0] = f32::NAN;
    assert!(e
        .step(d, Default::default(), &[candidate(1, 23)], 3)
        .is_err());
    assert_eq!(before, *e.state());
    let mut d = MotorLobeM0V1::SETPOINTS;
    d[1] = 0.9;
    let a = e
        .step(d, Default::default(), &[candidate(1, 23)], 3)
        .unwrap();
    assert_eq!(a.incremental_work.microsteps, 3);
    assert_eq!(delta(&e, 1, 23), 0.);
    let b = e
        .step(d, Default::default(), &[candidate(1, 23)], 3)
        .unwrap();
    assert_eq!(b.incremental_work.microsteps, 3);
    assert!(delta(&e, 1, 23) > 0.);
}

#[test]
fn configured_two_three_four_step_cadences_keep_real_onset() {
    for (maturation, steps) in [(0., 2), (0.5, 3), (1., 4)] {
        let g = BrainGenome::scaffold(
            0x2048_2026,
            BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID,
        );
        let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(maturation).unwrap());
        let (_, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
            g,
            d,
            SensorProfile::GroundedObjectSlotsV1,
        )
        .unwrap();
        let p = PhenotypeCompiler::compile_motor_lobe_m0(&i).unwrap().0;
        assert_eq!(p.microstep_count(), steps);
        let mut e = MotorLobeDetachedCpu::fresh(p, MotorLobeProbeControl::Full).unwrap();
        let mut drives = MotorLobeM0V1::SETPOINTS;
        drives[1] = 0.9;
        let first = e
            .step(drives, Default::default(), &[candidate(1, 23)], steps)
            .unwrap();
        assert_eq!(first.incremental_work.microsteps, u64::from(steps));
        if steps < 4 {
            assert_eq!(delta(&e, 1, 23), 0.);
        } else {
            assert!(delta(&e, 1, 23) > 0.);
        }
        e.step(drives, Default::default(), &[candidate(1, 23)], steps)
            .unwrap();
        assert!(delta(&e, 1, 23) > 0.);
    }
}
#[test]
fn separate_fixed_head_matches_native_logits_in_bounded_batches() {
    let mut drives = MotorLobeM0V1::SETPOINTS;
    for (i, d) in drives.iter_mut().enumerate() {
        *d = if i == 6 { 0.1 } else { 0.9 };
    }
    let mut full = run(MotorLobeProbeControl::Full, drives, 64);
    let mut cut = run(MotorLobeProbeControl::ReadoutCut, drives, 64);
    let all = (0..8)
        .flat_map(|f| [23, 36, 37, 38, 39, 40, 41, 42, 43].map(|l| candidate(f, l)))
        .collect::<Vec<_>>();
    let before = full.state().clone();
    assert!(full.step(drives, Default::default(), &all, 4).is_err());
    assert_eq!(before, *full.state());
    for batch in all.chunks(32) {
        let a = full.step(drives, Default::default(), batch, 4).unwrap();
        let b = cut.step(drives, Default::default(), batch, 4).unwrap();
        assert_eq!(a.incremental_work, b.incremental_work);
        assert_eq!(full.state(), cut.state());
        for (i, c) in batch.iter().enumerate() {
            let lane = c.decoder_inputs.iter().position(|x| *x == 1.).unwrap();
            let expected = delta(&full, c.family.raw(), lane);
            assert!(
                (a.evaluation.candidate_logits[0][i]
                    - b.evaluation.candidate_logits[0][i]
                    - expected)
                    .abs()
                    < 2e-5
            );
        }
    }
}
