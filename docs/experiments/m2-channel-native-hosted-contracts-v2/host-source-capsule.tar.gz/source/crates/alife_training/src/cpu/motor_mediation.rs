//! Fresh detached M2 arithmetic. No production phenotype, optimizer, sampling,
//! breeding, export, acquired-state import or fallback. The pinned graph uses
//! the identical native soma/dendrite functions as SparseGraph. Its signed
//! edges are private modulatory rows, never illegal MotorProposal edges.
use super::{
    finite, invalid,
    native_kernel::{self, CellState},
    replay::SparseGraph,
};
use crate::{
    TrainingError, TrainingInitialState, TrainingReplayCandidate, TrainingReplayEvaluation,
    TrainingReplayTick, TrainingSequence,
};
use alife_core::*;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
const MANIFEST: &str =
    include_str!("../../../../docs/experiments/motor-mediation-m2-design-v1/recipe.json");
pub const M2_RECIPE_SHA256: &str =
    "285841b7e9a6d26c60142b6e2dd25f04a0bef0bec943c6203834155e89af0278";
const START: usize = 2048;
const ADDED: usize = 444;
const SLOTS: usize = 32;
const PORT_BASE: usize = 60;
const DIVISORS: [f32; 5] = [4., 2., 1., 1., 0.25];
const BOUND_WEIGHTS: [f32; 5] = [0.5, 0.5, 0.5, 0.25, 1.5];
const REFERENCES: [f32; 11] = [
    0.35, 0.35, 0.25, 0.10, 0.35, 0.35, 0.75, 0.10, 0.50, 0.35, 0.,
];
const SCHEMA: &str = "detached-m2-native-v1-not-a-foundation";
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MediationModeV1 {
    Full,
    DriveSham,
    DirectSource,
}
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MediationModulationV1 {
    pub interoceptive_gain: f32,
    pub regional_gain: f32,
    pub offset: f32,
    pub projection_gain: f32,
    pub threshold: f32,
}
impl Default for MediationModulationV1 {
    fn default() -> Self {
        Self {
            interoceptive_gain: 1.,
            regional_gain: 1.,
            offset: 0.,
            projection_gain: 0.5,
            threshold: 0.25,
        }
    }
}
impl MediationModulationV1 {
    fn validate(&self) -> Result<(), TrainingError> {
        if ![
            self.interoceptive_gain,
            self.regional_gain,
            self.projection_gain,
        ]
        .iter()
        .all(|x| x.is_finite() && (0. ..=4.).contains(x))
            || ![self.offset, self.threshold]
                .iter()
                .all(|x| x.is_finite() && x.abs() <= 4.)
        {
            return Err(invalid());
        }
        Ok(())
    }
}
#[derive(Deserialize)]
struct Manifest {
    nodes: Vec<Node>,
    branches: Vec<Branch>,
    recurrent_edges: Vec<Edge>,
    drive_proposal_readouts: Vec<DriveRow>,
    final_readouts: Vec<FinalRow>,
}
#[derive(Deserialize)]
struct Node {
    id: usize,
    phase: u8,
    #[serde(flatten)]
    dynamics: NeuronDynamics,
}
#[derive(Deserialize)]
struct Branch {
    target: u32,
    threshold: f32,
    gain: f32,
    inputs: Vec<(u32, f32)>,
}
#[derive(Deserialize)]
struct Edge {
    source: usize,
    target: usize,
    weight: f32,
}
#[derive(Deserialize)]
struct DriveRow {
    family: CandidateActionFamily,
    source: usize,
    cue: String,
    weight: f32,
}
#[derive(Deserialize)]
struct FinalRow {
    source: usize,
    candidate_slot: usize,
    weight: f32,
}
struct Lowered {
    manifest: Manifest,
    branches: DendriticBranchSet,
}
impl Lowered {
    fn pinned(bytes: &str) -> Result<Self, TrainingError> {
        if format!("{:x}", Sha256::digest(bytes.as_bytes())) != M2_RECIPE_SHA256 {
            return Err(invalid());
        }
        let manifest: Manifest = serde_json::from_str(bytes).map_err(|_| invalid())?;
        if manifest.nodes.len() != ADDED
            || manifest.branches.len() != 36
            || manifest.recurrent_edges.len() != 640
            || manifest.drive_proposal_readouts.len() != 60
            || manifest.final_readouts.len() != 64
        {
            return Err(invalid());
        }
        let branches = DendriticBranchSet::new(
            manifest
                .branches
                .iter()
                .map(|b| {
                    DendriticBranch::new(
                        b.target - START as u32,
                        b.threshold,
                        b.gain,
                        b.inputs
                            .iter()
                            .map(|&(s, w)| DendriticInputRef::new(s - START as u32, w))
                            .collect::<Result<Vec<_>, _>>()?,
                    )
                })
                .collect::<Result<Vec<_>, ScaffoldContractError>>()?,
        )?;
        branches.validate_for_neuron_count(ADDED as u32)?;
        Ok(Self { manifest, branches })
    }
}
/// Slot/order are ephemeral. Targets, feature bits, operation and source inputs
/// are retained and checked against the complete frame on every decision.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MediationRowV1 {
    source_generation: u64,
    source_hash: PhenotypeHash,
    recipe: String,
    frame_digest: PerceptionFrameDigest,
    candidate_index: usize,
    action_id: ActionId,
    target: ActionTarget,
    features: CandidateFeatureVector,
    feature_digest: CandidateFeatureDigest,
    operation: Option<RecoveryOperationV1>,
    prefix: TrainingReplayCandidate,
}
impl MediationRowV1 {
    fn bind(
        frame: &PerceptionFrame,
        index: usize,
        prefix: &TrainingReplayCandidate,
        generation: u64,
        source_hash: PhenotypeHash,
    ) -> Result<Self, TrainingError> {
        if frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
            || frame.candidates().len() > SLOTS
        {
            return Err(invalid());
        }
        let c = frame.candidates().get(index).ok_or_else(invalid)?;
        let derived = prepare_sleep_choice_grounded_drive_features_v1(frame)?;
        if prefix.decoder_inputs[36..46]
            .iter()
            .zip(derived[index])
            .any(|(a, b)| a.to_bits() != b.to_bits())
        {
            return Err(invalid());
        }
        if prefix.family != c.family
            || prefix.decoder_inputs[..24]
                .iter()
                .zip(c.features.0)
                .any(|(a, b)| a.to_bits() != b.to_bits())
            || !prefix.innate_bias.is_finite()
            || prefix
                .decoder_inputs
                .iter()
                .any(|x| !x.is_finite() || !(-1. ..=1.).contains(x))
        {
            return Err(invalid());
        }
        Ok(Self {
            source_generation: generation,
            source_hash,
            recipe: M2_RECIPE_SHA256.into(),
            frame_digest: frame.frame_digest(),
            candidate_index: index,
            action_id: c.action_id,
            target: c.target,
            features: c.features,
            feature_digest: c.feature_digest()?,
            operation: RecoveryOperationV1::for_candidate(c)?,
            prefix: prefix.clone(),
        })
    }
    fn validate(
        &self,
        frame: &PerceptionFrame,
        index: usize,
        prefix: &TrainingReplayCandidate,
        generation: u64,
        source_hash: PhenotypeHash,
    ) -> Result<(), TrainingError> {
        let expected = Self::bind(frame, index, prefix, generation, source_hash)?;
        if serde_json::to_vec(self).map_err(|_| invalid())?
            != serde_json::to_vec(&expected).map_err(|_| invalid())?
        {
            return Err(invalid());
        }
        Ok(())
    }
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MediationDetachedSnapshotV1 {
    schema: String,
    recipe: String,
    source_hash: PhenotypeHash,
    source_asset: Vec<u8>,
    mode: MediationModeV1,
    generation: u64,
    source: TrainingInitialState,
    activations: Vec<f32>,
    ema: Vec<f32>,
    metabolic: Vec<f32>,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MediationWorkV1 {
    pub phases: u64,
    pub neuron_updates: u64,
    pub assignments: u64,
    pub branches: u64,
    pub branch_inputs: u64,
    pub recurrent_products: u64,
    pub drive_products: u64,
    pub final_products: u64,
}
impl MediationWorkV1 {
    fn expected() -> Self {
        Self {
            phases: 4,
            neuron_updates: 444,
            assignments: 444,
            branches: 36,
            branch_inputs: 72,
            recurrent_products: 640,
            drive_products: 1920,
            final_products: 64,
        }
    }
    pub fn cost_q24(&self) -> Result<u64, TrainingError> {
        [
            (self.neuron_updates, 32_u64),
            (self.assignments, 4),
            (self.branches, 16),
            (self.branch_inputs, 4),
            (self.recurrent_products, 4),
            (self.drive_products, 4),
            (self.final_products, 4),
        ]
        .into_iter()
        .try_fold(0_u64, |sum, (n, price)| {
            sum.checked_add(n.checked_mul(price)?)
        })
        .ok_or_else(invalid)
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MediationReceiptV1 {
    pub schema: String,
    pub recipe: String,
    pub source_hash: PhenotypeHash,
    pub source_generation: u64,
    pub final_generation: u64,
    pub rows: Vec<MediationRowV1>,
    pub mode: MediationModeV1,
    /// Canonical direct result, comparator only: never an M2 bypass.
    pub direct_source_logits: Vec<f32>,
    /// Exactly S,I,clamped M,clamped C,native D. No aggregate input exists.
    pub components: Vec<[f32; 5]>,
    pub port_activations: Vec<[[f32; 2]; 5]>,
    pub port_clip_slopes: Vec<[[f32; 2]; 5]>,
    pub jacobians: Vec<[f32; 5]>,
    pub upstream_context_slopes: Vec<[f32; 2]>,
    pub core_logits: Vec<f32>,
    pub output_logits: Vec<f32>,
    pub appended_activations: Vec<f32>,
    pub signed_opponents: Vec<f32>,
    pub positive_opponents: Vec<f32>,
    pub work: MediationWorkV1,
    pub detached_arithmetic_reservation_q24: u64,
    pub source_execution_count: u32,
    pub modulation: MediationModulationV1,
    pub raw_drives: [f32; 12],
    pub references: [f32; 12],
}
pub struct MediationProbeResultV1 {
    pub source_evaluation: TrainingReplayEvaluation,
    pub receipt: MediationReceiptV1,
    /// Per-candidate CORE derivative, including DirectSource comparator mode.
    /// Diagnostic only: not sampled-policy eligibility, BPTT, or an update.
    pub projected_core_decoder_derivatives: Vec<Vec<f32>>,
}
pub struct MediationDetachedCpuV1 {
    source: BrainPhenotype,
    weights: Vec<f32>,
    graph: SparseGraph,
    recipe: Lowered,
    pressure_reference: f32,
    state: MediationDetachedSnapshotV1,
}
impl MediationDetachedCpuV1 {
    /// Only genetic source inputs. No ordinary checkpoint or acquired M0/M1 state
    /// constructor. No production numeric identity is allocated by this fixture.
    pub fn fresh(
        inputs: &PhenotypeCompilerInputs,
        asset: &FoundationWeightAsset,
        mode: MediationModeV1,
    ) -> Result<Self, TrainingError> {
        let source = PhenotypeCompiler::compile_validated(
            inputs,
            &BrainCapacityClass::n2048_grounded_drive_research(),
        )?;
        asset.validate_against(&source)?;
        if asset
            .weights()
            .iter()
            .zip(source.synapses())
            .any(|(w, row)| w.to_bits() != row.genetic_weight().to_bits())
        {
            return Err(invalid());
        }
        if source.neuron_count() != START as u32
            || source.synapses().len() != 34048
            || source.foundation_abi().motor_lobe_m0().is_some()
        {
            return Err(invalid());
        }
        let motor = source.candidate_decoder().motor_start();
        let (branch_gain, branch_threshold) = source.foundation_abi().fresh_dendritic_parameters();
        let dendrites = DendriticBranchSet::new(
            (0..64)
                .map(|i| {
                    DendriticBranch::new(
                        motor + i,
                        branch_threshold,
                        branch_gain,
                        vec![
                            DendriticInputRef::new(motor + i, 1.)?,
                            DendriticInputRef::new(motor + i + 1, 1.)?,
                        ],
                    )
                })
                .collect::<Result<Vec<_>, ScaffoldContractError>>()?,
        )?;
        let state = MediationDetachedSnapshotV1 {
            schema: SCHEMA.into(),
            recipe: M2_RECIPE_SHA256.into(),
            source_hash: source.phenotype_hash(),
            source_asset: serde_json::to_vec(&asset.digest()).map_err(|_| invalid())?,
            mode,
            generation: 0,
            source: TrainingInitialState {
                activations: vec![0.; START],
                activity_ema: vec![0.; START],
                metabolic_load: vec![0.; START],
                dendrites,
            },
            activations: vec![0.; ADDED],
            ema: vec![0.; ADDED],
            metabolic: vec![0.; ADDED],
        };
        Ok(Self {
            graph: SparseGraph::new(&source),
            weights: asset.weights().to_vec(),
            source,
            recipe: Lowered::pinned(MANIFEST)?,
            pressure_reference: inputs
                .genome()
                .cognitive_architecture()
                .sleep_trigger_threshold(),
            state,
        })
    }
    pub fn bind_rows(
        &self,
        frame: &PerceptionFrame,
        tick: &TrainingReplayTick,
    ) -> Result<Vec<MediationRowV1>, TrainingError> {
        if tick.candidates.len() != frame.candidates().len() || tick.candidates.len() > SLOTS {
            return Err(invalid());
        }
        tick.candidates
            .iter()
            .enumerate()
            .map(|(i, c)| {
                MediationRowV1::bind(
                    frame,
                    i,
                    c,
                    self.state.generation,
                    self.source.phenotype_hash(),
                )
            })
            .collect()
    }
    pub fn source(&self) -> &BrainPhenotype {
        &self.source
    }
    pub fn snapshot(&self) -> MediationDetachedSnapshotV1 {
        self.state.clone()
    }
    pub fn source_state(&self) -> &TrainingInitialState {
        &self.state.source
    }
    /// Only the new detached envelope, never the ordinary checkpoint codec.
    pub fn restore(
        inputs: &PhenotypeCompilerInputs,
        asset: &FoundationWeightAsset,
        mode: MediationModeV1,
        snapshot: MediationDetachedSnapshotV1,
    ) -> Result<Self, TrainingError> {
        let mut fresh = Self::fresh(inputs, asset, mode)?;
        if snapshot.schema != SCHEMA
            || snapshot.recipe != M2_RECIPE_SHA256
            || snapshot.source_hash != fresh.state.source_hash
            || snapshot.source_asset != fresh.state.source_asset
            || snapshot.mode != mode
            || snapshot.source.dendrites != fresh.state.source.dendrites
        {
            return Err(invalid());
        }
        for (bank, size, bounded) in [
            (&snapshot.source.activations, START, false),
            (&snapshot.source.activity_ema, START, true),
            (&snapshot.source.metabolic_load, START, true),
            (&snapshot.activations, ADDED, false),
            (&snapshot.ema, ADDED, true),
            (&snapshot.metabolic, ADDED, true),
        ] {
            if bank.len() != size
                || bank
                    .iter()
                    .any(|x| !x.is_finite() || (bounded && !(0. ..=1.).contains(x)))
            {
                return Err(invalid());
            }
        }
        fresh.state = snapshot;
        Ok(fresh)
    }
    pub fn actor_optimization(&mut self) -> Result<(), TrainingError> {
        Err(invalid())
    }
    pub fn waking_outcome_plasticity(&mut self) -> Result<(), TrainingError> {
        Err(invalid())
    }
    /// Frozen-context input executes the REAL source prefix once and four native
    /// partitions. Not a world life. Forward arithmetic reservation excludes
    /// diagnostic Jacobians/credit, staging, validation and bookkeeping and is
    /// NOT a qualified host ATP bill. Nothing writes biological state.
    pub fn step(
        &mut self,
        frame: &PerceptionFrame,
        tick: TrainingReplayTick,
        rows: &[MediationRowV1],
        modulation: MediationModulationV1,
        available_arithmetic_q24: u64,
    ) -> Result<MediationProbeResultV1, TrainingError> {
        modulation.validate()?;
        if tick.microstep_count == 0
            || rows.len() != tick.candidates.len()
            || rows.len() != frame.candidates().len()
            || rows.len() > SLOTS
            || tick.projection_gain.to_bits() != modulation.projection_gain.to_bits()
            || tick.local_threshold_shift.to_bits() != modulation.threshold.to_bits()
            || tick.effective_weight_offsets.iter().any(|x| *x != 0.)
            || !tick.structural_synapses.is_empty()
        {
            return Err(invalid());
        }
        for (i, (row, c)) in rows.iter().zip(&tick.candidates).enumerate() {
            let physical = &frame.candidates()[i];
            let family = self
                .source
                .candidate_decoder()
                .families()
                .iter()
                .find(|f| f.family() == c.family)
                .ok_or_else(invalid)?;
            if c.innate_bias.to_bits()
                != family
                    .innate_contribution(frame.homeostasis().drives, physical.features)
                    .to_bits()
            {
                return Err(invalid());
            }

            row.validate(
                frame,
                i,
                c,
                self.state.generation,
                self.source.phenotype_hash(),
            )?;
        }
        let q = TrainingSequence {
            phenotype_hash: self.source.phenotype_hash(),
            initial: self.state.source.clone(),
            ticks: vec![tick],
            burn_in_ticks: 0,
            memory_candidate_gain: self
                .source
                .candidate_decoder()
                .memory_channel()
                .map_or(0., |p| p.max_candidate_gain()),
        };
        q.validate_for(&self.source)?;
        let t = &q.ticks[0];
        let generation = self.state.generation.checked_add(1).ok_or_else(invalid)?;
        let reservation = self.arithmetic_cost(t)?;
        if available_arithmetic_q24 < reservation {
            return Err(invalid());
        }
        let mut drives = [0.; 12];
        drives[..11].copy_from_slice(&frame.homeostasis().drives.to_array());
        drives[11] = frame.homeostasis().hormones.to_array()[8];
        if drives
            .iter()
            .any(|x| !x.is_finite() || !(0. ..=1.).contains(x))
        {
            return Err(invalid());
        }
        let tape = self
            .graph
            .forward_mediation_source(&self.source, &self.weights, &q)?;
        let mut components: Vec<[f32; 5]> = t
            .candidates
            .iter()
            .enumerate()
            .map(|(i, c)| {
                [
                    tape.mediation_source[0][i],
                    c.innate_bias,
                    tape.memory[0][i].clamp(-q.memory_candidate_gain, q.memory_candidate_gain),
                    tape.cognitive[0][i].clamp(-q.memory_candidate_gain, q.memory_candidate_gain),
                    0.,
                ]
            })
            .collect();
        let upstream = (0..rows.len())
            .map(|i| {
                [
                    clip_slope(tape.memory[0][i], q.memory_candidate_gain),
                    clip_slope(tape.cognitive[0][i], q.memory_candidate_gain),
                ]
            })
            .collect();
        let mut next = self.state.clone();
        let mut receipt = run_partitions(
            &self.recipe,
            &mut next,
            &mut components,
            &t.candidates,
            drives,
            self.pressure_reference,
            modulation,
        )?;
        receipt.schema = SCHEMA.into();
        receipt.recipe = M2_RECIPE_SHA256.into();
        receipt.source_hash = self.source.phenotype_hash();
        receipt.source_generation = self.state.generation;
        receipt.final_generation = generation;
        receipt.rows = rows.to_vec();
        receipt.direct_source_logits = tape.evaluation.candidate_logits[0].clone();
        receipt.upstream_context_slopes = upstream;
        receipt.output_logits = if self.state.mode == MediationModeV1::DirectSource {
            receipt.direct_source_logits.clone()
        } else {
            receipt.core_logits.clone()
        };
        receipt.detached_arithmetic_reservation_q24 = reservation;
        receipt.source_execution_count = 1;
        let eligibility = projected_credit(
            &self.source,
            t,
            &tape.evaluation.final_activations[0],
            &receipt,
        )?;
        next.source
            .activations
            .clone_from(&tape.evaluation.final_activations[0]);
        next.source
            .activity_ema
            .clone_from(&tape.evaluation.final_activity_ema[0]);
        next.source
            .metabolic_load
            .clone_from(&tape.evaluation.final_metabolic_load[0]);
        next.generation = generation;
        self.state = next;
        Ok(MediationProbeResultV1 {
            source_evaluation: tape.evaluation,
            receipt,
            projected_core_decoder_derivatives: eligibility,
        })
    }
    fn arithmetic_cost(&self, t: &TrainingReplayTick) -> Result<u64, TrainingError> {
        let steps = u64::from(t.microstep_count);
        let decoder_products:u64=t.candidates.iter().map(|c|self.source.synapses().iter().filter(|s|matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.head()!=DecoderHeadKind::SpeechPayload&&d.family()==c.family)).count() as u64).sum();
        let recurrent_products: u64 = (0..t.microstep_count as usize)
            .map(|step| {
                self.source
                    .synapses()
                    .iter()
                    .filter(|s| {
                        s.kind() == CompiledSynapseKind::Recurrent
                            && t.enabled_routes[s.route_index() as usize]
                            && super::replay::route_fires(
                                self.source.projections()[s.route_index() as usize]
                                    .update_cadence()
                                    .raw(),
                                step,
                            )
                    })
                    .count() as u64
            })
            .sum();
        let source = steps
            .checked_mul(START as u64 * 32 + 64 * 16 + 128 * 4)
            .and_then(|v| v.checked_add((recurrent_products + decoder_products) * 4))
            .and_then(|v| {
                v.checked_add(self.source.sensor_encoder().assignments().len() as u64 * 4)
            })
            .ok_or_else(invalid)?;
        source
            .checked_add(MediationWorkV1::expected().cost_q24()?)
            .ok_or_else(invalid)
    }
}
fn clip_slope(x: f32, bound: f32) -> f32 {
    f32::from(x > -bound && x < bound)
}
fn cue(row: &DriveRow, c: &TrainingReplayCandidate) -> f32 {
    if row.family != c.family {
        return 0.;
    }
    match row.cue.as_str() {
        "constant" => 1.,
        "object_present" => c.decoder_inputs[36],
        "positive_contact_chemical" => c.decoder_inputs[37],
        "observed_thermal_excess" => c.decoder_inputs[39] + c.decoder_inputs[40],
        "observed_agent_present" => c.decoder_inputs[41],
        "grounded_vocal" => c.decoder_inputs[42],
        _ => unreachable!("pinned recipe cue"),
    }
}
fn run_partitions(
    recipe: &Lowered,
    state: &mut MediationDetachedSnapshotV1,
    components: &mut [[f32; 5]],
    candidates: &[TrainingReplayCandidate],
    drives: [f32; 12],
    pressure_reference: f32,
    m: MediationModulationV1,
) -> Result<MediationReceiptV1, TrainingError> {
    run_partition_banks(
        recipe,
        state.mode,
        state.source_hash,
        &mut state.activations,
        &mut state.ema,
        &mut state.metabolic,
        components,
        candidates,
        drives,
        pressure_reference,
        m,
    )
}
/// Shared arithmetic only. The host borrows separate appendage banks and never
/// instantiates a detached source owner or freshens the organism's source state.
#[allow(clippy::too_many_arguments)]
fn run_partition_banks(
    recipe: &Lowered,
    mode: MediationModeV1,
    source_hash: PhenotypeHash,
    activations: &mut [f32],
    ema: &mut [f32],
    metabolic: &mut [f32],
    components: &mut [[f32; 5]],
    candidates: &[TrainingReplayCandidate],
    drives: [f32; 12],
    pressure_reference: f32,
    m: MediationModulationV1,
) -> Result<MediationReceiptV1, TrainingError> {
    if components.len() != candidates.len() || candidates.len() > SLOTS {
        return Err(invalid());
    }
    for component in components.iter() {
        finite(component)?;
    }
    let mut refs = [0.; 12];
    refs[..11].copy_from_slice(&REFERENCES);
    refs[11] = pressure_reference;
    let mut encoded = vec![m.offset; ADDED];
    let mut work = MediationWorkV1::default();
    let mut pairs = vec![[[0.; 2]; 5]; components.len()];
    let mut clip = vec![[[0.; 2]; 5]; components.len()];
    for phase in 1..=4 {
        work.phases += 1;
        if phase == 1 {
            for axis in 0..12 {
                let raw = if mode == MediationModeV1::DriveSham {
                    refs[axis]
                } else {
                    drives[axis]
                };
                encoded[axis * 5] = raw * m.interoceptive_gain * m.regional_gain + m.offset;
                encoded[axis * 5 + 1] =
                    refs[axis] * m.interoceptive_gain * m.regional_gain + m.offset;
            }
        }
        if phase == 3 {
            for slot in 0..SLOTS {
                let mut d = 0.;
                for r in &recipe.manifest.drive_proposal_readouts {
                    let input = candidates.get(slot).map_or(0., |c| cue(r, c));
                    d += activations[r.source - START] * (input * r.weight);
                    work.drive_products += 1;
                }
                if slot < components.len() {
                    components[slot][4] = d;
                }
            }
            for slot in 0..SLOTS {
                for port in 0..5 {
                    let x = components.get(slot).map_or(0., |c| c[port]);
                    for (side, sign) in [(0, 1.), (1, -1.)] {
                        let affine = sign * x / DIVISORS[port];
                        encoded[PORT_BASE + slot * 12 + port * 2 + side] =
                            affine.clamp(-8., 8.) + m.offset;
                        if slot < components.len() {
                            clip[slot][port][side] = clip_slope(affine, 8.);
                        }
                    }
                }
            }
        }
        let previous = activations.to_vec();
        for node in recipe
            .manifest
            .nodes
            .iter()
            .filter(|node| node.phase == phase)
        {
            let target = node.id - START;
            let mut recurrent = 0.;
            let mut dendritic = 0.;
            for edge in recipe
                .manifest
                .recurrent_edges
                .iter()
                .filter(|e| e.target == node.id)
            {
                recurrent += previous[edge.source - START] * edge.weight;
                work.recurrent_products += 1;
            }
            for b in &recipe.branches.branches()[recipe.branches.target_span(target as u32)] {
                dendritic += native_kernel::dendritic_activation(&previous, b);
                work.branches += 1;
                work.branch_inputs += b.inputs.len() as u64;
            }
            let result = native_kernel::neuron_step(
                &node.dynamics,
                CellState {
                    activation: previous[target],
                    ema: ema[target],
                    metabolic: metabolic[target],
                },
                encoded[target],
                recurrent,
                dendritic,
                m.projection_gain,
                m.threshold,
            );
            activations[target] = result.state.activation;
            ema[target] = result.state.ema;
            metabolic[target] = result.state.metabolic;
            work.neuron_updates += 1;
            work.assignments += 1;
        }
    }
    finite(activations)?;
    finite(ema)?;
    finite(metabolic)?;
    let mut logits = [0.; SLOTS];
    for r in &recipe.manifest.final_readouts {
        logits[r.candidate_slot] += activations[r.source - START] * r.weight;
        work.final_products += 1;
    }
    if work != MediationWorkV1::expected() {
        return Err(invalid());
    }
    let mut jacobians = vec![[0.; 5]; components.len()];
    for slot in 0..components.len() {
        let base = PORT_BASE + slot * 12;
        let a = activations[base + 10];
        let b = activations[base + 11];
        let final_slope = 2. * m.projection_gain * ((1. - a * a).max(0.) + (1. - b * b).max(0.));
        for port in 0..5 {
            let plus = activations[base + port * 2];
            let minus = activations[base + port * 2 + 1];
            pairs[slot][port] = [plus, minus];
            let port_slope = ((1. - plus * plus).max(0.) * clip[slot][port][0]
                + (1. - minus * minus).max(0.) * clip[slot][port][1])
                / (2. * DIVISORS[port]);
            jacobians[slot][port] = final_slope * BOUND_WEIGHTS[port] * port_slope;
        }
    }
    let signed = (0..12)
        .map(|i| activations[i * 5 + 2] - activations[i * 5 + 3])
        .collect();
    let positive = (0..12)
        .map(|i| activations[i * 5 + 2] - activations[i * 5 + 4])
        .collect();
    Ok(MediationReceiptV1 {
        schema: String::new(),
        recipe: String::new(),
        source_hash,
        source_generation: 0,
        final_generation: 0,
        rows: vec![],
        mode,
        direct_source_logits: vec![],
        components: components.to_vec(),
        port_activations: pairs,
        port_clip_slopes: clip,
        jacobians,
        upstream_context_slopes: vec![],
        core_logits: logits[..components.len()].to_vec(),
        output_logits: vec![],
        appended_activations: activations.to_vec(),
        signed_opponents: signed,
        positive_opponents: positive,
        work,
        detached_arithmetic_reservation_q24: 0,
        source_execution_count: 0,
        modulation: m,
        raw_drives: drives,
        references: refs,
    })
}
fn projected_credit(
    p: &BrainPhenotype,
    t: &TrainingReplayTick,
    activation: &[f32],
    receipt: &MediationReceiptV1,
) -> Result<Vec<Vec<f32>>, TrainingError> {
    let mut result = vec![vec![0.; p.synapses().len()]; t.candidates.len()];
    for (i, c) in t.candidates.iter().enumerate() {
        for (j, s) in p.synapses().iter().enumerate() {
            let CompiledSynapseKind::Decoder(d) = s.kind() else {
                continue;
            };
            if d.family() != c.family {
                continue;
            }
            let input = c
                .decoder_inputs
                .get(d.input_lane() as usize)
                .copied()
                .unwrap_or(0.);
            let factor = match d.head() {
                DecoderHeadKind::ActionCandidate => {
                    receipt.jacobians[i][0] * activation[s.source() as usize]
                }
                DecoderHeadKind::MemoryContext => {
                    receipt.jacobians[i][2] * receipt.upstream_context_slopes[i][0]
                }
                DecoderHeadKind::CognitiveContext => {
                    receipt.jacobians[i][3] * receipt.upstream_context_slopes[i][1]
                }
                _ => 0.,
            };
            result[i][j] = input * factor;
        }
        finite(&result[i])?;
    }
    Ok(result)
}
#[cfg(test)]
mod tests;

mod grouped;
pub use grouped::*;

mod confidence;
pub use confidence::*;
