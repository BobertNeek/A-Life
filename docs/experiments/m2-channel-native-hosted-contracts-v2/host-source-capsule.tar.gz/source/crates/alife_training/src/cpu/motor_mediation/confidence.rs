//! Fresh detached 32 physical + one virtual recovery group. Never a host adapter.
use super::*;
mod policy;
pub use policy::*;
const GROUP_SCHEMA: &str = "detached-m2-recovery-group-confidence-native-v2";
pub const RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256: &str =
    "eecb44a40ac6bbb7c3e742f10ec749668245c11f089b48cf257aeb4749dd4dff";
const GROUP_RECIPE: &str =
    include_str!("../../../../../docs/experiments/recovery-group-confidence-v2/recipe.json");
#[derive(Deserialize)]
struct GroupRecipe {
    nodes: Vec<Node>,
    operation_final_readouts: [[f32; 2]; 2],
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryGroupSnapshotV2 {
    schema: String,
    recipe: String,
    // Opaque until outer identity is checked. No old-state reinterpretation.
    core_json: String,
    activations: [f32; 16],
    ema: [f32; 16],
    metabolic: [f32; 16],
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryGroupNativeReceiptV2 {
    pub schema: String,
    pub recipe: String,
    pub core: MediationReceiptV1,
    pub group_components: [f32; 5],
    pub group_jacobian: [f32; 5],
    pub operation_context_jacobians: [[f32; 2]; 2],
    /// d z_operation / d native signed pressure opponent.
    pub operation_pressure_jacobians: [f32; 2],
    pub extension_activations: [f32; 16],
    pub extension_source_products: u64,
    pub extension_arithmetic_q24: u64,
    pub scores: RecoveryGroupScoresV2,
}
pub struct RecoveryGroupProbeResultV2 {
    pub source_evaluation: TrainingReplayEvaluation,
    pub receipt: RecoveryGroupNativeReceiptV2,
    /// Derivatives of ordinary scores; recovery slots are zero here.
    pub ordinary_decoder_derivatives: Vec<Vec<f32>>,
    pub group_decoder_derivatives: Vec<f32>,
    pub operation_decoder_derivatives: [Vec<f32>; 2],
}
impl RecoveryGroupProbeResultV2 {
    /// Derivative through this extension's pressure afferent only, holding the
    /// already executed source tape fixed. It is NOT a full hormone-to-policy
    /// derivative through upstream encoding/recurrent state.
    pub fn frozen_source_pressure_log_probability_derivative(
        &self,
        gradient: &RecoveryGroupGradientV2,
    ) -> Result<f64, TrainingError> {
        if gradient.binding != self.receipt.scores.binding
            || gradient.ordinary.len() != self.receipt.scores.ordinary.len()
            || gradient
                .ordinary
                .iter()
                .chain([&gradient.group])
                .chain(gradient.operations.iter())
                .any(|x| !x.is_finite())
        {
            return Err(invalid());
        }
        if self.receipt.core.mode == MediationModeV1::DriveSham {
            return Ok(0.);
        }
        let m = self.receipt.core.modulation;
        let gain = 4. * m.interoceptive_gain * m.regional_gain;
        let raw = gain * (self.receipt.core.raw_drives[11] - self.receipt.core.references[11]);
        let signed = m.projection_gain * gain * (1. - raw.tanh().powi(2));
        // Exact reference has the frozen zero derivative for rectification.
        let positive = if raw > 0. { signed } else { 0. };
        let result = gradient.group * f64::from(self.receipt.group_jacobian[4] * positive)
            + (0..2)
                .map(|o| {
                    gradient.operations[o]
                        * f64::from(self.receipt.operation_pressure_jacobians[o] * signed)
                })
                .sum::<f64>();
        if !result.is_finite() {
            return Err(invalid());
        }
        Ok(result)
    }
    /// Full sampled log-probability decoder derivative, not a local eligibility
    /// or recurrent BPTT implementation. No weights/state are written.
    pub fn decoder_log_probability_gradient(
        &self,
        gradient: &RecoveryGroupGradientV2,
    ) -> Result<Vec<f64>, TrainingError> {
        let width = self.group_decoder_derivatives.len();
        if gradient.binding != self.receipt.scores.binding
            || width == 0
            || gradient.ordinary.len() != self.ordinary_decoder_derivatives.len()
            || gradient
                .ordinary
                .iter()
                .chain([&gradient.group])
                .chain(gradient.operations.iter())
                .any(|x| !x.is_finite())
            || self
                .ordinary_decoder_derivatives
                .iter()
                .chain(self.operation_decoder_derivatives.iter())
                .any(|row| row.len() != width || row.iter().any(|x| !x.is_finite()))
            || self
                .group_decoder_derivatives
                .iter()
                .any(|x| !x.is_finite())
        {
            return Err(invalid());
        }
        let mut result = vec![0.; self.group_decoder_derivatives.len()];
        for (j, v) in result.iter_mut().enumerate() {
            *v = gradient.group * f64::from(self.group_decoder_derivatives[j]);
            for (g, row) in gradient
                .ordinary
                .iter()
                .zip(&self.ordinary_decoder_derivatives)
            {
                *v += g * f64::from(row[j]);
            }
            for o in 0..2 {
                *v += gradient.operations[o] * f64::from(self.operation_decoder_derivatives[o][j]);
            }
        }
        if result.iter().any(|x| !x.is_finite()) {
            return Err(invalid());
        }
        Ok(result)
    }
}
pub struct RecoveryGroupDetachedCpuV2 {
    core: MediationDetachedCpuV1,
    recipe: GroupRecipe,
    state: RecoveryGroupSnapshotV2,
}
impl RecoveryGroupDetachedCpuV2 {
    pub fn fresh(
        inputs: &PhenotypeCompilerInputs,
        asset: &FoundationWeightAsset,
        mode: MediationModeV1,
    ) -> Result<Self, TrainingError> {
        // DirectSource needs a separately specified group producer; do not quietly
        // compare direct ordinary logits against a mediated group.
        if mode == MediationModeV1::DirectSource {
            return Err(invalid());
        }
        let core = MediationDetachedCpuV1::fresh(inputs, asset, mode)?;
        if format!("{:x}", Sha256::digest(GROUP_RECIPE.as_bytes()))
            != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
        {
            return Err(invalid());
        }
        let recipe: GroupRecipe = serde_json::from_str(GROUP_RECIPE).map_err(|_| invalid())?;
        if recipe.operation_final_readouts != [[8., -8.]; 2]
            || recipe.nodes.len() != 16
            || recipe
                .nodes
                .iter()
                .enumerate()
                .any(|(i, n)| n.id != 2492 + i || n.phase != if i < 10 { 5 } else { 6 })
        {
            return Err(invalid());
        }
        let state = RecoveryGroupSnapshotV2 {
            schema: GROUP_SCHEMA.into(),
            recipe: RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256.into(),
            core_json: serde_json::to_string(&core.snapshot()).map_err(|_| invalid())?,
            activations: [0.; 16],
            ema: [0.; 16],
            metabolic: [0.; 16],
        };
        Ok(Self {
            core,
            recipe,
            state,
        })
    }
    pub fn source(&self) -> &BrainPhenotype {
        self.core.source()
    }
    pub fn source_state(&self) -> &TrainingInitialState {
        self.core.source_state()
    }
    pub fn bind_rows(
        &self,
        frame: &PerceptionFrame,
        tick: &TrainingReplayTick,
    ) -> Result<Vec<MediationRowV1>, TrainingError> {
        self.core.bind_rows(frame, tick)
    }
    pub fn snapshot(&self) -> RecoveryGroupSnapshotV2 {
        self.state.clone()
    }
    pub fn restore(
        inputs: &PhenotypeCompilerInputs,
        asset: &FoundationWeightAsset,
        mode: MediationModeV1,
        state: RecoveryGroupSnapshotV2,
    ) -> Result<Self, TrainingError> {
        if state.schema != GROUP_SCHEMA || state.recipe != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256 {
            return Err(invalid());
        }
        for (bank, bounded) in [
            (&state.activations, false),
            (&state.ema, true),
            (&state.metabolic, true),
        ] {
            if bank
                .iter()
                .any(|x| !x.is_finite() || (bounded && !(0. ..=1.).contains(x)))
            {
                return Err(invalid());
            }
        }
        let mut e = Self::fresh(inputs, asset, mode)?;
        let core = serde_json::from_str(&state.core_json).map_err(|_| invalid())?;
        e.core = MediationDetachedCpuV1::restore(inputs, asset, mode, core)?;
        e.state = state;
        Ok(e)
    }
    pub fn actor_optimization(&mut self) -> Result<(), TrainingError> {
        Err(invalid())
    }
    pub fn waking_outcome_plasticity(&mut self) -> Result<(), TrainingError> {
        Err(invalid())
    }
    /// available_effectors is an explicit detached capability fixture, not a claim
    /// of world legality. It can remove, never add, compiled motor capabilities.
    // Keep frame, replay, modulation and explicit admission inputs separate.
    #[allow(clippy::too_many_arguments)]
    pub fn step(
        &mut self,
        frame: &PerceptionFrame,
        tick: TrainingReplayTick,
        rows: &[MediationRowV1],
        modulation: MediationModulationV1,
        attempt_mask: u32,
        available_effectors: [bool; 6],
        available_arithmetic_q24: u64,
    ) -> Result<RecoveryGroupProbeResultV2, TrainingError> {
        let binding = RecoveryGroupBindingV2::bind(
            self.core.source(),
            frame,
            attempt_mask,
            available_effectors,
            self.core.state.generation,
        )?;
        let source_products=self.core.source.synapses().iter().filter(|s|matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.family()==CandidateActionFamily::Rest&&d.head()==DecoderHeadKind::ActionCandidate)).count() as u64;
        let extension_cost = 1016_u64
            .checked_add(source_products.checked_mul(4).ok_or_else(invalid)?)
            .ok_or_else(invalid)?;
        let core_budget = available_arithmetic_q24
            .checked_sub(extension_cost)
            .ok_or_else(invalid)?;
        // Whole decision transactional even if a late extension validation fails.
        let before = self.core.snapshot();
        let result = self.step_inner(
            frame,
            tick,
            rows,
            modulation,
            binding,
            source_products,
            extension_cost,
            core_budget,
        );
        if result.is_err() {
            self.core.state = before;
        }
        result
    }
    #[allow(clippy::too_many_arguments)]
    fn step_inner(
        &mut self,
        frame: &PerceptionFrame,
        tick: TrainingReplayTick,
        rows: &[MediationRowV1],
        m: MediationModulationV1,
        binding: RecoveryGroupBindingV2,
        source_products: u64,
        extension_cost: u64,
        core_budget: u64,
    ) -> Result<RecoveryGroupProbeResultV2, TrainingError> {
        let input_tick = tick.clone();
        let base = self.core.step(frame, tick, rows, m, core_budget)?;
        let p = &self.core.source;
        let activation = &base.source_evaluation.final_activations[0];
        let canonical =
            CandidateFeatureVector::zero().with_intrinsic_action_basis(ActionKind::Rest);
        let mut input = [0.; 54];
        input[..24].copy_from_slice(&canonical.0);
        let family = p
            .candidate_decoder()
            .families()
            .iter()
            .find(|f| f.family() == CandidateActionFamily::Rest)
            .ok_or_else(invalid)?;
        let mut common = [
            family.bias(),
            family.innate_contribution(frame.homeostasis().drives, canonical),
            0.,
            0.,
            0.,
        ];
        for (j, s) in p.synapses().iter().enumerate() {
            if let CompiledSynapseKind::Decoder(d) = s.kind() {
                if d.family() == CandidateActionFamily::Rest
                    && d.head() == DecoderHeadKind::ActionCandidate
                {
                    common[0] += activation[s.source() as usize]
                        * (input[d.input_lane() as usize] * self.core.weights[j]);
                }
            }
        }
        let virtual_candidate = TrainingReplayCandidate {
            family: CandidateActionFamily::Rest,
            decoder_inputs: input,
            innate_bias: common[1],
        };
        // Same native opponent readouts, not an average/max of operation scores.
        for r in &self.core.recipe.manifest.drive_proposal_readouts {
            common[4] += base.receipt.appended_activations[r.source - START]
                * (cue(r, &virtual_candidate) * r.weight);
        }
        let mut next = self.state.clone();
        let (group, group_jac, operations, op_jac, pressure_jac) =
            extension_forward(&self.recipe, &mut next, &base.receipt, &binding, common, m)?;
        let scores = RecoveryGroupScoresV2 {
            binding,
            ordinary: base
                .receipt
                .core_logits
                .iter()
                .map(|x| f64::from(*x))
                .collect(),
            group: f64::from(group),
            operations: operations.map(f64::from),
        };
        scores.validate()?;
        let mut ordinary = base.projected_core_decoder_derivatives;
        for i in scores.binding.operations.iter().flatten() {
            ordinary[*i] = vec![0.; p.synapses().len()];
        }
        let mut group_derivatives = vec![0.; p.synapses().len()];
        let mut op_derivatives = [vec![0.; p.synapses().len()], vec![0.; p.synapses().len()]];
        for (j, s) in p.synapses().iter().enumerate() {
            let CompiledSynapseKind::Decoder(d) = s.kind() else {
                continue;
            };
            if d.family() != CandidateActionFamily::Rest {
                continue;
            }
            if d.head() == DecoderHeadKind::ActionCandidate {
                group_derivatives[j] =
                    group_jac[0] * activation[s.source() as usize] * input[d.input_lane() as usize];
            }
            for o in 0..2 {
                if let Some(i) = scores.binding.operations[o] {
                    let context = match d.head() {
                        DecoderHeadKind::MemoryContext => Some(0),
                        DecoderHeadKind::CognitiveContext => Some(1),
                        _ => None,
                    };
                    if let Some(c) = context {
                        op_derivatives[o][j] = op_jac[o][c]
                            * base.receipt.upstream_context_slopes[i][c]
                            * input_tick.candidates[i].decoder_inputs[d.input_lane() as usize];
                    }
                }
            }
        }
        next.core_json = serde_json::to_string(&self.core.snapshot()).map_err(|_| invalid())?;
        let receipt = RecoveryGroupNativeReceiptV2 {
            schema: GROUP_SCHEMA.into(),
            recipe: RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256.into(),
            core: base.receipt,
            group_components: common,
            group_jacobian: group_jac,
            operation_context_jacobians: op_jac,
            operation_pressure_jacobians: pressure_jac,
            extension_activations: next.activations,
            extension_source_products: source_products,
            extension_arithmetic_q24: extension_cost,
            scores,
        };
        self.state = next;
        Ok(RecoveryGroupProbeResultV2 {
            source_evaluation: base.source_evaluation,
            receipt,
            ordinary_decoder_derivatives: ordinary,
            group_decoder_derivatives: group_derivatives,
            operation_decoder_derivatives: op_derivatives,
        })
    }
}
// Group score/J, operation scores/context J, and signed-pressure J.
type ExtensionReadout = (f32, [f32; 5], [f32; 2], [[f32; 2]; 2], [f32; 2]);
// The same native soma function as SparseGraph and M2; no bespoke activation engine.
fn extension_forward(
    recipe: &GroupRecipe,
    state: &mut RecoveryGroupSnapshotV2,
    base: &MediationReceiptV1,
    binding: &RecoveryGroupBindingV2,
    common: [f32; 5],
    m: MediationModulationV1,
) -> Result<ExtensionReadout, TrainingError> {
    extension_forward_banks(
        recipe,
        &mut state.activations,
        &mut state.ema,
        &mut state.metabolic,
        base,
        binding,
        common,
        m,
    )
}
#[allow(clippy::too_many_arguments)]
fn extension_forward_banks(
    recipe: &GroupRecipe,
    activations: &mut [f32; 16],
    ema: &mut [f32; 16],
    metabolic: &mut [f32; 16],
    base: &MediationReceiptV1,
    binding: &RecoveryGroupBindingV2,
    common: [f32; 5],
    m: MediationModulationV1,
) -> Result<ExtensionReadout, TrainingError> {
    finite(&common)?;
    let mut encoded = [m.offset; 16];
    for port in 0..5 {
        for (side, sign) in [(0, 1.), (1, -1.)] {
            encoded[port * 2 + side] =
                (sign * common[port] / DIVISORS[port]).clamp(-8., 8.) + m.offset;
        }
    }
    for phase in [5, 6] {
        let previous = *activations;
        for (i, node) in recipe
            .nodes
            .iter()
            .enumerate()
            .filter(|(_, n)| n.phase == phase)
        {
            let mut recurrent = 0.;
            if i == 10 || i == 11 {
                let sign = if i == 10 { 1. } else { -1. };
                for port in 0..5 {
                    recurrent += previous[port * 2] * (sign * BOUND_WEIGHTS[port] * 0.5);
                    recurrent += previous[port * 2 + 1] * (-sign * BOUND_WEIGHTS[port] * 0.5);
                }
            }
            if i >= 12 {
                let o = (i - 12) / 2;
                let side = if i % 2 == 0 { 1. } else { -1. };
                // Fixed six signed rows per soma. Absent operation uses zero
                // context but still pays padded work; no target-slot state reuse.
                for (port, w) in [(2, 0.25), (3, 0.125)] {
                    let pair =
                        binding.operations[o].map_or([0.; 2], |c| base.port_activations[c][port]);
                    recurrent += pair[0] * (side * w);
                    recurrent += pair[1] * (-side * w);
                }
                let sign = if o == 0 { side } else { -side };
                recurrent += base.appended_activations[57] * sign;
                recurrent += base.appended_activations[58] * -sign;
            }
            let result = native_kernel::neuron_step(
                &node.dynamics,
                CellState {
                    activation: previous[i],
                    ema: ema[i],
                    metabolic: metabolic[i],
                },
                encoded[i],
                recurrent,
                0.,
                m.projection_gain,
                m.threshold,
            );
            activations[i] = result.state.activation;
            ema[i] = result.state.ema;
            metabolic[i] = result.state.metabolic;
        }
    }
    finite(activations)?;
    let a = *activations;
    let pair_slope = |i: usize| {
        2. * m.projection_gain * ((1. - a[i] * a[i]).max(0.) + (1. - a[i + 1] * a[i + 1]).max(0.))
    };
    let mut jac = [0.; 5];
    for p in 0..5 {
        let slope = ((1. - a[p * 2] * a[p * 2]).max(0.) * clip_slope(common[p] / DIVISORS[p], 8.)
            + (1. - a[p * 2 + 1] * a[p * 2 + 1]).max(0.)
                * clip_slope(-common[p] / DIVISORS[p], 8.))
            / (2. * DIVISORS[p]);
        jac[p] = pair_slope(10) * BOUND_WEIGHTS[p] * slope;
    }
    // Fixed native decoder row weights. Neural soma state is unchanged;
    // scale enters before the categorical, never as posthoc probabilities.
    let operation_slope = |o: usize| {
        let i = 12 + o * 2;
        let w = recipe.operation_final_readouts[o];
        m.projection_gain
            * (w[0] * (1. - a[i] * a[i]).max(0.) - w[1] * (1. - a[i + 1] * a[i + 1]).max(0.))
    };
    let mut oj = [[0.; 2]; 2];
    let mut pj = [0.; 2];
    for o in 0..2 {
        pj[o] = operation_slope(o) * if o == 0 { 1. } else { -1. };
        if let Some(c) = binding.operations[o] {
            for (p, w) in [(2, 0.5), (3, 0.25)] {
                let q = base.port_activations[c][p];
                let clip = base.port_clip_slopes[c][p];
                oj[o][p - 2] = operation_slope(o)
                    * w
                    * ((1. - q[0] * q[0]).max(0.) * clip[0] + (1. - q[1] * q[1]).max(0.) * clip[1])
                    / (2. * DIVISORS[p]);
            }
        }
    }
    Ok((
        2. * a[10] - 2. * a[11],
        jac,
        std::array::from_fn(|o| {
            let w = recipe.operation_final_readouts[o];
            w[0] * a[12 + 2 * o] + w[1] * a[13 + 2 * o]
        }),
        oj,
        pj,
    ))
}
#[cfg(test)]
mod tests;

mod host;
pub use host::{GroupedAppendWorkV1, GroupedMotorReceiptV1, GroupedMotorStateV1};
