//! Disposable injected arithmetic fixtures, not acquired learning or world life.
use super::*;
use crate::cpu::{CpuFoundationTrainer, CpuOrganismState};
use crate::{AdamWConfig, StageTrainableMask};

fn fixture() -> (
    GroupedMotorStateV1,
    CpuFoundationTrainer,
    TrainingSequence,
    PerceptionFrame,
    NeuralReceptorFrame,
    NeuralReceptorEffects,
) {
    let (inputs, asset) = super::super::tests::source();
    let detached =
        RecoveryGroupDetachedCpuV2::fresh(&inputs, &asset, MediationModeV1::Full).unwrap();
    let p = detached.source().clone();
    let f = super::super::tests::frame();
    let receptors = NeuralReceptorFrame {
        schema_version: BIOCHEMICAL_GRAPH_SCHEMA_VERSION,
        source_chemistry_version: BIOCHEMICAL_GRAPH_SCHEMA_VERSION,
        source_tick: f.tick(),
        activations: vec![],
    };
    let effects = NeuralReceptorEffects::from_frame(
        &receptors,
        &NeuralReceptorPhenotype::compile(&p).unwrap(),
    )
    .unwrap();
    let t = super::super::tests::tick(&detached, &f);
    let q = TrainingSequence {
        phenotype_hash: p.phenotype_hash(),
        initial: detached.source_state().clone(),
        ticks: vec![t],
        burn_in_ticks: 0,
        memory_candidate_gain: p
            .candidate_decoder()
            .memory_channel()
            .unwrap()
            .max_candidate_gain(),
    };
    let motor = GroupedMotorStateV1::fresh(&inputs, &p, MediationModeV1::Full).unwrap();
    let founder = CpuFoundationTrainer::new(
        p,
        asset,
        StageTrainableMask::recurrent_only(detached.source()).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    (motor, founder, q, f, receptors, effects)
}
fn bits(e: &TrainingReplayEvaluation) -> Vec<u8> {
    let bits = [
        &e.candidate_logits,
        &e.final_activations,
        &e.final_activity_ema,
        &e.final_metabolic_load,
    ]
    .map(|bank| {
        bank.iter()
            .map(|row| row.iter().map(|v| v.to_bits()).collect::<Vec<_>>())
            .collect::<Vec<_>>()
    });
    serde_json::to_vec(&bits).unwrap()
}
#[test]
fn grouped_host_actual_source_once_uses_somatic_memory_dynamic_branches_and_edges() {
    let (mut motor, founder, mut q, f, r, e) = fixture();
    let p = founder.phenotype();
    let canonical = CandidateFeatureVector::zero().with_intrinsic_action_basis(ActionKind::Rest);
    let action_row=p.synapses().iter().position(|s|matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.family()==CandidateActionFamily::Rest && d.head()==DecoderHeadKind::ActionCandidate && (d.input_lane() as usize)<24 && canonical.0[d.input_lane() as usize]!=0.)).unwrap();
    let memory_row=p.synapses().iter().position(|s|matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.family()==CandidateActionFamily::Rest && d.head()==DecoderHeadKind::MemoryContext)).unwrap();
    q.ticks[0].effective_weight_offsets[action_row] = 0.75;
    q.ticks[0].effective_weight_offsets[memory_row] = 0.625;
    let CompiledSynapseKind::Decoder(d) = p.synapses()[memory_row].kind() else {
        panic!()
    };
    q.ticks[0].candidates[1].decoder_inputs[d.input_lane() as usize] = 0.25;
    q.ticks[0].candidates[6].decoder_inputs[d.input_lane() as usize] = 0.75;
    let s = p
        .synapses()
        .iter()
        .find(|s| s.kind() == CompiledSynapseKind::Recurrent)
        .unwrap();
    q.ticks[0]
        .structural_synapses
        .push(crate::TrainingFrozenSynapse {
            source: s.source(),
            target: s.target(),
            route: u32::from(s.route_index()),
            cadence: u32::from(
                p.projections()[s.route_index() as usize]
                    .update_cadence()
                    .raw(),
            ),
            effective_weight: 0.875,
        });
    let old = q.initial.dendrites.branches()[0].clone();
    let mut branches = q.initial.dendrites.branches().to_vec();
    branches[0] = DendriticBranch::new(old.target, 0.03125, 0.875, old.inputs).unwrap();
    q.initial.dendrites = DendriticBranchSet::new(branches).unwrap();
    let plain = SparseGraph::new(p)
        .forward(p, founder.weights(), &q)
        .unwrap();
    let actual = motor
        .forward(p, founder.weights(), &q, &f, &r, &e, [true; 6], 127)
        .unwrap();
    assert_eq!(bits(&plain.evaluation), bits(&actual.evaluation));
    let receipt = motor.last_receipt.as_ref().unwrap();
    assert_eq!(receipt.native.core.source_execution_count, 1);
    assert_eq!(receipt.raw_memory, actual.memory[0]);
    assert_ne!(receipt.raw_memory[1], 0.);
    assert_ne!(receipt.raw_memory[1], receipt.raw_memory[6]);
    assert_eq!(
        receipt.native.core.components[1][2],
        receipt.raw_memory[1].clamp(-q.memory_candidate_gain, q.memory_candidate_gain)
    );
    assert_eq!(receipt.native.group_components[2..4], [0., 0.]);
    let mut zero = q.clone();
    zero.ticks[0].effective_weight_offsets[action_row] = 0.;
    let mut control = motor.clone();
    control.generation = 0;
    control.last_receipt = None;
    control
        .forward(p, founder.weights(), &zero, &f, &r, &e, [true; 6], 127)
        .unwrap();
    assert_ne!(
        receipt.native.group_components[0].to_bits(),
        control
            .last_receipt
            .as_ref()
            .unwrap()
            .native
            .group_components[0]
            .to_bits(),
        "common Rest S must use the actual offset"
    );
    let wire = serde_json::to_value(&motor).unwrap();
    assert_eq!(
        wire["activations"].as_array().unwrap().len()
            + wire["group_activations"].as_array().unwrap().len(),
        460
    );
    assert!(wire.get("source").is_none());
    assert!(wire.get("weights").is_none());
}
#[test]
fn grouped_host_pending_boundary_rejects_export_and_retains_effective_offsets() {
    let (mut motor, founder, q, f, r, e) = fixture();
    let p = founder.phenotype();
    let mut organism = CpuOrganismState::new(p, f.organism_id(), q.initial).unwrap();
    let mut checkpoint = organism.checkpoint().unwrap();
    checkpoint.fast[0] = 0.125;
    checkpoint.lifetime[0] = 0.0625;
    organism = CpuOrganismState::from_checkpoint(p, checkpoint).unwrap();
    let before = founder.checkpoint();
    let output = organism
        .advance_grouped(
            &founder,
            q.ticks[0].clone(),
            &e,
            &mut motor,
            &f,
            &r,
            [true; 6],
            127,
        )
        .unwrap();
    assert!(organism.checkpoint().is_err());
    assert_eq!(
        output.replay_tick.effective_weight_offsets[0],
        0.0625 + p.synapses()[0].alpha() * 0.125
    );
    assert_eq!(
        serde_json::to_vec(&before).unwrap(),
        serde_json::to_vec(&founder.checkpoint()).unwrap()
    );
    // Explicit negative direct-decoder call. This independently sampled legacy
    // fixture is NOT the grouped action and never reaches world dispatch.
    let direct = crate::cpu::input::sample_cpu_sleep_choice_joint_action(
        p,
        &f,
        &output.candidate_logits,
        0x484f5354,
        0,
        0.7,
    )
    .unwrap();
    direct.validate(0.7).unwrap();
    let bundle =
        MotorCommandBundle::new(f.organism_id(), ExperienceSequenceId(1), f.tick(), vec![])
            .unwrap();
    let binding = crate::cpu::CpuDecisionBinding {
        sequence_id: ExperienceSequenceId(1),
        frame_digest: f.frame_digest(),
        action_id: f.candidates()[direct.representative as usize].action_id,
        candidate_feature_digest: f.candidates()[direct.representative as usize]
            .feature_digest()
            .unwrap(),
        dispatch_generation: output.dispatch_generation,
        active_activation_side: output.active_activation_side,
        joint_selection: JointActionSelectionV1::new(
            direct.motor_candidates.map(|i| i.map_or(0, |i| i + 1)),
            &bundle,
        )
        .unwrap(),
    };
    assert!(organism
        .stage_selection(p, &direct, binding, false)
        .is_err());
    assert!(organism.checkpoint().is_err());
    let scores = &motor.last_receipt.as_ref().unwrap().native.scores;
    let action = scores.sample(0x484f5354, 0, 0.7).unwrap();
    let evaluation = scores.evaluate(&action).unwrap();
    let (representative, slots) = scores.physical_selection(&action).unwrap();
    assert!((representative as usize) < f.candidates().len());
    assert_eq!(
        evaluation.joint_log_probability.to_bits(),
        action.old_joint_log_probability.to_bits()
    );
    assert!(slots
        .iter()
        .flatten()
        .all(|&i| (i as usize) < f.candidates().len()));
    assert!(
        action
            .draw_factors
            .iter()
            .filter(|&&i| i == 1 || i == 8)
            .count()
            <= 1
    );
    let mut tampered = action;
    tampered.old_joint_log_probability += 0.01;
    assert!(scores.physical_selection(&tampered).is_err());
}
#[test]
fn grouped_host_native_invalid_binding_and_partition_rollback() {
    let (mut motor, founder, q, f, r, e) = fixture();
    let before = serde_json::to_vec(&motor).unwrap();
    assert!(motor
        .forward(
            founder.phenotype(),
            founder.weights(),
            &q,
            &f,
            &r,
            &e,
            [false; 6],
            127
        )
        .is_err());
    assert_eq!(serde_json::to_vec(&motor).unwrap(), before);
    let mut qbad = q.clone();
    qbad.ticks[0]
        .structural_synapses
        .push(crate::TrainingFrozenSynapse {
            source: 2048,
            target: 0,
            route: 0,
            cadence: 1,
            effective_weight: 1.,
        });
    assert!(motor
        .forward(
            founder.phenotype(),
            founder.weights(),
            &qbad,
            &f,
            &r,
            &e,
            [true; 6],
            127
        )
        .is_err());
    assert_eq!(serde_json::to_vec(&motor).unwrap(), before);
    let (_, _, affordable) =
        GroupedMotorStateV1::work(founder.phenotype(), &BrainWorkCounters::default(), 0, 0)
            .unwrap();
    assert!(!affordable);
    motor.activations.push(0.);
    assert!(motor.validate(founder.phenotype()).is_err());
}

#[test]
fn grouped_host_work_prices_every_common_product_without_invented_bookkeeping_debit() {
    let (_, founder, _, _, _, _) = fixture();
    let p = founder.phenotype();
    let products=p.synapses().iter().filter(|s|matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.family()==CandidateActionFamily::Rest && d.head()==DecoderHeadKind::ActionCandidate)).count() as u64;
    let w = GroupedMotorStateV1::append_work(p).unwrap();
    assert_eq!(w.neuron_updates, 460);
    assert_eq!(w.synapse_products, 640 + 1920 + 64 + 44 + 6 + 60 + products);
    assert_eq!(w.other_work, 36 + 72 + 460);
    assert_eq!(
        w.reservation_q24,
        460 * 32 + 460 * 4 + 36 * 16 + 72 * 4 + w.synapse_products * 4
    );
    assert_eq!(w.reservation_q24, 27_344 + 1016 + products * 4);
}
