//! Hierarchical log probabilities. No PpoJointAction conversion or world dispatch.
use super::*;
mod optional_vocal;
pub use optional_vocal::*;
const POLICY_SCHEMA: &str = "grouped-recovery-confidence-joint-v2";
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct RecoveryGroupBindingV2 {
    schema: String,
    recipe: String,
    source_hash: PhenotypeHash,
    frame_digest: PerceptionFrameDigest,
    generation: u64,
    identities: Vec<String>,
    order: Vec<usize>,
    attempt_mask: u32,
    eligible_mask: u32,
    enabled: [bool; 6],
    forced: Vec<Option<usize>>,
    channel_members: Vec<bool>,
    pub(super) operations: [Option<usize>; 2],
}
fn channel(kind: ActionKind) -> Option<usize> {
    match kind {
        ActionKind::Move => Some(0),
        ActionKind::Look => Some(1),
        ActionKind::Interact | ActionKind::Write => Some(2),
        ActionKind::Vocalize => Some(3),
        ActionKind::Hold
        | ActionKind::Rest
        | ActionKind::Inspect
        | ActionKind::Idle
        | ActionKind::Gesture => Some(4),
    }
}
impl RecoveryGroupBindingV2 {
    pub(super) fn bind(
        p: &BrainPhenotype,
        frame: &PerceptionFrame,
        attempt_mask: u32,
        effectors: [bool; 6],
        generation: u64,
    ) -> Result<Self, TrainingError> {
        let n = frame.candidates().len();
        if frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
            || n == 0
            || n > 32
            || attempt_mask & !valid_mask(n) != 0
        {
            return Err(invalid());
        }
        let mut enabled = [false; 6];
        for c in p.candidate_decoder().factorized_motor_channels(p)? {
            let slot = match c {
                MotorChannel::Locomotion => 0,
                MotorChannel::Orientation => 1,
                MotorChannel::Manipulation => 2,
                MotorChannel::Vocal => 3,
                MotorChannel::Posture => 4,
                MotorChannel::SpeciesSpecific(_) => 5,
            };
            enabled[slot] = effectors[slot];
        }
        let mut operations = [None; 2];
        let mut forced = vec![];
        let mut identities = vec![];
        let mut channel_members = vec![];
        let mut eligible_mask = attempt_mask;
        for (i, c) in frame.candidates().iter().enumerate() {
            let op = RecoveryOperationV1::for_candidate(c)?;
            let expected_noop = match c.action_id.raw() {
                103 => Some((ActionKind::Move, CandidateActionFamily::Approach)),
                212 => Some((ActionKind::Interact, CandidateActionFamily::Contact)),
                104 => Some((ActionKind::Hold, CandidateActionFamily::Other)),
                _ => None,
            };
            if let Some((kind, family)) = expected_noop {
                if c.kind != kind
                    || c.family != family
                    || c.target != ActionTarget::NONE
                    || c.observation != CandidateObservationRef::None
                    || c.features
                        != CandidateFeatureVector::zero().with_intrinsic_action_basis(kind)
                {
                    return Err(invalid());
                }
            }
            if let Some(op) = op {
                let o = if op == RecoveryOperationV1::BodySleep {
                    0
                } else {
                    1
                };
                if operations[o].is_some()
                    || c.features
                        != CandidateFeatureVector::zero()
                            .with_intrinsic_action_basis(ActionKind::Rest)
                {
                    return Err(invalid());
                }
                operations[o] = Some(i);
            }
            let identity = serde_json::to_string(&(c.action_id, c.target, c.kind, c.family))
                .map_err(|_| invalid())?;
            if identities.contains(&identity) {
                return Err(invalid());
            }
            identities.push(identity);
            let slot = channel(c.kind);
            forced.push(slot);
            channel_members.push(!matches!(c.kind, ActionKind::Idle | ActionKind::Gesture));
            // Unknown dispatch and disabled capability cannot leak through a
            // representative force. No invented SpeciesSpecific mapping.
            if slot.is_none_or(|s| !enabled[s]) {
                eligible_mask &= !(1u32 << i);
            }
        }
        if eligible_mask == 0 {
            return Err(invalid());
        }
        let mut order: Vec<_> = (0..n).collect();
        order.sort_by(|a, b| identities[*a].cmp(&identities[*b]));
        Ok(Self {
            schema: POLICY_SCHEMA.into(),
            recipe: RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256.into(),
            source_hash: p.phenotype_hash(),
            frame_digest: frame.frame_digest(),
            generation,
            identities,
            order,
            attempt_mask,
            eligible_mask,
            enabled,
            forced,
            channel_members,
            operations,
        })
    }
    fn validate(&self) -> Result<(), TrainingError> {
        let n = self.identities.len();
        if self.schema != POLICY_SCHEMA
            || self.recipe != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
            || n == 0
            || n > 32
            || self.forced.len() != n
            || self.channel_members.len() != n
            || self.order.len() != n
            || self.attempt_mask & !valid_mask(n) != 0
            || self.eligible_mask == 0
            || self.eligible_mask & !self.attempt_mask != 0
        {
            return Err(invalid());
        }
        let mut expected: Vec<_> = (0..n).collect();
        expected.sort_by(|a, b| self.identities[*a].cmp(&self.identities[*b]));
        if self.order != expected
            || expected
                .windows(2)
                .any(|w| self.identities[w[0]] == self.identities[w[1]])
            || self.forced.iter().any(|s| s.is_some_and(|x| x >= 6))
        {
            return Err(invalid());
        }
        for i in 0..n {
            if self.eligible_mask & (1 << i) != 0 && self.forced[i].is_none_or(|s| !self.enabled[s])
            {
                return Err(invalid());
            }
        }
        for i in self.operations.iter().flatten() {
            if *i >= n || self.forced[*i] != Some(4) {
                return Err(invalid());
            }
        }
        if self.operations[0].is_some() && self.operations[0] == self.operations[1] {
            return Err(invalid());
        }
        Ok(())
    }
    fn operation_mask(&self) -> [bool; 2] {
        self.operations
            .map(|i| i.is_some_and(|i| self.eligible_mask & (1 << i) != 0))
    }
    fn is_recovery(&self, i: usize) -> bool {
        self.operations.contains(&Some(i))
    }
}
fn valid_mask(n: usize) -> u32 {
    u32::MAX >> (32 - n)
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryGroupScoresV2 {
    pub(super) binding: RecoveryGroupBindingV2,
    /// Physical slots preserved, but recovery entries are never used as scores.
    pub ordinary: Vec<f64>,
    pub group: f64,
    pub operations: [f64; 2],
}
impl RecoveryGroupScoresV2 {
    pub(super) fn validate(&self) -> Result<(), TrainingError> {
        self.binding.validate()?;
        if self.ordinary.len() != self.binding.identities.len()
            || self
                .ordinary
                .iter()
                .chain([&self.group])
                .chain(self.operations.iter())
                .any(|x| !x.is_finite() || x.abs() > 1e30)
        {
            return Err(invalid());
        }
        Ok(())
    }
    /// Revalidate full native context on detached replay, not merely shape.
    pub fn validate_context(
        &self,
        p: &BrainPhenotype,
        frame: &PerceptionFrame,
        attempt_mask: u32,
        effectors: [bool; 6],
        generation: u64,
    ) -> Result<(), TrainingError> {
        self.validate()?;
        if self.binding
            != RecoveryGroupBindingV2::bind(p, frame, attempt_mask, effectors, generation)?
        {
            return Err(invalid());
        }
        Ok(())
    }
    fn factor(
        &self,
        slot: Option<usize>,
        temperature: f64,
    ) -> Result<RecoveryGroupFactorV2, TrainingError> {
        let mut outcomes = vec![];
        let mut logits = vec![];

        for &i in &self.binding.order {
            if self.binding.eligible_mask & (1 << i) == 0 || self.binding.is_recovery(i) {
                continue;
            }
            if slot.is_some() && self.binding.forced[i] != slot {
                continue;
            }
            // Idle/Gesture are representative posture constraints, not separate
            // posture actions beside its explicit no-op.
            if slot.is_some() && !self.binding.channel_members[i] {
                continue;
            }
            outcomes.push(RecoveryGroupChoiceV2::Candidate(i as u16));
            logits.push(self.ordinary[i]);
        }
        if self.binding.operation_mask().contains(&true) && (slot.is_none() || slot == Some(4)) {
            outcomes.push(RecoveryGroupChoiceV2::RestGroup);
            logits.push(self.group);
        }
        if slot.is_some() && outcomes.is_empty() {
            outcomes.push(RecoveryGroupChoiceV2::NoOp);
            logits.push(0.);
        }
        RecoveryGroupFactorV2::new(outcomes, logits, temperature)
    }
    fn conditional(&self, temperature: f64) -> Result<Conditional, TrainingError> {
        let mask = self.binding.operation_mask();
        let mut p = [0.; 2];
        let mut lp = [None; 2];
        if !mask.contains(&true) {
            return Ok(Conditional { p, lp });
        }
        let max = (0..2)
            .filter(|i| mask[*i])
            .map(|i| self.operations[i])
            .fold(f64::NEG_INFINITY, f64::max);
        let z = (0..2)
            .filter(|i| mask[*i])
            .map(|i| ((self.operations[i] - max) / temperature).exp())
            .sum::<f64>();
        for i in 0..2 {
            if mask[i] {
                let l = (self.operations[i] - max) / temperature - z.ln();
                lp[i] = Some(l);
                p[i] = l.exp();
            }
        }
        Ok(Conditional { p, lp })
    }
    pub fn probabilities(
        &self,
        temperature: f64,
    ) -> Result<RecoveryGroupProbabilitiesV2, TrainingError> {
        self.validate()?;
        valid_temperature(temperature)?;
        let r = self.factor(None, temperature)?;
        let conditional = self.conditional(temperature)?;
        let mut channels: [Option<RecoveryGroupFactorV2>; 6] = std::array::from_fn(|_| None);
        for (s, c) in channels.iter_mut().enumerate() {
            if self.binding.enabled[s] {
                *c = Some(self.factor(Some(s), temperature)?);
            }
        }
        let group = r.probability(RecoveryGroupChoiceV2::RestGroup);
        // Sum the complement directly, avoiding cancellation near forced mass one.
        let non_forced_posture = r
            .outcomes
            .iter()
            .zip(&r.probabilities)
            .filter(|(o, _)| self.forced(**o) != Some(4))
            .map(|(_, p)| p)
            .sum::<f64>();
        let q = channels[4]
            .as_ref()
            .map_or(0., |d| d.probability(RecoveryGroupChoiceV2::RestGroup));
        let actual = (group + non_forced_posture * q).clamp(0., 1.);
        Ok(RecoveryGroupProbabilitiesV2 {
            representative: r,
            channels,
            conditional_operation: conditional.p,
            conditional_log_probability: conditional.lp,
            representative_rest_probability: group,
            posture_rest_probability: q,
            actual_posture_rest_probability: actual,
            actual_operation_probability: conditional.p.map(|p| p * actual),
        })
    }
    fn forced(&self, choice: RecoveryGroupChoiceV2) -> Option<usize> {
        match choice {
            RecoveryGroupChoiceV2::Candidate(i) => self.binding.forced[i as usize],
            RecoveryGroupChoiceV2::RestGroup => Some(4),
            RecoveryGroupChoiceV2::NoOp => None,
        }
    }
    /// Pure deterministic arithmetic sampling. Never dispatches a physical action.
    pub fn sample(
        &self,
        seed: u32,
        counter: u32,
        temperature: f64,
    ) -> Result<RecoveryGroupJointActionV2, TrainingError> {
        let d = self.probabilities(temperature)?;
        let mut draws = vec![];
        let mut pick = |factor: &RecoveryGroupFactorV2, id: u32| {
            draws.push(id);
            factor.sample(draw(seed, counter, id))
        };
        let representative = pick(&d.representative, 0);
        let forced = self.forced(representative);
        let mut motors = [RecoveryGroupChoiceV2::NoOp; 6];
        let mut operation_factor = None;
        if representative == RecoveryGroupChoiceV2::RestGroup {
            operation_factor = Some(1);
        }
        for (s, motor) in motors.iter_mut().enumerate() {
            if forced == Some(s) {
                *motor = representative;
            } else if let Some(f) = &d.channels[s] {
                *motor = if f.outcomes == [RecoveryGroupChoiceV2::NoOp] {
                    RecoveryGroupChoiceV2::NoOp
                } else {
                    pick(f, 2 + s as u32)
                };
                if *motor == RecoveryGroupChoiceV2::RestGroup {
                    operation_factor = Some(8);
                }
            }
        }
        let operation = if let Some(f) = operation_factor {
            draws.push(f);
            let u = draw(seed, counter, f);
            let mask = self.binding.operation_mask();
            Some(if mask[0] && (!mask[1] || u < d.conditional_operation[0]) {
                0
            } else {
                1
            })
        } else {
            None
        };
        let mut action = RecoveryGroupJointActionV2 {
            schema: POLICY_SCHEMA.into(),
            recipe: RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256.into(),
            binding: self.binding.clone(),
            representative,
            motors,
            operation,
            temperature,
            sampling_temperature_bits: temperature.to_bits(),
            old_joint_log_probability: 0.,
            seed,
            counter,
            draw_factors: draws,
        };
        action.old_joint_log_probability = self.evaluate(&action)?.joint_log_probability;
        Ok(action)
    }
    pub fn evaluate(
        &self,
        a: &RecoveryGroupJointActionV2,
    ) -> Result<RecoveryGroupEvaluationV2, TrainingError> {
        if a.schema != POLICY_SCHEMA
            || a.recipe != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
            || a.binding != self.binding
            || a.temperature.to_bits() != a.sampling_temperature_bits
            || !a.old_joint_log_probability.is_finite()
            || a.old_joint_log_probability > 1e-10
        {
            return Err(invalid());
        }
        let d = self.probabilities(a.temperature)?;
        let forced = self.forced_checked(a.representative)?;
        let mut gradient = RecoveryGroupGradientV2 {
            binding: self.binding.clone(),
            ordinary: vec![0.; self.ordinary.len()],
            group: 0.,
            operations: [0.; 2],
        };
        let mut lp = d.representative.logp(a.representative)?;
        accumulate(
            &mut gradient,
            &d.representative,
            a.representative,
            a.temperature,
        );
        let mut factors = vec![lp];
        let mut expected_draws = vec![0];
        let mut op_factor = if a.representative == RecoveryGroupChoiceV2::RestGroup {
            Some(1)
        } else {
            None
        };
        for s in 0..6 {
            if forced == Some(s) {
                if a.motors[s] != a.representative {
                    return Err(invalid());
                }
            } else if let Some(f) = &d.channels[s] {
                let l = f.logp(a.motors[s])?;
                factors.push(l);
                lp += l;
                accumulate(&mut gradient, f, a.motors[s], a.temperature);
                if f.outcomes != [RecoveryGroupChoiceV2::NoOp] {
                    expected_draws.push(2 + s as u32);
                }
                if a.motors[s] == RecoveryGroupChoiceV2::RestGroup {
                    if op_factor.is_some() {
                        return Err(invalid());
                    }
                    op_factor = Some(8);
                }
            } else if a.motors[s] != RecoveryGroupChoiceV2::NoOp {
                return Err(invalid());
            }
        }
        if let Some(f) = op_factor {
            let o = a.operation.filter(|o| *o < 2).ok_or_else(invalid)? as usize;
            let l = d.conditional_log_probability[o].ok_or_else(invalid)?;
            lp += l;
            factors.push(l);
            for i in 0..2 {
                if self.binding.operation_mask()[i] {
                    gradient.operations[i] =
                        (f64::from(i == o) - d.conditional_operation[i]) / a.temperature;
                }
            }
            expected_draws.push(f);
        } else if a.operation.is_some() {
            return Err(invalid());
        }
        if a.draw_factors != expected_draws || !lp.is_finite() {
            return Err(invalid());
        }
        let mut physical = vec![];
        for c in std::iter::once(a.representative).chain(a.motors) {
            let i = match c {
                RecoveryGroupChoiceV2::Candidate(i) => Some(i),
                RecoveryGroupChoiceV2::RestGroup => a
                    .operation
                    .and_then(|o| self.binding.operations[o as usize])
                    .map(|i| i as u16),
                RecoveryGroupChoiceV2::NoOp => None,
            };
            if let Some(i) = i {
                if !physical.contains(&i) {
                    physical.push(i);
                }
            }
        }
        Ok(RecoveryGroupEvaluationV2 {
            joint_log_probability: lp,
            joint_probability: lp.exp(),
            factor_log_probabilities: factors,
            gradient,
            selected_physical_candidates_once: physical,
        })
    }
    pub(crate) fn validate_host_identity(
        &self,
        source: PhenotypeHash,
        frame: PerceptionFrameDigest,
        generation: u64,
    ) -> Result<(), TrainingError> {
        self.validate()?;
        if self.binding.source_hash != source
            || self.binding.frame_digest != frame
            || self.binding.generation != generation
        {
            return Err(invalid());
        }
        Ok(())
    }
    /// Resolve the typed sampled policy into existing physical frame slots. The
    /// conditional operation is chosen once, even when it supplies both the
    /// representative and posture. No legacy flat/PPO action is manufactured.
    pub fn physical_selection(
        &self,
        action: &RecoveryGroupJointActionV2,
    ) -> Result<(u16, [Option<u16>; 6]), TrainingError> {
        let evidence = self.evaluate(action)?;
        if evidence.joint_log_probability.to_bits() != action.old_joint_log_probability.to_bits() {
            return Err(invalid());
        }
        let resolve = |choice| -> Result<Option<u16>, TrainingError> {
            match choice {
                RecoveryGroupChoiceV2::Candidate(i) => Ok(Some(i)),
                RecoveryGroupChoiceV2::NoOp => Ok(None),
                RecoveryGroupChoiceV2::RestGroup => action
                    .operation
                    .and_then(|o| self.binding.operations.get(o as usize).copied().flatten())
                    .map(|i| Some(i as u16))
                    .ok_or_else(invalid),
            }
        };
        let representative = resolve(action.representative)?.ok_or_else(invalid)?;
        let mut motors = [None; 6];
        for (out, choice) in motors.iter_mut().zip(action.motors) {
            *out = resolve(choice)?;
        }
        Ok((representative, motors))
    }
    fn forced_checked(&self, c: RecoveryGroupChoiceV2) -> Result<Option<usize>, TrainingError> {
        match c {
            RecoveryGroupChoiceV2::Candidate(i) if usize::from(i) >= self.ordinary.len() => {
                Err(invalid())
            }
            _ => Ok(self.forced(c)),
        }
    }
}
fn valid_temperature(t: f64) -> Result<(), TrainingError> {
    if !t.is_finite() || !(1e-6..=1e6).contains(&t) {
        Err(invalid())
    } else {
        Ok(())
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum RecoveryGroupChoiceV2 {
    NoOp,
    Candidate(u16),
    RestGroup,
}
#[derive(Debug, Clone, Serialize)]
pub struct RecoveryGroupFactorV2 {
    pub outcomes: Vec<RecoveryGroupChoiceV2>,
    pub probabilities: Vec<f64>,
    pub log_probabilities: Vec<f64>,
}
impl RecoveryGroupFactorV2 {
    fn new(
        outcomes: Vec<RecoveryGroupChoiceV2>,
        logits: Vec<f64>,
        temperature: f64,
    ) -> Result<Self, TrainingError> {
        if outcomes.is_empty() {
            return Err(invalid());
        }
        let m = logits.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let z = logits
            .iter()
            .map(|x| ((x - m) / temperature).exp())
            .sum::<f64>();
        if !z.is_finite() || z <= 0. {
            return Err(invalid());
        }
        let log_probabilities: Vec<_> = logits
            .iter()
            .map(|x| (x - m) / temperature - z.ln())
            .collect();
        let probabilities = log_probabilities.iter().map(|x| x.exp()).collect();
        Ok(Self {
            outcomes,
            probabilities,
            log_probabilities,
        })
    }
    fn logp(&self, c: RecoveryGroupChoiceV2) -> Result<f64, TrainingError> {
        self.outcomes
            .iter()
            .position(|x| *x == c)
            .map(|i| self.log_probabilities[i])
            .ok_or_else(invalid)
    }
    pub fn probability(&self, c: RecoveryGroupChoiceV2) -> f64 {
        self.outcomes
            .iter()
            .position(|x| *x == c)
            .map_or(0., |i| self.probabilities[i])
    }
    fn sample(&self, u: f64) -> RecoveryGroupChoiceV2 {
        let mut sum = 0.;
        for (i, p) in self.probabilities.iter().enumerate() {
            sum += p;
            if u < sum {
                return self.outcomes[i];
            }
        }
        *self.outcomes.last().expect("nonempty validated factor")
    }
}
struct Conditional {
    p: [f64; 2],
    lp: [Option<f64>; 2],
}
#[derive(Debug, Clone, Serialize)]
pub struct RecoveryGroupProbabilitiesV2 {
    pub representative: RecoveryGroupFactorV2,
    pub channels: [Option<RecoveryGroupFactorV2>; 6],
    pub conditional_operation: [f64; 2],
    pub conditional_log_probability: [Option<f64>; 2],
    pub representative_rest_probability: f64,
    pub posture_rest_probability: f64,
    pub actual_posture_rest_probability: f64,
    pub actual_operation_probability: [f64; 2],
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryGroupJointActionV2 {
    schema: String,
    recipe: String,
    binding: RecoveryGroupBindingV2,
    pub representative: RecoveryGroupChoiceV2,
    pub motors: [RecoveryGroupChoiceV2; 6],
    pub operation: Option<u8>,
    pub temperature: f64,
    sampling_temperature_bits: u64,
    pub old_joint_log_probability: f64,
    pub seed: u32,
    pub counter: u32,
    pub draw_factors: Vec<u32>,
}
#[derive(Debug, Clone, Serialize)]
pub struct RecoveryGroupGradientV2 {
    pub(super) binding: RecoveryGroupBindingV2,
    pub ordinary: Vec<f64>,
    pub group: f64,
    pub operations: [f64; 2],
}
#[derive(Debug, Clone, Serialize)]
pub struct RecoveryGroupEvaluationV2 {
    pub joint_log_probability: f64,
    pub joint_probability: f64,
    pub factor_log_probabilities: Vec<f64>,
    pub gradient: RecoveryGroupGradientV2,
    pub selected_physical_candidates_once: Vec<u16>,
}
fn accumulate(
    g: &mut RecoveryGroupGradientV2,
    d: &RecoveryGroupFactorV2,
    selected: RecoveryGroupChoiceV2,
    t: f64,
) {
    for (o, p) in d.outcomes.iter().zip(&d.probabilities) {
        let v = (f64::from(*o == selected) - p) / t;
        match o {
            RecoveryGroupChoiceV2::Candidate(i) => g.ordinary[*i as usize] += v,
            RecoveryGroupChoiceV2::RestGroup => g.group += v,
            RecoveryGroupChoiceV2::NoOp => {}
        }
    }
}
fn draw(seed: u32, counter: u32, factor: u32) -> f64 {
    let mut v =
        seed ^ 0x4752_5031 ^ counter.wrapping_mul(0x9e3779b9) ^ factor.wrapping_mul(0x85ebca6b);
    v = (v ^ (v >> 16)).wrapping_mul(0x7feb352d);
    v = (v ^ (v >> 15)).wrapping_mul(0x846ca68b);
    v ^= v >> 16;
    (f64::from(v >> 9) + 0.5) / 8388608.
}
