//! Additive runtime seam proposal. Builds ordinary core bundles only; it does not
//! call biology, execute a source forward, restore an organism, or apply learning.
//! No old GroupedPolicyStrategy implementation and no old checkpoint type.
use super::*;
use alife_core::{ExperienceSequenceId, MotorCommandBundle, JointActionSelectionV1,
    factorized_motor_bundle_for_candidates};
const RESIDENT: &str="m2-channel-native-owned-resident-v2";
const ENVELOPE: &str="m2-channel-native-owned-envelope-v2";
const RESTORE: &str="m2-channel-native-owned-restore-v2;not-admitted";
const NUMERIC: &str="f64-logsoftmax;T[1e-6,1e6];finite-scaled;strict-positive-exp;fail-closed";
const WORK: &str="sampler-work-unpriced;no-world-dispatch-admission";

/// Explicit process-local ownership. Cannot be Deserialize'd into a live resident.
struct FreshBundleResident {
    domain: &'static str,
    owner: OrganismId,
    phenotype: PhenotypeHash,
    seed: u32,
    next_counter: u32,
    next_generation: u64,
    next_sequence: Option<ExperienceSequenceId>,
    pending: Option<StagedBundle>,
    last_closed: Option<ClosedBundle>,
}
struct StagedBundle {
    scores: ChannelScores,
    action: BundleAction,
    sequence: ExperienceSequenceId,
    bundle: MotorCommandBundle,
    joint: JointActionSelectionV1,
    consumed: bool,
}
#[derive(Serialize)]
struct ClosedBundle { sequence: ExperienceSequenceId, generation:u64, bundle_digest:[u64;4], action:BundleAction }
#[derive(Serialize)]
struct SamplerEnvelope<'a> {
    domain: &'static str,
    restore_domain: &'static str,
    policy: &'static str,
    numeric_contract: &'static str,
    work_contract: &'static str,
    owner: OrganismId,
    phenotype: PhenotypeHash,
    seed:u32,
    next_counter:u32,
    next_generation:u64,
    last_closed: &'a Option<ClosedBundle>,
    // A source-only sampler envelope is not a full organism checkpoint.
    complete_organism_checkpoint:bool,
}
impl FreshBundleResident {
    /// Fresh owner only. The enclosing future host must establish newborn/no
    /// acquired-state admission; this function cannot authorize an old save.
    fn fresh(owner:OrganismId,phenotype:PhenotypeHash,seed:u32)->Result<Self,TrainingError> {
        owner.validate()?;
        Ok(Self {domain:RESIDENT,owner,phenotype,seed,next_counter:0,next_generation:1,
            next_sequence:None,pending:None,last_closed:None})
    }
    /// Receives real pending-forward evidence from the enclosing host. No source
    /// evidence is fabricated here, and the old policy's RNG is never consulted.
    fn stage(&mut self,p:&BrainPhenotype,frame:&PerceptionFrame,
        native:&RecoveryGroupScoresV2,source:&OptionalVocalSourceV1,
        sequence:ExperienceSequenceId,t:f64)->Result<(),TrainingError> {
        if self.domain!=RESIDENT || self.pending.is_some() || p.phenotype_hash()!=self.phenotype
            || frame.organism_id()!=self.owner || self.next_sequence.is_some_and(|s|s!=sequence) {
            return Err(invalid());
        }
        sequence.validate()?;
        if sequence.raw()!=u64::from(self.next_counter)+1 {return Err(invalid());}
        source.validate_identity(self.owner,frame.tick(),self.phenotype,frame.frame_digest(),
            self.next_generation,source.activation_side)?;
        let input=OptionalVocalScoresV1::bind(p,frame,native,source.clone())?;
        // Real fresh-owner domain requires a canonical eligible posture Idle.
        // It is not forced: posture still samples Idle/Hold/Rest/other rows.
        // This guarantees at least one physically represented sampled channel.
        if !input.native_binding.enabled[4] || input.eligible_mask & (1<<input.idle)==0 {
            return Err(invalid());
        }
        let scores=ChannelScores::bind(&input)?;
        let action=scores.sample(self.seed,self.next_counter,t)?;
        let evidence=scores.evaluate(&action)?;
        let representative=action.metadata_candidate.ok_or_else(invalid)?;
        if !evidence.physical.contains(&Some(representative)) {return Err(invalid());}
        let candidate=frame.candidates().get(representative as usize).ok_or_else(invalid)?;
        // EXACT confidence, not the old host's representative-only Q16 rounding.
        let command=candidate.to_command(self.owner,candidate.sensor_confidence)?;
        let speech=if evidence.physical[3].is_some() {source.speech()?} else {None};
        let prompted=frame.sensory().language_context.heard_tokens.iter().flatten()
            .any(|t|t.source_kind==UtteranceSourceKind::Player);
        let slots=evidence.physical.map(|i|i.map_or(0,|i|i+1));
        let bundle=factorized_motor_bundle_for_candidates(self.owner,sequence,frame.tick(),frame,slots,
            &p.candidate_decoder().factorized_motor_channels(p)?,&command,representative,speech.as_ref(),prompted)?;
        let joint=JointActionSelectionV1::new(slots,&bundle)?;
        joint.validate_bundle(&bundle)?;
        // Preserve the exact sampled slots; metadata cannot add an action.
        if joint.candidate_slots()!=slots {return Err(invalid());}
        self.pending=Some(StagedBundle {scores,action,sequence,bundle,joint,consumed:false});
        Ok(())
    }
    /// Once-only handoff of the *already built* ordinary bundle. Not a world
    /// call; this seam is private and no current host invokes it. Do not expose
    /// to a live host before native qualification and work pricing are admitted.
    fn take_for_future_dispatch(&mut self)->Result<(&MotorCommandBundle,&JointActionSelectionV1),TrainingError> {
        let pending=self.pending.as_mut().ok_or_else(invalid)?;
        if pending.consumed {return Err(invalid());}
        pending.scores.evaluate(&pending.action)?;
        pending.joint.validate_bundle(&pending.bundle)?;
        pending.consumed=true;
        Ok((&pending.bundle,&pending.joint))
    }
    /// Close only after the enclosing host supplies its authoritative receipt
    /// identity. Full joint physiology/memory integration is not implemented by
    /// this sampler seam. Digests are not a substitute for a real world receipt.
    fn close_after_receipt(&mut self,sequence:ExperienceSequenceId,bundle_digest:[u64;4])->Result<(),TrainingError> {
        let pending=self.pending.as_ref().ok_or_else(invalid)?;
        if !pending.consumed || pending.sequence!=sequence || pending.bundle.canonical_digest()?!=bundle_digest {
            return Err(invalid());
        }
        let next_counter=self.next_counter.checked_add(1).ok_or_else(invalid)?;
        let next_generation=self.next_generation.checked_add(1).ok_or_else(invalid)?;
        let closed=ClosedBundle {sequence,generation:self.next_generation,bundle_digest,action:pending.action.clone()};
        self.pending=None;self.last_closed=Some(closed);self.next_counter=next_counter;self.next_generation=next_generation;
        self.next_sequence=None;
        Ok(())
    }
    /// Boundary-only provenance export. It never masquerades as restorable CP.
    fn envelope(&self)->Result<SamplerEnvelope<'_>,TrainingError> {
        if self.pending.is_some() {return Err(invalid());}
        Ok(SamplerEnvelope {domain:ENVELOPE,restore_domain:RESTORE,policy:POLICY,numeric_contract:NUMERIC,
            work_contract:WORK,owner:self.owner,phenotype:self.phenotype,seed:self.seed,next_counter:self.next_counter,
            next_generation:self.next_generation,last_closed:&self.last_closed,complete_organism_checkpoint:false})
    }
    /// Restore remains closed until full native owner/pending/body/learned banks
    /// are bound and validated. No sampler-only envelope can recover an organism.
    fn restore_unadmitted(_bytes:&[u8])->Result<Self,TrainingError> {Err(invalid())}
}
