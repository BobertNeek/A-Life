//! Fixed synthetic sampler controls. No source forward, world tick, or learning.
//! Present payloads here are fixture data, never claims of autonomous speech.
use super::*;
const CONTROL_SEED: u32 = 0x4f56_4331;
fn phenotype() -> BrainPhenotype {
    let (inputs, _) = super::super::super::tests::source();
    PhenotypeCompiler::compile_validated(
        &inputs,
        &BrainCapacityClass::n2048_grounded_drive_research(),
    )
    .unwrap()
}
fn specs() -> Vec<(u32, ActionKind, CandidateActionFamily)> {
    vec![
        (1, ActionKind::Idle, CandidateActionFamily::Idle),
        (3, ActionKind::Rest, CandidateActionFamily::Rest),
        (400, ActionKind::Vocalize, CandidateActionFamily::Other),
        (103, ActionKind::Move, CandidateActionFamily::Approach),
        (212, ActionKind::Interact, CandidateActionFamily::Contact),
        (104, ActionKind::Hold, CandidateActionFamily::Other),
        (700, ActionKind::Rest, CandidateActionFamily::Rest),
    ]
}
fn frame(spec: &[(u32, ActionKind, CandidateActionFamily)]) -> PerceptionFrame {
    frame_edit(spec, |_| {})
}
fn frame_edit(
    spec: &[(u32, ActionKind, CandidateActionFamily)],
    edit: impl FnOnce(&mut Vec<ActionCandidate>),
) -> PerceptionFrame {
    let t = Tick::new(1);
    let owner = OrganismId(1);
    let profile = SensorProfile::GroundedObjectSlotsSleepChoiceV1;
    let mut candidates = spec
        .iter()
        .enumerate()
        .map(|(i, (id, kind, family))| {
            ActionCandidate::new(
                i as u16,
                ActionId(*id),
                *kind,
                *family,
                CandidateObservationRef::None,
                ActionTarget::NONE,
                CandidateFeatureVector::zero().with_intrinsic_action_basis(*kind),
                Confidence::new(1.).unwrap(),
                NormalizedScalar::ZERO,
                DurationTicks::new(1),
                DurationTicks::new(1),
            )
            .unwrap()
        })
        .collect();
    edit(&mut candidates);
    PerceptionFrame::new(
        owner,
        t,
        profile,
        SensorySnapshot::new(
            owner,
            t,
            Vec3f::ZERO,
            SensoryChannels::ZERO,
            Default::default(),
        )
        .unwrap(),
        BodySnapshot {
            pose: Pose::IDENTITY,
            velocity: Velocity::ZERO,
        },
        HomeostaticSnapshot::baseline(t),
        candidates,
        SensorProfileProvenance::new(profile, SensoryAbiVersion::CURRENT, t).unwrap(),
        vec![],
    )
    .unwrap()
}
fn synthetic_source(
    p: &BrainPhenotype,
    f: &PerceptionFrame,
    present: bool,
) -> OptionalVocalSourceV1 {
    let speech = present.then(|| {
        SpeechMotorPayload::try_new(
            SpeechActKind::Declare,
            vec![LanguageTokenId::new(1).unwrap()],
            Confidence::new(1.).unwrap(),
        )
        .unwrap()
    });
    OptionalVocalSourceV1::from_forward(
        f.organism_id(),
        f.tick(),
        p.phenotype_hash(),
        f.frame_digest(),
        1,
        0,
        &vec![0.; p.neuron_count() as usize],
        &vec![0.; p.synapses().len()],
        speech,
    )
    .unwrap()
}
fn native(p: &BrainPhenotype, f: &PerceptionFrame) -> RecoveryGroupScoresV2 {
    RecoveryGroupScoresV2 {
        binding: RecoveryGroupBindingV2::bind(
            p,
            f,
            (1u32 << f.candidates().len()) - 1,
            [true; 6],
            0,
        )
        .unwrap(),
        ordinary: vec![0.; f.candidates().len()],
        group: 0.,
        operations: [0.; 2],
    }
}
fn fixture(
    present: bool,
) -> (
    BrainPhenotype,
    PerceptionFrame,
    RecoveryGroupScoresV2,
    OptionalVocalScoresV1,
) {
    let p = phenotype();
    let f = frame(&specs());
    let n = native(&p, &f);
    let s = OptionalVocalScoresV1::bind(&p, &f, &n, synthetic_source(&p, &f, present)).unwrap();
    (p, f, n, s)
}
#[test]
fn absent_payload_removes_only_vocal_and_legacy_keeps_its_original_choice() {
    let (_, _, native, scores) = fixture(false);
    let d = scores.probabilities(0.73).unwrap();
    assert!((d.actual_quiet_probability - 1.).abs() < 1e-12);
    assert_eq!(d.actual_vocal_probability, 0.);
    assert!(!d
        .representative
        .outcomes
        .contains(&OptionalVocalChoiceV1::Candidate(2)));
    assert_eq!(
        d.channels[3].as_ref().unwrap().outcomes,
        vec![OptionalVocalChoiceV1::Quiet]
    );
    assert_eq!(
        scores.eligible_mask(),
        native.binding.eligible_mask & !(1 << 2)
    );
    let old = native.probabilities(0.73).unwrap();
    assert_eq!(
        old.channels[3]
            .as_ref()
            .unwrap()
            .probability(RecoveryGroupChoiceV2::Candidate(2)),
        1.
    );
    let old_wire = serde_json::to_vec(&native).unwrap();
    for counter in 0..64 {
        let a = scores.sample(CONTROL_SEED, counter, 0.73).unwrap();
        assert_eq!(a.motors()[3], OptionalVocalChoiceV1::Quiet);
        let (_, m) = scores.physical_selection(&a).unwrap();
        assert_eq!(m[3], None);
        assert!(!scores
            .evaluate(&a)
            .unwrap()
            .selected_physical_candidates_once
            .contains(&2));
    }
    assert_eq!(serde_json::to_vec(&native).unwrap(), old_wire);
}
#[test]
fn present_payload_can_remain_quiet_and_representative_and_independent_vocal_are_distinct() {
    let (p, f, mut native, _) = fixture(true);
    let source = synthetic_source(&p, &f, true);
    for (dominant, expected_vocal, forced) in [(0, false, false), (2, true, true), (4, true, false)]
    {
        native.ordinary.fill(-100.);
        native.group = -100.;
        native.ordinary[dominant] = 100.;
        if dominant == 4 {
            native.ordinary[2] = 0.;
        }
        let s = OptionalVocalScoresV1::bind(&p, &f, &native, source.clone()).unwrap();
        let a = s.sample(CONTROL_SEED, 0, 1.).unwrap();
        assert_eq!(
            a.representative(),
            OptionalVocalChoiceV1::Candidate(dominant as u16)
        );
        assert_eq!(
            s.physical_selection(&a).unwrap().1[3].is_some(),
            expected_vocal
        );
        assert_eq!(!a.draw_factors().contains(&5), forced);
        if !expected_vocal {
            assert_eq!(a.motors()[3], OptionalVocalChoiceV1::Quiet);
        }
    }
}
#[test]
fn all_factors_and_complete_joint_normalize_including_representative_forcing() {
    let (_, _, _, s) = fixture(true);
    let d = s.probabilities(1.).unwrap();
    fn walk(
        s: &OptionalVocalScoresV1,
        d: &OptionalVocalProbabilitiesV1,
        rep: OptionalVocalChoiceV1,
        slot: usize,
        motors: &mut [OptionalVocalChoiceV1; 6],
        mass: f64,
        total: &mut [f64; 2],
    ) {
        if slot == 6 {
            let rest = rep == OptionalVocalChoiceV1::RestGroup
                || motors.contains(&OptionalVocalChoiceV1::RestGroup);
            let conditional = if rest {
                d.conditional_operation.iter().sum()
            } else {
                1.
            };
            total[0] += mass * conditional;
            if matches!(motors[3], OptionalVocalChoiceV1::Candidate(_)) {
                total[1] += mass * conditional;
            }
        } else if s.forced(rep) == Some(slot) {
            motors[slot] = rep;
            walk(s, d, rep, slot + 1, motors, mass, total);
        } else if let Some(f) = &d.channels[slot] {
            for (&c, p) in f.outcomes.iter().zip(&f.probabilities) {
                motors[slot] = c;
                walk(s, d, rep, slot + 1, motors, mass * p, total);
            }
        } else {
            motors[slot] = OptionalVocalChoiceV1::NoOp;
            walk(s, d, rep, slot + 1, motors, mass, total);
        }
    }
    for f in std::iter::once(&d.representative).chain(d.channels.iter().flatten()) {
        assert!((f.probabilities.iter().sum::<f64>() - 1.).abs() < 1e-12);
    }
    let mut mass = [0.; 2];
    for (&rep, p) in d
        .representative
        .outcomes
        .iter()
        .zip(&d.representative.probabilities)
    {
        walk(
            &s,
            &d,
            rep,
            0,
            &mut [OptionalVocalChoiceV1::NoOp; 6],
            *p,
            &mut mass,
        );
    }
    assert!((mass[0] - 1.).abs() < 1e-12);
    assert!((mass[1] - d.actual_vocal_probability).abs() < 1e-12);
    assert!((d.actual_vocal_probability - 7. / 12.).abs() < 1e-12);
    assert!((d.actual_quiet_probability - 5. / 12.).abs() < 1e-12);
}
#[test]
fn canonical_idle_rejects_missing_alias_and_wrong_family_without_touching_other_rows() {
    let p = phenotype();
    for variant in 0..4 {
        let mut spec = specs();
        match variant {
            0 => {
                spec.remove(0);
            }
            1 => spec[0].0 = 99,
            2 => {
                // This malformed pair is rejected by the shared constructor,
                // before a valid frame can reach the optional binder.
                assert!(matches!(
                    ActionCandidate::new(
                        0,
                        ActionId(1),
                        ActionKind::Idle,
                        CandidateActionFamily::Other,
                        CandidateObservationRef::None,
                        ActionTarget::NONE,
                        CandidateFeatureVector::zero()
                            .with_intrinsic_action_basis(ActionKind::Idle),
                        Confidence::new(1.).unwrap(),
                        NormalizedScalar::ZERO,
                        DurationTicks::new(1),
                        DurationTicks::new(1),
                    ),
                    Err(alife_core::ScaffoldContractError::InvalidActionCandidate)
                ));
                continue;
            }
            _ => spec.push((99, ActionKind::Idle, CandidateActionFamily::Idle)),
        }
        let f = frame(&spec);
        let n = native(&p, &f);
        assert!(OptionalVocalScoresV1::bind(&p, &f, &n, synthetic_source(&p, &f, true)).is_err());
    }
    for variant in 0..4 {
        let malformed = frame_edit(&specs(), |c| match variant {
            0 => c[0].features.0[0] = 0.25,
            1 => c[0].sensor_confidence = Confidence::new(0.5).unwrap(),
            2 => c[0].required_effort = NormalizedScalar::new(0.25).unwrap(),
            _ => {
                c[0].min_duration = DurationTicks::new(2);
                c[0].max_duration = DurationTicks::new(2);
            }
        });
        let malformed_native = native(&p, &malformed);
        assert!(OptionalVocalScoresV1::bind(
            &p,
            &malformed,
            &malformed_native,
            synthetic_source(&p, &malformed, true)
        )
        .is_err());
    }
    let (_, _, native, s) = fixture(false);
    assert_eq!(
        s.eligible_mask() & (1 << 5),
        native.binding.eligible_mask & (1 << 5)
    ); // NoPosture/Other survives.
    for i in [3, 4, 5] {
        assert!(s.eligible_mask() & (1 << i) != 0);
    }
}
#[test]
fn exact_bits_rng_temperature_output_and_masks_are_bound() {
    let (_, _, native, s) = fixture(true);
    let a = s.sample(CONTROL_SEED, 9, 0.73).unwrap();
    s.validate_sampling_context(&a, CONTROL_SEED, 9, 0.73)
        .unwrap();
    assert!(s
        .validate_sampling_context(&a, CONTROL_SEED ^ 1, 9, 0.73)
        .is_err());
    assert!(s
        .validate_sampling_context(&a, CONTROL_SEED, 10, 0.73)
        .is_err());
    assert!(s
        .validate_sampling_context(&a, CONTROL_SEED, 9, 0.74)
        .is_err());
    for t in [0., -1., f64::NAN, f64::INFINITY] {
        assert!(s.sample(CONTROL_SEED, 9, t).is_err());
    }
    let mut changed = s.source.clone();
    changed.output_digest[0] ^= 1;
    assert!(s.validate_source(&changed).is_err());
    changed = s.source.clone();
    changed.dispatch_generation += 1;
    assert!(s.validate_source(&changed).is_err());
    changed = s.source.clone();
    changed.frame.0[0] ^= 1;
    assert!(s.validate_source(&changed).is_err());
    let mut wrong = s.clone();
    wrong.eligible_mask ^= 1 << 2;
    assert!(wrong.probabilities(1.).is_err());
    let mut changed_native = native.clone();
    changed_native.ordinary[0] = 0.1;
    assert!(s.validate_native(&changed_native).is_err());
    // Ordinary capability/attempt masks can remove speech, never create it.
    let (p, f, mut absent_effector, _) = fixture(true);
    let mut capabilities = [true; 6];
    capabilities[3] = false;
    absent_effector.binding = RecoveryGroupBindingV2::bind(&p, &f, 0x7f, capabilities, 0).unwrap();
    let disabled =
        OptionalVocalScoresV1::bind(&p, &f, &absent_effector, synthetic_source(&p, &f, true))
            .unwrap();
    assert!(disabled.probabilities(1.).unwrap().channels[3].is_none());
    assert_eq!(
        disabled
            .physical_selection(&disabled.sample(CONTROL_SEED, 9, 1.).unwrap())
            .unwrap()
            .1[3],
        None
    );
    let mut masked = native.clone();
    masked.binding = RecoveryGroupBindingV2::bind(&p, &f, 0x7f & !(1 << 2), [true; 6], 0).unwrap();
    let removed =
        OptionalVocalScoresV1::bind(&p, &f, &masked, synthetic_source(&p, &f, true)).unwrap();
    assert_eq!(
        removed.probabilities(1.).unwrap().channels[3]
            .as_ref()
            .unwrap()
            .outcomes,
        vec![OptionalVocalChoiceV1::Quiet]
    );
    let wire = serde_json::to_vec(&(s.clone(), a.clone())).unwrap();
    let (cold, cold_action): (OptionalVocalScoresV1, OptionalVocalActionV1) =
        serde_json::from_slice(&wire).unwrap();
    assert_eq!(cold, s);
    assert_eq!(cold_action, a);
    assert_eq!(
        cold.sample(CONTROL_SEED, 10, 0.73).unwrap(),
        s.sample(CONTROL_SEED, 10, 0.73).unwrap()
    );
    assert!(
        serde_json::from_slice::<RecoveryGroupJointActionV2>(&serde_json::to_vec(&a).unwrap())
            .is_err()
    );
    let mut malformed = a.clone();
    malformed.motors[3] = OptionalVocalChoiceV1::NoOp;
    assert!(s.evaluate(&malformed).is_err());
}
