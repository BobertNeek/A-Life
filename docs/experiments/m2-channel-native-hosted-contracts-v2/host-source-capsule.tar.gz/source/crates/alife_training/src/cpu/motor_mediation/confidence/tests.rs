use super::*;
use std::sync::OnceLock;
pub(super) fn source() -> (PhenotypeCompilerInputs, FoundationWeightAsset) {
    static SOURCE: OnceLock<(PhenotypeCompilerInputs, FoundationWeightAsset)> = OnceLock::new();
    SOURCE.get_or_init(|| source_with_heads(4)).clone()
}
fn source_with_heads(head_count: u8) -> (PhenotypeCompilerInputs, FoundationWeightAsset) {
    let g = BrainGenome::scaffold(
        0x4752_5031,
        BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID,
    );
    let a = g.cognitive_architecture();
    let heads = alife_core::genome::CognitiveArchitectureGenomeParameters::try_new_v1(
        a.attention_capacity(),
        a.active_concept_limit(),
        a.active_gap_limit(),
        a.predictor_capacity(),
        a.predictor_learning_rate(),
        head_count,
        a.motor_head_width(),
        a.dendritic_branch_capacity(),
        a.structural_candidate_budget(),
        a.structural_edit_budget(),
        a.sleep_trigger_threshold(),
        a.sleep_replay_rate(),
        a.sleep_consolidation_rate(),
        a.attention_learning_rate(),
        a.concept_learning_rate(),
        a.motor_learning_rate(),
        a.structural_learning_rate(),
    )
    .unwrap();
    let g = g.with_cognitive_architecture(heads).unwrap();
    let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
    let (p, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
        g,
        d,
        SensorProfile::GroundedObjectSlotsV1,
    )
    .unwrap();
    let a = FoundationWeightAsset::from_trained_weights(
        &p,
        p.synapses().iter().map(|s| s.genetic_weight()).collect(),
        TrainingStageManifest::bootstrap(),
    )
    .unwrap();
    let (_, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis_candidate(
        i.genome().clone(),
        i.development().clone(),
        a.clone(),
    )
    .unwrap();
    (i, a)
}

fn fresh() -> RecoveryGroupDetachedCpuV2 {
    let (i, a) = source();
    RecoveryGroupDetachedCpuV2::fresh(&i, &a, MediationModeV1::Full).unwrap()
}
fn specs() -> Vec<(u32, ActionKind, CandidateActionFamily)> {
    vec![
        (1, ActionKind::Idle, CandidateActionFamily::Idle),
        (3, ActionKind::Rest, CandidateActionFamily::Rest),
        (400, ActionKind::Vocalize, CandidateActionFamily::Other),
        (103, ActionKind::Move, CandidateActionFamily::Approach),
        (212, ActionKind::Interact, CandidateActionFamily::Contact),
        (104, ActionKind::Hold, CandidateActionFamily::Other),
        (700, ActionKind::Rest, CandidateActionFamily::Rest),
    ]
}
fn try_make_frame(
    spec: &[(u32, ActionKind, CandidateActionFamily)],
    fatigue: f32,
    pressure: f32,
) -> Result<PerceptionFrame, ScaffoldContractError> {
    let t = Tick::new(1);
    let profile = SensorProfile::GroundedObjectSlotsSleepChoiceV1;
    let cs = spec
        .iter()
        .enumerate()
        .map(|(i, (id, k, f))| {
            ActionCandidate::new(
                i as u16,
                ActionId(*id),
                *k,
                *f,
                CandidateObservationRef::None,
                ActionTarget::NONE,
                CandidateFeatureVector::zero().with_intrinsic_action_basis(*k),
                Confidence::new(1.).unwrap(),
                NormalizedScalar::new(0.).unwrap(),
                DurationTicks::new(1),
                DurationTicks::new(1),
            )
            .unwrap()
        })
        .collect();
    let mut home = HomeostaticSnapshot::baseline(t);
    home.drives.fatigue = fatigue;
    home.hormones.sleep_pressure = pressure;
    PerceptionFrame::new(
        OrganismId(1),
        t,
        profile,
        SensorySnapshot::new(
            OrganismId(1),
            t,
            Vec3f::ZERO,
            SensoryChannels::ZERO,
            Default::default(),
        )
        .unwrap(),
        BodySnapshot {
            pose: Pose::IDENTITY,
            velocity: Velocity::ZERO,
        },
        home,
        cs,
        SensorProfileProvenance::new(profile, SensoryAbiVersion::CURRENT, t).unwrap(),
        vec![],
    )
}
fn make_frame(
    spec: &[(u32, ActionKind, CandidateActionFamily)],
    fatigue: f32,
    pressure: f32,
) -> PerceptionFrame {
    try_make_frame(spec, fatigue, pressure).unwrap()
}
pub(super) fn frame() -> PerceptionFrame {
    make_frame(&specs(), 0.2, 0.2)
}
pub(super) fn tick(e: &RecoveryGroupDetachedCpuV2, f: &PerceptionFrame) -> TrainingReplayTick {
    let derived = prepare_sleep_choice_grounded_drive_features_v1(f).unwrap();
    let cs = f
        .candidates()
        .iter()
        .enumerate()
        .map(|(i, c)| {
            let mut x = [0.; 54];
            x[..24].copy_from_slice(&c.features.0);
            x[36..46].copy_from_slice(&derived[i]);
            let family = e
                .source()
                .candidate_decoder()
                .families()
                .iter()
                .find(|x| x.family() == c.family)
                .unwrap();
            TrainingReplayCandidate {
                family: c.family,
                decoder_inputs: x,
                innate_bias: family.innate_contribution(f.homeostasis().drives, c.features),
            }
        })
        .collect();
    TrainingReplayTick {
        encoded_inputs: (0..2048).map(|i| (i % 13) as f32 / 31. - 0.1).collect(),
        projection_gain: 0.5,
        local_threshold_shift: 0.25,
        microstep_count: 4,
        enabled_routes: vec![true; e.source().projections().len()],
        effective_weight_offsets: vec![0.; e.source().synapses().len()],
        structural_synapses: vec![],
        candidates: cs,
    }
}
fn run(e: &mut RecoveryGroupDetachedCpuV2, f: &PerceptionFrame) -> RecoveryGroupProbeResultV2 {
    let t = tick(e, f);
    let rows = e.bind_rows(f, &t).unwrap();
    e.step(
        f,
        t,
        &rows,
        MediationModulationV1::default(),
        u32::MAX >> (32 - f.candidates().len()),
        [true; 6],
        u64::MAX,
    )
    .unwrap()
}
fn synthetic(mask: u32, effectors: [bool; 6]) -> RecoveryGroupScoresV2 {
    let e = fresh();
    RecoveryGroupScoresV2 {
        binding: RecoveryGroupBindingV2::bind(e.source(), &frame(), mask, effectors, 0).unwrap(),
        ordinary: vec![0.; 7],
        group: 0.,
        operations: [0.; 2],
    }
}
fn close(a: f64, b: f64, t: f64) {
    assert!((a - b).abs() <= t, "{a} vs {b}, tol {t}");
}
#[test]
fn literal_neutral_seven_candidate_prior_and_no_duplicate_noops() {
    let s = synthetic(127, [true; 6]);
    let d = s.probabilities(1.).unwrap();
    assert_eq!(d.representative.outcomes.len(), 6);
    assert_eq!(d.channels[4].as_ref().unwrap().outcomes.len(), 2);
    close(d.representative_rest_probability, 1. / 6., 1e-15);
    close(d.posture_rest_probability, 0.5, 1e-15);
    close(d.actual_posture_rest_probability, 5. / 12., 1e-15);
    for channel in [0, 2, 3] {
        assert_eq!(d.channels[channel].as_ref().unwrap().outcomes.len(), 1);
    }
    assert!(d.channels[1].is_none());
    assert!(d.channels[5].is_none());
    // Legacy ungrouped neutral mass: 2/7 + (3/7)*(2/3) = 4/7.
    assert!(d.actual_posture_rest_probability < 4. / 7.);
}
#[test]
fn conditional_preference_temperature_and_operation_count_leave_rest_mass_invariant() {
    let mut s = synthetic(127, [true; 6]);
    s.group = 0.7;
    s.ordinary[5] = -0.2;
    for t in [1e-6, 0.1, 0.7, 1., 3., 40., 1e6] {
        let expected = s.probabilities(t).unwrap();
        for z in [-1000., -40., 0., 40., 1000.] {
            s.operations = [z, -z];
            let d = s.probabilities(t).unwrap();
            assert_eq!(
                d.actual_posture_rest_probability,
                expected.actual_posture_rest_probability
            );
            assert_eq!(
                d.representative_rest_probability,
                expected.representative_rest_probability
            );
            close(d.conditional_operation.iter().sum(), 1., 1e-12);
        }
        let mut one = synthetic(127 & !(1 << 6), [true; 6]);
        one.ordinary = s.ordinary.clone();
        one.group = s.group;
        one.operations = s.operations;
        let d = one.probabilities(t).unwrap();
        assert_eq!(
            d.actual_posture_rest_probability,
            expected.actual_posture_rest_probability
        );
        assert_eq!(d.conditional_log_probability, [Some(0.), None]);
    }
}
#[test]
fn masking_capabilities_and_malformed_identity_fail_closed() {
    let mut s = synthetic(127 & !(1 << 1) & !(1 << 6), [true; 6]);
    let d = s.probabilities(1.).unwrap();
    assert_eq!(d.actual_posture_rest_probability, 0.);
    let mut effectors = [true; 6];
    effectors[4] = false;
    s = synthetic(127, effectors);
    assert!(s.probabilities(1.).unwrap().channels[4].is_none());
    assert_eq!(
        s.probabilities(1.).unwrap().actual_posture_rest_probability,
        0.
    );
    assert!(!s
        .probabilities(1.)
        .unwrap()
        .representative
        .outcomes
        .contains(&RecoveryGroupChoiceV2::Candidate(0)));
    let e = fresh();
    assert!(RecoveryGroupBindingV2::bind(e.source(), &frame(), 128, [true; 6], 0).is_err());
    assert!(RecoveryGroupBindingV2::bind(e.source(), &frame(), 127, [false; 6], 0).is_err());
    let mut duplicate = specs();
    duplicate[6].0 = 3;
    let f = make_frame(&duplicate, 0.2, 0.2);
    assert!(RecoveryGroupBindingV2::bind(e.source(), &f, 127, [true; 6], 0).is_err());
    for (index, id, kind, family) in [
        (6, 701, ActionKind::Rest, CandidateActionFamily::Rest),
        (6, 700, ActionKind::Hold, CandidateActionFamily::Other),
        (5, 104, ActionKind::Rest, CandidateActionFamily::Rest),
    ] {
        let mut sp = specs();
        sp[index] = (id, kind, family);
        if let Ok(result) = try_make_frame(&sp, 0.2, 0.2) {
            assert!(RecoveryGroupBindingV2::bind(e.source(), &result, 127, [true; 6], 0).is_err());
        }
    }
}
#[test]
fn exact_joint_logp_gradient_and_no_double_operation_or_credit() {
    let mut s = synthetic(127, [true; 6]);
    s.ordinary = [0.1, 99., -0.3, 0.5, -0.4, 0.8, -99.].to_vec();
    s.group = 0.25;
    s.operations = [0.7, -0.2];
    for t in [0.4, 1., 2.5] {
        let mut representative = false;
        let mut secondary = false;
        for counter in 0..100 {
            let a = s.sample(42, counter, t).unwrap();
            let e = s.evaluate(&a).unwrap();
            assert_eq!(a, s.sample(42, counter, t).unwrap());
            close(
                e.factor_log_probabilities.iter().sum(),
                e.joint_log_probability,
                1e-12,
            );
            assert!(
                a.draw_factors
                    .iter()
                    .filter(|f| **f == 1 || **f == 8)
                    .count()
                    <= 1
            );
            let mut unique = e.selected_physical_candidates_once.clone();
            unique.sort();
            unique.dedup();
            assert_eq!(unique.len(), e.selected_physical_candidates_once.len());
            representative |= a.representative == RecoveryGroupChoiceV2::RestGroup;
            secondary |= a.representative != RecoveryGroupChoiceV2::RestGroup
                && a.motors[4] == RecoveryGroupChoiceV2::RestGroup;
            for i in 0..10 {
                let h = 1e-5;
                let mut plus = s.clone();
                let mut minus = s.clone();
                let expected = if i < 7 {
                    plus.ordinary[i] += h;
                    minus.ordinary[i] -= h;
                    e.gradient.ordinary[i]
                } else if i == 7 {
                    plus.group += h;
                    minus.group -= h;
                    e.gradient.group
                } else {
                    plus.operations[i - 8] += h;
                    minus.operations[i - 8] -= h;
                    e.gradient.operations[i - 8]
                };
                let fd = (plus.evaluate(&a).unwrap().joint_log_probability
                    - minus.evaluate(&a).unwrap().joint_log_probability)
                    / (2. * h);
                close(fd, expected, 1e-8);
            }
        }
        assert!(representative && secondary);
    }
}
#[test]
fn source_once_fresh_envelope_native_common_need_and_restore() {
    let (i, a) = source();
    let mut e = fresh();
    let f = frame();
    let t = tick(&e, &f);
    let rows = e.bind_rows(&f, &t).unwrap();
    let before = e.snapshot();
    assert!(e
        .step(
            &f,
            t.clone(),
            &rows,
            MediationModulationV1::default(),
            127,
            [true; 6],
            0
        )
        .is_err());
    assert_eq!(before, e.snapshot());
    let mut control = MediationDetachedCpuV1::fresh(&i, &a, MediationModeV1::Full).unwrap();
    let cr = control.bind_rows(&f, &t).unwrap();
    let c = control
        .step(&f, t, &cr, MediationModulationV1::default(), u64::MAX)
        .unwrap();
    let r = run(&mut e, &f);
    assert_eq!(r.receipt.core.source_execution_count, 1);
    assert_eq!(
        r.source_evaluation.final_activations,
        c.source_evaluation.final_activations
    );
    assert_eq!(r.receipt.core.core_logits, c.receipt.core_logits);
    assert_eq!(r.receipt.extension_activations.len(), 16);
    assert_eq!(r.receipt.group_components[2..4], [0., 0.]);
    assert_eq!(
        r.receipt.extension_arithmetic_q24,
        1016 + r.receipt.extension_source_products * 4
    );
    let mut restored =
        RecoveryGroupDetachedCpuV2::restore(&i, &a, MediationModeV1::Full, e.snapshot()).unwrap();
    let x = run(&mut e, &f);
    let y = run(&mut restored, &f);
    assert_eq!(
        serde_json::to_vec(&x.receipt).unwrap(),
        serde_json::to_vec(&y.receipt).unwrap()
    );
    assert!(serde_json::from_str::<RecoveryGroupSnapshotV2>(
        &serde_json::to_string(&control.snapshot()).unwrap()
    )
    .is_err());
    assert!(serde_json::from_str::<MediationDetachedSnapshotV1>(
        &serde_json::to_string(&e.snapshot()).unwrap()
    )
    .is_err());
    let mut bad = e.snapshot();
    bad.recipe = "old".into();
    assert!(RecoveryGroupDetachedCpuV2::restore(&i, &a, MediationModeV1::Full, bad).is_err());
    assert!(e.actor_optimization().is_err());
    assert!(e.waking_outcome_plasticity().is_err());
    assert!(RecoveryGroupDetachedCpuV2::fresh(&i, &a, MediationModeV1::DirectSource).is_err());
    let low = run(&mut fresh(), &make_frame(&specs(), 0., 0.));
    let high = run(&mut fresh(), &make_frame(&specs(), 0., 1.));
    assert!(low.receipt.group_components[4] <= 0.);
    assert!(high.receipt.group_components[4] > 0.);
    assert!(high.receipt.scores.group > low.receipt.scores.group);
    assert!(high.receipt.scores.operations[0] > high.receipt.scores.operations[1]);
    assert!(low.receipt.scores.operations[0] < low.receipt.scores.operations[1]);
}
#[test]
fn native_group_and_conditional_chain_source_memory_gradients() {
    let f = frame();
    let mut e = fresh();
    let mut t = tick(&e, &f);
    // Synthetic recall feature values, not episodes or fabricated group memory.
    for i in [1, 6] {
        t.candidates[i].decoder_inputs[24] = if i == 1 { 0.2 } else { -0.1 };
    }
    let rows = e.bind_rows(&f, &t).unwrap();
    let r = e
        .step(
            &f,
            t.clone(),
            &rows,
            MediationModulationV1::default(),
            127,
            [true; 6],
            u64::MAX,
        )
        .unwrap();
    let a = (0..100)
        .map(|n| r.receipt.scores.sample(75, n, 1.7).unwrap())
        .find(|a| a.operation.is_some())
        .unwrap();
    let g = r.receipt.scores.evaluate(&a).unwrap().gradient;
    let dg = r.decoder_log_probability_gradient(&g).unwrap();
    let mut tested = [false; 2];
    for (j, row) in e.source().synapses().iter().enumerate() {
        let CompiledSynapseKind::Decoder(d) = row.kind() else {
            continue;
        };
        if d.family() != CandidateActionFamily::Rest {
            continue;
        }
        let k = match d.head() {
            DecoderHeadKind::ActionCandidate => 0,
            DecoderHeadKind::MemoryContext => 1,
            _ => continue,
        };
        if tested[k] || dg[j].abs() < 1e-5 {
            continue;
        }
        let h = 0.002;
        let run_weight = |delta: f32| {
            let mut q = fresh();
            q.core.weights[j] += delta;
            let rr = q.bind_rows(&f, &t).unwrap();
            q.step(
                &f,
                t.clone(),
                &rr,
                MediationModulationV1::default(),
                127,
                [true; 6],
                u64::MAX,
            )
            .unwrap()
        };
        let plus = run_weight(h);
        let minus = run_weight(-h);
        let fd = (plus
            .receipt
            .scores
            .evaluate(&a)
            .unwrap()
            .joint_log_probability
            - minus
                .receipt
                .scores
                .evaluate(&a)
                .unwrap()
                .joint_log_probability)
            / f64::from(2. * h);
        close(fd, dg[j], 0.0002);
        tested[k] = true;
    }
    assert!(tested[0]);
    assert!(tested[1]);
    assert!(!e.source().synapses().iter().any(|s|matches!(s.kind(),CompiledSynapseKind::Decoder(d)if d.head()==DecoderHeadKind::CognitiveContext)));
}
#[test]
fn candidate_capacity_order_rng_and_receipt_rejection() {
    let mut sp = specs();
    while sp.len() < 32 {
        sp.push((
            900 + sp.len() as u32,
            ActionKind::Move,
            CandidateActionFamily::Approach,
        ));
    }
    let f = make_frame(&sp, 0.2, 0.2);
    let mut e = fresh();
    let r = run(&mut e, &f);
    assert_eq!(r.receipt.scores.ordinary.len(), 32);
    assert_eq!(r.receipt.core.work.neuron_updates, 444);
    let a = r.receipt.scores.sample(44, 8, 1.).unwrap();
    assert!(r.receipt.scores.evaluate(&a).is_ok());
    let mut wrong = a.clone();
    wrong.temperature = 2.;
    assert!(r.receipt.scores.evaluate(&wrong).is_err());
    wrong = a.clone();
    wrong.operation = Some(2);
    assert!(r.receipt.scores.evaluate(&wrong).is_err());
    wrong = a.clone();
    wrong.draw_factors.push(8);
    assert!(r.receipt.scores.evaluate(&wrong).is_err());
    assert!(
        serde_json::from_str::<crate::PpoJointAction>(&serde_json::to_string(&a).unwrap()).is_err()
    );
    let mut rev = sp.clone();
    rev.reverse();
    let f2 = make_frame(&rev, 0.2, 0.2);
    let q = run(&mut fresh(), &f2);
    assert_eq!(
        r.receipt.scores.group.to_bits(),
        q.receipt.scores.group.to_bits()
    );
    for (i, c) in f.candidates().iter().enumerate() {
        let j = f2
            .candidates()
            .iter()
            .position(|x| x.action_id == c.action_id)
            .unwrap();
        assert_eq!(r.receipt.scores.ordinary[i], q.receipt.scores.ordinary[j]);
    }
    for counter in 0..30 {
        let a = r.receipt.scores.sample(33, counter, 0.8).unwrap();
        let b = q.receipt.scores.sample(33, counter, 0.8).unwrap();
        let id = |a: RecoveryGroupChoiceV2, f: &PerceptionFrame| match a {
            RecoveryGroupChoiceV2::Candidate(i) => f.candidates()[i as usize].action_id.raw(),
            RecoveryGroupChoiceV2::RestGroup => u32::MAX,
            RecoveryGroupChoiceV2::NoOp => 0,
        };
        assert_eq!(id(a.representative, &f), id(b.representative, &f2));
        assert_eq!(a.operation, b.operation);
    }
    assert!(r
        .receipt
        .scores
        .validate_context(e.source(), &f2, u32::MAX, [true; 6], 0)
        .is_err());
}
#[test]
fn malformed_gradient_and_forged_action_binding_reject_without_panics() {
    let mut r = run(&mut fresh(), &frame());
    let a = r.receipt.scores.sample(1, 2, 1.).unwrap();
    let g = r.receipt.scores.evaluate(&a).unwrap().gradient;
    r.ordinary_decoder_derivatives[0].clear();
    assert!(r.decoder_log_probability_gradient(&g).is_err());
    let r = run(&mut fresh(), &frame());
    let mut g = r.receipt.scores.evaluate(&a).unwrap().gradient;
    g.group = f64::NAN;
    assert!(r.decoder_log_probability_gradient(&g).is_err());
    let mut wire = serde_json::to_value(&a).unwrap();
    wire["binding"]["operations"] = serde_json::json!([5, 6]);
    let forged: RecoveryGroupJointActionV2 = serde_json::from_value(wire).unwrap();
    assert!(r.receipt.scores.evaluate(&forged).is_err());
}
#[test]
fn physically_absent_operations_empty_channels_idle_and_unsupported_gesture() {
    let p = fresh();
    for remove in [vec![6], vec![1], vec![1, 6]] {
        let sp: Vec<_> = specs()
            .into_iter()
            .enumerate()
            .filter(|(i, _)| !remove.contains(i))
            .map(|(_, v)| v)
            .collect();
        let f = make_frame(&sp, 0.2, 0.2);
        let s = RecoveryGroupScoresV2 {
            binding: RecoveryGroupBindingV2::bind(
                p.source(),
                &f,
                u32::MAX >> (32 - sp.len()),
                [true; 6],
                0,
            )
            .unwrap(),
            ordinary: vec![0.; sp.len()],
            group: 0.,
            operations: [4., -4.],
        };
        let d = s.probabilities(1.).unwrap();
        if remove.len() == 2 {
            assert_eq!(d.actual_posture_rest_probability, 0.);
        } else {
            close(d.actual_posture_rest_probability, 5. / 12., 1e-15);
            assert_eq!(
                d.conditional_operation.iter().filter(|x| **x == 1.).count(),
                1
            );
        }
    }
    assert!(try_make_frame(
        &[(50, ActionKind::Gesture, CandidateActionFamily::Other)],
        0.2,
        0.2
    )
    .is_err());
    let sp = vec![(1, ActionKind::Idle, CandidateActionFamily::Idle)];
    let f = make_frame(&sp, 0.2, 0.2);
    let s = RecoveryGroupScoresV2 {
        binding: RecoveryGroupBindingV2::bind(p.source(), &f, 1, [true; 6], 0).unwrap(),
        ordinary: vec![0.],
        group: 0.,
        operations: [0.; 2],
    };
    let a = s.sample(7, 9, 1.).unwrap();
    assert_eq!(a.motors[4], RecoveryGroupChoiceV2::Candidate(0));
    assert_eq!(a.draw_factors, vec![0]);
    for c in [0, 2, 3] {
        assert_eq!(a.motors[c], RecoveryGroupChoiceV2::NoOp);
    }
    close(s.evaluate(&a).unwrap().joint_probability, 1., 0.);
}
#[test]
fn native_extension_all_context_and_common_jacobians_match_finite_differences() {
    let e = fresh();
    let r = run(&mut fresh(), &frame());
    let m = MediationModulationV1::default();
    let binding = &r.receipt.scores.binding;
    let mut base = r.receipt.core.clone();
    let common = [0.3, -0.2, 0., 0., 0.1];
    let calculate = |base: &MediationReceiptV1, common: [f32; 5]| {
        extension_forward(&e.recipe, &mut e.snapshot(), base, binding, common, m).unwrap()
    };
    let (g, j, z, oj, pj) = calculate(&base, common);
    assert!(g.is_finite() && z.iter().all(|x| x.is_finite()));
    for port in 0..5 {
        let h = 0.001;
        let mut plus = common;
        let mut minus = common;
        plus[port] += h;
        minus[port] -= h;
        let fd = (calculate(&base, plus).0 - calculate(&base, minus).0) / (2. * h);
        close(f64::from(fd), f64::from(j[port]), 0.0004);
    }
    // Port-pair activation finite difference chains exactly to M/C raw values;
    // these are synthetic arithmetic ports, not source cognitive rows.
    for o in 0..2 {
        let c = binding.operations[o].unwrap();
        for port in [2, 3] {
            let h = 0.001;
            let v = 0.2;
            let mut q = base.clone();
            let set = |q: &mut MediationReceiptV1, value: f32| {
                let b = m.offset - m.threshold;
                q.port_activations[c][port] = [
                    (b + value / DIVISORS[port]).tanh(),
                    (b - value / DIVISORS[port]).tanh(),
                ];
                q.port_clip_slopes[c][port] = [1.; 2];
            };
            set(&mut q, v);
            let expected = calculate(&q, common).3[o][port - 2];
            set(&mut q, v + h);
            let p = calculate(&q, common).2[o];
            set(&mut q, v - h);
            let n = calculate(&q, common).2[o];
            close(f64::from((p - n) / (2. * h)), f64::from(expected), 0.0004);
        }
    }
    let h = 0.001;
    base.appended_activations[57] += h;
    let p = calculate(&base, common).2;
    base.appended_activations[57] -= 2. * h;
    let n = calculate(&base, common).2;
    for o in 0..2 {
        close(
            f64::from((p[o] - n[o]) / (2. * h)),
            f64::from(pj[o]),
            0.0004,
        );
    }
    let _ = oj;
}
#[test]
fn pressure_joint_derivative_includes_common_and_conditional_native_chain() {
    for pressure in [0.2, 0.9] {
        let f = make_frame(&specs(), 0., pressure);
        let r = run(&mut fresh(), &f);
        let action = (0..100)
            .map(|i| r.receipt.scores.sample(32, i, 1.3).unwrap())
            .find(|a| a.operation.is_some())
            .unwrap();
        let gradient = r.receipt.scores.evaluate(&action).unwrap().gradient;
        let analytic = r
            .frozen_source_pressure_log_probability_derivative(&gradient)
            .unwrap();
        let h = 0.0005;
        let evaluate = |p: f32| {
            let x = run(&mut fresh(), &make_frame(&specs(), 0., p));
            let mut s = r.receipt.scores.clone();
            s.group = x.receipt.scores.group;
            s.operations = x.receipt.scores.operations;
            s.evaluate(&action).unwrap().joint_log_probability
        };
        close(
            (evaluate(pressure + h) - evaluate(pressure - h)) / f64::from(2. * h),
            analytic,
            0.001,
        );
    }
}
#[test]
fn common_source_need_cannot_wash_out_conditional_preference() {
    let e = fresh();
    let r = run(&mut fresh(), &make_frame(&specs(), 0., 0.));
    let binding = &r.receipt.scores.binding;
    let mut previous = f32::NEG_INFINITY;
    let mut conditional = None;
    for source in [-1e6, -32., -8., 0., 8., 32., 1e6] {
        let (g, _, z, _, _) = extension_forward(
            &e.recipe,
            &mut e.snapshot(),
            &r.receipt.core,
            binding,
            [source, 0., 0., 0., 0.],
            MediationModulationV1::default(),
        )
        .unwrap();
        assert!(g >= previous);
        previous = g;
        if let Some(old) = conditional {
            assert_eq!(z, old);
        }
        conditional = Some(z);
        assert!(z[1] > z[0]);
    }
    let mut previous = f32::NEG_INFINITY;
    for need in [-1e6, -32., -1., 0., 0.1, 0.5, 1., 32., 1e6] {
        let (g, _, z, _, _) = extension_forward(
            &e.recipe,
            &mut e.snapshot(),
            &r.receipt.core,
            binding,
            [0., 0., 0., 0., need],
            MediationModulationV1::default(),
        )
        .unwrap();
        assert!(g >= previous);
        previous = g;
        assert_eq!(z, conditional.unwrap());
    }
}
#[test]
fn disabled_compiled_capability_and_bad_mask_preserve_state_and_rng() {
    let (i, a) = source_with_heads(1);
    let e = RecoveryGroupDetachedCpuV2::fresh(&i, &a, MediationModeV1::Full).unwrap();
    let binding = RecoveryGroupBindingV2::bind(e.source(), &frame(), 127, [true; 6], 0).unwrap();
    let s = RecoveryGroupScoresV2 {
        binding,
        ordinary: vec![0.; 7],
        group: 9.,
        operations: [9., -9.],
    };
    let d = s.probabilities(1.).unwrap();
    assert_eq!(
        d.representative.outcomes,
        vec![RecoveryGroupChoiceV2::Candidate(3)]
    );
    assert_eq!(d.actual_posture_rest_probability, 0.);
    let mut e = fresh();
    let f = frame();
    let t = tick(&e, &f);
    let rows = e.bind_rows(&f, &t).unwrap();
    let before = e.snapshot();
    assert!(e
        .step(
            &f,
            t,
            &rows,
            MediationModulationV1::default(),
            128,
            [true; 6],
            u64::MAX
        )
        .is_err());
    assert_eq!(e.snapshot(), before);
    let s = synthetic(127, [true; 6]);
    let original = s.sample(55, 8, 1.).unwrap();
    let mut invalid = original.clone();
    invalid.motors[4] = RecoveryGroupChoiceV2::Candidate(65535);
    assert!(s.evaluate(&invalid).is_err());
    assert_eq!(s.sample(55, 8, 1.).unwrap(), original);
}

#[test]
fn v2_exact_readout_change_and_cross_version_state_action_rejection() {
    let (inputs, asset) = source();
    let mut v1 = RecoveryGroupDetachedCpuV1::fresh(&inputs, &asset, MediationModeV1::Full).unwrap();
    let mut v2 = fresh();
    let f = frame();
    let t = tick(&v2, &f);
    let r1 = v1.bind_rows(&f, &t).unwrap();
    let r2 = v2.bind_rows(&f, &t).unwrap();
    let a = v1
        .step(
            &f,
            t.clone(),
            &r1,
            MediationModulationV1::default(),
            127,
            [true; 6],
            u64::MAX,
        )
        .unwrap();
    let b = v2
        .step(
            &f,
            t,
            &r2,
            MediationModulationV1::default(),
            127,
            [true; 6],
            u64::MAX,
        )
        .unwrap();
    assert_eq!(
        serde_json::to_vec(&a.receipt.core).unwrap(),
        serde_json::to_vec(&b.receipt.core).unwrap()
    );
    assert_eq!(
        a.source_evaluation.final_activations,
        b.source_evaluation.final_activations
    );
    assert_eq!(
        a.receipt.extension_activations.map(f32::to_bits),
        b.receipt.extension_activations.map(f32::to_bits)
    );
    assert_eq!(a.receipt.group_components, b.receipt.group_components);
    assert_eq!(a.receipt.group_jacobian, b.receipt.group_jacobian);
    assert_eq!(a.group_decoder_derivatives, b.group_decoder_derivatives);
    assert_eq!(
        a.ordinary_decoder_derivatives,
        b.ordinary_decoder_derivatives
    );
    assert_eq!(
        a.receipt.scores.group.to_bits(),
        b.receipt.scores.group.to_bits()
    );
    for o in 0..2 {
        assert_eq!(
            (a.receipt.scores.operations[o] * 4.).to_bits(),
            b.receipt.scores.operations[o].to_bits()
        );
        for (x, y) in a.operation_decoder_derivatives[o]
            .iter()
            .zip(&b.operation_decoder_derivatives[o])
        {
            assert_eq!((x * 4.).to_bits(), y.to_bits());
        }
    }
    let s1 = serde_json::to_value(v1.snapshot()).unwrap();
    let s2 = serde_json::to_value(v2.snapshot()).unwrap();
    for key in ["core_json", "activations", "ema", "metabolic"] {
        assert_eq!(s1[key], s2[key]);
    }
    assert!(RecoveryGroupDetachedCpuV2::restore(
        &inputs,
        &asset,
        MediationModeV1::Full,
        serde_json::from_value(s1).unwrap()
    )
    .is_err());
    assert!(RecoveryGroupDetachedCpuV1::restore(
        &inputs,
        &asset,
        MediationModeV1::Full,
        serde_json::from_value(s2).unwrap()
    )
    .is_err());
    let act1 = a.receipt.scores.sample(42, 0, 1.).unwrap();
    let act2 = b.receipt.scores.sample(42, 0, 1.).unwrap();
    let wire1 = serde_json::to_value(act1).unwrap();
    let wire2 = serde_json::to_value(act2).unwrap();
    assert!(b
        .receipt
        .scores
        .evaluate(&serde_json::from_value(wire1).unwrap())
        .is_err());
    assert!(a
        .receipt
        .scores
        .evaluate(&serde_json::from_value(wire2).unwrap())
        .is_err());
    assert_eq!(v2.recipe.operation_final_readouts, [[8., -8.]; 2]);
}

#[test]
fn v2_pressure_curve_tolerance_sham_and_fatigue_separation() {
    let (i, a) = source();
    for p in [0., 0.1, 0.3, 0.5, 0.6, 0.7, 1.] {
        let f = make_frame(&specs(), 0., p);
        let r = run(&mut fresh(), &f);
        let d = r.receipt.scores.probabilities(1.).unwrap();
        if p <= 0.1 {
            assert!(d.conditional_operation[0] < 0.001);
        }
        if p >= 0.7 {
            assert!(d.conditional_operation[0] > 0.9);
        }
        if p == 0.6 {
            assert_eq!(d.conditional_operation, [0.5; 2]);
        }
        assert!(d.conditional_operation.iter().all(|x| *x > 0. && *x < 1.));
        let mut sham =
            RecoveryGroupDetachedCpuV2::fresh(&i, &a, MediationModeV1::DriveSham).unwrap();
        let s = run(&mut sham, &f);
        assert_eq!(
            s.receipt
                .scores
                .probabilities(1.)
                .unwrap()
                .conditional_operation,
            [0.5; 2]
        );
    }
    let high_f = run(&mut fresh(), &make_frame(&specs(), 1., 0.));
    let high_p = run(&mut fresh(), &make_frame(&specs(), 0., 1.));
    assert!(high_f.receipt.scores.operations[0] < high_f.receipt.scores.operations[1]);
    assert!(high_p.receipt.scores.operations[0] > high_p.receipt.scores.operations[1]);
    assert!(high_f.receipt.group_components[4] > 0.);
    assert!(high_p.receipt.group_components[4] > 0.);
}

#[test]
fn v2_native_bounded_operation_memory_and_zero_cognitive_context() {
    let e = fresh();
    let cap = e
        .source()
        .candidate_decoder()
        .memory_channel()
        .unwrap()
        .max_candidate_gain();
    let m = MediationModulationV1::default();
    assert_eq!(cap, 0.5);
    let memory: Vec<_> = e.source().synapses().iter().enumerate().filter(|(_,s)| matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.family()==CandidateActionFamily::Rest && d.head()==DecoderHeadKind::MemoryContext)).collect();
    assert!(!memory.is_empty());
    assert!(memory.iter().all(|(j, _)| e.core.weights[*j] == 0.));
    // Preserved first fixture failure exposed zero inherited memory readouts.
    // Nonzero M here is an explicit intervention at the bounded native port,
    // not source-produced recall, a learned episode or a source-weight change.
    let mut old_weight_control: GroupRecipe = serde_json::from_str(GROUP_RECIPE).unwrap();
    old_weight_control.operation_final_readouts = [[2., -2.]; 2];
    for p in [0.1, 0.6, 0.7] {
        let f = make_frame(&specs(), 0., p);
        let r = run(&mut fresh(), &f);
        assert_eq!(r.receipt.core.components[1][2..4], [0., 0.]);
        assert_eq!(r.receipt.core.components[6][2..4], [0., 0.]);
        for signs in [[-1., 1.], [0., 0.], [1., -1.], [1., 1.], [-1., -1.]] {
            let mut base = r.receipt.core.clone();
            for (o, c) in [1, 6].into_iter().enumerate() {
                let value = signs[o] * cap;
                base.components[c][2] = value;
                for (side, sign) in [(0, 1.), (1, -1.)] {
                    let node = &e.core.recipe.manifest.nodes[PORT_BASE + c * 12 + 4 + side];
                    assert_eq!(node.id, START + PORT_BASE + c * 12 + 4 + side);
                    let n = native_kernel::neuron_step(
                        &node.dynamics,
                        CellState {
                            activation: 0.,
                            ema: 0.,
                            metabolic: 0.,
                        },
                        sign * value / DIVISORS[2] + m.offset,
                        0.,
                        0.,
                        m.projection_gain,
                        m.threshold,
                    );
                    base.port_activations[c][2][side] = n.state.activation;
                    base.port_clip_slopes[c][2][side] = 1.;
                }
            }
            let mut old_state = e.snapshot();
            let mut new_state = e.snapshot();
            let old = extension_forward(
                &old_weight_control,
                &mut old_state,
                &base,
                &r.receipt.scores.binding,
                r.receipt.group_components,
                m,
            )
            .unwrap();
            let new = extension_forward(
                &e.recipe,
                &mut new_state,
                &base,
                &r.receipt.scores.binding,
                r.receipt.group_components,
                m,
            )
            .unwrap();
            assert_eq!(old_state, new_state);
            assert_eq!(old.0.to_bits(), new.0.to_bits());
            let mut old_scores = r.receipt.scores.clone();
            old_scores.group = f64::from(old.0);
            old_scores.operations = old.2.map(f64::from);
            let mut new_scores = old_scores.clone();
            new_scores.operations = new.2.map(f64::from);
            for o in 0..2 {
                assert_eq!((old.2[o] * 4.).to_bits(), new.2[o].to_bits());
            }
            let old_d = old_scores.probabilities(1.).unwrap();
            let d = new_scores.probabilities(1.).unwrap();
            assert_eq!(
                old_d.actual_posture_rest_probability.to_bits(),
                d.actual_posture_rest_probability.to_bits()
            );
            assert!(d.conditional_operation.iter().all(|x| *x > 0. && *x < 1.));
            if p == 0.6 && signs[0] == signs[1] {
                close(d.conditional_operation[0], 0.5, 1e-15);
            }
            println!(
                "BOUNDED_MEMORY_NATIVE_FIXTURE {}",
                serde_json::json!({"pressure":p,"memory_cap":cap,"memory":signs.map(|s|s*cap),"cognitive":[0.,0.],"scope":"injected bounded M port via native neuron_step, not source-produced recall; baseline control uses native V1 readout weights on identical graph", "source_memory_rows_zero":true,"all_predecode_state_equal":true,"operation_scores_v1_weight_control":old.2,"operation_scores_v2":new.2,"probabilities_v1_weight_control":old_d,"probabilities_v2":d})
            );
        }
    }
}

#[test]
fn v2_warm_cold_and_mode_boundaries_are_exact() {
    let (i, a) = source();
    for mode in [MediationModeV1::Full, MediationModeV1::DriveSham] {
        let mut e = RecoveryGroupDetachedCpuV2::fresh(&i, &a, mode).unwrap();
        let f = frame();
        run(&mut e, &f);
        let state = e.snapshot();
        let opposite = if mode == MediationModeV1::Full {
            MediationModeV1::DriveSham
        } else {
            MediationModeV1::Full
        };
        assert!(RecoveryGroupDetachedCpuV2::restore(&i, &a, opposite, state.clone()).is_err());
        let mut cold = RecoveryGroupDetachedCpuV2::restore(&i, &a, mode, state).unwrap();
        let warm = run(&mut e, &f);
        let cold_result = run(&mut cold, &f);
        assert_eq!(
            serde_json::to_vec(&warm.receipt).unwrap(),
            serde_json::to_vec(&cold_result.receipt).unwrap()
        );
        assert_eq!(e.snapshot(), cold.snapshot());
    }
}
