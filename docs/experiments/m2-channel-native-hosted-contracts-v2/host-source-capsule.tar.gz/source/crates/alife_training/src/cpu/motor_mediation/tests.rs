use super::*;
use std::sync::OnceLock;
fn evaluation_bits(e: &TrainingReplayEvaluation) -> [Vec<Vec<u32>>; 4] {
    [
        &e.candidate_logits,
        &e.final_activations,
        &e.final_activity_ema,
        &e.final_metabolic_load,
    ]
    .map(|bank| {
        bank.iter()
            .map(|row| row.iter().map(|v| v.to_bits()).collect())
            .collect()
    })
}
fn source() -> (PhenotypeCompilerInputs, FoundationWeightAsset) {
    static SOURCE: OnceLock<(PhenotypeCompilerInputs, FoundationWeightAsset)> = OnceLock::new();
    SOURCE
        .get_or_init(|| {
            let g =
                BrainGenome::scaffold(0x4d32, BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID);
            let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
            let (p, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
                g,
                d,
                SensorProfile::GroundedObjectSlotsV1,
            )
            .unwrap();
            let a = FoundationWeightAsset::from_trained_weights(
                &p,
                p.synapses().iter().map(|s| s.genetic_weight()).collect(),
                TrainingStageManifest::bootstrap(),
            )
            .unwrap();
            let (_, bound_inputs) =
                PhenotypeCompiler::compile_n2048_grounded_drive_basis_candidate(
                    i.genome().clone(),
                    i.development().clone(),
                    a.clone(),
                )
                .unwrap();
            (bound_inputs, a)
        })
        .clone()
}
fn fresh(mode: MediationModeV1) -> MediationDetachedCpuV1 {
    let (i, a) = source();
    MediationDetachedCpuV1::fresh(&i, &a, mode).unwrap()
}
fn candidate(f: CandidateActionFamily) -> TrainingReplayCandidate {
    let mut c = TrainingReplayCandidate {
        family: f,
        decoder_inputs: [0.; 54],
        innate_bias: 0.,
    };
    c.decoder_inputs[36] = 1.;
    c.decoder_inputs[37] = 1.;
    c
}
fn refs() -> [f32; 12] {
    let mut d = [0.; 12];
    d[..11].copy_from_slice(&REFERENCES);
    d[11] = source()
        .0
        .genome()
        .cognitive_architecture()
        .sleep_trigger_threshold();
    d
}
fn synthetic(
    cs: &[TrainingReplayCandidate],
    components: &[[f32; 5]],
    drives: [f32; 12],
    m: MediationModulationV1,
) -> MediationReceiptV1 {
    static E: OnceLock<MediationDetachedCpuV1> = OnceLock::new();
    let e = E.get_or_init(|| fresh(MediationModeV1::Full));
    let mut state = e.snapshot();
    let mut c = components.to_vec();
    run_partitions(
        &e.recipe,
        &mut state,
        &mut c,
        cs,
        drives,
        e.pressure_reference,
        m,
    )
    .unwrap()
}
fn neutral() -> MediationModulationV1 {
    MediationModulationV1 {
        projection_gain: 1.,
        threshold: 0.,
        ..Default::default()
    }
}
fn close(a: f32, b: f32, tolerance: f32) {
    assert!(
        (a - b).abs() <= tolerance,
        "{a} versus {b}, tolerance {tolerance}"
    );
}
#[test]
fn pinned_manifest_counts_and_tampered_bounds_fail_closed() {
    let r = Lowered::pinned(MANIFEST).unwrap();
    assert_eq!(r.manifest.nodes.last().unwrap().id, 2491);
    assert_eq!(r.branches.branches().len(), 36);
    assert!(Lowered::pinned(&MANIFEST.replace("4.0,", "400.0,")).is_err());
    assert!(Lowered::pinned(&(MANIFEST.to_owned() + " ")).is_err());
    assert_eq!(MediationWorkV1::expected().cost_q24().unwrap(), 27344);
    let mut e = fresh(MediationModeV1::Full);
    let before = e.snapshot();
    let cs = vec![candidate(CandidateActionFamily::Rest); 33];
    let mut c = vec![[0.; 5]; 33];
    assert!(run_partitions(
        &e.recipe,
        &mut e.state,
        &mut c,
        &cs,
        refs(),
        e.pressure_reference,
        neutral()
    )
    .is_err());
    assert_eq!(before, e.snapshot());
    c[0][0] = f32::NAN;
    assert!(run_partitions(
        &e.recipe,
        &mut e.state,
        &mut c[..1],
        &cs[..1],
        refs(),
        e.pressure_reference,
        neutral()
    )
    .is_err());
    assert_eq!(before, e.snapshot());
}
#[test]
fn signed_ports_bound_source_without_double_counting_or_second_gain() {
    let cs = [candidate(CandidateActionFamily::Other)];
    for s in [-1e30, -32., -16., -8., -4., 0., 4., 8., 16., 32., 1e30] {
        let r = synthetic(&cs, &[[s, 0., 0., 0., 0.]], refs(), neutral());
        let expected = 4. * (0.5 * (s / 4.).clamp(-8., 8.).tanh()).tanh();
        close(r.core_logits[0], expected, 1e-6);
        assert!(r.core_logits[0].abs() <= 4.);
        assert_eq!(r.components[0][0], s);
        if s.abs() >= 32. {
            assert_eq!(r.jacobians[0][0], 0.);
        }
    }
    let r = synthetic(&cs, &[[4., 2., 1., 1., 0.]], refs(), neutral());
    let expected = 4. * (1.75_f32 * 1_f32.tanh()).tanh();
    close(r.core_logits[0], expected, 1e-6);
    for g in [0., 0.5, 4.] {
        let r = synthetic(
            &cs,
            &[[4., 0., 0., 0., 0.]],
            refs(),
            MediationModulationV1 {
                interoceptive_gain: g,
                regional_gain: g,
                ..neutral()
            },
        );
        close(r.core_logits[0], 4. * (0.5 * 1_f32.tanh()).tanh(), 1e-6);
    }
}
#[test]
fn every_port_jacobian_and_drive_chain_matches_finite_difference() {
    let cs = [candidate(CandidateActionFamily::Ingest)];
    let mut d = refs();
    d[0] += 0.03;
    for m in [
        neutral(),
        MediationModulationV1::default(),
        MediationModulationV1 {
            offset: 0.4,
            threshold: -0.2,
            projection_gain: 0.7,
            ..neutral()
        },
    ] {
        let values = [1.2, -0.3, 0.2, -0.1, 0.];
        let r = synthetic(&cs, &[values], d, m);
        for port in 0..4 {
            let h = 0.001;
            let mut plus = values;
            let mut minus = values;
            plus[port] += h;
            minus[port] -= h;
            let finite = (synthetic(&cs, &[plus], d, m).core_logits[0]
                - synthetic(&cs, &[minus], d, m).core_logits[0])
                / (2. * h);
            close(finite, r.jacobians[0][port], 0.0004);
        }
        let mut plus = d;
        let mut minus = d;
        plus[0] += 0.0001;
        minus[0] -= 0.0001;
        let a = synthetic(&cs, &[values], plus, m);
        let b = synthetic(&cs, &[values], minus, m);
        let finite =
            (a.core_logits[0] - b.core_logits[0]) / (a.components[0][4] - b.components[0][4]);
        close(finite, r.jacobians[0][4], 0.002);
    }
    assert_eq!(clip_slope(1., 1.), 0.);
    assert_eq!(clip_slope(-1., 1.), 0.);
    assert_eq!(clip_slope(0., 1.), 1.);
}
#[test]
fn opponents_have_native_sign_reference_and_gain_envelope_without_clipping() {
    for m in [
        neutral(),
        MediationModulationV1 {
            interoceptive_gain: 4.,
            regional_gain: 4.,
            offset: 4.,
            projection_gain: 4.,
            threshold: 4.,
        },
        MediationModulationV1 {
            offset: -4.,
            threshold: 4.,
            ..neutral()
        },
        MediationModulationV1 {
            interoceptive_gain: 0.,
            ..neutral()
        },
        MediationModulationV1 {
            projection_gain: 0.,
            ..neutral()
        },
    ] {
        let base = refs();
        let r = synthetic(&[], &[], base, m);
        assert_eq!(r.signed_opponents, vec![0.; 12]);
        assert_eq!(r.positive_opponents, vec![0.; 12]);
        for axis in 0..12 {
            for delta in [-0.08, 0.08] {
                let mut drives = base;
                drives[axis] = (base[axis] + delta).clamp(0., 1.);
                let r = synthetic(&[], &[], drives, m);
                let polarity = if axis == 6 { -1. } else { 1. };
                let raw = 4.
                    * m.interoceptive_gain
                    * m.regional_gain
                    * (drives[axis] - base[axis])
                    * polarity;
                close(
                    r.signed_opponents[axis],
                    m.projection_gain * raw.tanh(),
                    1e-5,
                );
                close(
                    r.positive_opponents[axis],
                    m.projection_gain * raw.max(0.).tanh(),
                    1e-5,
                );
            }
        }
    }
}
#[test]
fn low_fatigue_high_pressure_rest_and_satisfied_need_controls() {
    let rest = candidate(CandidateActionFamily::Rest);
    let ingest = candidate(CandidateActionFamily::Ingest);
    let inspect = candidate(CandidateActionFamily::Inspect);
    let cs = [rest, ingest, inspect];
    let mut d = refs();
    d[0] = 0.;
    d[1] = 0.;
    d[5] = 0.;
    d[11] = 0.;
    let low = synthetic(&cs, &[[0.; 5]; 3], d, neutral());
    assert!(low.core_logits.iter().all(|x| *x <= 0.));
    assert_eq!(low.positive_opponents[11], 0.);
    let mut previous = low.components[0][4];
    for pressure in [d[11], refs()[11], 0.8, 0.9, 1.] {
        d[11] = pressure;
        let r = synthetic(&cs, &[[0.; 5]; 3], d, neutral());
        assert!(r.components[0][4] >= previous - 1e-6);
        previous = r.components[0][4];
    }
    assert!(previous > 0.);
    let high = synthetic(&cs, &[[0.; 5]; 3], d, neutral());
    assert!(high.core_logits[0] > 0.);
    // Synthetic adversarial scale, not a claim that the source life is satiated.
    let r = synthetic(
        &cs,
        &[[0.; 5], [7.0672383, 0., 0., 0., 0.], [0.; 5]],
        d,
        neutral(),
    );
    assert!(r.core_logits[1] < 0.);
    let mut high_fatigue = refs();
    high_fatigue[1] = 0.9;
    high_fatigue[11] = 0.;
    assert!(synthetic(&cs, &[[0.; 5]; 3], high_fatigue, neutral()).core_logits[0] > 0.);
    high_fatigue[11] = 1.;
    assert!(
        synthetic(&cs, &[[0.; 5]; 3], high_fatigue, neutral()).core_logits[0] > high.core_logits[0]
    );
    let mut low_atp = refs();
    low_atp[6] = 0.1;
    let r = synthetic(&cs, &[[0.; 5]; 3], low_atp, neutral());
    assert!(r.core_logits[0] > 0.);
    assert!(r.core_logits[2] < 0.);
}
#[test]
fn grounded_social_thermal_and_no_duplicate_optional_play() {
    let mut d = refs();
    d[4] = 0.9;
    d[7] = 0.9;
    d[9] = 0.9;
    let mut contact = candidate(CandidateActionFamily::Contact);
    let mut avoid = candidate(CandidateActionFamily::Avoid);
    let other = candidate(CandidateActionFamily::Other);
    let r = synthetic(
        &[contact.clone(), avoid.clone(), other.clone()],
        &[[0.; 5]; 3],
        d,
        neutral(),
    );
    assert_eq!(r.core_logits, [0., 0., 0.]);
    contact.decoder_inputs[41] = 1.;
    avoid.decoder_inputs[39] = 0.6;
    let r = synthetic(&[contact, avoid, other], &[[0.; 5]; 3], d, neutral());
    assert!(r.core_logits[0] > 0.);
    assert!(r.core_logits[1] > 0.);
    assert_eq!(r.core_logits[2], 0.);
}
#[test]
fn candidate_permutation_isolation_padding_and_no_cross_decision_latency() {
    let mut e = fresh(MediationModeV1::Full);
    let mut d = refs();
    d[0] = 0.5;
    for n in [1, 18, 32] {
        let cs = vec![candidate(CandidateActionFamily::Ingest); n];
        let mut values: Vec<_> = (0..n).map(|i| [i as f32 * 0.1, 0., 0., 0., 0.]).collect();
        let a = run_partitions(
            &e.recipe,
            &mut e.state,
            &mut values,
            &cs,
            d,
            e.pressure_reference,
            neutral(),
        )
        .unwrap();
        assert_eq!(a.work, MediationWorkV1::expected());
        values.reverse();
        let b = run_partitions(
            &e.recipe,
            &mut e.state,
            &mut values,
            &cs,
            d,
            e.pressure_reference,
            neutral(),
        )
        .unwrap();
        assert_eq!(
            a.core_logits.iter().rev().copied().collect::<Vec<_>>(),
            b.core_logits
        );
        let mut changed = values.clone();
        changed[0][0] = -8.;
        let c = run_partitions(
            &e.recipe,
            &mut e.state,
            &mut changed,
            &cs,
            d,
            e.pressure_reference,
            neutral(),
        )
        .unwrap();
        assert_eq!(b.core_logits[1..], c.core_logits[1..]);
    }
    let mut values = vec![[0.; 5]];
    let cs = [candidate(CandidateActionFamily::Other)];
    let r = run_partitions(
        &e.recipe,
        &mut e.state,
        &mut values,
        &cs,
        refs(),
        e.pressure_reference,
        neutral(),
    )
    .unwrap();
    assert_eq!(r.core_logits, [0.]);
    assert!(e.state.ema.iter().any(|x| *x > 0.));
}
// Separate literal pre-refactor equations, not another caller of the shared
// helper. Covers all soma functions, nonzero state and real branch primitives.
#[test]
fn native_kernel_matches_literal_prechange_equations_bit_for_bit() {
    let e = fresh(MediationModeV1::Full);
    let previous: Vec<_> = (0..START).map(|i| (i % 19) as f32 / 31. - 0.3).collect();
    for (i, d) in e.source.neuron_dynamics().iter().enumerate() {
        let state = CellState {
            activation: previous[i],
            ema: 0.12,
            metabolic: 0.34,
        };
        let recurrent = (i % 13) as f32 / 29. - 0.2;
        let mut dendritic = 0.;
        for b in
            &e.state.source.dendrites.branches()[e.state.source.dendrites.target_span(i as u32)]
        {
            let sum = b
                .inputs
                .iter()
                .map(|r| previous[r.source as usize] * r.weight)
                .sum::<f32>();
            let value = (sum - b.threshold).max(0.).tanh() * b.output_gain;
            assert_eq!(
                value.to_bits(),
                native_kernel::dendritic_activation(&previous, b).to_bits()
            );
            dendritic += value;
        }
        let x = d.bias() + 0.17 + 0.63 * (recurrent + dendritic)
            - d.homeostatic_gain() * state.metabolic
            - 0.21;
        let activated = match d.activation().raw() {
            0 => x,
            1 => x.max(0.),
            2 => x.tanh(),
            3 => 1. / (1. + (-x).exp()),
            _ => 0.,
        };
        let next = (1. - d.leak()) * state.activation + d.leak() * activated;
        let metabolic = (d.metabolic_decay() * state.metabolic
            + (1. - d.metabolic_decay()) * next * next)
            .clamp(0., 1.);
        let ema = (d.activity_ema_decay() * state.ema + (1. - d.activity_ema_decay()) * next.abs())
            .clamp(0., 1.);
        let got = native_kernel::neuron_step(d, state, 0.17, recurrent, dendritic, 0.63, 0.21);
        assert_eq!(
            [
                got.activated.to_bits(),
                got.state.activation.to_bits(),
                got.state.metabolic.to_bits(),
                got.state.ema.to_bits()
            ],
            [
                activated.to_bits(),
                next.to_bits(),
                metabolic.to_bits(),
                ema.to_bits()
            ]
        );
    }
}
fn frame(cs: &[TrainingReplayCandidate], tick: u64) -> PerceptionFrame {
    let tick = Tick::new(tick);
    let profile = SensorProfile::GroundedObjectSlotsSleepChoiceV1;
    let mut slots = Vec::new();
    let candidates = cs
        .iter()
        .enumerate()
        .map(|(i, c)| {
            let kind = match c.family {
                CandidateActionFamily::Rest => ActionKind::Rest,
                CandidateActionFamily::Idle => ActionKind::Idle,
                CandidateActionFamily::Inspect => ActionKind::Inspect,
                CandidateActionFamily::Approach | CandidateActionFamily::Avoid => ActionKind::Move,
                _ => ActionKind::Interact,
            };
            let id = if c.family == CandidateActionFamily::Rest {
                if i % 2 == 0 {
                    3
                } else {
                    700
                }
            } else {
                200
            };
            let target = if c.family == CandidateActionFamily::Rest {
                ActionTarget::NONE
            } else {
                ActionTarget::new(Some(WorldEntityId(i as u64 + 2)), None)
            };
            let mut f = CandidateFeatureVector::zero();
            f.0.copy_from_slice(&c.decoder_inputs[..24]);
            let observation = if c.family == CandidateActionFamily::Rest {
                CandidateObservationRef::None
            } else {
                let v = &c.decoder_inputs;
                let si = slots.len() as u16;
                slots.push(GroundedObjectSlotV1 {
                    slot_index: si,
                    tracked_object_id: TrackedObjectId(i as u64 + 2),
                    bearing: [v[0], v[1]],
                    distance: v[2],
                    relative_velocity: v[3..6].try_into().unwrap(),
                    color: v[6..9].try_into().unwrap(),
                    material: v[9..12].try_into().unwrap(),
                    shape: v[12..15].try_into().unwrap(),
                    chemical: v[15..18].try_into().unwrap(),
                    contact: v[18],
                    proprioception: v[19..21].try_into().unwrap(),
                    temperature: v[21],
                    terrain: v[22..24].try_into().unwrap(),
                    confidence: Confidence::new(1.).unwrap(),
                });
                CandidateObservationRef::ObjectSlot(si)
            };
            ActionCandidate::new(
                i as u16,
                ActionId(id),
                kind,
                c.family,
                observation,
                target,
                f,
                Confidence::new(1.).unwrap(),
                NormalizedScalar::new(0.).unwrap(),
                DurationTicks::new(1),
                DurationTicks::new(1),
            )
            .unwrap()
        })
        .collect();
    PerceptionFrame::new(
        OrganismId(1),
        tick,
        profile,
        SensorySnapshot::new(
            OrganismId(1),
            tick,
            Vec3f::ZERO,
            SensoryChannels::ZERO,
            Default::default(),
        )
        .unwrap(),
        BodySnapshot {
            pose: Pose::IDENTITY,
            velocity: Velocity::ZERO,
        },
        HomeostaticSnapshot::baseline(tick),
        candidates,
        SensorProfileProvenance::new(profile, SensoryAbiVersion::CURRENT, tick).unwrap(),
        slots,
    )
    .unwrap()
}
fn tick(
    e: &MediationDetachedCpuV1,
    mut cs: Vec<TrainingReplayCandidate>,
    frame: &PerceptionFrame,
) -> TrainingReplayTick {
    for (c, derived) in cs
        .iter_mut()
        .zip(prepare_sleep_choice_grounded_drive_features_v1(frame).unwrap())
    {
        c.decoder_inputs[36..46].copy_from_slice(&derived);
    }
    TrainingReplayTick {
        encoded_inputs: (0..START).map(|i| (i % 13) as f32 / 31. - 0.1).collect(),
        projection_gain: 0.5,
        local_threshold_shift: 0.25,
        microstep_count: 4,
        enabled_routes: vec![true; e.source.projections().len()],
        effective_weight_offsets: vec![0.; e.weights.len()],
        structural_synapses: vec![],
        candidates: cs,
    }
}
#[test]
fn real_source_once_equal_work_modes_state_and_completed_boundary_restore() {
    let (i, a) = source();
    let mut full = fresh(MediationModeV1::Full);
    let mut sham = fresh(MediationModeV1::DriveSham);
    let mut direct = fresh(MediationModeV1::DirectSource);
    let cs = vec![
        candidate(CandidateActionFamily::Ingest),
        candidate(CandidateActionFamily::Ingest),
        candidate(CandidateActionFamily::Rest),
        candidate(CandidateActionFamily::Rest),
    ];
    let f = frame(&cs, 1);
    let t = tick(&full, cs, &f);
    for generation in 0..3 {
        let q = TrainingSequence {
            phenotype_hash: full.source.phenotype_hash(),
            initial: full.source_state().clone(),
            ticks: vec![t.clone()],
            burn_in_ticks: 0,
            memory_candidate_gain: full
                .source
                .candidate_decoder()
                .memory_channel()
                .unwrap()
                .max_candidate_gain(),
        };
        let control = full.graph.forward(&full.source, &full.weights, &q).unwrap();
        let rows = full.bind_rows(&f, &t).unwrap();
        let r = full
            .step(&f, t.clone(), &rows, Default::default(), u64::MAX)
            .unwrap();
        assert_eq!(
            evaluation_bits(&r.source_evaluation),
            evaluation_bits(&control.evaluation)
        );
        assert_eq!(r.receipt.source_execution_count, 1);
        assert_eq!(r.receipt.source_generation, generation);
        assert_eq!(r.receipt.final_generation, generation + 1);
        let s = sham
            .step(
                &f,
                t.clone(),
                &sham.bind_rows(&f, &t).unwrap(),
                Default::default(),
                u64::MAX,
            )
            .unwrap();
        let d = direct
            .step(
                &f,
                t.clone(),
                &direct.bind_rows(&f, &t).unwrap(),
                Default::default(),
                u64::MAX,
            )
            .unwrap();
        assert_eq!(
            evaluation_bits(&s.source_evaluation),
            evaluation_bits(&r.source_evaluation)
        );
        assert_eq!(
            evaluation_bits(&d.source_evaluation),
            evaluation_bits(&r.source_evaluation)
        );
        assert_eq!(s.receipt.work, r.receipt.work);
        assert_eq!(d.receipt.work, r.receipt.work);
        assert_eq!(
            s.receipt.detached_arithmetic_reservation_q24,
            r.receipt.detached_arithmetic_reservation_q24
        );
        assert_eq!(d.receipt.output_logits, r.receipt.direct_source_logits);
        assert!(s.receipt.components.iter().all(|c| c[4] == 0.));
        let bytes = serde_json::to_vec(&full.snapshot()).unwrap();
        let snapshot = serde_json::from_slice(&bytes).unwrap();
        let restored =
            MediationDetachedCpuV1::restore(&i, &a, MediationModeV1::Full, snapshot).unwrap();
        assert_eq!(restored.snapshot(), full.snapshot());
        if generation == 1 {
            full =
                MediationDetachedCpuV1::restore(&i, &a, MediationModeV1::Full, restored.snapshot())
                    .unwrap();
        }
    }
}
#[test]
fn atomic_budget_zero_steps_bad_rows_generation_profile_and_learning_rejection() {
    let mut e = fresh(MediationModeV1::Full);
    let cs = vec![candidate(CandidateActionFamily::Ingest); 2];
    let f = frame(&cs, 1);
    let t = tick(&e, cs, &f);
    let rows = e.bind_rows(&f, &t).unwrap();
    let before = e.snapshot();
    assert!(e.step(&f, t.clone(), &rows, Default::default(), 0).is_err());
    assert_eq!(e.snapshot(), before);
    let ordinary = PerceptionFrame::new(
        f.organism_id(),
        f.tick(),
        SensorProfile::GroundedObjectSlotsV1,
        f.sensory().clone(),
        f.body(),
        *f.homeostasis(),
        f.candidates().to_vec(),
        SensorProfileProvenance::new(
            SensorProfile::GroundedObjectSlotsV1,
            SensoryAbiVersion::CURRENT,
            f.tick(),
        )
        .unwrap(),
        f.grounded_object_slots().to_vec(),
    )
    .unwrap();
    assert!(e.bind_rows(&ordinary, &t).is_err());
    let mut too_many = t.clone();
    too_many.candidates = vec![candidate(CandidateActionFamily::Ingest); 33];
    assert!(e.bind_rows(&f, &too_many).is_err());
    assert!(e
        .step(&f, too_many, &rows, Default::default(), u64::MAX)
        .is_err());
    assert_eq!(e.snapshot(), before);
    let mut zero = t.clone();
    zero.microstep_count = 0;
    assert!(e
        .step(&f, zero, &rows, Default::default(), u64::MAX)
        .is_err());
    assert_eq!(e.snapshot(), before);
    let mut wrong = rows.clone();
    wrong.swap(0, 1);
    assert!(e
        .step(&f, t.clone(), &wrong, Default::default(), u64::MAX)
        .is_err());
    let mut wrong = rows.clone();
    wrong[0].target = ActionTarget::NONE;
    assert!(e
        .step(&f, t.clone(), &wrong, Default::default(), u64::MAX)
        .is_err());
    let mut wrong = rows.clone();
    wrong[0].recipe = "old".into();
    assert!(e
        .step(&f, t.clone(), &wrong, Default::default(), u64::MAX)
        .is_err());
    let f2 = frame(&t.candidates, 2);
    assert!(e
        .step(&f2, t.clone(), &rows, Default::default(), u64::MAX)
        .is_err());
    assert_eq!(e.snapshot(), before);
    assert!(e.actor_optimization().is_err());
    assert!(e.waking_outcome_plasticity().is_err());
    assert_eq!(e.snapshot(), before);
    e.step(&f, t.clone(), &rows, Default::default(), u64::MAX)
        .unwrap();
    let after = e.snapshot();
    assert!(e.step(&f, t, &rows, Default::default(), u64::MAX).is_err());
    assert_eq!(e.snapshot(), after);
    let (i, a) = source();
    let mut old = after.clone();
    old.schema = "old-class5-checkpoint".into();
    assert!(MediationDetachedCpuV1::restore(&i, &a, MediationModeV1::Full, old).is_err());
    let mut wrong = after;
    wrong.recipe = "old".into();
    assert!(MediationDetachedCpuV1::restore(&i, &a, MediationModeV1::Full, wrong).is_err());
}
#[test]
fn projected_core_decoder_derivatives_include_nonlinear_ports_and_context_clamps() {
    let cs = vec![TrainingReplayCandidate {
        family: CandidateActionFamily::Ingest,
        decoder_inputs: [0.2; 54],
        innate_bias: 0.,
    }];
    let f = frame(&cs, 1);
    let mut e = fresh(MediationModeV1::Full);
    let t = tick(&e, cs, &f);
    let r = e
        .step(
            &f,
            t.clone(),
            &e.bind_rows(&f, &t).unwrap(),
            Default::default(),
            u64::MAX,
        )
        .unwrap();
    for head in [
        DecoderHeadKind::ActionCandidate,
        DecoderHeadKind::MemoryContext,
        DecoderHeadKind::CognitiveContext,
    ] {
        let head_count = e
            .source
            .synapses()
            .iter()
            .filter(|s| matches!(s.kind(), CompiledSynapseKind::Decoder(d) if d.head() == head))
            .count();
        if head_count == 0 {
            assert_eq!(head, DecoderHeadKind::CognitiveContext);
            continue; // C-port FD is separate; this source has no cognitive rows.
        }
        let index = e.source.synapses().iter().enumerate()
            .find(|(i, s)| {
                matches!(s.kind(), CompiledSynapseKind::Decoder(d) if d.head() == head && d.family() == CandidateActionFamily::Ingest)
                    && r.projected_core_decoder_derivatives[0][*i].abs() > 1e-6
            })
            .map(|(i, _)| i)
            .unwrap_or_else(|| panic!("nonzero {head:?} derivative coordinate, components {:?}, J {:?}", r.receipt.components, r.receipt.jacobians));
        let evaluate = |delta: f32| {
            let mut e = fresh(MediationModeV1::Full);
            e.weights[index] += delta;
            e.step(
                &f,
                t.clone(),
                &e.bind_rows(&f, &t).unwrap(),
                Default::default(),
                u64::MAX,
            )
            .unwrap()
            .receipt
            .core_logits[0]
        };
        let fd = (evaluate(0.01) - evaluate(-0.01)) / 0.02;
        close(fd, r.projected_core_decoder_derivatives[0][index], 0.00003);
    }
    let action = r.projected_core_decoder_derivatives[0]
        .iter()
        .copied()
        .filter(|g| *g != 0.)
        .count();
    assert!(action > 0);
    assert_ne!(r.receipt.jacobians[0][0], 1.);
}
#[test]
fn operating_point_recorded_proposals_are_not_a_live_policy_assay() {
    let cs = [
        candidate(CandidateActionFamily::Ingest),
        candidate(CandidateActionFamily::Other),
        candidate(CandidateActionFamily::Rest),
    ];
    let cases = [
        (
            "satisfied_hunger_high_boredom",
            0.,
            0.,
            0.1,
            0.,
            0.75,
            0.,
            0.,
        ),
        (
            "archived_hunger_high_boredom",
            0.4074517,
            0.14272085,
            0.1,
            0.,
            0.6450322,
            0.14272085,
            0.,
        ),
        ("high_hunger_high_boredom", 0.9, 0.1, 0.1, 0., 0.75, 0.1, 0.),
        (
            "urgent_fear_high_boredom",
            0.1,
            0.1,
            0.9,
            0.,
            0.75,
            0.1,
            -1.3439999,
        ),
        ("high_fatigue_low_atp", 0.25, 0.9, 0.1, 0., 0.1, 0.1, 0.),
        ("low_fatigue_high_pressure", 0., 0., 0.1, 0., 0.75, 0.9, 0.),
    ];
    for (name, h, f, fear, pain, atp, pressure, play_innate) in cases {
        let mut drives = refs();
        drives[0] = h;
        drives[1] = f;
        drives[2] = fear;
        drives[3] = pain;
        drives[6] = atp;
        drives[9] = 0.9;
        drives[11] = pressure;
        let rest_innate = if f > 0.55 { 1.344 } else { 0. };
        let values = [
            [7.0672383, 0., 0., 0., 0.],
            [0., play_innate, 0., 0., 0.],
            [1.6424918, rest_innate, 0., 0., 0.],
        ];
        let full = synthetic(&cs, &values, drives, Default::default());
        let mut e = fresh(MediationModeV1::DriveSham);
        let mut v = values;
        let sham = run_partitions(
            &e.recipe,
            &mut e.state,
            &mut v,
            &cs,
            drives,
            e.pressure_reference,
            Default::default(),
        )
        .unwrap();
        let mut cut_values = values;
        for v in &mut cut_values {
            v[0] = 0.;
        }
        let cut = synthetic(&cs, &cut_values, drives, Default::default());
        assert_eq!(full.work, sham.work);
        assert_eq!(full.work, cut.work);
        println!(
            "M2_OPERATING_POINT {}",
            serde_json::json!({"case":name,"scope":"synthetic input-only recorded source proposal scales, NOT a current native source frame or physiological life", "order":["Ingest","Other/Play-candidate-no-adapter","Rest"],"old_play_appended_for_context_only":0.012442939,"inputs":values,"full":full.core_logits,"drive_sham":sham.core_logits,"source_cut":cut.core_logits,"drive_components":full.components.iter().map(|v|v[4]).collect::<Vec<_>>(),"work":full.work})
        );
        if name == "satisfied_hunger_high_boredom" {
            assert!(full.core_logits[0] < full.core_logits[1]);
            assert!(sham.core_logits[0] > sham.core_logits[1]);
        }
        if name == "archived_hunger_high_boredom" {
            assert!(full.core_logits[0] > full.core_logits[1]);
        }
    }
}
