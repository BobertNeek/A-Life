//! Shared CPU neuron/dendrite equations. SparseGraph and detached partitions
//! call this identical primitive; operation order is the original replay order.
use alife_core::{ActivationFunction, DendriticBranch, NeuronDynamics};
#[derive(Clone, Copy, Debug, Default)]
pub(super) struct CellState {
    pub activation: f32,
    pub ema: f32,
    pub metabolic: f32,
}
pub(super) struct StepResult {
    pub state: CellState,
    pub activated: f32,
}
fn activate(x: f32, kind: ActivationFunction) -> f32 {
    match kind.raw() {
        0 => x,
        1 => x.max(0.),
        2 => x.tanh(),
        3 => 1. / (1. + (-x).exp()),
        _ => 0.,
    }
}
pub(super) fn dendritic_activation(previous: &[f32], b: &DendriticBranch) -> f32 {
    let sum = b
        .inputs
        .iter()
        .map(|i| previous[i.source as usize] * i.weight)
        .sum::<f32>();
    (sum - b.threshold).max(0.).tanh() * b.output_gain
}
pub(super) fn neuron_step(
    d: &NeuronDynamics,
    previous: CellState,
    encoded: f32,
    recurrent: f32,
    dendritic: f32,
    projection_gain: f32,
    threshold: f32,
) -> StepResult {
    let activated = activate(
        d.bias() + encoded + projection_gain * (recurrent + dendritic)
            - d.homeostatic_gain() * previous.metabolic
            - threshold,
        d.activation(),
    );
    let activation = (1. - d.leak()) * previous.activation + d.leak() * activated;
    let metabolic = (d.metabolic_decay() * previous.metabolic
        + (1. - d.metabolic_decay()) * activation * activation)
        .clamp(0., 1.);
    let ema = (d.activity_ema_decay() * previous.ema
        + (1. - d.activity_ema_decay()) * activation.abs())
    .clamp(0., 1.);
    StepResult {
        state: CellState {
            activation,
            ema,
            metabolic,
        },
        activated,
    }
}
