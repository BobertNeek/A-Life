//! Authored bounded native/world controls, NOT executed in source-only preparation.
//! Fixed disposable fixtures are not autonomous learning or scientific life evidence.
use super::*;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
#[allow(dead_code)]
#[path = "grouped_host_fixture.rs"]
mod recipe;
// Fixed mnemonic control seed, declared before any execution. No seed search.
const FIXTURE_SEED: u64 = 0x004f_5054_564f_4331;
fn build<P: GroupedPolicyStrategy>() -> (CpuGroupedM2HostV1, PhenotypeCompilerInputs) {
    let recipe = recipe::build(FIXTURE_SEED, true).unwrap();
    let mut founder = CpuFoundationTrainer::new(
        recipe.phenotype.clone(),
        recipe.asset.clone(),
        StageTrainableMask::recurrent_only(&recipe.phenotype).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    // Disposable optimizer sentinels, not trained or imported acquired state.
    let mut optimizer = founder.checkpoint();
    optimizer.optimizer_step = 23;
    optimizer.update_ages[0] = 23;
    optimizer.first_moment[0] = 0.03125;
    optimizer.second_moment[0] = 0.0625;
    founder =
        CpuFoundationTrainer::from_checkpoint(recipe.phenotype.clone(), recipe.asset, optimizer)
            .unwrap();
    // This fixture must retain the audited zero payload head; no token seeding.
    assert!(founder.phenotype().synapses().iter().enumerate().filter(|(_,s)|
        matches!(s.kind(),CompiledSynapseKind::Decoder(c) if c.head()==DecoderHeadKind::SpeechPayload))
        .all(|(i,_)|founder.weights()[i].to_bits()==0_f32.to_bits()));
    let mut game =
        create_grounded_drive_research_new_game(&recipe.config, &recipe.genotype).unwrap();
    let newborn = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    let mut blank = HeadlessScenarioBuilder::new(FIXTURE_SEED)
        .agent("learner", newborn.organism_id(), Vec3f::ZERO)
        .build()
        .unwrap();
    blank
        .register_grounded_drive_research_record(newborn)
        .unwrap();
    game.world = blank;
    let inputs = recipe.inputs;
    let (host, ()) = CpuGroupedM2HostV1::new_prepared_policy::<P, _, String>(
        game,
        founder,
        inputs.clone(),
        (FIXTURE_SEED ^ (FIXTURE_SEED >> 32)) as u32,
        MediationModeV1::Full,
        |_| Ok(()),
    )
    .unwrap();
    (host, inputs)
}
fn fresh() -> (CpuOptionalVocalM2HostV1, PhenotypeCompilerInputs) {
    let (inner, inputs) = build::<OptionalVocalPolicy>();
    (CpuOptionalVocalM2HostV1 { inner }, inputs)
}
fn frozen(host: &CpuOptionalVocalM2HostV1) -> Vec<u8> {
    let r = host.inner.host.residents.values().next().unwrap();
    let n = r.neural.checkpoint().unwrap();
    serde_json::to_vec(&(
        host.inner.founder.checkpoint(),
        n.lifetime,
        n.fast,
        n.eligibility,
        n.weight_generation,
        n.neural.dendrites,
        r.v11.checkpoint(),
    ))
    .unwrap()
}
#[test]
fn optional_host_source_once_quiet_physics_and_exact_next_boundary() {
    let (mut warm, inputs) = fresh();
    let frozen_before = frozen(&warm);
    let first = warm.step(0.73).unwrap();
    assert_eq!(first.decisions.len(), 1);
    let d = &first.decisions[0];
    assert_eq!(first.tick_after.raw(), first.tick_before.raw() + 1);
    assert_eq!(d.motor.native.core.source_execution_count, 1);
    assert_eq!(d.motor.native.core.final_generation, 1);
    assert_eq!(d.action.counter(), d.sampling_counter);
    let scores = warm.last_selection_scores(d.organism_id).unwrap();
    assert!(!scores.source().payload_present());
    scores
        .validate_sampling_context(
            &d.action,
            d.action.seed(),
            d.sampling_counter,
            f64::from(0.73_f32),
        )
        .unwrap();
    assert_eq!(scores.physical_selection(&d.action).unwrap().1[3], None);
    assert_eq!(
        d.action.motors()[3],
        crate::cpu::OptionalVocalChoiceV1::Quiet
    );
    assert!(d
        .patch
        .selected_bundle()
        .unwrap()
        .channels
        .iter()
        .all(|c| c.channel != MotorChannel::Vocal));
    assert_eq!(d.physical.outcome_tick.raw(), first.tick_after.raw());
    assert_eq!(
        warm.world()
            .organism_registry()
            .get(d.organism_id)
            .unwrap()
            .biochemistry()
            .tick,
        first.tick_after
    );
    assert_eq!(warm.world().audible_utterances().len(), 0);
    let charged = d.patch.decision().cognitive_work.as_ref().unwrap();
    assert_eq!(charged.learning_ops, 0);
    assert_eq!(charged.neural_updates, d.brain_work.neuron_updates);
    assert_eq!(charged.synapses_evaluated, d.brain_work.synapse_ops);
    let extra = GroupedMotorStateV1::append_work(warm.inner.founder.phenotype()).unwrap();
    assert_eq!(
        charged.neural_updates,
        2048 * u64::from(d.brain_work.microsteps) + extra.neuron_updates
    );
    assert!(d.motor.applied_body_energy_debit > 0.);
    assert_eq!(frozen(&warm), frozen_before);
    let wire = warm.checkpoint().unwrap().encode().unwrap();
    let mut cold = CpuOptionalVocalM2HostV1::restore(
        CpuOptionalVocalM2HostCheckpointV1::decode(&wire).unwrap(),
        &inputs,
        MediationModeV1::Full,
    )
    .unwrap();
    assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), wire);
    let a = warm.step(0.73).unwrap();
    let b = cold.step(0.73).unwrap();
    assert_eq!(a.decisions.len(), b.decisions.len());
    for (x, y) in a.decisions.iter().zip(&b.decisions) {
        assert_eq!(
            serde_json::to_vec(&x.action).unwrap(),
            serde_json::to_vec(&y.action).unwrap()
        );
        assert_eq!(
            serde_json::to_vec(&x.patch).unwrap(),
            serde_json::to_vec(&y.patch).unwrap()
        );
        assert_eq!(
            serde_json::to_vec(&x.motor).unwrap(),
            serde_json::to_vec(&y.motor).unwrap()
        );
    }
    assert_eq!(
        warm.checkpoint().unwrap().encode().unwrap(),
        cold.checkpoint().unwrap().encode().unwrap()
    );
    assert_eq!(frozen(&warm), frozen_before);
    assert_eq!(frozen(&cold), frozen_before);
}
#[test]
fn optional_host_rejects_opposite_policy_and_bad_temperature_transactionally() {
    let (mut new, _) = fresh();
    let (old, _) = build::<LegacyGroupedPolicy>();
    let new_wire = new.checkpoint().unwrap().encode().unwrap();
    let old_wire = old.checkpoint().unwrap().encode().unwrap();
    assert!(CpuGroupedM2HostCheckpointV1::decode(&new_wire).is_err());
    assert!(CpuOptionalVocalM2HostCheckpointV1::decode(&old_wire).is_err());
    assert!(new.inner.checkpoint().is_err());
    assert!(new
        .inner
        .host
        .grouped_step(&new.inner.founder, 0.73)
        .is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(), new_wire);
    assert!(new.step(f32::NAN).is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(), new_wire);
    assert!(new.actor_optimization().is_err());
    assert!(new.waking_synaptic_plasticity().is_err());
    assert!(new.synaptic_sleep_consolidation().is_err());
    assert_eq!(new.checkpoint().unwrap().encode().unwrap(), new_wire);
    let old_json: serde_json::Value =
        serde_json::from_slice(&old_wire[super::super::MAGIC.len()..]).unwrap();
    assert!(old_json["controllers"]
        .as_object()
        .unwrap()
        .values()
        .all(|r| r.get("optional_vocal").is_none()));
}
#[test]
fn quiet_does_not_change_real_empty_payload_or_cooldown_failure() {
    let (host, _) = fresh();
    let id = host
        .world()
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .organism_id();
    let command = ActionCommand::structured(
        id,
        ActionId(400),
        ActionKind::Vocalize,
        ActionTarget::NONE,
        Intensity::new(1.).unwrap(),
        DurationTicks::new(1),
        Confidence::new(1.).unwrap(),
        0,
        None,
        None,
        None,
    )
    .unwrap();
    // Deliberate fixture commands bypass the new sampler, not the physical guard.
    let mut empty = host.world().clone();
    let failed = empty.apply_neural_command(&command, None, false).unwrap();
    assert!(!failed.execution.succeeded);
    assert_eq!(
        failed.execution.failure,
        Some(ReferenceActionFailure::ActionRejected)
    );
    assert!(failed.emitted_utterance.is_none());
    assert!(empty.audible_utterances().is_empty());
    let payload = SpeechMotorPayload::try_new(
        SpeechActKind::Declare,
        vec![LanguageTokenId::new(1).unwrap()],
        Confidence::new(1.).unwrap(),
    )
    .unwrap();
    let mut speech = host.world().clone();
    let succeeded = speech
        .apply_neural_command(&command, Some(payload.clone()), false)
        .unwrap();
    assert!(succeeded.execution.succeeded);
    assert!(succeeded.emitted_utterance.is_some());
    let cooldown = speech
        .apply_neural_command(&command, Some(payload), false)
        .unwrap();
    assert!(!cooldown.execution.succeeded);
    assert_eq!(
        cooldown.execution.failure,
        Some(ReferenceActionFailure::ActionRejected)
    );
    assert!(cooldown.emitted_utterance.is_none());
    assert_eq!(speech.audible_utterances().len(), 1);
}
// Test-only adapters deliberately cross the pending owner, never exposed publicly.
struct RejectLegacyStage;
struct RejectLegacyClose;
macro_rules! optional_strategy_constants {
    () => {
        type Action = OptionalVocalActionV1;
        const OPTIONAL: bool = true;
        const MAGIC: &'static [u8] = OPTIONAL_MAGIC;
        const LINEAGE: &'static str = OPTIONAL_LINEAGE;
        const POLICY: &'static str = OPTIONAL_VOCAL_POLICY_V1;
    };
}
impl GroupedPolicyStrategy for RejectLegacyStage {
    optional_strategy_constants!();
    fn select(
        f: &CpuFoundationTrainer,
        r: &mut Resident,
        p: &PerceptionFrame,
        o: &CpuDecisionOutput,
        s: u32,
        c: u32,
        t: f64,
    ) -> Result<Selection<Self::Action>, CpuHostError> {
        OptionalVocalPolicy::select(f, r, p, o, s, c, t)
    }
    fn stage(
        r: &mut Resident,
        p: &BrainPhenotype,
        a: &Self::Action,
        b: CpuDecisionBinding,
    ) -> Result<(), CpuHostError> {
        let scores = &r
            .grouped
            .as_ref()
            .unwrap()
            .motor
            .last_receipt
            .as_ref()
            .unwrap()
            .native
            .scores;
        let legacy = scores.sample(a.seed(), a.counter(), a.temperature())?;
        assert!(r
            .neural
            .stage_grouped_closed_selection(p, &legacy, scores, b)
            .is_err());
        Err(CpuHostError::State(
            "fixed legacy stage rejection after optional forward",
        ))
    }
    fn close(
        _: &mut CpuOrganismState,
        _: &CpuFoundationTrainer,
        _: &ExperiencePatch,
        _: &NeuralReceptorFrame,
    ) -> Result<(), CpuHostError> {
        panic!("stage must reject before physical execution")
    }
}
impl GroupedPolicyStrategy for RejectLegacyClose {
    optional_strategy_constants!();
    fn select(
        f: &CpuFoundationTrainer,
        r: &mut Resident,
        p: &PerceptionFrame,
        o: &CpuDecisionOutput,
        s: u32,
        c: u32,
        t: f64,
    ) -> Result<Selection<Self::Action>, CpuHostError> {
        OptionalVocalPolicy::select(f, r, p, o, s, c, t)
    }
    fn stage(
        r: &mut Resident,
        p: &BrainPhenotype,
        a: &Self::Action,
        b: CpuDecisionBinding,
    ) -> Result<(), CpuHostError> {
        OptionalVocalPolicy::stage(r, p, a, b)
    }
    fn close(
        n: &mut CpuOrganismState,
        f: &CpuFoundationTrainer,
        p: &ExperiencePatch,
        r: &NeuralReceptorFrame,
    ) -> Result<(), CpuHostError> {
        assert!(n.close_grouped_outcome(f, p, r).is_err());
        Err(CpuHostError::State(
            "fixed legacy close rejection after optional physical transaction",
        ))
    }
}
#[test]
fn optional_pending_owner_rejects_legacy_stage_and_close() {
    let (mut host, _) = fresh();
    let before = host.checkpoint().unwrap().encode().unwrap();
    assert!(matches!(
        host.inner
            .host
            .grouped_policy_step::<RejectLegacyStage>(&host.inner.founder, 0.73),
        Err(CpuHostError::State(
            "fixed legacy stage rejection after optional forward"
        ))
    ));
    assert_eq!(host.checkpoint().unwrap().encode().unwrap(), before);
    assert!(matches!(
        host.inner
            .host
            .grouped_policy_step::<RejectLegacyClose>(&host.inner.founder, 0.73),
        Err(CpuHostError::State(
            "fixed legacy close rejection after optional physical transaction"
        ))
    ));
    assert_eq!(host.checkpoint().unwrap().encode().unwrap(), before);
}

#[test]
fn optional_extracted_inner_source_and_canonical_owners_reject_old_loaders() {
    let (host, _) = fresh();
    let checkpoint = host.checkpoint().unwrap();
    let wire = checkpoint.encode().unwrap();
    let metadata: serde_json::Value =
        serde_json::from_slice(&wire[OPTIONAL_MAGIC.len()..]).unwrap();
    // Exactly the serialized inner state, not a privately accessible wrapper.
    let canonical: CpuCanonicalCheckpoint =
        serde_json::from_value(metadata["canonical"].clone()).unwrap();
    let source: CpuOrganismCheckpoint =
        serde_json::from_value(metadata["canonical"]["residents"][0]["neural"].clone()).unwrap();
    assert_eq!(canonical.schema_version, OPTIONAL_VOCAL_CANONICAL_SCHEMA);
    assert_eq!(
        source.schema_version,
        crate::cpu::organism::OPTIONAL_VOCAL_NEURAL_SCHEMA
    );
    assert!(CpuOrganismState::from_checkpoint(host.inner.founder.phenotype(), source).is_err());
    assert!(CpuCanonicalHost::from_checkpoint(canonical.clone(), &host.inner.founder).is_err());
    let research = CpuGroundedDriveResearchCheckpoint {
        schema_version: 1,
        recipe_digest: N2048GroundedDriveBasisV1::recipe_digest(),
        policy: BrainActivityPolicyV1::grounded_drive_research_v1(),
        source_asset_digest: host.inner.founder.source_foundation.digest(),
        checkpoint: canonical,
    };
    assert!(CpuCanonicalHost::from_grounded_drive_research_checkpoint(
        research,
        &host.inner.founder
    )
    .is_err());
    for variant in 0..3 {
        let mut tampered = metadata.clone();
        match variant {
            0 => tampered["canonical"]["schema_version"] = serde_json::json!(2),
            1 => {
                tampered["canonical"]["residents"][0]["neural"]["schema_version"] =
                    serde_json::json!(2)
            }
            _ => {
                for state in tampered["controllers"]
                    .as_object_mut()
                    .unwrap()
                    .values_mut()
                {
                    state.as_object_mut().unwrap().remove("optional_vocal");
                }
            }
        }
        let mut bytes = OPTIONAL_MAGIC.to_vec();
        bytes.extend(serde_json::to_vec(&tampered).unwrap());
        assert!(CpuOptionalVocalM2HostCheckpointV1::decode(&bytes).is_err());
    }
    let mut foreign = metadata.clone();
    foreign["source_lineage"] = serde_json::json!(super::super::LINEAGE);
    foreign["policy"] = serde_json::json!(super::super::POLICY);
    let mut disguised = super::super::MAGIC.to_vec();
    disguised.extend(serde_json::to_vec(&foreign).unwrap());
    assert!(CpuGroupedM2HostCheckpointV1::decode(&disguised).is_err());
    // Even explicit raw marker stripping cannot silently discard the proof
    // through the old host: world brain authority still commits to it.
    let mut stripped: CpuCanonicalCheckpoint =
        serde_json::from_value(metadata["canonical"].clone()).unwrap();
    stripped.schema_version = 2;
    for r in &mut stripped.residents {
        r.neural.schema_version = 2;
    }
    let envelope = CpuGroundedDriveResearchCheckpoint {
        schema_version: 1,
        recipe_digest: N2048GroundedDriveBasisV1::recipe_digest(),
        policy: BrainActivityPolicyV1::grounded_drive_research_v1(),
        source_asset_digest: host.inner.founder.source_foundation.digest(),
        checkpoint: stripped,
    };
    assert!(CpuCanonicalHost::from_grounded_drive_research_checkpoint(
        envelope,
        &host.inner.founder
    )
    .is_err());
    assert_eq!(host.checkpoint().unwrap().encode().unwrap(), wire);
}
