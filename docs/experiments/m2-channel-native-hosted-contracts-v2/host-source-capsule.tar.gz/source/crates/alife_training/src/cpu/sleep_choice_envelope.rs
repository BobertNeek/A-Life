//! Fresh M1-only source-bound CPU envelope. The fixed prefix is inspected before
//! any source/world/enum decoding. No old research import or ordinary export.
use super::super::sleep_choice_motor::{
    SleepChoiceMotorModeV1, SleepChoiceMotorReceiptV1, SleepChoiceMotorStateV1,
};
use super::*;
use serde::{Deserialize, Serialize};

const MAGIC: &[u8] = b"ALIFE-SLEEP-CHOICE-M1\0V1\0SELECTOR12\0PROFILE5\0STRIDE55\0SOURCE27D01603\0";
const LINEAGE: &str = "fresh-m1-v1/source27d01603/body-f482b99/no-historical-import";
const POLICY: &str = "emergency-only-preperception;stationary-receipt-voluntary-entry;source2-runtime5;exact-recovery-memory-v1;inherited-posture-head;per-operation-recovery-success;legacy-body-sleep-physics";

pub(super) fn sleep_choice_profile_identity() -> SensorProfileIdentity {
    SensorProfileIdentity {
        profile_id: SensorProfile::GroundedObjectSlotsSleepChoiceV1.into(),
        profile_schema_version: 1,
        sensory_abi_version: SensoryAbiVersion::CURRENT.raw(),
    }
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct VoluntarySleepReceiptV1 {
    sequence: ExperienceSequenceId,
    frame: PerceptionFrameDigest,
    bundle_digest: [u64; 4],
    outcome_tick: Tick,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct SleepChoiceResidentV1 {
    pub(super) motor: SleepChoiceMotorStateV1,
    pub(super) memory_proofs: Vec<SleepMemorySourceProofV1>,
    pub(super) last_physical: Option<alife_world::SleepChoicePhysicalReceiptV1>,
    consumed_voluntary: Option<VoluntarySleepReceiptV1>,
}
impl SleepChoiceResidentV1 {
    pub(super) fn validate_replay(&self, events: &[CpuReplayEvent]) -> Result<(), CpuHostError> {
        if events.len() != self.memory_proofs.len() {
            return Err(CpuHostError::State("M1 replay provenance omitted"));
        }
        for (event, proof) in events.iter().zip(&self.memory_proofs) {
            proof.validate_against(&event.event, &event.target)?;
        }
        if let Some(p) = &self.last_physical {
            if !p.awake_recovery.is_finite()
                || !p.sleep_recovery.is_finite()
                || !(0. ..=1.).contains(&p.awake_recovery)
                || !(0. ..=1.).contains(&p.sleep_recovery)
                || p.source_tick >= p.outcome_tick
                || (p.successful_stationary_body_sleep
                    && (p.operation != Some(RecoveryOperationV1::BodySleep)
                        || p.sleep_recovery <= 0.
                        || !p.body_sleeping))
            {
                return Err(CpuHostError::State("invalid M1 physical receipt"));
            }
        }
        Ok(())
    }
    pub(super) fn validate_boundary(
        &self,
        owner: OrganismId,
        next_sequence: u64,
        world_tick: Tick,
    ) -> Result<(), CpuHostError> {
        match (&self.last_physical, &self.motor.last_receipt) {
            (None, None) if next_sequence == 1 && self.consumed_voluntary.is_none() => Ok(()),
            (Some(physical), Some(motor)) => {
                if physical.organism_id != owner
                    || physical.sequence_id.raw().checked_add(1) != Some(next_sequence)
                    || physical.outcome_tick > world_tick
                    || physical.source_tick != motor.tick
                {
                    return Err(CpuHostError::State("M1 physical boundary mismatch"));
                }
                if let Some(consumed) = &self.consumed_voluntary {
                    if consumed.sequence.raw() == 0
                        || consumed.sequence.raw() > physical.sequence_id.raw()
                        || consumed.outcome_tick > physical.outcome_tick
                        || (physical.successful_stationary_body_sleep
                            && (consumed.sequence != physical.sequence_id
                                || consumed.outcome_tick != physical.outcome_tick
                                || consumed.frame != motor.frame_digest))
                    {
                        return Err(CpuHostError::State("M1 consumed sleep boundary mismatch"));
                    }
                } else if physical.successful_stationary_body_sleep {
                    return Err(CpuHostError::State(
                        "M1 successful sleep receipt not consumed",
                    ));
                }
                Ok(())
            }
            _ => Err(CpuHostError::State("M1 incomplete physical boundary")),
        }
    }
    /// Consume only a just-produced typed physical receipt. The host commits
    /// this state together with world and memory state in its existing clone.
    pub(super) fn observe_physical(
        &mut self,
        frame: &PerceptionFrame,
        bundle: &MotorCommandBundle,
        physical: &alife_world::SleepChoiceWorldReceiptV1,
        sleep: &mut SleepController,
    ) -> Result<(), CpuHostError> {
        if physical.motor.bundle != *bundle
            || frame.organism_id() != bundle.organism_id
            || frame.tick() != bundle.tick
            || frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
        {
            return Err(CpuHostError::State(
                "M1 physical receipt selection mismatch",
            ));
        }
        if physical.successful_stationary_body_sleep {
            if sleep.state().phase != SleepPhase::Awake {
                return Err(CpuHostError::State("M1 voluntary receipt outside Awake"));
            }
            self.consume_voluntary_receipt(
                bundle.sequence_id,
                frame.frame_digest(),
                bundle,
                physical.motor.outcome_tick,
            )?;
            sleep.request_voluntary_sleep(physical.motor.outcome_tick)?;
        }
        self.last_physical = Some(physical.summary());
        Ok(())
    }
    pub(super) fn consume_voluntary_receipt(
        &mut self,
        sequence: ExperienceSequenceId,
        frame: PerceptionFrameDigest,
        bundle: &MotorCommandBundle,
        outcome_tick: Tick,
    ) -> Result<(), CpuHostError> {
        if self.consumed_voluntary.as_ref().is_some_and(|old| {
            old.sequence.raw() >= sequence.raw() || old.outcome_tick >= outcome_tick
        }) {
            return Err(CpuHostError::State("M1 voluntary receipt already consumed"));
        }
        self.consumed_voluntary = Some(VoluntarySleepReceiptV1 {
            sequence,
            frame,
            bundle_digest: json_digest(b"ALIFE-M1-VOLUNTARY-BUNDLE-V1", bundle)?,
            outcome_tick,
        });
        Ok(())
    }
}

pub struct CpuSleepChoiceHostV1 {
    host: CpuCanonicalHost,
    founder: CpuFoundationTrainer,
    source_inputs: PhenotypeCompilerInputs,
    mode: SleepChoiceMotorModeV1,
}
/// Only an M1 byte envelope creates this object. No public unqualified Serde
/// decoder is implemented, so historic positional inputs cannot enter restore.
#[derive(Debug, Clone)]
pub struct CpuSleepChoiceHostCheckpointV1 {
    payload: SleepChoicePayloadV1,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SleepChoicePayloadV1 {
    schema_version: u16,
    source_lineage: String,
    policy: String,
    runtime_profile_raw: u16,
    selector_tag: u16,
    decoder_stride: u16,
    mode: SleepChoiceMotorModeV1,
    source_inputs: PhenotypeCompilerInputs,
    recipe_digest: [u64; 4],
    source_asset: FoundationWeightAsset,
    founder: crate::FoundationTrainerCheckpoint,
    canonical: CpuCanonicalCheckpoint,
    controllers: BTreeMap<u64, SleepChoiceResidentV1>,
}
impl CpuSleepChoiceHostCheckpointV1 {
    pub fn encode(&self) -> Result<Vec<u8>, CpuHostError> {
        let mut out = MAGIC.to_vec();
        out.extend(serde_json::to_vec(&self.payload)?);
        Ok(out)
    }
    pub fn decode(bytes: &[u8]) -> Result<Self, CpuHostError> {
        // This check is structurally before even a generic JSON parse, and well
        // before PhenotypeCompilerInputs' historic positional enum codecs.
        let body = bytes.strip_prefix(MAGIC).ok_or(CpuHostError::State(
            "not the explicit fresh M1 lineage envelope",
        ))?;
        let metadata: serde_json::Value = serde_json::from_slice(body)?;
        if metadata["schema_version"] != 1
            || metadata["source_lineage"] != LINEAGE
            || metadata["policy"] != POLICY
            || metadata["runtime_profile_raw"] != 5
            || metadata["selector_tag"] != 12
            || metadata["decoder_stride"] != 55
        {
            return Err(CpuHostError::State(
                "M1 outer lineage/profile/policy mismatch",
            ));
        }
        Ok(Self {
            payload: serde_json::from_value(metadata)?,
        })
    }
}
pub struct CpuSleepChoiceHostStepV1 {
    pub tick_before: Tick,
    pub tick_after: Tick,
    pub decisions: Vec<CpuSleepChoiceHostDecisionV1>,
    pub sleeping_organisms: usize,
    pub sleep_consolidations: usize,
}
pub struct CpuSleepChoiceHostDecisionV1 {
    pub organism_id: OrganismId,
    pub action: crate::PpoJointAction,
    pub patch: ExperiencePatch,
    pub motor: SleepChoiceMotorReceiptV1,
    pub physical: alife_world::SleepChoicePhysicalReceiptV1,
    pub sleep_phase: SleepPhase,
    pub sleep_trigger: Option<SleepTrigger>,
}
impl CpuSleepChoiceHostV1 {
    fn validate_pressure_valuation(value: BiologicalValueProfile) -> Result<(), CpuHostError> {
        if value.hormones[8] != 0. {
            return Err(CpuHostError::State(
                "initial M1 routing requires unchanged pressure valuation",
            ));
        }
        Ok(())
    }
    fn validate_source_biology(world: &HeadlessWorld) -> Result<(), CpuHostError> {
        for record in world.organism_registry().iter() {
            alife_world::SleepChoiceWorldAdmissionV1::for_organism(world, record.organism_id())?;
            Self::validate_pressure_valuation(
                record.phenotype().chemistry.biochemical.value_profile(),
            )?;
        }
        Ok(())
    }
    fn validate_source_channels(source: &BrainPhenotype) -> Result<(), CpuHostError> {
        if !source
            .candidate_decoder()
            .factorized_motor_channels(source)?
            .contains(&MotorChannel::Posture)
        {
            return Err(CpuHostError::State(
                "M1 requires an inherited Posture motor head",
            ));
        }
        Ok(())
    }
    pub fn new_prepared<T, E: std::fmt::Display>(
        game: CanonicalNewGame,
        founder: CpuFoundationTrainer,
        source_inputs: PhenotypeCompilerInputs,
        sampling_seed: u32,
        mode: SleepChoiceMotorModeV1,
        prepare: impl FnOnce(&mut HeadlessWorld) -> Result<T, E>,
    ) -> Result<(Self, T), CpuHostError> {
        Self::validate_source_channels(founder.phenotype())?;
        let motor = SleepChoiceMotorStateV1::fresh(&source_inputs, mode)?;
        motor.validate(founder.phenotype())?;
        // The caller supplied a fresh genome whose circuit was present before
        // developmental expression. Never replace stored chemistry here.
        Self::validate_source_biology(&game.world)?;
        let (mut host, prepared) = CpuCanonicalHost::new_prepared_grounded_drive_research_cohort(
            game,
            &founder,
            sampling_seed,
            prepare,
        )?;
        Self::validate_source_biology(&host.world)?;
        for (&id, r) in &mut host.residents {
            if r.neural.checkpoint()?.last_decision_tick.is_some()
                || r.next_sequence != 1
                || !r.replay.is_empty()
            {
                return Err(CpuHostError::State(
                    "M1 is fresh-only, cannot reset acquired resident",
                ));
            }
            let profile = sleep_choice_profile_identity();
            r.memory = MemorySidecarState::new_profiled(
                OrganismId(id),
                profile,
                MemoryBankConfig::new(256, 64, 4, 0.72, Confidence::new(0.)?)?,
            )?;
            r.topology = TopologySidecar::new_profiled(
                OrganismId(id),
                profile,
                TopologicalMapConfig::default(),
            )?;
            r.sleep_choice = Some(SleepChoiceResidentV1 {
                motor: motor.clone(),
                memory_proofs: Vec::new(),
                last_physical: None,
                consumed_voluntary: None,
            });
        }
        host.seal_all_residents()?;
        Ok((
            Self {
                host,
                founder,
                source_inputs,
                mode,
            },
            prepared,
        ))
    }
    pub fn world(&self) -> &HeadlessWorld {
        self.host.world()
    }
    /// Read-only observation, including emergency intervals without a decision.
    pub fn sleep_state(&self, organism: OrganismId) -> Option<alife_core::sleep::SleepState> {
        self.host
            .residents
            .get(&organism.raw())
            .map(|resident| resident.sleep.state())
    }
    pub fn checkpoint(&self) -> Result<CpuSleepChoiceHostCheckpointV1, CpuHostError> {
        Ok(CpuSleepChoiceHostCheckpointV1 {
            payload: SleepChoicePayloadV1 {
                schema_version: 1,
                source_lineage: LINEAGE.into(),
                policy: POLICY.into(),
                runtime_profile_raw: 5,
                selector_tag: 12,
                decoder_stride: 55,
                mode: self.mode,
                source_inputs: self.source_inputs.clone(),
                recipe_digest: SleepChoiceM1V1::recipe_digest(),
                source_asset: self.founder.source_foundation.clone(),
                founder: self.founder.checkpoint(),
                canonical: self.host.checkpoint_inner(&self.founder)?,
                controllers: self
                    .host
                    .residents
                    .iter()
                    .map(|(&id, r)| {
                        Ok((
                            id,
                            r.sleep_choice
                                .clone()
                                .ok_or(CpuHostError::State("missing M1 controller"))?,
                        ))
                    })
                    .collect::<Result<_, CpuHostError>>()?,
            },
        })
    }
    pub fn restore(
        checkpoint: CpuSleepChoiceHostCheckpointV1,
        expected_source: &PhenotypeCompilerInputs,
        expected_mode: SleepChoiceMotorModeV1,
    ) -> Result<Self, CpuHostError> {
        let wire = checkpoint.encode()?;
        let c = checkpoint.payload;
        if c.schema_version != 1
            || c.source_lineage != LINEAGE
            || c.policy != POLICY
            || c.runtime_profile_raw != 5
            || c.selector_tag != 12
            || c.decoder_stride != 55
            || c.mode != expected_mode
            || &c.source_inputs != expected_source
            || c.recipe_digest != SleepChoiceM1V1::recipe_digest()
        {
            return Err(CpuHostError::State(
                "M1 source, controller, profile or policy mismatch",
            ));
        }
        let p = PhenotypeCompiler::compile_validated(
            expected_source,
            &BrainCapacityClass::n2048_grounded_drive_research(),
        )?;
        Self::validate_source_channels(&p)?;
        let founder = CpuFoundationTrainer::from_checkpoint(p, c.source_asset, c.founder)?;
        let host = CpuCanonicalHost::from_checkpoint_inner(
            c.canonical,
            &founder,
            true,
            None,
            Some(c.controllers),
        )?;
        for r in host.residents.values() {
            if !r
                .sleep_choice
                .as_ref()
                .is_some_and(|s| s.motor.matches(expected_source, expected_mode))
            {
                return Err(CpuHostError::State("M1 resident mode/source mismatch"));
            }
        }
        Self::validate_source_biology(&host.world)?;
        let result = Self {
            host,
            founder,
            source_inputs: c.source_inputs,
            mode: c.mode,
        };
        if result.checkpoint()?.encode()? != wire {
            return Err(CpuHostError::State(
                "M1 restore would rewrite acquired state",
            ));
        }
        Ok(result)
    }
    pub fn step(&mut self, temperature: f32) -> Result<CpuSleepChoiceHostStepV1, CpuHostError> {
        let step = self.host.step(&self.founder, temperature)?;
        let decisions = step
            .decisions
            .into_iter()
            .map(|d| {
                let resident = &self.host.residents[&d.organism_id.raw()];
                let state = resident
                    .sleep_choice
                    .as_ref()
                    .ok_or(CpuHostError::State("missing M1 controller"))?;
                Ok(CpuSleepChoiceHostDecisionV1 {
                    organism_id: d.organism_id,
                    action: d.action,
                    patch: d.patch,
                    motor: state
                        .motor
                        .last_receipt
                        .clone()
                        .ok_or(CpuHostError::State("missing M1 neural receipt"))?,
                    physical: state
                        .last_physical
                        .clone()
                        .ok_or(CpuHostError::State("missing M1 physical receipt"))?,
                    sleep_phase: resident.sleep.state().phase,
                    sleep_trigger: resident.sleep.state().last_trigger,
                })
            })
            .collect::<Result<_, CpuHostError>>()?;
        Ok(CpuSleepChoiceHostStepV1 {
            tick_before: step.tick_before,
            tick_after: step.tick_after,
            decisions,
            sleeping_organisms: step.sleeping_organisms,
            sleep_consolidations: step.sleep_consolidations,
        })
    }
}
#[cfg(test)]
#[path = "sleep_choice_host_tests.rs"]
mod tests;
