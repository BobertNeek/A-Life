//! Fixed fresh CPU fixtures only. No seed sweep, cohort, behavioral optimization,
//! or trained private-life input is used here.
use super::*;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
// The new-game constructor multiplies its seed by 16. The original mnemonic
// 0x5343_4D31_4658_0001 overflowed before constructing any organism or decision;
// its high nibble is cleared to fit that documented domain, not selected by outcome.
const FIXTURE_SEED: u64 = 0x0343_4D31_4658_0001;

#[derive(Clone, Copy)]
enum FixedBodyPreparation {
    Ordinary240,
    // Separate controlled mechanism context. This changes only the existing
    // age-death option at birth, never the genotype, chemistry or neural state.
    AgeDisabled10000,
}
fn fixture() -> (CpuSleepChoiceHostV1, PhenotypeCompilerInputs) {
    fixture_with_preparation(FixedBodyPreparation::Ordinary240)
}
fn fixture_with_preparation(
    preparation: FixedBodyPreparation,
) -> (CpuSleepChoiceHostV1, PhenotypeCompilerInputs) {
    let mut config = CanonicalNewGameConfig::phase3(FIXTURE_SEED, 1).unwrap();
    config.brain_class = BrainScaleTier::Standard2048;
    let builtin = FoundationWeightAsset::builtin_n2048_v1(config.sensor_profile).unwrap();
    let ordinary = create_canonical_new_game_with_n2048_candidate(&config, &builtin).unwrap();
    let record = ordinary.world.organism_registry().iter().next().unwrap();
    // Author the new fixture genotype before its expression. Four inherited
    // heads are required to expose Posture; the earlier one-head fixture was
    // ineligible and its 32-tick non-sleep trace is retained as failed evidence.
    let mut source_genotype = record.genome().clone();
    let a = source_genotype.brain.construction.maternal_architecture;
    let architecture = alife_core::genome::CognitiveArchitectureGenomeParameters::try_new_v1(
        a.attention_capacity(),
        a.active_concept_limit(),
        a.active_gap_limit(),
        a.predictor_capacity(),
        a.predictor_learning_rate(),
        4,
        a.motor_head_width(),
        a.dendritic_branch_capacity(),
        a.structural_candidate_budget(),
        a.structural_edit_budget(),
        a.sleep_trigger_threshold(),
        a.sleep_replay_rate(),
        a.sleep_consolidation_rate(),
        a.attention_learning_rate(),
        a.concept_learning_rate(),
        a.motor_learning_rate(),
        a.structural_learning_rate(),
    )
    .unwrap();
    source_genotype.brain.construction.maternal_architecture = architecture;
    source_genotype.brain.construction.paternal_architecture = architecture;
    source_genotype.chemistry.graph = source_genotype
        .chemistry
        .graph
        .with_awake_rest_recovery_v1(AlleleSide::Maternal)
        .unwrap()
        .with_awake_rest_recovery_v1(AlleleSide::Paternal)
        .unwrap();
    let expression = source_genotype.express().unwrap();
    let genome = expression.brain_genome.clone();
    let development = foundation_construction_development(
        &genome,
        &BrainCapacityClass::n2048(),
        &expression.development_state_at(Tick::ZERO).unwrap(),
    )
    .unwrap();
    let (bounded, _) = PhenotypeCompiler::compile_n2048_bounded_founder(
        genome.clone(),
        development.clone(),
        config.sensor_profile,
    )
    .unwrap();
    let source_asset = FoundationWeightAsset::from_phenotype_for_genetic_birth(&bounded).unwrap();
    let manifest = source_asset.manifest();
    source_genotype.foundation = FoundationGeneticIdentity::new(
        manifest.foundation_id().raw(),
        manifest.foundation_version().raw() as u16,
        manifest.compatibility_family_id().raw(),
        BrainCapacityClass::N2048_ID,
    )
    .unwrap();
    source_genotype.n2048_foundation_candidate = Some(source_asset.clone());
    source_genotype.validate_contract().unwrap();
    assert_eq!(source_genotype.express().unwrap().brain_genome, genome);
    let (source, inputs) = PhenotypeCompiler::compile_n2048_bounded_founder_candidate(
        genome,
        development,
        source_asset.clone(),
    )
    .unwrap();
    let transfer =
        crate::transfer_bounded_genetic_founder_to_grounded_drive(&source, &inputs, &source_asset)
            .unwrap();
    let genotype = CreatureGenome::from_n2048_grounded_drive_transfer(
        &source_genotype,
        &transfer.inputs,
        transfer.asset.clone(),
    )
    .unwrap();
    assert!(genotype
        .express_n2048_grounded_drive_research()
        .unwrap()
        .chemistry
        .biochemical
        .supports_awake_rest_recovery_v1());
    let p = transfer.phenotype;
    let trainer = CpuFoundationTrainer::new(
        p.clone(),
        transfer.asset.clone(),
        StageTrainableMask::recurrent_only(&p).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    // Explicit test-owned nonzero optimizer sentinel, not a claim of training.
    // It makes age/moment retention assertions nonvacuous without importing life.
    let mut optimizer = trainer.checkpoint();
    optimizer.optimizer_step = 23;
    optimizer.update_ages[0] = 23;
    optimizer.first_moment[0] = 0.03125;
    optimizer.second_moment[0] = 0.0625;
    let trainer = CpuFoundationTrainer::from_checkpoint(p, transfer.asset, optimizer).unwrap();
    let mut game = create_grounded_drive_research_new_game(&config, &genotype).unwrap();
    let record = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    let mut scene = HeadlessScenarioBuilder::new(FIXTURE_SEED)
        .agent("fixture", record.organism_id(), Vec3f::ZERO)
        .build()
        .unwrap();
    scene
        .register_grounded_drive_research_record(record)
        .unwrap();
    if matches!(preparation, FixedBodyPreparation::AgeDisabled10000) {
        scene.set_age_death_disabled_for_new_game(true).unwrap();
    }
    game.world = scene;
    let pressure_reference = trainer
        .phenotype()
        .cognitive_architecture()
        .sleep_trigger_threshold();
    let (host, ()) = CpuSleepChoiceHostV1::new_prepared(
        game,
        trainer,
        transfer.inputs.clone(),
        0x53434d31,
        SleepChoiceMotorModeV1::Full,
        |world| -> Result<(), String> {
            // Physical development only, no neural settling or previous choices.
            let ticks = match preparation {
                FixedBodyPreparation::Ordinary240 => 240,
                FixedBodyPreparation::AgeDisabled10000 => 10_000,
            };
            for _ in 0..ticks {
                world.try_advance_tick().map_err(|e| e.to_string())?;
            }
            if matches!(preparation, FixedBodyPreparation::AgeDisabled10000) {
                let record = world.organism_registry().iter().next().unwrap();
                let body = record.biochemistry();
                eprintln!("M1_HIGH_PRESSURE_PREPARATION ticks={} age_death_disabled={} alive={} pressure={} reference={} fatigue={} energy={} atp={} expression={}; biology-only, no neural decisions or settling", ticks,
                    world.age_death_disabled(), record.lifecycle().is_alive(), body.homeostasis.hormones.sleep_pressure,
                    pressure_reference, body.homeostasis.drives.fatigue, body.body.energy,
                    body.homeostasis.drives.brain_atp, body.development.biochemical_expression);
                assert!(world.age_death_disabled());
                assert!(record.lifecycle().is_alive());
                assert!(!body.body.sleeping);
                assert!(body.homeostasis.hormones.sleep_pressure > pressure_reference);
            }
            Ok(())
        },
    )
    .unwrap();
    (host, transfer.inputs)
}
#[test]
fn sleep_choice_host_fresh_roundtrip_runs_native_and_preserves_full_next_step() {
    let (mut host, source) = fixture();
    let initial = host.checkpoint().unwrap().encode().unwrap();
    let reader: Vec<_> = host.founder.phenotype().synapses().iter().enumerate()
        .filter(|(_, s)| matches!(s.kind(), CompiledSynapseKind::Decoder(c) if c.head() == DecoderHeadKind::MemoryContext))
        .map(|(index, _)| host.founder.weights()[index]).collect();
    eprintln!("M1_FIXTURE_SOURCE inputs_digest={:?} phenotype_hash={:?} motor_heads={} memory_reader_count={} reader_nonzero={} reader_max_abs={}",
        source.canonical_digest(), host.founder.phenotype().phenotype_hash(),
        host.founder.phenotype().cognitive_architecture().motor_head_count(), reader.len(),
        reader.iter().filter(|x| **x != 0.).count(), reader.iter().map(|x| x.abs()).fold(0_f32, f32::max));
    let value = host
        .world()
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .phenotype()
        .chemistry
        .biochemical
        .value_profile();
    eprintln!(
        "M1_EXPRESSED_VALUE profile={:?} drive_hormone_energy_mass={}",
        value,
        value
            .drives
            .iter()
            .chain(value.hormones.iter())
            .map(|x| x.abs())
            .sum::<f32>()
            + value.energy.abs()
    );
    assert_eq!(value.hormones[8], 0.);
    let first = host.step(1.).unwrap();
    assert_eq!(first.decisions.len(), 1);
    let receipt = &first.decisions[0].motor;
    eprintln!(
        "M1_FIRST_FRAME tick={} configured_microsteps={} actual_microsteps={} pressure={} reference={} encoded={:?} opponent={:?} pressure_head={:?} selected_operation={:?} phase={:?}",
        first.tick_before.raw(),
        receipt.configured_microsteps,
        receipt.work.microsteps,
        receipt.raw_pressure,
        receipt.pressure_reference,
        receipt.pressure_encoded_pair,
        receipt.pressure_opponent_pair,
        receipt.pressure_candidate_contributions,
        first.decisions[0].physical.operation,
        first.decisions[0].sleep_phase
    );
    eprintln!(
        "M1_FIRST_MEMORY contributions={:?}",
        receipt.memory_contributions
    );
    assert_eq!(receipt.work.encoder_assignments, 24);
    assert_eq!(receipt.work.branches, receipt.work.microsteps * 72);
    assert_eq!(receipt.work.branch_inputs, receipt.work.microsteps * 188);
    assert_eq!(
        first.decisions[0]
            .patch
            .pre_action()
            .perception()
            .sensor_profile(),
        SensorProfile::GroundedObjectSlotsSleepChoiceV1
    );
    assert!(receipt.applied_body_energy_debit > 0.);
    assert_eq!(host.founder.checkpoint().optimizer_step, 23);
    let resident = host.host.residents.values().next().unwrap();
    let neural = resident.neural.checkpoint().unwrap();
    assert!(neural.neural.activations.iter().any(|x| *x != 0.));
    assert!(neural.eligibility.iter().any(|x| *x != 0.));
    assert!(
        neural.fast.iter().any(|x| *x != 0.),
        "fixed native outcome must retain actual somatic learning"
    );
    assert!(
        !resident
            .memory
            .export_active_bank()
            .unwrap()
            .records
            .is_empty(),
        "restore fixture needs actual retained memory"
    );
    assert_eq!(resident.next_sequence, 2);
    assert_eq!(
        resident.sleep_choice.as_ref().unwrap().memory_proofs.len(),
        1
    );
    let checkpoint = host.checkpoint().unwrap();
    let bytes = checkpoint.encode().unwrap();
    assert_ne!(bytes, initial);
    let mut cold = CpuSleepChoiceHostV1::restore(
        CpuSleepChoiceHostCheckpointV1::decode(&bytes).unwrap(),
        &source,
        SleepChoiceMotorModeV1::Full,
    )
    .unwrap();
    assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), bytes);
    let a = host.step(1.).unwrap();
    let b = cold.step(1.).unwrap();
    eprintln!(
        "M1_NEXT_FRAME tick={} decisions={} sleeping={} consolidations={}",
        a.tick_before.raw(),
        a.decisions.len(),
        a.sleeping_organisms,
        a.sleep_consolidations
    );
    for d in &a.decisions {
        eprintln!(
            "M1_CARRIED_FRAME pressure={} encoded={:?} opponent={:?} pressure_head={:?} selected_operation={:?} phase={:?}",
            d.motor.raw_pressure,
            d.motor.pressure_encoded_pair,
            d.motor.pressure_opponent_pair,
            d.motor.pressure_candidate_contributions,
            d.physical.operation,
            d.sleep_phase
        );
        eprintln!(
            "M1_CARRIED_MEMORY contributions={:?}",
            d.motor.memory_contributions
        );
    }
    assert_eq!(a.decisions.len(), b.decisions.len());
    for (a, b) in a.decisions.iter().zip(&b.decisions) {
        assert_eq!(
            serde_json::to_vec(&a.patch).unwrap(),
            serde_json::to_vec(&b.patch).unwrap()
        );
        assert_eq!(
            serde_json::to_vec(&a.motor).unwrap(),
            serde_json::to_vec(&b.motor).unwrap()
        );
        assert_eq!(
            serde_json::to_vec(&a.physical).unwrap(),
            serde_json::to_vec(&b.physical).unwrap()
        );
    }
    assert_eq!(
        host.checkpoint().unwrap().encode().unwrap(),
        cold.checkpoint().unwrap().encode().unwrap()
    );
    assert_eq!(host.founder.checkpoint().first_moment[0], 0.03125);
    assert_eq!(host.founder.checkpoint().second_moment[0], 0.0625);
    assert_eq!(host.founder.checkpoint().update_ages[0], 23);
}
#[test]
fn sleep_choice_host_rejects_old_outer_lineages_and_partial_or_altered_state() {
    let (mut host, source) = fixture();
    host.step(1.).unwrap();
    let checkpoint = host.checkpoint().unwrap();
    let good = checkpoint.encode().unwrap();
    assert!(CpuSleepChoiceHostCheckpointV1::decode(&good[MAGIC.len()..]).is_err());
    for prefix in [
        b"ALIFE-MOTOR-M0".as_slice(),
        b"ALIFE-GRIP-RESEARCH".as_slice(),
        b"{}".as_slice(),
    ] {
        assert!(CpuSleepChoiceHostCheckpointV1::decode(prefix).is_err());
    }
    for key in [
        "source_lineage",
        "policy",
        "runtime_profile_raw",
        "selector_tag",
        "decoder_stride",
    ] {
        let mut v = serde_json::to_value(&checkpoint.payload).unwrap();
        v[key] = serde_json::Value::Null;
        let mut bytes = MAGIC.to_vec();
        bytes.extend(serde_json::to_vec(&v).unwrap());
        assert!(
            CpuSleepChoiceHostCheckpointV1::decode(&bytes).is_err(),
            "{key}"
        );
    }
    assert!(CpuSleepChoiceHostV1::restore(
        checkpoint.clone(),
        &source,
        SleepChoiceMotorModeV1::PressureSham
    )
    .is_err());
    let mut missing = checkpoint.clone();
    missing.payload.controllers.clear();
    assert!(CpuSleepChoiceHostV1::restore(missing, &source, SleepChoiceMotorModeV1::Full).is_err());
    let mut changed = checkpoint.clone();
    changed
        .payload
        .controllers
        .values_mut()
        .next()
        .unwrap()
        .memory_proofs
        .clear();
    assert!(CpuSleepChoiceHostV1::restore(changed, &source, SleepChoiceMotorModeV1::Full).is_err());
    // Each real appended controller bank is covered, not only the old prefix.
    for bank in ["activations", "inactive", "ema", "metabolic"] {
        let mut value = serde_json::to_value(&checkpoint.payload).unwrap();
        let controller = value["controllers"]
            .as_object_mut()
            .unwrap()
            .values_mut()
            .next()
            .unwrap();
        controller["motor"][bank][0] = serde_json::json!(0.314159);
        let changed = CpuSleepChoiceHostCheckpointV1 {
            payload: serde_json::from_value(value).unwrap(),
        };
        assert!(
            CpuSleepChoiceHostV1::restore(changed, &source, SleepChoiceMotorModeV1::Full).is_err(),
            "altered {bank}"
        );
    }
    let mut changed = checkpoint.clone();
    changed.payload.canonical.residents[0]
        .neural
        .neural
        .activations[0] += 0.125;
    assert!(CpuSleepChoiceHostV1::restore(changed, &source, SleepChoiceMotorModeV1::Full).is_err());
    assert!(CpuCanonicalHost::from_checkpoint_inner(
        checkpoint.payload.canonical.clone(),
        &host.founder,
        true,
        None,
        None
    )
    .is_err());
    assert_eq!(
        host.founder.phenotype().brain_class_id(),
        BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID
    );
    let stripped: CpuCanonicalCheckpoint =
        serde_json::from_slice(&serde_json::to_vec(&checkpoint.payload.canonical).unwrap())
            .unwrap();
    let ordinary = CpuGroundedDriveResearchCheckpoint {
        schema_version: 1,
        recipe_digest: N2048GroundedDriveBasisV1::recipe_digest(),
        policy: BrainActivityPolicyV1::grounded_drive_research_v1(),
        source_asset_digest: host.founder.source_foundation.digest(),
        checkpoint: stripped,
    };
    match CpuCanonicalHost::from_grounded_drive_research_checkpoint(ordinary, &host.founder) {
        Err(error) => eprintln!("M1_STRIPPED_CANONICAL_PUBLIC_RESTORE_REJECT class5 source retained, valid ordinary metadata, no M1 controllers: {error}"),
        Ok(_) => panic!("ordinary grounded host accepted M1 life after dropping its envelope/controller"),
    }
    assert!(host
        .host
        .grounded_drive_research_checkpoint(&host.founder)
        .is_err());
}

// This is actuator/controller persistence, not a complete host decision. The
// real world receipt supplied below has no fabricated neural selection or replay
// proof. Whole-host acquired-state continuation is tested separately above.
#[derive(Clone, serde::Serialize, serde::Deserialize)]
struct SleepActuatorComponents {
    body: BiochemistryState,
    sleep: SleepController,
    controller: SleepChoiceResidentV1,
    neural: CpuOrganismCheckpoint,
    consolidation_count: u32,
}
fn advance_sleep_actuator_components(
    value: &mut SleepActuatorComponents,
    founder: &CpuFoundationTrainer,
    phenotype: &CreaturePhenotype,
) {
    let tick = Tick(value.body.tick.raw() + 1);
    value.sleep.advance(tick).unwrap();
    if value.sleep.state().phase == SleepPhase::Consolidating
        && matches!(value.sleep.state().consolidation, ConsolidationState::None)
    {
        // Real empty-replay neural consolidation, exactly the host's no-event
        // branch. No memory observation, proof, reward or optimizer credit is
        // invented for this manually supplied physical operation.
        let evidence = replay_evidence(founder.phenotype(), &[]).unwrap();
        let mut neural =
            CpuOrganismState::from_checkpoint(founder.phenotype(), value.neural.clone()).unwrap();
        neural
            .consolidate_sleep(
                founder,
                &evidence,
                &phenotype.development_state_at(tick).unwrap(),
                phenotype.brain_genome.plasticity_parameters(),
            )
            .unwrap();
        value.neural = neural.checkpoint().unwrap();
        let mut state = value.sleep.state();
        state.consolidation = ConsolidationState::Committed {
            cycle_id: state.active_cycle_id,
            output_generation: value.neural.weight_generation,
            output_digest: json_digest(b"ALIFE-CPU-SLEEP-OUTPUT-V1", &value.neural).unwrap(),
        };
        value.sleep = SleepController::restore(value.sleep.config(), state).unwrap();
        value.consolidation_count += 1;
    }
    value.body = value
        .body
        .advance_with_neural_emission(
            tick,
            tick,
            BodyEventDelta {
                sleep_recovery: if value.sleep.state().phase == SleepPhase::Awake {
                    0.
                } else {
                    1.
                },
                ..BodyEventDelta::zero()
            },
            None,
            phenotype,
        )
        .unwrap();
}
fn verify_sleep_actuator_component_restore(
    founder: &CpuFoundationTrainer,
    phenotype: &CreaturePhenotype,
    initial: SleepActuatorComponents,
    frame: &PerceptionFrame,
    bundle: &MotorCommandBundle,
    physical: &SleepChoiceWorldReceiptV1,
) {
    let mut warm = initial;
    assert!(warm.body.body.sleeping);
    assert_eq!(warm.sleep.state().phase, SleepPhase::EnteringSleep);
    let mut cold: SleepActuatorComponents =
        serde_json::from_slice(&serde_json::to_vec(&warm).unwrap()).unwrap();
    let mut committed = false;
    let mut waking = false;
    for _ in 0..12 {
        advance_sleep_actuator_components(&mut warm, founder, phenotype);
        advance_sleep_actuator_components(&mut cold, founder, phenotype);
        let bytes = serde_json::to_vec(&warm).unwrap();
        assert_eq!(bytes, serde_json::to_vec(&cold).unwrap());
        cold = serde_json::from_slice(&bytes).unwrap();
        cold.sleep = SleepController::restore(cold.sleep.config(), cold.sleep.state()).unwrap();
        cold.controller.motor.validate(founder.phenotype()).unwrap();
        cold.controller.validate_replay(&[]).unwrap();
        committed |= matches!(
            warm.sleep.state().consolidation,
            ConsolidationState::Committed { .. }
        );
        waking |= warm.sleep.state().phase == SleepPhase::Waking;
        if warm.sleep.state().phase == SleepPhase::Awake {
            break;
        }
    }
    assert!(committed && waking);
    assert_eq!(warm.sleep.state().phase, SleepPhase::Awake);
    assert_eq!(warm.sleep.state().cycles_completed, 1);
    assert_eq!(warm.consolidation_count, 1);
    assert!(!warm.body.body.sleeping);
    assert!(cold
        .controller
        .observe_physical(frame, bundle, physical, &mut cold.sleep)
        .is_err());
    assert_eq!(warm.sleep.state(), cold.sleep.state());
    eprintln!("M1_ACTUATOR_COMPONENT_RESTORE entering/committed/waking/awake byte-exact; one empty-replay consolidation; duplicate receipt rejected; not a complete-host voluntary cycle or learned choice");
}

#[test]
fn sleep_choice_host_consumes_actual_sleep_receipt_once_and_awake_or_motion_never_enters() {
    let (host, source) = fixture();
    let initial = host.checkpoint().unwrap().encode().unwrap();
    for (id, moving) in [(3, false), (700, false), (3, true), (700, true)] {
        // Paired fixed actuator/controller fixtures, not forced neural choices.
        let mut h = CpuSleepChoiceHostV1::restore(
            CpuSleepChoiceHostCheckpointV1::decode(&initial).unwrap(),
            &source,
            SleepChoiceMotorModeV1::Full,
        )
        .unwrap();
        let world = &mut h.host.world;
        let organism = world
            .organism_registry()
            .iter()
            .next()
            .unwrap()
            .organism_id();
        let tick = world.tick();
        let home = world
            .organism_registry()
            .get(organism)
            .unwrap()
            .biochemistry()
            .homeostasis;
        let cap = SleepChoiceWorldAdmissionV1::for_organism(world, organism).unwrap();
        let (draft, _) = world
            .perception_sleep_choice_draft_with_bindings(&cap, tick, home)
            .unwrap();
        let frame = draft.finalize(PerceptionContextBlock::empty()).unwrap();
        let mut channels = vec![ChannelCommand::new(
            MotorChannel::Posture,
            ActionId(id),
            None,
            Vec3f::ZERO,
            Intensity::new(1.).unwrap(),
            DurationTicks(1),
            0.,
            Confidence::new(1.).unwrap(),
            0,
        )
        .unwrap()];
        if moving {
            channels.push(
                ChannelCommand::new(
                    MotorChannel::Locomotion,
                    HeadlessActionIds::STEP_FORWARD,
                    None,
                    Vec3f::new(1., 0., 0.),
                    Intensity::new(1.).unwrap(),
                    DurationTicks(1),
                    0.,
                    Confidence::new(1.).unwrap(),
                    0,
                )
                .unwrap(),
            );
        }
        let bundle =
            MotorCommandBundle::new(organism, ExperienceSequenceId(1), tick, channels).unwrap();
        let request = RecoveryRequestV1::new(&cap, &frame, &bundle).unwrap();
        let physical = world
            .apply_sleep_choice_motor_bundle_in_staged_tick(
                &request,
                &NeuralEmissionFrame::new(tick, 1, vec![]).unwrap(),
                0.,
                &[],
            )
            .unwrap();
        let r = h.host.residents.get_mut(&organism.raw()).unwrap();
        let state = r.sleep_choice.as_mut().unwrap();
        state
            .observe_physical(&frame, &bundle, &physical, &mut r.sleep)
            .unwrap();
        if id == 3 && !moving {
            assert!(physical.successful_stationary_body_sleep);
            assert_eq!(r.sleep.state().phase, SleepPhase::EnteringSleep);
            assert_eq!(
                r.sleep.state().last_trigger,
                Some(SleepTrigger::VoluntaryBodySleepV1)
            );
            assert_eq!(
                physical
                    .motor
                    .biology_after
                    .homeostasis
                    .hormones
                    .sleep_pressure,
                0.
            );
            let phase = r.sleep.state();
            assert!(state
                .observe_physical(&frame, &bundle, &physical, &mut r.sleep)
                .is_err());
            assert_eq!(r.sleep.state(), phase);
            verify_sleep_actuator_component_restore(
                &h.founder,
                h.host
                    .world
                    .organism_registry()
                    .get(organism)
                    .unwrap()
                    .phenotype(),
                SleepActuatorComponents {
                    body: physical.motor.biology_after,
                    sleep: r.sleep,
                    controller: state.clone(),
                    neural: r.neural.checkpoint().unwrap(),
                    consolidation_count: 0,
                },
                &frame,
                &bundle,
                &physical,
            );
        } else {
            assert_eq!(r.sleep.state().phase, SleepPhase::Awake);
            assert!(state.consumed_voluntary.is_none());
        }
        if moving {
            assert_ne!(physical.actual_displacement, Vec3f::ZERO);
        }
    }
}

#[test]
fn sleep_choice_host_generic_cpu_gpu_live_and_m0_paths_reject_m1() {
    let (host, source) = fixture();
    let p = host.founder.phenotype();
    let low = BrainGenome::scaffold(
        0x5343_4c4f,
        BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID,
    );
    let low_development =
        DevelopmentState::new(low.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
    let (low, _) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
        low,
        low_development,
        SensorProfile::GroundedObjectSlotsV1,
    )
    .unwrap();
    assert!(CpuSleepChoiceHostV1::validate_source_channels(&low).is_err());
    assert!(CpuSleepChoiceHostV1::validate_source_channels(p).is_ok());
    let (m1, _) = PhenotypeCompiler::compile_sleep_choice_m1(&source).unwrap();
    assert!(StageTrainableMask::recurrent_only(&m1).is_err());
    assert!(CpuFoundationTrainer::new(
        m1.clone(),
        host.founder.source_foundation.clone(),
        host.founder.checkpoint().stage_mask,
        AdamWConfig::default()
    )
    .is_err());
    assert!(alife_gpu_backend::GpuPhenotypeUpload::try_from(&m1).is_err());
    assert!(alife_gpu_backend::GpuClassBucketPlan::new(
        BrainCapacityClass::n2144_sleep_choice_research(),
        1
    )
    .is_err());
    assert!(alife_gpu_backend::GpuV11CausalState::for_phenotype(&m1).is_err());
    assert!(BrainCapacityClass::production_for_id(m1.brain_class_id()).is_err());
    let source_record = host.world().organism_registry().iter().next().unwrap();
    assert!(
        CreatureGenome::reproduce(source_record.genome(), source_record.genome(), 0x53434d32)
            .is_err()
    );
    let mut config = CanonicalNewGameConfig::phase3(FIXTURE_SEED, 1).unwrap();
    config.sensor_profile = SensorProfile::GroundedObjectSlotsSleepChoiceV1;
    let builtin =
        FoundationWeightAsset::builtin_nano512_v1(SensorProfile::GroundedObjectSlotsV1).unwrap();
    assert!(create_canonical_new_game(&config, &builtin).is_err());
    assert!(create_grounded_drive_research_new_game(&config, source_record.genome()).is_err());
    let mut world = host.world().clone();
    let cap =
        SleepChoiceWorldAdmissionV1::for_organism(&world, source_record.organism_id()).unwrap();
    let (draft, _) = world
        .perception_sleep_choice_draft_with_bindings(
            &cap,
            world.tick(),
            source_record.biochemistry().homeostasis,
        )
        .unwrap();
    let frame = draft.finalize(PerceptionContextBlock::empty()).unwrap();
    let mut bucket = alife_gpu_backend::GpuClassBucketPlan::new(
        BrainCapacityClass::n2048_grounded_drive_research(),
        1,
    )
    .unwrap();
    let slot = bucket.insert_phenotype(0, 1, p).unwrap();
    assert!(alife_gpu_backend::GpuPerceptionUpload::try_from_frame(&frame, &slot, 0).is_err());
    assert!(super::super::super::input::sample_cpu_joint_action(
        p,
        &frame,
        &vec![0.; frame.candidates().len()],
        1,
        0,
        1.
    )
    .is_err());
    let cp = host.checkpoint().unwrap();
    let m0 = MotorHostStateV1::fresh(&source, MotorHostModeV1::Full).unwrap();
    let mut controllers = std::collections::BTreeMap::new();
    controllers.insert(source_record.organism_id().raw(), m0);
    let old = serde_json::json!({"schema_version":1,
        "policy":"class5-body+sealed-m0-native-composite-v1;construction-cadence;single-metabolic-debit",
        "mode":MotorHostModeV1::Full,"source_inputs":source,"recipe_digest":MotorLobeM0V1::recipe_digest(),
        "source_asset":host.founder.source_foundation,"founder":host.founder.checkpoint(),
        "canonical":cp.payload.canonical,"controllers":controllers});
    let old: CpuMotorLobeHostCheckpointV1 = serde_json::from_value(old).unwrap();
    assert!(CpuMotorLobeHostV1::restore(old, &source, MotorHostModeV1::Full).is_err());
}

#[test]
fn sleep_choice_neutral_repertoire_prior_is_measured_not_attributed_to_pressure() {
    let (host, _) = fixture();
    let record = host.world().organism_registry().iter().next().unwrap();
    let mut world = host.world().clone();
    let cap = SleepChoiceWorldAdmissionV1::for_organism(&world, record.organism_id()).unwrap();
    let (draft, _) = world
        .perception_sleep_choice_draft_with_bindings(
            &cap,
            world.tick(),
            record.biochemistry().homeostasis,
        )
        .unwrap();
    let frame = draft.finalize(PerceptionContextBlock::empty()).unwrap();
    let rest: Vec<_> = frame
        .candidates()
        .iter()
        .enumerate()
        .filter(|(_, candidate)| candidate.family == CandidateActionFamily::Rest)
        .collect();
    assert_eq!(rest.len(), 2);
    assert_eq!(
        rest.iter()
            .map(|(_, c)| c.action_id.raw())
            .collect::<std::collections::BTreeSet<_>>(),
        [3, 700].into_iter().collect()
    );
    let count = frame.candidates().len();
    assert!(count > 2);
    // Exact neutral logits, not a neural output or empirical choice frequency.
    let logits = vec![0.; count];
    let action = super::super::super::input::sample_cpu_sleep_choice_joint_action(
        host.founder.phenotype(),
        &frame,
        &logits,
        1,
        0,
        1.,
    )
    .unwrap();
    assert_eq!(action.representative_mask.count_ones() as usize, count);
    let old_mass = 0_f64.exp();
    let new_mass = 2. * 0_f64.exp();
    assert_eq!(new_mass, 2. * old_mass);
    let old_probability = old_mass / (count - 1) as f64;
    let new_probability = new_mass / count as f64;
    assert!(new_probability > old_probability);
    let rest_mask = rest
        .iter()
        .fold(0_u32, |mask, (index, _)| mask | (1 << index));
    assert_eq!(action.motor_masks[4] & rest_mask, rest_mask);
    eprintln!(
        "M1_NEUTRAL_PRIOR candidates={} rest_candidates=2 old_projected_candidates={} old_rest_mass={} new_rest_mass={} old_representative_rest_probability={} new_representative_rest_probability={} posture_mask={:#x}; no repertoire normalization; conditional factorized posture is distinct from representative probability",
        count,
        count - 1,
        old_mass,
        new_mass,
        old_probability,
        new_probability,
        action.motor_masks[4]
    );
}

#[test]
fn sleep_choice_fixed_host_preserves_natural_continuation_without_demanding_sleep() {
    let (mut host, source) = fixture();
    let mut cold = CpuSleepChoiceHostV1::restore(
        CpuSleepChoiceHostCheckpointV1::decode(&host.checkpoint().unwrap().encode().unwrap())
            .unwrap(),
        &source,
        SleepChoiceMotorModeV1::Full,
    )
    .unwrap();
    let mut saw_entry = false;
    let mut saw_committed = false;
    let mut saw_waking = false;
    let mut saw_later_decision = false;
    let mut entry_sequence = 0;
    // One declared fixed fixture and horizon. Ordinary logits, candidates,
    // random draws and the first frame are untouched; no seed search or settling.
    for _ in 0..32 {
        let step = host.step(1.).unwrap();
        for decision in &step.decisions {
            eprintln!("M1_PHASE_DECISION source_tick={} actual_microsteps={} operation={:?} awake_dose={} sleep_dose={} memory={:?}",
                decision.motor.tick.raw(), decision.motor.work.microsteps,
                decision.physical.operation, decision.physical.awake_recovery,
                decision.physical.sleep_recovery, decision.motor.memory_contributions);
        }
        cold.step(1.).unwrap();
        assert_eq!(
            host.checkpoint().unwrap().encode().unwrap(),
            cold.checkpoint().unwrap().encode().unwrap()
        );
        let resident = host.host.residents.values().next().unwrap();
        let state = resident.sleep.state();
        if state.last_trigger == Some(SleepTrigger::VoluntaryBodySleepV1) {
            if state.phase == SleepPhase::EnteringSleep {
                if !saw_entry {
                    entry_sequence = resident.next_sequence - 1;
                }
                saw_entry = true;
                assert!(resident
                    .sleep_choice
                    .as_ref()
                    .unwrap()
                    .consumed_voluntary
                    .is_some());
            }
            saw_committed |= matches!(state.consolidation, ConsolidationState::Committed { .. });
            saw_waking |= state.phase == SleepPhase::Waking;
            saw_later_decision |=
                state.cycles_completed > 0 && resident.next_sequence - 1 > entry_sequence;
        }
        if state.phase != SleepPhase::Awake {
            let bytes = host.checkpoint().unwrap().encode().unwrap();
            cold = CpuSleepChoiceHostV1::restore(
                CpuSleepChoiceHostCheckpointV1::decode(&bytes).unwrap(),
                &source,
                SleepChoiceMotorModeV1::Full,
            )
            .unwrap();
            assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), bytes);
            // The next iteration compares this cold state against the original
            // uninterrupted warm host, never against another cold clone.
        }
        eprintln!(
            "M1_PHASE_FIXTURE tick={} decisions={} phase={:?} trigger={:?} cycles={} sequence={}",
            step.tick_after.raw(),
            step.decisions.len(),
            state.phase,
            state.last_trigger,
            state.cycles_completed,
            resident.next_sequence - 1
        );
    }
    // This low-pressure context is not required to choose BodySleep. Treating
    // absence of that sampled action as a source failure was a test-design
    // error; the original failed trace remains archived, not retuned away.
    assert_eq!(host.world().tick().raw(), 272);
    eprintln!("M1_NATURAL_RESTORE_HORIZON ticks=32 voluntary_entry={} committed={} waking={} later_decision={}; phase mechanics are qualified separately with a real actuator receipt", saw_entry, saw_committed, saw_waking, saw_later_decision);
}

#[test]
fn sleep_choice_route_only_valuation_policy_is_shared_by_construction_and_restore() {
    let profile = BiologicalValueProfile::default();
    assert!(CpuSleepChoiceHostV1::validate_pressure_valuation(profile).is_ok());
    for coefficient in [-1. / 7., 1. / 7., f32::NAN, f32::INFINITY] {
        let mut changed = profile;
        changed.hormones[8] = coefficient;
        assert!(CpuSleepChoiceHostV1::validate_pressure_valuation(changed).is_err());
    }
}

#[test]
fn sleep_choice_fixture_natural_pressure_reference_exceeds_default_lifetime() {
    let (host, _) = fixture();
    let record = host.world().organism_registry().iter().next().unwrap();
    let phenotype = record.phenotype();
    let graph = &phenotype.chemistry.biochemical;
    let pressure_id = ChemicalSpeciesId(18);
    let pressure = graph
        .species()
        .iter()
        .find(|s| s.id == pressure_id)
        .unwrap();
    let positive: Vec<_> = graph
        .emitters()
        .iter()
        .filter(|e| e.target == pressure_id && e.gain > 0.)
        .collect();
    assert_eq!(positive.len(), 1);
    let awake = positive[0];
    assert_eq!(awake.source, BiochemicalSourceLocus::Awake);
    assert_eq!(awake.response, EmitterResponse::Analogue);
    assert!(!awake.inverted);
    assert_eq!(awake.threshold, 0.);
    assert_eq!(awake.cadence_ticks, 1);
    assert_eq!(pressure.minimum, 0.);
    assert_eq!(
        graph
            .neuroemitters()
            .iter()
            .filter(|e| e.target == pressure_id)
            .count(),
        0
    );
    assert!(graph.reactions().iter().all(|r| r
        .products
        .iter()
        .chain(&r.reactants)
        .all(|t| t.species != pressure_id)));
    assert_eq!(
        phenotype
            .development_state_at(Tick::ZERO)
            .unwrap()
            .maturation
            .raw(),
        0.
    );
    assert_eq!(record.biochemistry().development.biochemical_expression, 1.);
    assert!(!host.world().age_death_disabled());
    let retention = f64::from(pressure.decay_retention);
    let equilibrium = f64::from(pressure.baseline) + f64::from(awake.gain) / (1. - retention);
    let lifespan = PassiveBodyUpkeepPolicy::maximum_lifespan_ticks(phenotype);
    let reference = f64::from(
        host.founder
            .phenotype()
            .cognitive_architecture()
            .sleep_trigger_threshold(),
    );
    // Optimistically grant full expression from birth. Actual maturation, rest,
    // or earlier metabolic death can only reduce this uninterrupted-awake bound.
    let upper_at_age_death = equilibrium * (1. - retention.powf(lifespan as f64));
    let earliest_optimistic_crossing =
        ((1. - reference / equilibrium).ln() / retention.ln()).ceil() as u64;
    assert!(upper_at_age_death < reference);
    assert!(earliest_optimistic_crossing > lifespan);
    // Prospective lower bound for the separate age-disabled fixture: discard all
    // accumulation before the known full-expression update240. Do not choose a
    // preparation length from sampled biology or a neural outcome.
    let lower_at_10000 = equilibrium * (1. - retention.powf((10_000 - 240) as f64));
    assert!(lower_at_10000 > reference);
    eprintln!("M1_PRESSURE_TIMESCALE baseline={} retention={} awake_gain={} age_death_tick={} optimistic_pressure_at_death={} reference={} earliest_optimistic_crossing={} controlled_10000_lower_bound={}; unchanged default life cannot meet the high-pressure preparation condition",
        pressure.baseline, pressure.decay_retention, awake.gain, lifespan, upper_at_age_death,
        reference, earliest_optimistic_crossing, lower_at_10000);
}

#[test]
fn sleep_choice_age_disabled_high_pressure_host_has_byte_exact_voluntary_cycle() {
    // A separate controlled context, not the default-life fixture or a behavioral
    // cohort. Same source genotype, seed, logits, sampler and actual first frame.
    // Fixed before execution:10000 body-only ticks with age death disabled at
    // birth, followed by exactly32 neural/world ticks. No adaptive extension.
    let (mut host, source) = fixture_with_preparation(FixedBodyPreparation::AgeDisabled10000);
    let initial = host.checkpoint().unwrap().encode().unwrap();
    let mut cold = CpuSleepChoiceHostV1::restore(
        CpuSleepChoiceHostCheckpointV1::decode(&initial).unwrap(),
        &source,
        SleepChoiceMotorModeV1::Full,
    )
    .unwrap();
    let mut saw_entry = false;
    let mut saw_committed = false;
    let mut saw_waking = false;
    let mut saw_later_decision = false;
    let mut entry_sequence = 0;
    let mut consolidations = std::collections::BTreeSet::new();
    for offset in 0..32 {
        let step = host.step(1.).unwrap();
        for decision in &step.decisions {
            eprintln!("M1_HIGH_PRESSURE_DECISION offset={} tick={} configured_microsteps={} actual_microsteps={} pressure={} reference={} encoded={:?} opponent={:?} pressure_head={:?} operation={:?} awake_dose={} sleep_dose={} memory={:?}",
                offset, decision.motor.tick.raw(), decision.motor.configured_microsteps,
                decision.motor.work.microsteps, decision.motor.raw_pressure, decision.motor.pressure_reference,
                decision.motor.pressure_encoded_pair, decision.motor.pressure_opponent_pair,
                decision.motor.pressure_candidate_contributions, decision.physical.operation,
                decision.physical.awake_recovery, decision.physical.sleep_recovery, decision.motor.memory_contributions);
        }
        let restored_step = cold.step(1.).unwrap();
        assert_eq!(step.decisions.len(), restored_step.decisions.len());
        assert_eq!(
            step.sleep_consolidations,
            restored_step.sleep_consolidations
        );
        for (a, b) in step.decisions.iter().zip(&restored_step.decisions) {
            assert_eq!(
                serde_json::to_vec(&a.patch).unwrap(),
                serde_json::to_vec(&b.patch).unwrap()
            );
            assert_eq!(
                serde_json::to_vec(&a.motor).unwrap(),
                serde_json::to_vec(&b.motor).unwrap()
            );
            assert_eq!(
                serde_json::to_vec(&a.physical).unwrap(),
                serde_json::to_vec(&b.physical).unwrap()
            );
        }
        let bytes = host.checkpoint().unwrap().encode().unwrap();
        assert_eq!(bytes, cold.checkpoint().unwrap().encode().unwrap());
        let resident = host.host.residents.values().next().unwrap();
        let state = resident.sleep.state();
        if state.phase == SleepPhase::EnteringSleep
            && state.last_trigger == Some(SleepTrigger::VoluntaryBodySleepV1)
        {
            if !saw_entry {
                entry_sequence = resident.next_sequence - 1;
            }
            saw_entry = true;
            assert!(resident
                .sleep_choice
                .as_ref()
                .unwrap()
                .consumed_voluntary
                .is_some());
        }
        if state.last_trigger == Some(SleepTrigger::VoluntaryBodySleepV1) {
            saw_committed |= matches!(state.consolidation, ConsolidationState::Committed { .. });
            saw_waking |= state.phase == SleepPhase::Waking;
            saw_later_decision |=
                state.cycles_completed > 0 && resident.next_sequence - 1 > entry_sequence;
        }
        if step.sleep_consolidations > 0 {
            assert_eq!(step.sleep_consolidations, 1);
            assert!(
                consolidations.insert(state.active_cycle_id),
                "duplicate consolidation credit"
            );
        }
        if state.phase != SleepPhase::Awake {
            cold = CpuSleepChoiceHostV1::restore(
                CpuSleepChoiceHostCheckpointV1::decode(&bytes).unwrap(),
                &source,
                SleepChoiceMotorModeV1::Full,
            )
            .unwrap();
            assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), bytes);
        }
        eprintln!("M1_HIGH_PRESSURE_PHASE tick={} decisions={} phase={:?} trigger={:?} cycles={} sequence={} consolidations={}",
            step.tick_after.raw(), step.decisions.len(), state.phase, state.last_trigger,
            state.cycles_completed, resident.next_sequence - 1, step.sleep_consolidations);
    }
    eprintln!("M1_HIGH_PRESSURE_RESULT fixed_ticks=32 entry={} committed={} waking={} later_decision={} consolidation_cycles={:?}; age-disabled full-host mechanism fixture, not default-life or learned competence", saw_entry, saw_committed, saw_waking, saw_later_decision, consolidations);
    assert_eq!(host.world().tick().raw(), 10_032);
    assert!(saw_entry && saw_committed && saw_waking && saw_later_decision);
    assert!(!consolidations.is_empty());
    let resident = host.host.residents.values().next().unwrap();
    assert!(resident
        .neural
        .checkpoint()
        .unwrap()
        .fast
        .iter()
        .any(|x| *x != 0.));
    assert!(!resident
        .memory
        .export_active_bank()
        .unwrap()
        .records
        .is_empty());
    assert_eq!(host.founder.checkpoint().optimizer_step, 23);
    assert_eq!(host.founder.checkpoint().update_ages[0], 23);
    assert_eq!(host.founder.checkpoint().first_moment[0], 0.03125);
    assert_eq!(host.founder.checkpoint().second_moment[0], 0.0625);
}
