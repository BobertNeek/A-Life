//! Private composite execution for the fresh-host successor. The class-5 body
//! stays class 5. This module does not admit class 7 to an ordinary trainer.
use super::{
    finite, invalid,
    replay::{SparseGraph, Tape},
};
use crate::{TrainingError, TrainingSequence};
use alife_core::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SleepChoiceMotorModeV1 {
    Full,
    PressureSham,
    SignSwap,
}

/// No writable controller parameters, optimizer slots or somatic offsets exist.
/// All inherited writable state stays in the ordinary class-5 resident.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct SleepChoiceMotorStateV1 {
    schema_version: u16,
    source_inputs: PhenotypeCompilerInputs,
    mode: SleepChoiceMotorModeV1,
    recipe_digest: [u64; 4],
    composite_hash: PhenotypeHash,
    descriptor: SleepChoiceM1V1,
    activations: Vec<f32>,
    inactive: Vec<f32>,
    ema: Vec<f32>,
    metabolic: Vec<f32>,
    pub(super) last_receipt: Option<SleepChoiceMotorReceiptV1>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SleepChoiceMotorReceiptV1 {
    pub tick: Tick,
    pub frame_digest: PerceptionFrameDigest,
    pub chemistry_version: u16,
    pub raw_drives: [f32; 11],
    pub raw_pressure: f32,
    pub pressure_reference: f32,
    pub pressure_encoded_pair: [f32; 2],
    pub pressure_opponent_pair: [f32; 2],
    pub mode: SleepChoiceMotorModeV1,
    pub configured_microsteps: u8,
    pub live_maturation: f32,
    pub reservation_q24: u64,
    pub reservation_q16: u32,
    pub available_atp_q16: u32,
    pub applied_body_energy_debit: f32,
    pub candidate_logits: Vec<f32>,
    pub source_candidate_logits: Vec<f32>,
    pub innate_contributions: Vec<f32>,
    pub family_biases: Vec<f32>,
    pub memory_contributions: Vec<f32>,
    pub cognitive_contributions: Vec<f32>,
    pub reference: [f32; 11],
    pub interoceptive_gain: f32,
    pub regional_gain: f32,
    pub offset: f32,
    pub encoded_pairs: Vec<[f32; 2]>,
    pub pressure_pairs: Vec<[f32; 2]>,
    pub appended_activations: Vec<f32>,
    pub fixed_candidate_contributions: Vec<f32>,
    pub pressure_candidate_contributions: Vec<f32>,
    pub work: SleepChoiceWorkV1,
}
impl SleepChoiceMotorStateV1 {
    pub(super) fn fresh(
        source: &PhenotypeCompilerInputs,
        mode: SleepChoiceMotorModeV1,
    ) -> Result<Self, TrainingError> {
        let (p, descriptor) = PhenotypeCompiler::compile_sleep_choice_m1(source)?;
        Ok(Self {
            schema_version: 1,
            source_inputs: source.clone(),
            mode,
            recipe_digest: SleepChoiceM1V1::recipe_digest(),
            composite_hash: p.phenotype_hash(),
            descriptor,
            activations: vec![0.; 96],
            inactive: vec![0.; 96],
            ema: vec![0.; 96],
            metabolic: vec![0.; 96],
            last_receipt: None,
        })
    }
    pub(super) fn matches(
        &self,
        source: &PhenotypeCompilerInputs,
        mode: SleepChoiceMotorModeV1,
    ) -> bool {
        &self.source_inputs == source && self.mode == mode
    }
    pub(super) fn validate(
        &self,
        source: &BrainPhenotype,
    ) -> Result<BrainPhenotype, TrainingError> {
        let (p, descriptor) = PhenotypeCompiler::compile_sleep_choice_m1(&self.source_inputs)?;
        let source_compiled = PhenotypeCompiler::compile_validated(
            &self.source_inputs,
            &BrainCapacityClass::n2048_grounded_drive_research(),
        )?;
        if self.descriptor != descriptor
            || self.schema_version != 1
            || self.recipe_digest != SleepChoiceM1V1::recipe_digest()
            || self.composite_hash != p.phenotype_hash()
            || source_compiled != *source
            || p.synapses()[..MotorLobeM0V1::BASE_SYNAPSES] != *source.synapses()
            || p.neuron_dynamics()[..2048] != *source.neuron_dynamics()
            || self
                .ema
                .iter()
                .chain(&self.metabolic)
                .any(|v| !(0. ..=1.).contains(v))
        {
            return Err(invalid());
        }
        for bank in [
            &self.activations,
            &self.inactive,
            &self.ema,
            &self.metabolic,
        ] {
            if bank.len() != 96 {
                return Err(invalid());
            }
            finite(bank)?;
        }
        Ok(p)
    }
    pub(super) fn validate_partition(
        &self,
        initial: &crate::TrainingInitialState,
    ) -> Result<(), TrainingError> {
        initial.dendrites.validate_for_neuron_count(2048)?;
        let capacity = usize::from(
            self.source_inputs
                .genome()
                .cognitive_architecture()
                .dendritic_branch_capacity(),
        );
        if initial
            .dendrites
            .branches()
            .len()
            .checked_add(SleepChoiceM1V1::NEW_BRANCHES)
            .is_none_or(|n| n > capacity)
        {
            return Err(invalid());
        }
        Ok(())
    }
    /// One native forward, never a second prefix pass. Prefix validation occurs
    /// before joining; dynamic edges and branches cannot enter the fixed region.
    pub(super) fn forward(
        &mut self,
        source: &BrainPhenotype,
        weights: &[f32],
        q: &TrainingSequence,
        frame: &PerceptionFrame,
        receptors: &NeuralReceptorFrame,
        effects: &NeuralReceptorEffects,
    ) -> Result<Tape, TrainingError> {
        q.validate_for(source)?;
        self.validate_partition(&q.initial)?;
        let p = self.validate(source)?;
        receptors.validate_contract()?;
        let expected_effects = NeuralReceptorEffects::from_frame(
            receptors,
            &NeuralReceptorPhenotype::compile(source)?,
        )?;
        if q.ticks.len() != 1
            || q.initial.activations.len() != 2048
            || weights.len() != MotorLobeM0V1::BASE_SYNAPSES
            || *effects != expected_effects
            || effects.source_tick != frame.tick()
            || source.sensor_profile() != SensorProfile::GroundedObjectSlotsV1
            || frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
            || q.ticks[0].candidates.len() != frame.candidates().len()
            || q.initial
                .dendrites
                .branches()
                .iter()
                .any(|b| b.target >= 2048 || b.inputs.iter().any(|i| i.source >= 2048))
            || q.ticks[0].structural_synapses.iter().any(|e| {
                e.source >= 2048
                    || e.target >= 2048
                    || e.route as usize >= source.projections().len()
            })
        {
            return Err(invalid());
        }
        let mut joined = q.clone();
        joined.phenotype_hash = p.phenotype_hash();
        joined.initial.activations.extend(&self.activations);
        joined.initial.activity_ema.extend(&self.ema);
        joined.initial.metabolic_load.extend(&self.metabolic);
        let mut branches = q.initial.dendrites.branches().to_vec();
        branches.extend(self.descriptor.fixed_branches()?.branches().iter().cloned());
        joined.initial.dendrites = DendriticBranchSet::new(branches)?;
        let t = &mut joined.ticks[0];
        let offset =
            ((effects.structural_growth_gate + effects.sleep_gate + effects.consolidation_gate)
                / 3.
                - 0.5)
                * 0.05;
        // Preserve the old encoder byte-for-byte. Appended unused cells receive
        // the same canonical afferent offset, just as the native encoder does.
        t.encoded_inputs.resize(2144, offset.clamp(-1., 1.));
        let drives = frame.homeostasis().drives.to_array();
        for a in p
            .sensor_encoder()
            .assignments()
            .iter()
            .filter(|a| a.target_neuron() >= 2048)
        {
            let target = a.target_neuron() as usize;
            if target >= 2140 {
                continue;
            }
            let raw = drives[a.source_index() as usize];
            let (lo, hi) = a.clamp_range();
            let affine = (raw * a.scale() + a.bias()).clamp(lo, hi);
            t.encoded_inputs[target] =
                (affine * effects.interoceptive_gain * effects.regional_excitability + offset)
                    .clamp(-1., 1.);
        }
        let pressure_reference = self.descriptor.pressure_reference();
        let raw_pressure = frame.homeostasis().hormones.to_array()[8];
        let pressure = if self.mode == SleepChoiceMotorModeV1::PressureSham {
            pressure_reference
        } else {
            raw_pressure
        };
        for (target, raw) in [(2140, pressure), (2141, pressure_reference)] {
            t.encoded_inputs[target] =
                (raw * effects.interoceptive_gain * effects.regional_excitability + offset)
                    .clamp(-1., 1.);
        }
        t.enabled_routes.push(true);
        t.effective_weight_offsets.resize(p.synapses().len(), 0.);
        let mut execution_weights = weights.to_vec();
        execution_weights.extend(
            p.synapses()[MotorLobeM0V1::BASE_SYNAPSES..]
                .iter()
                .map(|s| s.genetic_weight()),
        );
        if self.mode == SleepChoiceMotorModeV1::SignSwap {
            for weight in
                &mut execution_weights[MotorLobeM0V1::BASE_SYNAPSES + MotorLobeM0V1::NEW_READOUTS..]
            {
                *weight = -*weight;
            }
        }
        let t = &joined.ticks[0];
        let rows = t
            .candidates
            .iter()
            .enumerate()
            .map(|(i, c)| super::sleep_choice_replay::SleepChoiceReplayRowV1::bind(frame, i, c))
            .collect::<Result<Vec<_>, _>>()?;
        let mut tape = SparseGraph::new(&p).forward_sleep_choice(
            &p,
            &execution_weights,
            &joined,
            frame,
            &rows,
        )?;
        let steps = t.microstep_count as usize;
        let activations = &tape.evaluation.final_activations[0];
        let products = t
            .candidates
            .iter()
            .map(|c| SleepChoiceM1V1::readout_count(c.family) as u64)
            .sum();
        // These are the actual accumulators from the one native forward, not
        // another telemetry-only multiplication of the fixed readout head.
        let contributions = tape.fixed_motor_head[0].clone();
        let receipt = SleepChoiceMotorReceiptV1 {
            tick: frame.tick(),
            frame_digest: frame.frame_digest(),
            chemistry_version: effects.source_chemistry_version,
            configured_microsteps: source.microstep_count(),
            live_maturation: 0.,
            reservation_q24: 0,
            reservation_q16: 0,
            available_atp_q16: 0,
            applied_body_energy_debit: 0.,
            candidate_logits: tape.evaluation.candidate_logits[0].clone(),
            source_candidate_logits: tape.source_candidate_logits[0].clone(),
            innate_contributions: t.candidates.iter().map(|c| c.innate_bias).collect(),
            family_biases: t
                .candidates
                .iter()
                .map(|c| {
                    source
                        .candidate_decoder()
                        .families()
                        .iter()
                        .find(|f| f.family() == c.family)
                        .map_or(0., |f| f.bias())
                })
                .collect(),
            memory_contributions: tape.memory[0]
                .iter()
                .map(|v| v.clamp(-q.memory_candidate_gain, q.memory_candidate_gain))
                .collect(),
            cognitive_contributions: tape.cognitive[0]
                .iter()
                .map(|v| v.clamp(-q.memory_candidate_gain, q.memory_candidate_gain))
                .collect(),
            raw_drives: drives,
            raw_pressure,
            pressure_reference,
            pressure_encoded_pair: [t.encoded_inputs[2140], t.encoded_inputs[2141]],
            pressure_opponent_pair: [activations[2142], activations[2143]],
            mode: self.mode,
            reference: MotorLobeM0V1::SETPOINTS,
            interoceptive_gain: effects.interoceptive_gain,
            regional_gain: effects.regional_excitability,
            offset,
            encoded_pairs: t.encoded_inputs[2048..2070].as_chunks::<2>().0.to_vec(),
            pressure_pairs: activations[2070..2094].as_chunks::<2>().0.to_vec(),
            appended_activations: activations[2048..].to_vec(),
            fixed_candidate_contributions: contributions,
            pressure_candidate_contributions: tape.sleep_pressure_head[0].clone(),
            work: SleepChoiceWorkV1::checked(steps as u64, 1, products)?,
        };
        self.activations = activations[2048..].to_vec();
        if steps > 0 {
            self.inactive = tape.a[steps - 1][2048..].to_vec();
        }
        self.ema = tape.evaluation.final_activity_ema[0][2048..].to_vec();
        self.metabolic = tape.evaluation.final_metabolic_load[0][2048..].to_vec();
        self.last_receipt = Some(receipt);
        // The ordinary plasticity machinery sees only its original coordinates.
        for bank in &mut tape.a {
            bank.truncate(2048);
        }
        for bank in &mut tape.m {
            bank.truncate(2048);
        }
        for bank in &mut tape.evaluation.final_activations {
            bank.truncate(2048);
        }
        for bank in &mut tape.evaluation.final_activity_ema {
            bank.truncate(2048);
        }
        for bank in &mut tape.evaluation.final_metabolic_load {
            bank.truncate(2048);
        }
        Ok(tape)
    }
}

/// One conversion after every term, including zero-valued fixed operations.
pub(super) fn reserve_work(
    source: &BrainWorkCounters,
    source_dynamic_q24: u64,
    appended: &SleepChoiceWorkV1,
    available_q16: u32,
) -> Result<(u64, u32, bool), ScaffoldContractError> {
    let cost = BrainActivityPolicyV1::grounded_drive_research_v1().cost;
    let total = cost
        .neural_cost_q24(source)?
        .checked_add(source_dynamic_q24)
        .and_then(|n| n.checked_add(appended.cost_q24().ok()?))
        .ok_or(ScaffoldContractError::BrainActivityPolicyMismatch)?;
    let debit = cost.q24_to_atp_q16_round_half_up(total)?;
    Ok((total, debit, available_q16 >= debit))
}
