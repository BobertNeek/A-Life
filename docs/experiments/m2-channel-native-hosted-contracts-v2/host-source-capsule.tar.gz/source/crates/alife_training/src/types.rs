//! Offline-only foundation-training inputs and receipts.

use alife_core::{
    BrainPhenotype, CandidateActionFamily, CandidateFeatureVector, CompiledSynapseKind,
    ScaffoldContractError, SpeechDecoderLayoutV1, Validate,
};

pub const TRAINING_SEQUENCE_TICKS: usize = 32;
pub const MAX_TRAINING_SEQUENCE_TICKS: usize = 2048;

/// Equal positive/silence loss budgets per replay window. A single physically
/// completed verb must not be diluted by dozens of waiting/silence frames.
/// Relative label weights remain meaningful within each class; missing classes
/// receive no budget. Only the 18 positive or two silence outputs are supervised.
pub fn replay_speech_loss_scales(targets: &[Option<ReplaySpeechTarget>]) -> [f32; 2] {
    let mut mass = [0.0_f32; 2];
    for target in targets.iter().flatten() {
        mass[usize::from(target.token.is_none())] += target.weight * target.len() as f32;
    }
    let classes = mass.iter().filter(|m| **m > 0.0).count().max(1) as f32;
    [0, 1].map(|class| {
        if mass[class] > 0.0 {
            1.0 / (classes * mass[class] * if class == 0 { 18.0 } else { 2.0 })
        } else {
            0.0
        }
    })
}

/// Diagnostic contributions to the existing normalized speech MSE objective.
/// These are payload losses, not action imitation losses or emitted utterances.
#[derive(Debug, Clone, Default, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct ReplaySpeechPayloadDiagnostics {
    pub positive_loss: f64,
    pub silence_loss: f64,
    pub positive_label_rows: usize,
    pub silence_label_rows: usize,
    pub positive_token_steps: usize,
}

/// Reduce the already computed GPU speech outputs without another forward pass.
/// Uses the same class scales and supervised outputs as the existing objective.
pub fn replay_speech_payload_diagnostics(
    logits: &[f32],
    targets: &[Option<ReplaySpeechTarget>],
) -> Result<ReplaySpeechPayloadDiagnostics, crate::TrainingError> {
    if logits.len() != targets.len().saturating_mul(192) {
        return Err(crate::TrainingError::MalformedReadback);
    }
    for target in targets.iter().flatten() {
        target.validate()?;
    }
    let scales = replay_speech_loss_scales(targets);
    let mut result = ReplaySpeechPayloadDiagnostics::default();
    for (tick, target) in targets.iter().enumerate() {
        let Some(target) = target else { continue };
        let silence = target.token.is_none();
        if silence {
            result.silence_label_rows += 1;
        } else {
            result.positive_label_rows += 1;
            result.positive_token_steps += target.len();
        }
        for step in 0..target.len() {
            for (output, expected) in target.step_logits(step).into_iter().enumerate() {
                let weight = target.output_weight(output) * scales[usize::from(silence)];
                if weight == 0.0 {
                    continue;
                }
                let error = f64::from(logits[(tick * 6 + step) * 32 + output] - expected);
                let loss = f64::from(weight) * error * error;
                if !loss.is_finite() {
                    return Err(crate::TrainingError::MalformedReadback);
                }
                if silence {
                    result.silence_loss += loss;
                } else {
                    result.positive_loss += loss;
                }
            }
        }
    }
    Ok(result)
}

#[cfg(test)]
mod speech_payload_diagnostic_tests {
    use super::*;

    fn positive() -> ReplaySpeechTarget {
        ReplaySpeechTarget {
            token: Some(11),
            continuation: [1, 0, 0, 0, 0],
            act: alife_core::SpeechActKind::Declare,
            weight: 1.0,
        }
    }

    #[test]
    fn speech_payload_diagnostics_preserve_equal_class_budgets() {
        let positive = positive();
        let silence = ReplaySpeechTarget {
            token: None,
            continuation: [0; 5],
            weight: 0.25,
            ..positive
        };
        let measured =
            replay_speech_payload_diagnostics(&[0.0; 384], &[Some(positive), Some(silence)])
                .unwrap();
        // Every supervised target is +/-0.8. Each present class receives half
        // the objective budget, regardless of token length or relative weight.
        assert!((measured.positive_loss - 0.32).abs() < 1.0e-6);
        assert!((measured.silence_loss - 0.32).abs() < 1.0e-6);
        assert_eq!(measured.positive_label_rows, 1);
        assert_eq!(measured.silence_label_rows, 1);
        assert_eq!(measured.positive_token_steps, 2);
    }

    #[test]
    fn speech_payload_diagnostics_ignore_unsupervised_outputs() {
        let target = ReplaySpeechTarget {
            token: None,
            continuation: [0; 5],
            ..positive()
        };
        let mut logits = vec![f32::NAN; 384];
        logits[16] = -0.8;
        logits[17] = 0.8;
        let measured = replay_speech_payload_diagnostics(&logits, &[Some(target), None]).unwrap();
        assert_eq!(measured.silence_loss, 0.0);
        assert_eq!(measured.positive_loss, 0.0);
        logits[16] = f32::NAN;
        assert!(replay_speech_payload_diagnostics(&logits, &[Some(target), None]).is_err());
    }

    #[test]
    fn speech_payload_diagnostics_reject_bad_shapes_and_labels() {
        assert!(replay_speech_payload_diagnostics(&[], &[None]).is_err());
        let invalid = ReplaySpeechTarget {
            token: Some(0),
            ..positive()
        };
        assert!(replay_speech_payload_diagnostics(&[0.0; 192], &[Some(invalid)]).is_err());
    }
}

/// Grounded bounded utterance label, never an input or policy probability.
#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize)]
pub struct ReplaySpeechTarget {
    /// None teaches silence; it is not a reserved or fabricated language token.
    pub token: Option<u16>,
    #[serde(default)]
    pub continuation: [u16; 5],
    pub act: alife_core::SpeechActKind,
    pub weight: f32,
}
impl ReplaySpeechTarget {
    pub fn validate(self) -> Result<(), ScaffoldContractError> {
        if self.token.is_some_and(|token| token == 0 || token >= 256)
            || self.continuation.iter().any(|token| *token >= 256)
            || (self.token.is_none() && self.continuation != [0; 5])
            || self
                .continuation
                .windows(2)
                .any(|pair| pair[0] == 0 && pair[1] != 0)
            || !self.weight.is_finite()
            || self.weight <= 0.0
        {
            return Err(ScaffoldContractError::InvalidDecisionEvidence);
        }
        Ok(())
    }
    pub fn logits(self) -> [f32; 32] {
        self.step_logits(0)
    }
    pub fn len(self) -> usize {
        if self.token.is_none() {
            1
        } else {
            1 + self.continuation.iter().take_while(|v| **v != 0).count()
        }
    }
    /// Silence still contributes one supervised step, so a target is never empty.
    pub const fn is_empty(self) -> bool {
        false
    }
    pub fn step_logits(self, step: usize) -> [f32; 32] {
        let mut logits = [0.0; 32];
        let token = if step == 0 {
            self.token
        } else {
            self.continuation.get(step - 1).copied().filter(|v| *v != 0)
        };
        let Some(token) = token else {
            logits[16] = -0.8;
            logits[17] = 0.8;
            return logits;
        };
        logits[..8].fill(-0.8);
        logits[self.act.raw() as usize] = 0.8;
        for bit in 0..8 {
            logits[8 + bit] = if token & (1 << bit) != 0 { 0.8 } else { -0.8 };
        }
        logits[16] = 0.8;
        logits[17] = if step + 1 == self.len() { 0.8 } else { -0.8 };
        logits
    }
    pub fn output_weight(self, output: usize) -> f32 {
        if self.token.is_none() && !matches!(output, 16 | 17) {
            0.0
        } else if output >= 18 {
            // Recurrent controls learn through later tokens, not zero clamps.
            0.0
        } else {
            self.weight
        }
    }
}

/// Detached production state at a replay boundary. These are real runtime
/// snapshots, not hidden teacher inputs. Gradients stop at this boundary.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct TrainingInitialState {
    pub activations: Vec<f32>,
    pub activity_ema: Vec<f32>,
    pub metabolic_load: Vec<f32>,
    pub dendrites: alife_core::DendriticBranchSet,
}

/// One production decoder candidate, including confidence-weighted memory
/// lanes (24..36) and cognitive projection lanes (36..54).
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct TrainingReplayCandidate {
    pub family: CandidateActionFamily,
    #[serde(with = "decoder_input_array")]
    pub decoder_inputs: [f32; 54],
    /// Fixed gene-compiled salience already present in production selection.
    // Positional compact replay codecs require this field even when zero.
    // The default retains backward reading of older JSON replay fixtures.
    #[serde(default)]
    pub innate_bias: f32,
}

mod decoder_input_array {
    use serde::{Deserialize, Deserializer, Serialize, Serializer};

    pub fn serialize<S: Serializer>(values: &[f32; 54], serializer: S) -> Result<S::Ok, S::Error> {
        values.as_slice().serialize(serializer)
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(deserializer: D) -> Result<[f32; 54], D::Error> {
        Vec::<f32>::deserialize(deserializer)?
            .try_into()
            .map_err(|values: Vec<f32>| {
                serde::de::Error::invalid_length(values.len(), &"exactly 54 decoder inputs")
            })
    }
}

/// A frozen ordinary-runtime context. Lifetime/fast weights, chemistry,
/// memory and activity decisions are detached; their evolution is not BPTT.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct TrainingReplayTick {
    /// The final production sensor-encoder output, including receptor effects.
    pub encoded_inputs: Vec<f32>,
    pub projection_gain: f32,
    pub local_threshold_shift: f32,
    pub microstep_count: u32,
    pub enabled_routes: Vec<bool>,
    /// Per compiled synapse: lifetime + alpha * fast, in canonical synapse order.
    pub effective_weight_offsets: Vec<f32>,
    /// Live structural edges are fixed context, never trainable genetic weights.
    pub structural_synapses: Vec<TrainingFrozenSynapse>,
    pub candidates: Vec<TrainingReplayCandidate>,
}

#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct TrainingFrozenSynapse {
    pub source: u32,
    pub target: u32,
    pub route: u32,
    pub cadence: u32,
    pub effective_weight: f32,
}

/// Fixed-topology, frozen-context replay with a detached burn-in boundary.
/// Production collection must supply every context; there is no neutral default.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct TrainingSequence {
    pub phenotype_hash: alife_core::PhenotypeHash,
    pub initial: TrainingInitialState,
    pub ticks: Vec<TrainingReplayTick>,
    pub burn_in_ticks: usize,
    pub memory_candidate_gain: f32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct TrainingReplayEvaluation {
    pub candidate_logits: Vec<Vec<f32>>,
    pub final_activations: Vec<Vec<f32>>,
    pub final_activity_ema: Vec<Vec<f32>>,
    pub final_metabolic_load: Vec<Vec<f32>>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct TrainingGradientProbe {
    pub objective: f64,
    pub gradients: Vec<f32>,
}

impl TrainingSequence {
    pub fn validate_for(&self, phenotype: &BrainPhenotype) -> Result<(), ScaffoldContractError> {
        if phenotype.foundation_abi().motor_lobe_m0().is_some()
            || phenotype.brain_class_id().raw() == 7
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        let n = phenotype.neuron_count() as usize;
        let finite = |xs: &[f32]| xs.iter().all(|x| x.is_finite());
        if self.ticks.is_empty()
            || self.ticks.len() > MAX_TRAINING_SEQUENCE_TICKS
            || self.phenotype_hash != phenotype.phenotype_hash()
            || self.burn_in_ticks >= self.ticks.len()
            || self.initial.activations.len() != n
            || self.initial.activity_ema.len() != n
            || self.initial.metabolic_load.len() != n
            || !finite(&self.initial.activations)
            || !self
                .initial
                .activity_ema
                .iter()
                .chain(&self.initial.metabolic_load)
                .all(|x| x.is_finite() && (0.0..=1.0).contains(x))
            || !self.memory_candidate_gain.is_finite()
            || self.memory_candidate_gain < 0.0
            || self.memory_candidate_gain
                != phenotype
                    .candidate_decoder()
                    .memory_channel()
                    .map_or(0.0, |p| p.max_candidate_gain())
            || phenotype
                .projections()
                .iter()
                .any(|p| p.delay_microsteps() != 0)
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        self.initial
            .dendrites
            .validate_for_neuron_count(phenotype.neuron_count())?;
        for tick in &self.ticks {
            if tick.encoded_inputs.len() != n
                || !finite(&tick.encoded_inputs)
                || !tick.projection_gain.is_finite()
                || !tick.local_threshold_shift.is_finite()
                || tick.microstep_count > u32::from(phenotype.microstep_count())
                || tick.enabled_routes.len() != phenotype.projections().len()
                || tick.effective_weight_offsets.len() != phenotype.synapses().len()
                || !finite(&tick.effective_weight_offsets)
                || tick.structural_synapses.len() > alife_core::MAX_STRUCTURAL_EDGES
                || tick.structural_synapses.iter().any(|edge| {
                    edge.source >= phenotype.neuron_count()
                        || edge.target >= phenotype.neuron_count()
                        || edge.route as usize >= phenotype.projections().len()
                        || edge.cadence
                            != u32::from(
                                phenotype.projections()[edge.route as usize]
                                    .update_cadence()
                                    .raw(),
                            )
                        || !edge.effective_weight.is_finite()
                })
                || tick.candidates.is_empty()
                || tick.candidates.len() > alife_core::MAX_ACTION_CANDIDATES
                || tick
                    .candidates
                    .iter()
                    .any(|c| !finite(&c.decoder_inputs) || !c.innate_bias.is_finite())
            {
                return Err(ScaffoldContractError::PhenotypeCompile);
            }
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct AdamWConfig {
    pub learning_rate: f32,
    pub beta1: f32,
    pub beta2: f32,
    pub epsilon: f32,
    pub weight_decay: f32,
    pub gradient_clip: f32,
}

impl Default for AdamWConfig {
    fn default() -> Self {
        Self {
            learning_rate: 3.0e-4,
            beta1: 0.9,
            beta2: 0.999,
            epsilon: 1.0e-8,
            weight_decay: 1.0e-4,
            gradient_clip: 1.0,
        }
    }
}

impl AdamWConfig {
    pub fn validate(self) -> Result<(), ScaffoldContractError> {
        if [
            self.learning_rate,
            self.beta1,
            self.beta2,
            self.epsilon,
            self.weight_decay,
            self.gradient_clip,
        ]
        .into_iter()
        .all(f32::is_finite)
            && self.learning_rate > 0.0
            && (0.0..1.0).contains(&self.beta1)
            && (0.0..1.0).contains(&self.beta2)
            && self.epsilon > 0.0
            && self.weight_decay >= 0.0
            && self.gradient_clip > 0.0
        {
            Ok(())
        } else {
            Err(ScaffoldContractError::PhenotypeCompile)
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CandidateTrainingTarget {
    pub family: CandidateActionFamily,
    pub features: CandidateFeatureVector,
    pub target_logit: f32,
    pub loss_weight: f32,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SpeechTrainingTarget {
    pub output_index: u16,
    pub target_logit: f32,
    pub loss_weight: f32,
}

impl SpeechTrainingTarget {
    pub fn try_new(
        output_index: u16,
        target_logit: f32,
        loss_weight: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let value = Self {
            output_index,
            target_logit,
            loss_weight,
        };
        value.validate()?;
        Ok(value)
    }

    fn validate(self) -> Result<(), ScaffoldContractError> {
        if self.output_index < SpeechDecoderLayoutV1::OUTPUT_WIDTH
            && self.target_logit.is_finite()
            && self.loss_weight.is_finite()
            && self.loss_weight > 0.0
        {
            Ok(())
        } else {
            Err(ScaffoldContractError::PhenotypeCompile)
        }
    }
}

impl CandidateTrainingTarget {
    pub fn try_new(
        family: CandidateActionFamily,
        features: CandidateFeatureVector,
        target_logit: f32,
        loss_weight: f32,
    ) -> Result<Self, ScaffoldContractError> {
        let value = Self {
            family,
            features,
            target_logit,
            loss_weight,
        };
        value.validate()?;
        Ok(value)
    }

    fn validate(self) -> Result<(), ScaffoldContractError> {
        self.features.validate_contract()?;
        if self.target_logit.is_finite() && self.loss_weight.is_finite() && self.loss_weight > 0.0 {
            Ok(())
        } else {
            Err(ScaffoldContractError::PhenotypeCompile)
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct TrainingTick {
    encoded_inputs: Vec<f32>,
    target_activations: Vec<f32>,
    target_weights: Vec<f32>,
    candidate_target: Option<CandidateTrainingTarget>,
    speech_target: Option<SpeechTrainingTarget>,
}

impl TrainingTick {
    pub fn try_new(
        encoded_inputs: Vec<f32>,
        target_activations: Vec<f32>,
        target_weights: Vec<f32>,
        candidate_target: Option<CandidateTrainingTarget>,
    ) -> Result<Self, ScaffoldContractError> {
        let value = Self {
            encoded_inputs,
            target_activations,
            target_weights,
            candidate_target,
            speech_target: None,
        };
        value.validate_finite()?;
        Ok(value)
    }

    pub fn encoded_inputs(&self) -> &[f32] {
        &self.encoded_inputs
    }

    pub fn target_activations(&self) -> &[f32] {
        &self.target_activations
    }

    pub fn target_weights(&self) -> &[f32] {
        &self.target_weights
    }

    pub const fn candidate_target(&self) -> Option<CandidateTrainingTarget> {
        self.candidate_target
    }

    pub fn with_speech_target(
        mut self,
        speech_target: SpeechTrainingTarget,
    ) -> Result<Self, ScaffoldContractError> {
        speech_target.validate()?;
        self.speech_target = Some(speech_target);
        Ok(self)
    }

    pub const fn speech_target(&self) -> Option<SpeechTrainingTarget> {
        self.speech_target
    }

    fn validate_finite(&self) -> Result<(), ScaffoldContractError> {
        if self.encoded_inputs.is_empty()
            || self.encoded_inputs.len() != self.target_activations.len()
            || self.encoded_inputs.len() != self.target_weights.len()
            || self
                .encoded_inputs
                .iter()
                .chain(&self.target_activations)
                .chain(&self.target_weights)
                .any(|value| !value.is_finite())
            || self.target_weights.iter().any(|weight| *weight < 0.0)
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        if let Some(candidate) = self.candidate_target {
            candidate.validate()?;
        }
        if let Some(speech) = self.speech_target {
            speech.validate()?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct TrainingSequence32 {
    ticks: Vec<TrainingTick>,
}

impl TrainingSequence32 {
    pub fn try_new(ticks: Vec<TrainingTick>) -> Result<Self, ScaffoldContractError> {
        if ticks.len() != TRAINING_SEQUENCE_TICKS {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        for tick in &ticks {
            tick.validate_finite()?;
        }
        Ok(Self { ticks })
    }

    pub fn ticks(&self) -> &[TrainingTick] {
        &self.ticks
    }

    pub fn validate_for(&self, phenotype: &BrainPhenotype) -> Result<(), ScaffoldContractError> {
        if phenotype.foundation_abi().motor_lobe_m0().is_some()
            || phenotype.brain_class_id().raw() == 7
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        let neurons = phenotype.neuron_count() as usize;
        if self.ticks.iter().all(|tick| {
            tick.encoded_inputs.len() == neurons
                && tick.target_activations.len() == neurons
                && tick.target_weights.len() == neurons
        }) {
            Ok(())
        } else {
            Err(ScaffoldContractError::PhenotypeCompile)
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct StageTrainableMask {
    words: Vec<u32>,
}

impl StageTrainableMask {
    pub fn from_synapse_indices(
        phenotype: &BrainPhenotype,
        indices: &[u32],
    ) -> Result<Self, ScaffoldContractError> {
        if phenotype.foundation_abi().motor_lobe_m0().is_some()
            || phenotype.brain_class_id().raw() == 7
            || indices.is_empty()
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        let mut words = vec![0; phenotype.synapses().len()];
        for index in indices {
            let word = words
                .get_mut(*index as usize)
                .ok_or(ScaffoldContractError::PhenotypeCompile)?;
            if *word != 0 {
                return Err(ScaffoldContractError::PhenotypeCompile);
            }
            *word = 1;
        }
        Ok(Self { words })
    }

    pub fn from_route_indices(
        phenotype: &BrainPhenotype,
        route_indices: &[u16],
    ) -> Result<Self, ScaffoldContractError> {
        let selected = phenotype
            .synapses()
            .iter()
            .enumerate()
            .filter(|(_, synapse)| route_indices.contains(&synapse.route_index()))
            .map(|(index, _)| index as u32)
            .collect::<Vec<_>>();
        Self::from_synapse_indices(phenotype, &selected)
    }

    pub fn recurrent_only(phenotype: &BrainPhenotype) -> Result<Self, ScaffoldContractError> {
        let selected = phenotype
            .synapses()
            .iter()
            .enumerate()
            .filter(|(_, synapse)| matches!(synapse.kind(), CompiledSynapseKind::Recurrent))
            .map(|(index, _)| index as u32)
            .collect::<Vec<_>>();
        Self::from_synapse_indices(phenotype, &selected)
    }

    pub const fn len(&self) -> usize {
        self.words.len()
    }

    pub fn is_empty(&self) -> bool {
        self.words.is_empty()
    }

    pub fn trainable_count(&self) -> usize {
        self.words.iter().filter(|word| **word != 0).count()
    }

    pub fn is_trainable(&self, index: usize) -> bool {
        self.words.get(index).copied() == Some(1)
    }

    pub(crate) fn words(&self) -> &[u32] {
        &self.words
    }

    pub(crate) fn validate_for(
        &self,
        phenotype: &BrainPhenotype,
    ) -> Result<(), ScaffoldContractError> {
        if phenotype.foundation_abi().motor_lobe_m0().is_none()
            && phenotype.brain_class_id().raw() != 7
            && self.words.len() == phenotype.synapses().len()
            && self.words.contains(&1)
            && self.words.iter().all(|word| *word <= 1)
        {
            Ok(())
        } else {
            Err(ScaffoldContractError::PhenotypeCompile)
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TrainingStepReceipt {
    pub optimizer_step: u32,
    pub loss_before: f32,
    pub loss_after: f32,
    pub unclipped_gradient_norm: f32,
    pub trained_weight_count: u32,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TrainingStepStatistics {
    pub optimizer_step: u32,
    pub loss_before: f32,
    pub loss_after: Option<f32>,
    pub unclipped_gradient_norm: f32,
    pub trained_weight_count: u32,
}

/// Offline optimizer checkpoint. Organism saves never contain Adam state.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FoundationTrainerCheckpoint {
    pub schema_version: u32,
    pub phenotype_hash: alife_core::PhenotypeHash,
    pub source_foundation_digest: alife_core::Blake3Digest,
    pub optimizer_step: u32,
    pub config: AdamWConfig,
    pub stage_mask: StageTrainableMask,
    pub weights: Vec<f32>,
    pub first_moment: Vec<f32>,
    pub second_moment: Vec<f32>,
    /// Schema 2: successful Adam updates per weight, unchanged while frozen.
    pub update_ages: Vec<u32>,
}

impl FoundationTrainerCheckpoint {
    /// Validate the exact restore contract without creating a GPU session or
    /// writing optimizer buffers. The source digest binds the admitted asset.
    pub fn validate_for(
        &self,
        phenotype: &BrainPhenotype,
        source_foundation_digest: alife_core::Blake3Digest,
    ) -> Result<(), ScaffoldContractError> {
        self.config.validate()?;
        self.stage_mask.validate_for(phenotype)?;
        let n = phenotype.synapses().len();
        if self.schema_version != 2
            || self.phenotype_hash != phenotype.phenotype_hash()
            || self.source_foundation_digest != source_foundation_digest
            || self.weights.len() != n
            || self.first_moment.len() != n
            || self.second_moment.len() != n
            || self.update_ages.len() != n
            || self
                .update_ages
                .iter()
                .any(|age| *age > self.optimizer_step)
            || self
                .update_ages
                .iter()
                .zip(&self.first_moment)
                .zip(&self.second_moment)
                .any(|((age, m), v)| *age == 0 && (*m != 0.0 || *v != 0.0))
            || self
                .weights
                .iter()
                .chain(&self.first_moment)
                .chain(&self.second_moment)
                .any(|v| !v.is_finite())
            || self.second_moment.iter().any(|v| *v < 0.0)
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct SequenceEvaluation {
    mean_loss: f32,
    candidate_logits: Vec<f32>,
    speech_logits: Vec<f32>,
    episode_count: u32,
    success_count: u32,
}

impl SequenceEvaluation {
    pub(crate) fn new(
        mean_loss: f32,
        candidate_logits: Vec<f32>,
        speech_logits: Vec<f32>,
        episode_count: u32,
        success_count: u32,
    ) -> Result<Self, ScaffoldContractError> {
        if !mean_loss.is_finite()
            || mean_loss < 0.0
            || candidate_logits.len() != TRAINING_SEQUENCE_TICKS
            || speech_logits.len() != TRAINING_SEQUENCE_TICKS
            || candidate_logits.iter().any(|value| !value.is_finite())
            || speech_logits.iter().any(|value| !value.is_finite())
            || success_count > episode_count
        {
            return Err(ScaffoldContractError::PhenotypeCompile);
        }
        Ok(Self {
            mean_loss,
            candidate_logits,
            speech_logits,
            episode_count,
            success_count,
        })
    }

    pub const fn mean_loss(&self) -> f32 {
        self.mean_loss
    }

    pub fn candidate_logits(&self) -> &[f32] {
        &self.candidate_logits
    }

    pub fn speech_logits(&self) -> &[f32] {
        &self.speech_logits
    }

    pub const fn episode_count(&self) -> u32 {
        self.episode_count
    }

    pub const fn success_count(&self) -> u32 {
        self.success_count
    }
}

pub(crate) const CANDIDATE_RECORD_WORDS: usize = 64;
