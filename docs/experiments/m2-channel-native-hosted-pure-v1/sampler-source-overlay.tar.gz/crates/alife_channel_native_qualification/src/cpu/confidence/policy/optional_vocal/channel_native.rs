//! Disabled, separately owned channel-native law. No host, world, checkpoint,
//! PPO conversion or gradient application. Parent OptionalVocal evidence is
//! used ONLY as authenticated input provenance, never as this sampler's proof.
use super::*;
const POLICY: &str = "m2-channel-native-product-rust-v1;disabled;learning-closed";
const SCORE_DOMAIN: &str = "m2-channel-native-score-v1";
const SOURCE_DOMAIN: &str = "m2-channel-native-forward-binding-v1";
const ACTION_DOMAIN: &str = "m2-channel-native-action-v1";
const PROOF_DOMAIN: &str = "m2-channel-native-draw-proof-v1";
const OWNER_DOMAIN: &str = "m2-channel-native-fresh-owner-v1";
const RNG_DOMAIN: u32 = 0x434e_5031;

#[derive(Debug, Clone, PartialEq, Serialize)]
struct SourceBinding {
    domain: String,
    owner_domain: String,
    organism: OrganismId,
    generation: u64,
    digest: [u8; 32],
}
#[derive(Debug, Clone, Serialize)]
struct ChannelScores {
    domain: String,
    source: SourceBinding,
    // No Deserialize: no caller-authored fixture can claim admission.
    input: OptionalVocalScoresV1,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
enum Choice { NoOp, Candidate(u16), Rest, Quiet }
#[derive(Debug, Clone, PartialEq, Serialize)]
struct DrawProof {
    domain: String,
    scores_digest: [u8; 32],
    seed: u32,
    counter: u32,
    temperature_bits: u64,
    factors: Vec<u32>,
}
#[derive(Debug, Clone, PartialEq, Serialize)]
struct BundleAction {
    domain: String,
    policy: String,
    owner_domain: String,
    motors: [Choice; 6],
    operation: Option<u8>,
    // Descriptive first physical selection, not an extra dispatched action.
    // None is permitted. It has no independent probability or reward.
    metadata_candidate: Option<u16>,
    log_probability_bits: u64,
    proof: DrawProof,
}
struct Factor { choices: Vec<Choice>, p: Vec<f64>, lp: Vec<f64> }
struct Distribution { channels: [Factor; 6], operations: [f64; 2], operation_lp: [Option<f64>; 2] }
struct ScoreDerivative { ordinary: Vec<f64>, group: f64, operations: [f64; 2] }
struct Evaluation { log_probability: f64, derivative: ScoreDerivative, physical: [Option<u16>; 6] }
/// Concrete proposed interface shape. Not an admitted host command. There is
/// intentionally no primary ActionCommand and no representative action index.
struct UnadmittedBundlePlan {
    source_binding: SourceBinding,
    draw_proof: DrawProof,
    motor_candidates: [Option<u16>; 6],
    speech: Option<SpeechMotorPayload>,
    metadata_candidate: Option<u16>,
}


fn hash<T: Serialize>(domain: &str, value: &T) -> Result<[u8; 32], TrainingError> {
    let mut h = Sha256::new(); h.update(domain.as_bytes());
    h.update(serde_json::to_vec(value).map_err(|_| invalid())?);
    Ok(h.finalize().into())
}
impl Factor {
    fn new(choices: Vec<Choice>, logits: Vec<f64>, t: f64) -> Result<Self, TrainingError> {
        valid_temperature(t)?;
        if choices.is_empty() || choices.len() != logits.len() || logits.iter().any(|v| !v.is_finite()) { return Err(invalid()); }
        let max = logits.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let scaled: Vec<_> = logits.iter().map(|x| (x-max)/t).collect();
        if scaled.iter().any(|x| !x.is_finite()) { return Err(invalid()); }
        let z = scaled.iter().map(|x| x.exp()).sum::<f64>();
        let lp: Vec<_> = scaled.iter().map(|x| x-z.ln()).collect();
        let p: Vec<_> = lp.iter().map(|x| x.exp()).collect();
        // Fail closed, never silently erase finite support via floating underflow.
        if lp.iter().any(|x| !x.is_finite()) || p.iter().any(|x| !x.is_finite() || *x <= 0.) { return Err(invalid()); }
        Ok(Self { choices, p, lp })
    }
    fn noop() -> Self { Self { choices: vec![Choice::NoOp], p: vec![1.], lp: vec![0.] } }
    fn pick(&self, u: f64) -> Choice {
        let mut sum = 0.;
        for (c,p) in self.choices.iter().zip(&self.p) { sum+=p; if u<sum {return *c;} }
        *self.choices.last().unwrap()
    }
    fn logp(&self, c: Choice) -> Result<f64, TrainingError> {
        self.choices.iter().position(|x| *x==c).map(|i| self.lp[i]).ok_or_else(invalid)
    }
}
impl ChannelScores {
    // Private and uncalled outside pure tests: a future fresh owner must invoke
    // this only after the pending-forward identity has been checked in its host.
    // It validates genuine baseline provenance; it does not fabricate that proof.
    fn bind(input: &OptionalVocalScoresV1) -> Result<Self, TrainingError> {
        input.validate()?;
        let source = SourceBinding { domain: SOURCE_DOMAIN.into(), owner_domain: OWNER_DOMAIN.into(),
            organism: input.source.owner, generation: input.source.dispatch_generation,
            digest: hash(SOURCE_DOMAIN, &input.source)? };
        Ok(Self { domain: SCORE_DOMAIN.into(), source, input: input.clone() })
    }
    fn validate(&self) -> Result<(), TrainingError> {
        let expected = Self::bind(&self.input)?;
        if self.domain != SCORE_DOMAIN || self.source != expected.source {return Err(invalid());}
        Ok(())
    }
    fn distribution(&self, t: f64) -> Result<Distribution, TrainingError> {
        self.validate()?; valid_temperature(t)?;
        let input=&self.input;
        let mut channels = std::array::from_fn(|_| Factor::noop());
        for (s, f) in channels.iter_mut().enumerate() {
            if !input.native_binding.enabled[s] { continue; }
            let mut choices=vec![]; let mut logits=vec![];
            if s==3 { choices.push(Choice::Quiet); logits.push(input.quiet_score()); }
            for &i in &input.native_binding.order {
                if input.eligible_mask & (1u32 << i)==0 || input.native_binding.is_recovery(i)
                    || input.native_binding.forced[i]!=Some(s) {continue;}
                // Deliberately includes Idle/Gesture: no channel_members filter.
                choices.push(Choice::Candidate(i as u16)); logits.push(f64::from_bits(input.ordinary_bits[i]));
            }
            if s==4 && input.native_binding.operation_mask().contains(&true) {
                choices.push(Choice::Rest); logits.push(f64::from_bits(input.group_bits));
            }
            if !choices.is_empty() { *f=Factor::new(choices,logits,t)?; }
        }
        let native=input.native();
        let op=native.conditional(t)?;
        if op.lp.iter().flatten().any(|x| !x.is_finite()) || (0..2).any(|i| op.lp[i].is_some() && op.p[i]<=0.) {return Err(invalid());}
        Ok(Distribution { channels, operations: op.p, operation_lp: op.lp })
    }
    fn physical(&self, motors: &[Choice;6], op: Option<u8>) -> Result<[Option<u16>;6],TrainingError> {
        let mut physical=[None;6];
        for (slot,c) in motors.iter().enumerate() {
            physical[slot]=match *c { Choice::Candidate(i)=>Some(i), Choice::NoOp|Choice::Quiet=>None,
                Choice::Rest=>Some(self.input.native_binding.operations.get(op.ok_or_else(invalid)? as usize)
                    .copied().flatten().ok_or_else(invalid)? as u16) };
        }
        Ok(physical)
    }
    fn sample(&self, seed:u32, counter:u32, t:f64)->Result<BundleAction,TrainingError> {
        let d=self.distribution(t)?;
        let mut motors=[Choice::NoOp;6]; let mut factors=vec![]; let mut lp=0.;
        for s in 0..6 {
            // Separate fixed domain IDs; no representative draw exists.
            factors.push(16+s as u32);
            motors[s]=d.channels[s].pick(draw(seed,counter,16+s as u32));
            lp+=d.channels[s].logp(motors[s])?;
        }
        let operation=if motors[4]==Choice::Rest {
            factors.push(32);
            let mask=self.input.native_binding.operation_mask();
            let o=if mask[0] && (!mask[1] || draw(seed,counter,32)<d.operations[0]) {0} else {1};
            lp+=d.operation_lp[o].ok_or_else(invalid)?; Some(o as u8)
        } else {None};
        let physical=self.physical(&motors,operation)?;
        Ok(BundleAction { domain:ACTION_DOMAIN.into(), policy:POLICY.into(), owner_domain:OWNER_DOMAIN.into(),
            motors,operation,metadata_candidate:physical.iter().copied().flatten().next(),log_probability_bits:lp.to_bits(),
            proof:DrawProof {domain:PROOF_DOMAIN.into(),scores_digest:hash(SCORE_DOMAIN,self)?,seed,counter,temperature_bits:t.to_bits(),factors} })
    }
    fn inspect_unadmitted_plan(&self,a:&BundleAction)->Result<UnadmittedBundlePlan,TrainingError> {
        let e=self.evaluate(a)?;
        let speech=if e.physical[3].is_some() {self.input.source.speech()?} else {None};
        Ok(UnadmittedBundlePlan {source_binding:self.source.clone(),draw_proof:a.proof.clone(),
            motor_candidates:e.physical,speech,metadata_candidate:a.metadata_candidate})
    }
    fn evaluate(&self,a:&BundleAction)->Result<Evaluation,TrainingError> {
        if *a!=self.sample(a.proof.seed,a.proof.counter,f64::from_bits(a.proof.temperature_bits))? {return Err(invalid());}
        self.evaluate_selection(a.motors,a.operation,f64::from_bits(a.proof.temperature_bits))
    }
    // Counterfactual arithmetic only; no action/proof is minted by this method.
    fn evaluate_selection(&self,motors:[Choice;6],operation:Option<u8>,t:f64)->Result<Evaluation,TrainingError> {
        let d=self.distribution(t)?;
        let mut derivative=ScoreDerivative { ordinary:vec![0.;self.input.ordinary_bits.len()],group:0.,operations:[0.;2] };
        let mut lp=0.;
        for s in 0..6 {
            lp+=d.channels[s].logp(motors[s])?;
            for (c,p) in d.channels[s].choices.iter().zip(&d.channels[s].p) {
                let g=((if *c==motors[s] {1.} else {0.}) - *p)/t;
                match *c {Choice::Candidate(i)=>derivative.ordinary[i as usize]+=g,
                    Choice::Quiet=>derivative.ordinary[self.input.idle as usize]+=g,
                    Choice::Rest=>derivative.group+=g,Choice::NoOp=>{}}
            }
        }
        if motors[4]==Choice::Rest {
            let o=usize::from(operation.ok_or_else(invalid)?);
            lp+=d.operation_lp.get(o).copied().flatten().ok_or_else(invalid)?;
            for i in 0..2 {if d.operation_lp[i].is_some() {derivative.operations[i]=((if i==o {1.} else {0.})-d.operations[i])/t;}}
        } else if operation.is_some() {return Err(invalid());}
        Ok(Evaluation {log_probability:lp,derivative,physical:self.physical(&motors,operation)?})
    }
}
fn draw(seed:u32,counter:u32,factor:u32)->f64 {
    let mut v=seed ^ RNG_DOMAIN ^ counter.wrapping_mul(0x9e3779b9) ^ factor.wrapping_mul(0x85ebca6b);
    v=(v^(v>>16)).wrapping_mul(0x7feb352d); v=(v^(v>>15)).wrapping_mul(0x846ca68b); v^=v>>16;
    (f64::from(v>>9)+0.5)/8388608.
}

#[cfg(test)]
mod tests;
