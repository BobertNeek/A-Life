use super::*;
use std::sync::OnceLock;
pub(super) fn source() -> (PhenotypeCompilerInputs, FoundationWeightAsset) {
    static SOURCE: OnceLock<(PhenotypeCompilerInputs, FoundationWeightAsset)> = OnceLock::new();
    SOURCE.get_or_init(|| source_with_heads(4)).clone()
}
fn source_with_heads(head_count: u8) -> (PhenotypeCompilerInputs, FoundationWeightAsset) {
    let g = BrainGenome::scaffold(
        0x4752_5031,
        BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID,
    );
    let a = g.cognitive_architecture();
    let heads = alife_core::genome::CognitiveArchitectureGenomeParameters::try_new_v1(
        a.attention_capacity(),
        a.active_concept_limit(),
        a.active_gap_limit(),
        a.predictor_capacity(),
        a.predictor_learning_rate(),
        head_count,
        a.motor_head_width(),
        a.dendritic_branch_capacity(),
        a.structural_candidate_budget(),
        a.structural_edit_budget(),
        a.sleep_trigger_threshold(),
        a.sleep_replay_rate(),
        a.sleep_consolidation_rate(),
        a.attention_learning_rate(),
        a.concept_learning_rate(),
        a.motor_learning_rate(),
        a.structural_learning_rate(),
    )
    .unwrap();
    let g = g.with_cognitive_architecture(heads).unwrap();
    let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
    let (p, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
        g,
        d,
        SensorProfile::GroundedObjectSlotsV1,
    )
    .unwrap();
    let a = FoundationWeightAsset::from_trained_weights(
        &p,
        p.synapses().iter().map(|s| s.genetic_weight()).collect(),
        TrainingStageManifest::bootstrap(),
    )
    .unwrap();
    let (_, i) = PhenotypeCompiler::compile_n2048_grounded_drive_basis_candidate(
        i.genome().clone(),
        i.development().clone(),
        a.clone(),
    )
    .unwrap();
    (i, a)
}
