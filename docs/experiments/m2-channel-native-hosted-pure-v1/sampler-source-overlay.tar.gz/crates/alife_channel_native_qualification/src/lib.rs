//! Pure policy-only test assembly. Reuses immutable core/training dependencies.
//! No resident, host, world-loop, checkpoint or source-forward module is included.
#![recursion_limit="256"]
mod cpu {
    use alife_core::*;
    use alife_training::TrainingError;
    use serde::{Serialize, Deserialize};
    use sha2::{Digest, Sha256};
    fn invalid() -> TrainingError { ScaffoldContractError::InvalidDecisionEvidence.into() }
    fn finite(xs: &[f32]) -> Result<(), TrainingError> {
        if xs.iter().all(|x|x.is_finite()) {Ok(())} else {Err(invalid())}
    }
    mod confidence {
        use super::*;
        const RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256: &str = "eecb44a40ac6bbb7c3e742f10ec749668245c11f089b48cf257aeb4749dd4dff";
        mod policy;
        mod tests;
    }
}
