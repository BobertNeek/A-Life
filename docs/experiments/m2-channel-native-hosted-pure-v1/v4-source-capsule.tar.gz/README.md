# V4 fixture-only correction, source only

V3 evidence is retained: first batch6passes, one invalid-frame fixture failure, eighth not run; a separate unchanged-binary eighth invocation later passed. Neither is an8/8claim. This revision has not been compiled or run.

Only channel_native/tests.rs changes. Its frame helper now exposes the actual Result while preserving existing unwrap behavior for other legal fixtures. The corrected seventh test asserts exact InvalidPerceptionFrame for the original ungrounded Gesture/Other/None, then independently validates the existing legal profile5 frame and tests normalized single-operation Rest support. It does not weaken or change the core validator, fabricate grounded Gesture, change policy math, or claim legal Gesture coverage. That coverage remains absent.

The source-only tarball carries all103source files with only this fixture correction, a relocatable companion template, unchanged fixture source helper, and dependency/compile reference metadata. It contains no executable, checkpoint, credentials or acquired state. The hosted consumer must materialize and hash-check exact dependencies at its own paths; their presence here is not evidence of availability there. Stop if unavailable rather than guessing.

Run only the bounded hosted plan after verifying the consumer environment. No local rebuild is proposed: local headroom is below16MiB. One compiler, inventory, eight exact tests; stop on first failure and preserve artifacts. No deletion, retries, world/source forwards, checkpoint access or learning. V2 actual host/receipt/cold/work qualification remains separate.
