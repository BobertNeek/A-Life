//! Separately owned channel-native law and fresh host bridge.
//! No PPO conversion or actor/recurrent eligibility update; full checkpoint owner validates evidence. Parent OptionalVocal evidence is
//! used ONLY as authenticated input provenance, never as this sampler's proof.
use super::*;
use serde::Deserialize;
pub const CHANNEL_NATIVE_POLICY_V1: &str = "m2-channel-native-product-rust-v3;native-host;admin-unpriced-not-production;actor-recurrent-credit-closed";
const POLICY: &str = CHANNEL_NATIVE_POLICY_V1;
const SCORE_DOMAIN: &str = "m2-channel-native-score-v3";
const SOURCE_DOMAIN: &str = "m2-channel-native-forward-binding-v3";
const ACTION_DOMAIN: &str = "m2-channel-native-action-v3";
const PROOF_DOMAIN: &str = "m2-channel-native-draw-proof-v3";
const OWNER_DOMAIN: &str = "m2-channel-native-fresh-owner-v3";
const RNG_DOMAIN: u32 = 0x434e_5033;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct SourceBinding {
    domain: String,
    owner_domain: String,
    organism: OrganismId,
    generation: u64,
    digest: [u8; 32],
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ChannelScores {
    domain: String,
    source: SourceBinding,
    // Deserialized evidence is never trusted without full source/native/draw validation.
    input: OptionalVocalScoresV1,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Choice { NoOp, Candidate(u16), Rest, Quiet }
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct DrawProof {
    domain: String,
    scores_digest: [u8; 32],
    seed: u32,
    counter: u32,
    temperature_bits: u64,
    factors: Vec<u32>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BundleAction {
    domain: String,
    policy: String,
    owner_domain: String,
    motors: [Choice; 6],
    operation: Option<u8>,
    // Descriptive first physical selection, not an extra dispatched action.
    // None is permitted. It has no independent probability or reward.
    metadata_candidate: Option<u16>,
    log_probability_bits: u64,
    proof: DrawProof,
    // Only disposable test assembly can represent this controlled intervention.
    // Production deserialization rejects this field; no native RNG claim.
    #[cfg(test)]
    #[serde(default,skip_serializing_if="Option::is_none")]
    controlled_physics: Option<bool>,
}
struct Factor { choices: Vec<Choice>, p: Vec<f64>, lp: Vec<f64> }
struct Distribution { channels: [Factor; 6], operations: [f64; 2], operation_lp: [Option<f64>; 2] }
struct ScoreDerivative { ordinary: Vec<f64>, group: f64, operations: [f64; 2] }
struct Evaluation { log_probability: f64, derivative: ScoreDerivative, physical: [Option<u16>; 6] }
/// Concrete proposed interface shape. Not an admitted host command. There is
/// intentionally no primary ActionCommand and no representative action index.
struct UnadmittedBundlePlan {
    source_binding: SourceBinding,
    draw_proof: DrawProof,
    motor_candidates: [Option<u16>; 6],
    speech: Option<SpeechMotorPayload>,
    metadata_candidate: Option<u16>,
}


fn hash<T: Serialize>(domain: &str, value: &T) -> Result<[u8; 32], TrainingError> {
    let mut h = Sha256::new(); h.update(domain.as_bytes());
    h.update(serde_json::to_vec(value).map_err(|_| invalid())?);
    Ok(h.finalize().into())
}
impl Factor {
    fn new(choices: Vec<Choice>, logits: Vec<f64>, t: f64) -> Result<Self, TrainingError> {
        valid_temperature(t)?;
        if choices.is_empty() || choices.len() != logits.len() || logits.iter().any(|v| !v.is_finite()) { return Err(invalid()); }
        let max = logits.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let scaled: Vec<_> = logits.iter().map(|x| (x-max)/t).collect();
        if scaled.iter().any(|x| !x.is_finite()) { return Err(invalid()); }
        let z = scaled.iter().map(|x| x.exp()).sum::<f64>();
        let lp: Vec<_> = scaled.iter().map(|x| x-z.ln()).collect();
        let p: Vec<_> = lp.iter().map(|x| x.exp()).collect();
        // Fail closed, never silently erase finite support via floating underflow.
        if lp.iter().any(|x| !x.is_finite()) || p.iter().any(|x| !x.is_finite() || *x <= 0.) { return Err(invalid()); }
        Ok(Self { choices, p, lp })
    }
    fn noop() -> Self { Self { choices: vec![Choice::NoOp], p: vec![1.], lp: vec![0.] } }
    fn pick(&self, u: f64) -> Choice {
        let mut sum = 0.;
        for (c,p) in self.choices.iter().zip(&self.p) { sum+=p; if u<sum {return *c;} }
        *self.choices.last().unwrap()
    }
    fn logp(&self, c: Choice) -> Result<f64, TrainingError> {
        self.choices.iter().position(|x| *x==c).map(|i| self.lp[i]).ok_or_else(invalid)
    }
}
impl ChannelScores {
    // Private and uncalled outside pure tests: a future fresh owner must invoke
    // this only after the pending-forward identity has been checked in its host.
    // It validates genuine baseline provenance; it does not fabricate that proof.
    fn bind(input: &OptionalVocalScoresV1) -> Result<Self, TrainingError> {
        input.validate()?;
        let source = SourceBinding { domain: SOURCE_DOMAIN.into(), owner_domain: OWNER_DOMAIN.into(),
            organism: input.source.owner, generation: input.source.dispatch_generation,
            digest: hash(SOURCE_DOMAIN, &input.source)? };
        Ok(Self { domain: SCORE_DOMAIN.into(), source, input: input.clone() })
    }
    fn validate(&self) -> Result<(), TrainingError> {
        let expected = Self::bind(&self.input)?;
        if self.domain != SCORE_DOMAIN || self.source != expected.source {return Err(invalid());}
        Ok(())
    }
    fn distribution(&self, t: f64) -> Result<Distribution, TrainingError> {
        self.validate()?; valid_temperature(t)?;
        let input=&self.input;
        let mut channels = std::array::from_fn(|_| Factor::noop());
        for (s, f) in channels.iter_mut().enumerate() {
            if !input.native_binding.enabled[s] { continue; }
            let mut choices=vec![]; let mut logits=vec![];
            if s==3 { choices.push(Choice::Quiet); logits.push(input.quiet_score()); }
            for &i in &input.native_binding.order {
                if input.eligible_mask & (1u32 << i)==0 || input.native_binding.is_recovery(i)
                    || input.native_binding.forced[i]!=Some(s) {continue;}
                // Deliberately includes Idle/Gesture: no channel_members filter.
                choices.push(Choice::Candidate(i as u16)); logits.push(f64::from_bits(input.ordinary_bits[i]));
            }
            if s==4 && input.native_binding.operation_mask().contains(&true) {
                choices.push(Choice::Rest); logits.push(f64::from_bits(input.group_bits));
            }
            if !choices.is_empty() { *f=Factor::new(choices,logits,t)?; }
        }
        let native=input.native();
        let op=native.conditional(t)?;
        if op.lp.iter().flatten().any(|x| !x.is_finite()) || (0..2).any(|i| op.lp[i].is_some() && op.p[i]<=0.) {return Err(invalid());}
        Ok(Distribution { channels, operations: op.p, operation_lp: op.lp })
    }
    fn physical(&self, motors: &[Choice;6], op: Option<u8>) -> Result<[Option<u16>;6],TrainingError> {
        let mut physical=[None;6];
        for (slot,c) in motors.iter().enumerate() {
            physical[slot]=match *c { Choice::Candidate(i)=>Some(i), Choice::NoOp|Choice::Quiet=>None,
                Choice::Rest=>Some(self.input.native_binding.operations.get(op.ok_or_else(invalid)? as usize)
                    .copied().flatten().ok_or_else(invalid)? as u16) };
        }
        Ok(physical)
    }
    fn sample(&self, seed:u32, counter:u32, t:f64)->Result<BundleAction,TrainingError> {
        let d=self.distribution(t)?;
        let mut motors=[Choice::NoOp;6]; let mut factors=vec![]; let mut lp=0.;
        for s in 0..6 {
            // Separate fixed domain IDs; no representative draw exists.
            factors.push(16+s as u32);
            motors[s]=d.channels[s].pick(draw(seed,counter,16+s as u32));
            lp+=d.channels[s].logp(motors[s])?;
        }
        let operation=if motors[4]==Choice::Rest {
            factors.push(32);
            let mask=self.input.native_binding.operation_mask();
            let o=if mask[0] && (!mask[1] || draw(seed,counter,32)<d.operations[0]) {0} else {1};
            lp+=d.operation_lp[o].ok_or_else(invalid)?; Some(o as u8)
        } else {None};
        let physical=self.physical(&motors,operation)?;
        Ok(BundleAction { domain:ACTION_DOMAIN.into(), policy:CHANNEL_NATIVE_POLICY_V1.into(), owner_domain:OWNER_DOMAIN.into(),
            motors,operation,metadata_candidate:self.compatibility_metadata(&physical)?,log_probability_bits:lp.to_bits(),
            proof:DrawProof {domain:PROOF_DOMAIN.into(),scores_digest:hash(SCORE_DOMAIN,self)?,seed,counter,temperature_bits:t.to_bits(),factors},
            #[cfg(test)] controlled_physics:None })
    }
    // Existing core builder treats Idle/Gesture only through its compatibility
    // command. Choose that already-sampled posture row first, never force it.
    fn compatibility_metadata(&self,physical:&[Option<u16>;6])->Result<Option<u16>,TrainingError> {
        if let Some(i)=physical[4] {
            if !self.input.native_binding.channel_members[i as usize] {return Ok(Some(i));}
        }
        Ok(physical.iter().copied().flatten().next())
    }
    fn inspect_unadmitted_plan(&self,a:&BundleAction)->Result<UnadmittedBundlePlan,TrainingError> {
        let e=self.evaluate(a)?;
        let speech=if e.physical[3].is_some() {self.input.source.speech()?} else {None};
        Ok(UnadmittedBundlePlan {source_binding:self.source.clone(),draw_proof:a.proof.clone(),
            motor_candidates:e.physical,speech,metadata_candidate:a.metadata_candidate})
    }
    fn evaluate(&self,a:&BundleAction)->Result<Evaluation,TrainingError> {
        #[cfg(test)]
        if let Some(play)=a.controlled_physics {
            let expected=self.controlled_physics_fixture(play,a.proof.seed,a.proof.counter,f64::from_bits(a.proof.temperature_bits))?;
            if *a!=expected {return Err(invalid());}
            let mut e=self.evaluate_selection(a.motors,a.operation,f64::from_bits(a.proof.temperature_bits))?;
            // Deterministic controlled intervention, not nominal actor likelihood.
            e.log_probability=0.;e.derivative.ordinary.fill(0.);e.derivative.group=0.;e.derivative.operations=[0.;2];
            return Ok(e);
        }

        if *a!=self.sample(a.proof.seed,a.proof.counter,f64::from_bits(a.proof.temperature_bits))? {return Err(invalid());}
        self.evaluate_selection(a.motors,a.operation,f64::from_bits(a.proof.temperature_bits))
    }
    // Counterfactual arithmetic only; no action/proof is minted by this method.
    fn evaluate_selection(&self,motors:[Choice;6],operation:Option<u8>,t:f64)->Result<Evaluation,TrainingError> {
        let d=self.distribution(t)?;
        let mut derivative=ScoreDerivative { ordinary:vec![0.;self.input.ordinary_bits.len()],group:0.,operations:[0.;2] };
        let mut lp=0.;
        for s in 0..6 {
            lp+=d.channels[s].logp(motors[s])?;
            for (c,p) in d.channels[s].choices.iter().zip(&d.channels[s].p) {
                let g=((if *c==motors[s] {1.} else {0.}) - *p)/t;
                match *c {Choice::Candidate(i)=>derivative.ordinary[i as usize]+=g,
                    Choice::Quiet=>derivative.ordinary[self.input.idle as usize]+=g,
                    Choice::Rest=>derivative.group+=g,Choice::NoOp=>{}}
            }
        }
        if motors[4]==Choice::Rest {
            let o=usize::from(operation.ok_or_else(invalid)?);
            lp+=d.operation_lp.get(o).copied().flatten().ok_or_else(invalid)?;
            for i in 0..2 {if d.operation_lp[i].is_some() {derivative.operations[i]=((if i==o {1.} else {0.})-d.operations[i])/t;}}
        } else if operation.is_some() {return Err(invalid());}
        Ok(Evaluation {log_probability:lp,derivative,physical:self.physical(&motors,operation)?})
    }
}
fn draw(seed:u32,counter:u32,factor:u32)->f64 {
    let mut v=seed ^ RNG_DOMAIN ^ counter.wrapping_mul(0x9e3779b9) ^ factor.wrapping_mul(0x85ebca6b);
    v=(v^(v>>16)).wrapping_mul(0x7feb352d); v=(v^(v>>15)).wrapping_mul(0x846ca68b); v^=v>>16;
    (f64::from(v>>9)+0.5)/8388608.
}

#[cfg(test)]
mod tests;

// Additive owned sampler/staging seam; no registration into old host policy.
// Historical V2 unadmitted seam is not linked into this owner.

impl BundleAction {
    pub fn seed(&self)->u32 {self.proof.seed}
    pub fn counter(&self)->u32 {self.proof.counter}
    pub fn operation(&self)->Option<u8> {self.operation}
    pub fn motors(&self)->[Choice;6] {self.motors}
    pub fn joint_log_probability(&self)->f64 {f64::from_bits(self.log_probability_bits)}
}
impl ChannelScores {
    pub(in crate::cpu) fn bind_native(p:&BrainPhenotype, frame:&PerceptionFrame,
        native:&RecoveryGroupScoresV2, source:OptionalVocalSourceV1)->Result<Self,TrainingError> {
        frame.validate_contract()?;
        let input=OptionalVocalScoresV1::bind(p,frame,native,source)?;
        if !input.native_binding.enabled[4] || input.eligible_mask & (1<<input.idle)==0 {return Err(invalid());}
        Self::bind(&input)
    }
    pub(in crate::cpu) fn sample_native(&self,seed:u32,counter:u32,t:f64)->Result<BundleAction,TrainingError> {self.sample(seed,counter,t)}
    pub(in crate::cpu) fn validate_native(&self,native:&RecoveryGroupScoresV2)->Result<(),TrainingError> {self.validate()?;self.input.validate_native(native)}
    pub(in crate::cpu) fn validate_source(&self,source:&OptionalVocalSourceV1)->Result<(),TrainingError> {self.validate()?;self.input.validate_source(source)}
    pub fn source(&self)->&OptionalVocalSourceV1 {self.input.source()}
    pub fn physical_selection(&self,a:&BundleAction)->Result<(u16,[Option<u16>;6]),TrainingError> {
        let e=self.evaluate(a)?;
        let i=a.metadata_candidate.ok_or_else(invalid)?;
        if !e.physical.contains(&Some(i)) {return Err(invalid());}
        Ok((i,e.physical))
    }
    pub fn validate_sampling_context(&self,a:&BundleAction,seed:u32,counter:u32,t:f64)->Result<(),TrainingError> {
        self.evaluate(a)?;
        if a.proof.seed!=seed || a.proof.counter!=counter || a.proof.temperature_bits!=t.to_bits() {return Err(invalid());}
        Ok(())
    }
    /// Read-only chain-rule input. This is the CHANNEL-NATIVE joint score gradient,
    /// not an assertion of the old policy's sampled action or family reward.
    /// Idle's ordinary component includes both posture and Quiet contributions.
    pub fn native_score_gradient(&self,a:&BundleAction)->Result<RecoveryGroupGradientV2,TrainingError> {
        #[cfg(test)] if a.controlled_physics.is_some() {return Err(invalid());}
        let e=self.evaluate(a)?;
        Ok(RecoveryGroupGradientV2 {binding:self.input.native_binding.clone(),
            ordinary:e.derivative.ordinary,group:e.derivative.group,operations:e.derivative.operations})
    }
    /// Marginal posture probability, NOT quiet-rest dose or energy recovery.
    pub fn rest_posture_probability(&self,t:f64)->Result<f64,TrainingError> {
        let d=self.distribution(t)?;
        Ok(d.channels[4].choices.iter().position(|c|*c==Choice::Rest).map_or(0.,|i|d.channels[4].p[i]))
    }
}

impl ChannelScores {
    /// Correct read-only M2 decoder chain rule. The probe supplies actual native
    /// Jacobians; no score gradient is passed to old action/credit evaluators.
    /// This does not update recurrent eligibility, Adam, fast or lifetime banks.
    pub fn decoder_gradient_readout(&self,a:&BundleAction,probe:&RecoveryGroupProbeResultV2)->Result<Vec<f64>,TrainingError> {
        self.validate_native(&probe.receipt.scores)?;
        probe.decoder_log_probability_gradient(&self.native_score_gradient(a)?)
    }
    /// Counterfactual numeric readout only. Returns no admissible scores/action.
    /// Frozen support and source; this is NOT a new forward or treatment run.
    pub fn unrelated_score_rest_readout(&self,index:u16,delta:f64,t:f64)->Result<(f64,f64),TrainingError> {
        self.validate()?;
        let i=index as usize;
        if !delta.is_finite() || i>=self.input.ordinary_bits.len()
            || self.input.eligible_mask & (1<<i)==0
            || self.input.native_binding.is_recovery(i)
            || self.input.native_binding.forced[i]==Some(4) {return Err(invalid());}
        let before=self.rest_posture_probability(t)?;
        let mut altered=self.clone();
        altered.input.ordinary_bits[i]=(f64::from_bits(altered.input.ordinary_bits[i])+delta).to_bits();
        let after=altered.rest_posture_probability(t)?;
        Ok((before,after))
    }
}
/// Explicit administrative scope, NOT neurons, synapses, or a measured tariff.
/// Counts below identify bounded input size, not executed hardware instructions.
#[derive(Debug,Clone,PartialEq,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ChannelNativeAdministrativeReceiptV1 {
    pub candidate_rows:u16,
    pub channel_factors:u8,
    pub conditional_operation_factors:u8,
    pub selected_physical_rows:u8,
    pub body_price_qualified:bool,
}
impl ChannelScores {
    pub fn administrative_receipt(&self,a:&BundleAction)->Result<ChannelNativeAdministrativeReceiptV1,TrainingError> {
        let e=self.evaluate(a)?;
        Ok(ChannelNativeAdministrativeReceiptV1 {candidate_rows:self.input.ordinary_bits.len() as u16,
            channel_factors:6,conditional_operation_factors:u8::from(a.operation.is_some()),
            selected_physical_rows:e.physical.iter().flatten().count() as u8,body_price_qualified:false})
    }
}

#[cfg(test)]
impl ChannelScores {
    /// Exact controlled-physics fixture, never an autonomous sampled action.
    /// Every physical selection must belong to the real bound frame/support.
    pub(in crate::cpu) fn controlled_physics_fixture(&self,play:bool,seed:u32,counter:u32,t:f64)->Result<BundleAction,TrainingError> {
        self.validate()?;
        let d=self.distribution(t)?;
        let find=|id:u32,slot:usize|->Result<u16,TrainingError>{
            let matches=self.input.native_binding.identities.iter().enumerate().filter_map(|(i,identity)|{
                let row:(ActionId,ActionTarget,ActionKind,CandidateActionFamily)=serde_json::from_str(identity).ok()?;
                (row.0.raw()==id && self.input.eligible_mask&(1<<i)!=0 && self.input.native_binding.forced[i]==Some(slot)).then_some(i as u16)
            }).collect::<Vec<_>>();
            if matches.len()!=1 {return Err(invalid());} Ok(matches[0])
        };
        let mut motors=[Choice::NoOp;6];
        motors[0]=Choice::Candidate(find(103,0)?); // genuine NoLocomotion
        if d.channels[1].choices!=vec![Choice::NoOp] {motors[1]=Choice::Candidate(find(606,1)?);}
        motors[2]=Choice::Candidate(find(if play{213}else{212},2)?);
        motors[3]=if self.input.native_binding.enabled[3] {Choice::Quiet}else{Choice::NoOp};
        motors[4]=Choice::Rest;
        let operation=Some(1); // actual supported AwakeRest, never BodySleep
        let e=self.evaluate_selection(motors,operation,t)?;
        let action=BundleAction {domain:"channel-native-controlled-physics-action-v1".into(),
            policy:"channel-native-controlled-physics-v1;not-autonomous;actor-credit-forbidden".into(),
            owner_domain:"channel-native-controlled-physics-fixture-owner-v1".into(),
            motors,operation,metadata_candidate:self.compatibility_metadata(&e.physical)?,log_probability_bits:0_f64.to_bits(),
            proof:DrawProof {domain:"channel-native-controlled-physics-proof-v1;no-rng-draw".into(),
                scores_digest:hash(SCORE_DOMAIN,self)?,seed,counter,temperature_bits:t.to_bits(),factors:vec![]},
            controlled_physics:Some(play)};
        Ok(action)
    }
}
