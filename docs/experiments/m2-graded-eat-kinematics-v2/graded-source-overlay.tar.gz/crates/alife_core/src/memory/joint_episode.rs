//! Fresh-only bounded joint episodes. No candidate-family value projection.
//! Physical ingestion is a fact; experienced valence belongs to the WHOLE action.
//! This API does not change existing MemoryBank readers, wire formats or sleep.
use super::*;
use crate::{ChannelCommand, DecisionEvidence, MotorChannel, MotorCommandBundle, PhenotypeHash,
    WorldEntityId};

pub const JOINT_EPISODE_POLICY_V1: &str = "m2-full-command-context-episode-v1";
const CAPACITY_LIMIT: usize = 64;
const WIRE_LIMIT: usize = 4 * 1024 * 1024;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Owner {
    organism: OrganismId,
    phenotype: PhenotypeHash,
    // Fresh host-assigned identity, never inferred from a restored old bank.
    lineage: [u64; 4],
}

/// No reward, success, energy, pain or confidence estimate is attributed to Eat.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ConsumedFactV1 {
    pub query: CandidateMemoryQueryV2,
    pub target: WorldEntityId,
    pub command_confidence: Confidence,
}

/// Not convertible to a candidate value, family memory or isolated sleep target.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JointEpisodeV1 {
    pub sequence: ExperienceSequenceId,
    pub dispatch_generation: u64,
    pub source_tick: Tick,
    pub pre_action_drives: [f32; crate::DriveSnapshot::CHANNEL_COUNT],
    pub channel_receipts: Vec<crate::experience::ChannelPhysicalOutcome>,
    pub frame_digest: PerceptionFrameDigest,
    pub source_digest: [u64; 4],
    pub bundle_digest: [u64; 4],
    pub commands: Vec<ChannelCommand>,
    pub coordination: crate::BoundedCoordinationSummary,
    pub consumed: Option<ConsumedFactV1>,
    /// Whole-event association, not an isolated causal estimate.
    pub joint_experienced_valence: SignedValence,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Wire {
    schema: u16,
    policy: String,
    owner: Owner,
    capacity: usize,
    generation: u64,
    last_sequence: u64,
    last_dispatch: u64,
    episodes: Vec<JointEpisodeV1>,
}

/// Separate owner; deliberately has neither Deserialize nor an inner-bank loader.
/// Fresh host integration must use this readout exclusively for episodic value.
/// Existing old lives/readers are not migrated or disabled.
#[derive(Debug, Clone, PartialEq)]
pub struct JointEpisodeMemoryV1 {
    wire: Wire,
}

/// Must be kept in the enclosing host checkpoint and checked against its trusted
/// current lineage/generation. This is an integrity anchor, not authentication.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JointEpisodeAnchorV1 {
    pub policy: String,
    pub lineage: [u64; 4],
    pub organism: OrganismId,
    pub phenotype: PhenotypeHash,
    pub generation: u64,
    pub last_sequence: u64,
    pub digest: [u8; 32],
}

fn invalid() -> ScaffoldContractError { ScaffoldContractError::InvalidDecisionEvidence }

impl JointEpisodeMemoryV1 {
    pub fn fresh(organism: OrganismId, phenotype: PhenotypeHash, lineage: [u64; 4],
        capacity: usize) -> Result<Self, ScaffoldContractError> {
        organism.validate()?;
        if capacity == 0 || capacity > CAPACITY_LIMIT || lineage == [0; 4] {
            return Err(invalid());
        }
        Ok(Self { wire: Wire { schema: 1, policy: JOINT_EPISODE_POLICY_V1.into(),
            owner: Owner { organism, phenotype, lineage }, capacity, generation: 0,
            last_sequence: 0, last_dispatch: 0,
            episodes: vec![] } })
    }

    /// Atomic append. No body advance, predictor, optimizer, reward assignment,
    /// source replay, or invocation of the supplemental value writer occurs.
    pub fn observe(&mut self, patch: &ExperiencePatch, frame: &PerceptionFrame)
        -> Result<(), ScaffoldContractError> {
        let episode = self.derive(patch, frame)?;
        let mut staged = self.clone();
        staged.wire.generation = staged.wire.generation.checked_add(1).ok_or_else(invalid)?;
        staged.wire.last_sequence = episode.sequence.raw();
        staged.wire.last_dispatch = episode.dispatch_generation;
        if staged.wire.episodes.len() == staged.wire.capacity { staged.wire.episodes.remove(0); }
        staged.wire.episodes.push(episode);
        staged.validate()?;
        *self = staged;
        Ok(())
    }

    fn derive(&self, patch: &ExperiencePatch, frame: &PerceptionFrame)
        -> Result<JointEpisodeV1, ScaffoldContractError> {
        patch.validate_contract()?;
        frame.validate_contract()?;
        if frame != patch.pre_action().perception()
            || frame.profile_provenance().identity().profile_id.raw() != 5
            || !matches!(patch.decision().evidence, DecisionEvidence::NeuralClosedLoopCpu(_)) {
            return Err(invalid());
        }
        let evidence = patch.decision().neural_evidence()?;
        let bundle = patch.selected_bundle().ok_or_else(invalid)?;
        if bundle.organism_id != self.wire.owner.organism
            || evidence.phenotype_hash != self.wire.owner.phenotype
            || bundle.sequence_id.raw() <= self.wire.last_sequence
            || evidence.dispatch_generation <= self.wire.last_dispatch { return Err(invalid()); }
        let joint = patch.outcome().joint.as_ref().ok_or_else(invalid)?;
        // Incomplete, duplicate, unmatched receipt sets cannot establish facts.
        if joint.channel_outcomes.len() != bundle.channels.len() { return Err(invalid()); }
        for command in &bundle.channels {
            if joint.channel_outcomes.iter().filter(|r| r.channel == command.channel).count() != 1 {
                return Err(invalid());
            }
        }
        let mut consumed = None;
        for command in &bundle.channels {
            let receipt = joint.channel_outcomes.iter().find(|r| r.channel == command.channel)
                .ok_or_else(invalid)?;
            if receipt.physical.contact != PhysicalContactKind::Consumed { continue; }
            // Unknown provenance stays unknown. Other contacts remain joint context,
            // regardless of sign; no target ownership is inferred from physiology.
            if command.channel != MotorChannel::Manipulation { return Err(invalid()); }
            let binding = command.target.ok_or_else(invalid)?;
            let target = binding.entity.ok_or_else(invalid)?;
            if receipt.physical.target_entity != Some(target) { return Err(invalid()); }
            let mut matching = frame.candidates().iter()
                .filter(|c| c.action_id == command.primitive && c.target == binding);
            let candidate = matching.next().ok_or_else(invalid)?;
            if matching.next().is_some() || candidate.family != CandidateActionFamily::Ingest
                || candidate.kind != ActionKind::Interact { return Err(invalid()); }
            let query = MemoryQueryEncoderV2::encode_from_frame(frame, candidate)?;
            if query.tracked_object_id().is_none() || consumed.is_some() { return Err(invalid()); }
            consumed = Some(ConsumedFactV1 { query, target, command_confidence: command.confidence });
        }
        Ok(JointEpisodeV1 { sequence: bundle.sequence_id, dispatch_generation: evidence.dispatch_generation,
            source_tick: bundle.tick, pre_action_drives: frame.homeostasis().drives.to_array(),
            channel_receipts: joint.channel_outcomes.clone(),
            frame_digest: frame.frame_digest(), source_digest: patch.causal_digest()?,
            bundle_digest: bundle.canonical_digest()?, commands: bundle.channels.clone(),
            coordination: bundle.coordination.clone(), consumed,
            joint_experienced_valence: patch.outcome().experienced_valence() })
    }

    /// Structural full-command recall, NOT an isolated action value. Every channel,
    /// primitive, entity target, operation payload and coordination group must match.
    /// Intensity and duration must match (different operations remain different).
    /// Clock, confidence, direction, world-space target point and stand-off are NOT
    /// identity. All measured pre-action drive components must be within 0.15.
    /// This declared conservative heuristic is not a learned similarity function.
    pub fn recall_joint(&self, proposed: &MotorCommandBundle, frame: &PerceptionFrame)
        -> Result<Vec<&JointEpisodeV1>, ScaffoldContractError> {
        proposed.validate_contract()?;
        frame.validate_contract()?;
        if proposed.organism_id != self.wire.owner.organism
            || frame.organism_id() != proposed.organism_id
            || frame.profile_provenance().identity().profile_id.raw() != 5 { return Err(invalid()); }
        let drives = frame.homeostasis().drives.to_array();
        Ok(self.wire.episodes.iter().filter(|e|
            structural_match(&e.commands, &proposed.channels)
            && e.coordination == proposed.coordination
            && e.pre_action_drives.iter().zip(drives).all(|(a, b)| (a - b).abs() <= 0.15)
        ).collect())
    }

    /// Sleep is allowed to inspect whole joint records only. No old replay API is
    /// called or mapped to representative/Flee or Eat scalar targets here.
    pub fn sleep_joint_sources(&self) -> &[JointEpisodeV1] { &self.wire.episodes }

    fn validate(&self) -> Result<(), ScaffoldContractError> {
        let w = &self.wire;
        if w.schema != 1 || w.policy != JOINT_EPISODE_POLICY_V1 || w.owner.lineage == [0; 4]
            || w.capacity == 0 || w.capacity > CAPACITY_LIMIT || w.episodes.len() > w.capacity
            || w.generation < w.episodes.len() as u64 { return Err(invalid()); }
        w.owner.organism.validate()?;
        let mut previous = (0, 0);
        for e in &w.episodes {
            e.sequence.validate()?;
            SignedValence::new(e.joint_experienced_valence.raw())?;
            if e.sequence.raw() <= previous.0 || e.dispatch_generation <= previous.1 { return Err(invalid()); }
            previous = (e.sequence.raw(), e.dispatch_generation);
            validate_finite_slice(&e.pre_action_drives)?;
            if e.pre_action_drives.iter().any(|x| !(0.0..=1.0).contains(x)) { return Err(invalid()); }
            let bundle = MotorCommandBundle::new(w.owner.organism, e.sequence, e.source_tick,
                e.commands.clone())?.with_coordination(e.coordination.clone())?;
            if bundle.canonical_digest()? != e.bundle_digest
                || e.channel_receipts.len() != e.commands.len() { return Err(invalid()); }
            for c in &e.commands {
                let matching: Vec<_> = e.channel_receipts.iter().filter(|r| r.channel == c.channel).collect();
                if matching.len() != 1 { return Err(invalid()); }
                matching[0].validate_contract()?;
            }
            let consumed_receipts: Vec<_> = e.channel_receipts.iter()
                .filter(|r| r.physical.contact == PhysicalContactKind::Consumed).collect();
            if let Some(f) = &e.consumed {
                f.query.validate_contract()?;
                f.target.validate()?;
                Confidence::new(f.command_confidence.raw())?;
                let command = e.commands.iter().find(|c| c.channel == MotorChannel::Manipulation)
                    .ok_or_else(invalid)?;
                if f.query.organism_id() != w.owner.organism
                    || f.query.action_family() != CandidateActionFamily::Ingest
                    || f.query.action_kind() != ActionKind::Interact
                    || f.query.action_id() != command.primitive
                    || f.query.tracked_object_id().is_none()
                    || command.target.and_then(|t| t.entity) != Some(f.target)
                    || command.confidence != f.command_confidence
                    || consumed_receipts.len() != 1
                    || consumed_receipts[0].channel != command.channel
                    || consumed_receipts[0].physical.target_entity != Some(f.target) { return Err(invalid()); }
            } else if !consumed_receipts.is_empty() { return Err(invalid()); }
        }
        if previous != (w.last_sequence, w.last_dispatch) { return Err(invalid()); }
        if (w.generation == 0) != w.episodes.is_empty() { return Err(invalid()); }
        Ok(())
    }

    pub fn checkpoint(&self) -> Result<(Vec<u8>, JointEpisodeAnchorV1), ScaffoldContractError> {
        self.validate()?;
        let bytes = serde_json::to_vec(&self.wire).map_err(|_| invalid())?;
        if bytes.len() > WIRE_LIMIT { return Err(invalid()); }
        let anchor = JointEpisodeAnchorV1 { policy: JOINT_EPISODE_POLICY_V1.into(),
            lineage: self.wire.owner.lineage, organism: self.wire.owner.organism,
            phenotype: self.wire.owner.phenotype, generation: self.wire.generation,
            last_sequence: self.wire.last_sequence, digest: *blake3::hash(&bytes).as_bytes() };
        Ok((bytes, anchor))
    }

    /// `expected` must be the trusted enclosing host checkpoint owner/anchor, not
    /// one extracted from the untrusted input. Old bank bytes cannot be imported.
    pub fn restore(bytes: &[u8], expected: &JointEpisodeAnchorV1)
        -> Result<Self, ScaffoldContractError> {
        if bytes.len() > WIRE_LIMIT || expected.policy != JOINT_EPISODE_POLICY_V1
            || *blake3::hash(bytes).as_bytes() != expected.digest { return Err(invalid()); }
        let result = Self { wire: serde_json::from_slice(bytes).map_err(|_| invalid())? };
        result.validate()?;
        let (_, actual) = result.checkpoint()?;
        if actual != *expected { return Err(invalid()); }
        Ok(result)
    }
}

fn structural_match(left: &[ChannelCommand], right: &[ChannelCommand]) -> bool {
    left.len() == right.len() && left.iter().all(|a| right.iter().any(|b|
        a.channel == b.channel && a.primitive == b.primitive
        && a.target.and_then(|t| t.entity) == b.target.and_then(|t| t.entity)
        && a.payload == b.payload && a.coordination_group == b.coordination_group
        && a.intensity == b.intensity && a.duration_ticks == b.duration_ticks))
}
