//! Public-contract companion adapter. The frozen joint module is unchanged.
//! The local encoder below is NOT an exported or widened core API.
pub use alife_core::*;
use serde::{Serialize,Deserialize};
// Explicitly shadows the glob-imported encoder only inside this companion.
// Warm core's frame encoder is crate-private. Reconstruct and validate the
// IDENTICAL draft, then call its public candidate encoder. No frame field,
// provenance, context or query digest is patched or inferred.
struct MemoryQueryEncoderV2;
impl MemoryQueryEncoderV2 {
    fn encode_from_frame(frame:&PerceptionFrame,candidate:&ActionCandidate)
        -> Result<CandidateMemoryQueryV2,ScaffoldContractError> {
        frame.validate_contract()?;
        let draft=PerceptionFrameDraft::new(frame.organism_id(),frame.tick(),frame.sensor_profile(),
            frame.sensory().clone(),frame.body(),frame.homeostasis().clone(),frame.candidates().to_vec(),
            frame.profile_provenance(),frame.grounded_object_slots().to_vec())?;
        if draft.base_digest()!=frame.base_digest()
            || draft.clone().finalize(frame.context().clone())? != *frame {
            return Err(ScaffoldContractError::InvalidMemoryQuery);
        }
        alife_core::MemoryQueryEncoderV2::encode_candidate(&draft,candidate)
    }
}
#[path = "../../alife_core/src/memory/joint_episode.rs"]
pub mod joint_episode;
