// Proposed test-only include inside visible_cue_joint. No production mutation.
// Inputs must be the exact retained disposable fixture's pre-action frames.
#[cfg(test)]
impl FreshVisibleCueMemoryV1 {
    pub(crate) fn diagnose_two_sources(&self,sources:&[(u64,&PerceptionFrame)],query_frame:&PerceptionFrame,query_bundle:&MotorCommandBundle)
        ->Result<serde_json::Value,ScaffoldContractError>{
        if sources.len()>2||self.cues.len()>2{return Err(invalid());}
        let query=ObservedJoint::capture(query_frame,query_bundle);
        let mut records=Vec::new();
        for record in &self.cues {
            let e=self.exact.sleep_joint_sources().iter().find(|e|e.sequence.raw()==record.sequence).ok_or_else(invalid)?;
            let frames=sources.iter().filter(|(seq,_)|*seq==record.sequence).collect::<Vec<_>>();
            if frames.len()!=1{return Err(invalid());}let source_frame=frames[0].1;
            if source_frame.frame_digest()!=e.frame_digest{return Err(invalid());}
            let bundle=MotorCommandBundle::new(source_frame.organism_id(),e.sequence,e.source_tick,e.commands.clone())?.with_coordination(e.coordination.clone())?;
            let rebuild=ObservedJoint::capture(source_frame,&bundle);
            let self_match=record.observed.as_ref().zip(rebuild.as_ref().ok()).map(|(a,b)|a.matches(b,LookupModeV1::ExecutorEntityRoutesV2,record.consumed_channel));
            let pair=record.observed.as_ref().zip(query.as_ref().ok());
            records.push(serde_json::json!({"sequence":record.sequence,"source_frame_bytes":serde_json::to_vec(source_frame).map_err(|_|invalid())?.len(),
                "frame_budget_bytes":MAX_FRAME_BYTES,"witness_retained":record.frame.is_some(),"stored_capture_success":record.observed.is_some(),
                "rebuild_capture_success":rebuild.is_ok(),"rebuild_capture_error":rebuild.as_ref().err().map(|e|format!("{e:?}")),
                "original_self_match":self_match,"pair_match":pair.map(|(a,b)|a.matches(b,LookupModeV1::ExecutorEntityRoutesV2,record.consumed_channel)),
                "pair_rejections":pair.map(|(a,b)|cue_pair_rejections(a,b,record.consumed_channel)),
                "signed_joint_valence":e.joint_experienced_valence.raw(),"source_consumed":e.consumed.is_some()}));
        }
        let result=serde_json::json!({"query_capture_success":query.is_ok(),"query_capture_error":query.as_ref().err().map(|e|format!("{e:?}")),
            "records":records,"future_grip":"Unknown","future_consumption":"Unknown","scope":"historical-frame diagnostic, no policy dispatch"});
        if serde_json::to_vec(&result).map_err(|_|invalid())?.len()>32*1024{return Err(invalid());}Ok(result)
    }
}
#[cfg(test)]
fn cue_pair_rejections(a:&ObservedJoint,b:&ObservedJoint,consumed:Option<MotorChannel>)->Vec<String>{
    let mut why=Vec::new();
    if a.owner!=b.owner{why.push("owner".into());}
    if a.roles.len()!=b.roles.len(){why.push("channel_count".into());}
    if a.coordination!=b.coordination{why.push("coordination_summary".into());}
    for(i,(x,y))in a.drives.iter().zip(b.drives).enumerate(){if(x-y).abs()>0.15{why.push(format!("drive:{i}"));}}
    for ar in &a.roles {
        let Some(br)=b.roles.iter().find(|r|r.command.channel==ar.command.channel)else{why.push(format!("missing_channel:{:?}",ar.command.channel));continue;};
        let x=&ar.command;let y=&br.command;let tag=format!("{:?}",x.channel);
        if x.primitive!=y.primitive||x.payload!=y.payload||x.intensity!=y.intensity||x.duration_ticks!=y.duration_ticks||x.coordination_group!=y.coordination_group{why.push(format!("{tag}:operation_or_effort"));}
        if !entity_route_equivalent(x,y,LookupModeV1::ExecutorEntityRoutesV2)&&(x.direction!=y.direction||x.stand_off_distance!=y.stand_off_distance||x.confidence!=y.confidence){why.push(format!("{tag}:physical_command_fields"));}
        if x.target.and_then(|t|t.entity).is_some()!=y.target.and_then(|t|t.entity).is_some(){why.push(format!("{tag}:target_presence"));}
        match(&ar.query,&br.query){
            (Some(xq),Some(yq))=>{
                let x=&xq.features()[TARGET_START..TARGET_START+24];let y=&yq.features()[TARGET_START..TARGET_START+24];
                for(name,range)in [("color",6..9),("material",9..12),("shape",12..15),("chemical",15..18),("temperature",21..22),("terrain",22..24)]{
                    if range.clone().any(|i|x[i].to_bits()!=y[i].to_bits()){why.push(format!("{tag}:{name}"));}
                }
                for i in 0..6{if(x[i]-y[i]).abs()>if i<2{0.05}else{0.02}{why.push(format!("{tag}:relative_geometry_lane:{i}"));}}
                for i in 19..21{if(x[i]-y[i]).abs()>0.05{why.push(format!("{tag}:proprioception_lane:{i}"));}}
                if x[18].to_bits()!=y[18].to_bits(){why.push(format!("{tag}:contact_difference"));}
                if ar.command.channel==MotorChannel::Manipulation {
                    if x[2]>MAX_INTERACTION_DISTANCE||y[2]>MAX_INTERACTION_DISTANCE{why.push(format!("{tag}:interaction_range"));}
                    if consumed==Some(ar.command.channel)&&(x[18]!=1.||y[18]!=1.){why.push(format!("{tag}:consumed_source_contact_required"));}
                }
            },(None,None)=>{},_=>why.push(format!("{tag}:observation_presence")),
        }
    }
    for ar in &a.roles{for other in &a.roles{
        let br=b.roles.iter().find(|r|r.command.channel==ar.command.channel);let bo=b.roles.iter().find(|r|r.command.channel==other.command.channel);
        if let(Some(br),Some(bo))=(br,bo){
            let target=|r:&ObservedRole|r.command.target.and_then(|t|t.entity);
            if(target(ar)==target(other))!=(target(br)==target(bo)){why.push("target_equality_graph".into());}
        }
    }}
    why
}
