// New private wire owner. Anchors provide integrity, not authentication against
// an actor replacing the entire enclosing host proof and all its commitments.
use alife_joint_episode::joint_episode::{JointEpisodeAnchorV1,JointEpisodeV1};
use serde::{Serialize,Deserialize};
const MAX_FRAME_BYTES:usize=32*1024;
const MAX_CUE_WIRE_BYTES:usize=12*1024*1024;
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
struct CueWire {owner:String,exact_bytes:String,exact_anchor:JointEpisodeAnchorV1,frames:Vec<(u64,Option<PerceptionFrame>)>}
impl FreshVisibleCueMemoryV1 {
 pub fn checkpoint(&self)->Result<(Vec<u8>,JointEpisodeAnchorV1),ScaffoldContractError>{
  let(exact_bytes,exact_anchor)=self.exact.checkpoint()?;
  let wire=CueWire{owner:VISIBLE_CUE_JOINT_OWNER_V1.into(),exact_bytes:String::from_utf8(exact_bytes).map_err(|_|invalid())?,exact_anchor:exact_anchor.clone(),
   frames:self.cues.iter().map(|c|(c.sequence,c.frame.clone())).collect()};
  let bytes=serde_json::to_vec(&wire).map_err(|_|invalid())?;
  if bytes.len()>MAX_CUE_WIRE_BYTES{return Err(invalid());}
  let mut anchor=exact_anchor;anchor.policy=VISIBLE_CUE_JOINT_OWNER_V1.into();anchor.digest=*blake3::hash(&bytes).as_bytes();
  Ok((bytes,anchor))
 }
 pub fn restore(bytes:&[u8],anchor:&JointEpisodeAnchorV1)->Result<Self,ScaffoldContractError>{
  if bytes.len()>MAX_CUE_WIRE_BYTES||anchor.policy!=VISIBLE_CUE_JOINT_OWNER_V1||*blake3::hash(bytes).as_bytes()!=anchor.digest{return Err(invalid());}
  let w:CueWire=serde_json::from_slice(bytes).map_err(|_|invalid())?;
  if w.owner!=VISIBLE_CUE_JOINT_OWNER_V1||w.frames.len()>CAPACITY
   ||w.exact_anchor.organism!=anchor.organism||w.exact_anchor.phenotype!=anchor.phenotype
   ||w.exact_anchor.lineage!=anchor.lineage||w.exact_anchor.generation!=anchor.generation
   ||w.exact_anchor.last_sequence!=anchor.last_sequence{return Err(invalid());}
  let exact=JointEpisodeMemoryV1::restore(w.exact_bytes.as_bytes(),&w.exact_anchor)?;
  if w.frames.len()!=exact.sleep_joint_sources().len(){return Err(invalid());}
  let mut cues=Vec::new();
  for ((sequence,frame),e) in w.frames.into_iter().zip(exact.sleep_joint_sources()) {
   if sequence!=e.sequence.raw(){return Err(invalid());}
   let bundle=MotorCommandBundle::new(anchor.organism,e.sequence,e.source_tick,e.commands.clone())?.with_coordination(e.coordination.clone())?;
   let observed=if let Some(f)=&frame {
    f.validate_contract()?;
    if serde_json::to_vec(f).map_err(|_|invalid())?.len()>MAX_FRAME_BYTES
     ||f.frame_digest()!=e.frame_digest||f.organism_id()!=anchor.organism||f.tick()!=e.source_tick
     ||f.homeostasis().drives.to_array()!=e.pre_action_drives||bundle.canonical_digest()?!=e.bundle_digest{return Err(invalid());}
    ObservedJoint::capture(f,&bundle).ok()
   }else{None};
   // Consumed remains solely the exact sealed episode's source fact.
   let consumed_channel=e.consumed.as_ref().map(|_|MotorChannel::Manipulation);
   cues.push(CueRecord{sequence,observed,consumed_channel,frame});
  }
  let result=Self{owner_domain:VISIBLE_CUE_JOINT_OWNER_V1.into(),exact,cues};
  if result.checkpoint()?.1!=*anchor{return Err(invalid());}Ok(result)
 }
 pub fn recall_joint(&self,bundle:&MotorCommandBundle,frame:&PerceptionFrame)->Result<Vec<&JointEpisodeV1>,ScaffoldContractError>{
  // Invalid/missing cue evidence means no learned value, never failed biology.
  let Ok(observed)=ObservedJoint::capture(frame,bundle)else{return Ok(vec![]);};
  Ok(self.cues.iter().zip(self.exact.sleep_joint_sources()).filter_map(|(c,e)|
   c.observed.as_ref().filter(|s|s.matches(&observed,LookupModeV1::ExecutorEntityRoutesV2,c.consumed_channel)).map(|_|e)).collect())
 }
 pub fn sleep_joint_sources(&self)->&[JointEpisodeV1]{self.exact.sleep_joint_sources()}
}
