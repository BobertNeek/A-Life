// New-owner graded whole-event readout. No descriptor edits, family projection,
// reward manufacture, hidden object categories or physical possession inference.
#[derive(Debug,Clone,Copy)]
enum GradedRoute { EntityEat, EntityMove, EntityInspect }
fn graded_route(c:&ChannelCommand)->Option<GradedRoute>{
    c.target.and_then(|t|t.entity)?;
    match(c.channel,c.primitive.raw()){
        (MotorChannel::Manipulation,210)=>Some(GradedRoute::EntityEat),
        (MotorChannel::Locomotion,101|102)=>Some(GradedRoute::EntityMove),
        (MotorChannel::Posture,4)=>Some(GradedRoute::EntityInspect),_=>None,
    }
}
impl ObservedJoint {
    fn graded_weight(&self,b:&Self,consumed:Option<MotorChannel>)->Option<f32>{
        if self.owner!=b.owner||self.roles.len()!=b.roles.len()||self.coordination!=b.coordination
            ||self.drives.iter().zip(b.drives).any(|(x,y)|(x-y).abs()>0.15){return None;}
        let mut distance=0f64;
        for a in &self.roles {
            let z=b.roles.iter().find(|z|z.command.channel==a.command.channel)?;
            let x=&a.command;let y=&z.command;let route=graded_route(x)?;graded_route(y)?;
            if x.primitive!=y.primitive||x.payload!=y.payload||x.intensity!=y.intensity||x.duration_ticks!=y.duration_ticks||x.coordination_group!=y.coordination_group{return None;}
            if !entity_route_equivalent(x,y,LookupModeV1::ExecutorEntityRoutesV2)
                &&(x.direction!=y.direction||x.stand_off_distance!=y.stand_off_distance||x.confidence!=y.confidence){return None;}
            let af=&a.query.as_ref()?.features()[TARGET_START..TARGET_START+24];let bf=&z.query.as_ref()?.features()[TARGET_START..TARGET_START+24];
            // Strict chemical boundary; even subtle changed chemistry is not
            // generalized from a positive event without separate evidence.
            if (15..18).any(|i|af[i].to_bits()!=bf[i].to_bits()){return None;}
            if (3..6).any(|i|(af[i]-bf[i]).abs()>0.02)||(19..21).any(|i|(af[i]-bf[i]).abs()>0.05){return None;}
            match route {
                GradedRoute::EntityEat=>{
                    // Actual entity-target ingestion resolves world position;
                    // bearing/fallback point is not its command operation.
                    // Reach and observed contact still constrain transfer.
                    if af[2]>MAX_INTERACTION_DISTANCE||bf[2]>MAX_INTERACTION_DISTANCE||af[18].to_bits()!=bf[18].to_bits(){return None;}
                    if consumed==Some(x.channel)&&(af[18]!=1.||bf[18]!=1.){return None;}
                },
                GradedRoute::EntityMove|GradedRoute::EntityInspect=>{
                    if (0..3).any(|i|(af[i]-bf[i]).abs()>if i<2{0.05}else{0.02})||af[18].to_bits()!=bf[18].to_bits(){return None;}
                }
            }
            for range in [6..9,9..12,12..15]{distance+=range.map(|i|(f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/3.;}
            // Full observed temperature range is[-1,1]; terrain range[0,1].
            // Keep both as nonzero, stronger context penalties, not nuisance
            // channels erased globally. Scales fixed before any evaluation.
            distance+=2.*((f64::from(af[21])-f64::from(bf[21]))/2.).powi(2);
            distance+=2.*(22..24).map(|i|(f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/2.;
        }
        for a in &self.roles{for other in &self.roles{
            let z=b.roles.iter().find(|z|z.command.channel==a.command.channel)?;
            let zo=b.roles.iter().find(|z|z.command.channel==other.command.channel)?;
            let target=|r:&ObservedRole|r.command.target.and_then(|t|t.entity);
            if(target(a)==target(other))!=(target(z)==target(zo)){return None;}
        }}
        Some((-distance).exp()as f32)
    }
}
fn attenuated_signed_mean(values:&[(f32,f32)])->Result<Option<f32>,ScaffoldContractError>{
    if values.is_empty(){return Ok(None);}
    if values.iter().any(|(v,w)|!v.is_finite()||!(-1.0..=1.0).contains(v)||!w.is_finite()||!(0.0..=1.0).contains(w)){return Err(invalid());}
    // Divide by event count, NOT sum(weights): a single distant positive event
    // cannot regain full strength merely through weight normalization.
    Ok(Some((values.iter().map(|(v,w)|f64::from(*v)*f64::from(*w)).sum::<f64>()/values.len()as f64)as f32))
}
impl FreshVisibleCueMemoryV1 {
    pub(crate) fn expected_graded_joint_value(&self,bundle:&MotorCommandBundle,frame:&PerceptionFrame)->Result<Option<f32>,ScaffoldContractError>{
        if self.owner_domain!=VISIBLE_CUE_JOINT_OWNER_V1{return Err(invalid());}
        let Ok(query)=ObservedJoint::capture(frame,bundle)else{return Ok(None);};
        let mut values=Vec::new();
        for(record,e)in self.cues.iter().zip(self.exact.sleep_joint_sources()){
            if record.sequence!=e.sequence.raw(){return Err(invalid());}
            if let Some(w)=record.observed.as_ref().and_then(|s|s.graded_weight(&query,record.consumed_channel)){
                values.push((e.joint_experienced_valence.raw(),w));
            }
        }
        attenuated_signed_mean(&values)
    }
}
