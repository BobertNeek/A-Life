//! AUTHORED ONLY, not run. Fixed-source registered-world controls. No archived life or new study seed.
//! Scripted action intervention is separate from unchanged real sampling.
#[allow(dead_code)]
#[path = "grouped_host_fixture.rs"]
mod recipe;
use super::*;
use super::super::optional_vocal::OptionalVocalPolicy;
use crate::{AdamWConfig, StageTrainableMask};
use alife_world::*;
// Reuse the existing closed grouped-host test seed, not a new study seed.
const SEED: u64 = 0x0347_5250_484F_5354;
fn setup(
    food: bool,
) -> (
    CanonicalNewGame,
    CpuFoundationTrainer,
    PhenotypeCompilerInputs,
) {
    let recipe = recipe::build(SEED, true).unwrap();
    let mut trainer = CpuFoundationTrainer::new(
        recipe.phenotype.clone(),
        recipe.asset.clone(),
        StageTrainableMask::recurrent_only(&recipe.phenotype).unwrap(),
        AdamWConfig::default(),
    )
    .unwrap();
    let mut state = trainer.checkpoint();
    state.optimizer_step = 23;
    state.update_ages[0] = 23;
    state.first_moment[0] = 0.03125;
    state.second_moment[0] = 0.0625;
    trainer = CpuFoundationTrainer::from_checkpoint(recipe.phenotype, recipe.asset, state).unwrap();
    let mut game =
        create_grounded_drive_research_new_game(&recipe.config, &recipe.genotype).unwrap();
    let newborn = game
        .world
        .organism_registry()
        .iter()
        .next()
        .unwrap()
        .clone();
    let builder =
        HeadlessScenarioBuilder::new(SEED).agent("learner", newborn.organism_id(), Vec3f::ZERO);
    let builder = if food {builder.food("near-root", Vec3f::new(1.,0.,-0.5),0.65)
        .food("far-fruit",Vec3f::new(2.75,0.,1.75),0.45)
        .toy("activity-toy",Vec3f::new(0.8,0.,2.1),false)
        .food("second-root",Vec3f::new(0.35,0.,0.),0.65)}else{builder};
    let mut world = builder.build().unwrap();
    if food {
        world.set_food_variety(world.entity_id("near-root").unwrap(),FoodVariety::Root).unwrap();
        world.set_food_variety(world.entity_id("far-fruit").unwrap(),FoodVariety::Fruit).unwrap();
        world.set_food_variety(world.entity_id("second-root").unwrap(),FoodVariety::Root).unwrap();
    }
    world
        .register_grounded_drive_research_record(newborn)
        .unwrap();
    game.world = world;
    (game, trainer, recipe.inputs)
}
fn mature(world: &mut HeadlessWorld) -> Result<(), String> {
    for _ in 0..240 {
        world.try_advance_tick().map_err(|e| e.to_string())?;
    }
    Ok(())
}
fn fixture(food: bool) -> (CpuJointOptionalM2HostV2, PhenotypeCompilerInputs) {
    let (game, trainer, inputs) = setup(food);
    let (host, ()) = CpuJointOptionalM2HostV2::new_prepared(
        game,
        trainer,
        inputs.clone(),
        (SEED ^ (SEED >> 32)) as u32,
        MediationModeV1::Full,
        mature,
    )
    .unwrap();
    (host, inputs)
}
fn bytes<T: Serialize>(value: &T) -> Vec<u8> {
    serde_json::to_vec(value).unwrap()
}
fn frozen(host: &CpuJointOptionalM2HostV2) -> Vec<u8> {
    let r = host.inner.host.residents.values().next().unwrap();
    let n = r.neural.checkpoint().unwrap();
    bytes(&(
        host.inner.founder.checkpoint(),
        n.fast,
        n.lifetime,
        n.eligibility,
        n.weight_generation,
        n.neural.dendrites,
        r.v11.checkpoint(),
    ))
}
// These counters distinguish one actual world/source/credit boundary from the
// two memory associations. The read-only recall probe below advances none.
fn event_counters(host: &CpuJointOptionalM2HostV2) -> (u64, u64, u64, u64, usize) {
    let r = host.inner.host.residents.values().next().unwrap();
    let body = host.world().organism_registry().iter().next().unwrap();
    (
        host.world().tick().raw(),
        body.biochemistry().development.age_ticks.raw(),
        r.next_sequence,
        r.neural.checkpoint().unwrap().dispatch_generation,
        r.replay.len(),
    )
}

#[cfg(any())]
#[test]
fn cue_host_cold_continuation_and_owner_rejection() {
    let (mut host, inputs) = fixture(false);
    let frozen_before = frozen(&host);
    let before = event_counters(&host);
    let first = host.step(0.9).unwrap();
    assert_eq!(first.decisions.len(), 1);
    let after = event_counters(&host);
    assert_eq!(after, (before.0+1, before.1+1, before.2+1, before.3+1, before.4+1));
    assert_eq!(first.decisions[0].motor.native.core.source_execution_count, 1);
    assert_eq!(frozen(&host), frozen_before);
    let encoded = host.checkpoint().unwrap().encode().unwrap();
    assert!(CpuGroupedM2HostCheckpointV1::decode(&encoded).is_err());
    assert!(CpuOptionalVocalM2HostCheckpointV1::decode(&encoded).is_err());
    let c=host.checkpoint().unwrap();
    assert!(CpuOptionalVocalM2HostCheckpointV1::decode(c.payload.inner.as_bytes()).is_err());
    assert!(host.inner.checkpoint_payload::<OptionalVocalPolicy>().is_err());
    let mut bad=c.clone();bad.payload.owner_digest[0]^=1;
    assert!(CpuJointOptionalM2HostCheckpointV2::decode(&bad.encode().unwrap()).is_err());

    let mut cold = CpuJointOptionalM2HostV2::restore(
        CpuJointOptionalM2HostCheckpointV2::decode(&encoded).unwrap(), &inputs, MediationModeV1::Full).unwrap();
    assert_eq!(cold.checkpoint().unwrap().encode().unwrap(), encoded);
    let a = host.step(0.9).unwrap();
    let b = cold.step(0.9).unwrap();
    assert_eq!(a.decisions.len(),b.decisions.len());
    for (x,y) in a.decisions.iter().zip(&b.decisions) {
        assert_eq!(bytes(&x.action),bytes(&y.action));
        assert_eq!(bytes(&x.patch),bytes(&y.patch));
        assert_eq!(bytes(&x.motor),bytes(&y.motor));
    }
    assert_eq!(host.checkpoint().unwrap().encode().unwrap(), cold.checkpoint().unwrap().encode().unwrap());
    assert_eq!(frozen(&host), frozen_before);
}


#[cfg(any())]
#[test]
fn joint_optional_quiet_is_not_empty_vocal() {
    let (mut host,_)=fixture(false);
    let step=host.step(0.9).unwrap(); let d=&step.decisions[0];
    assert_eq!(d.action.motors()[3],crate::cpu::OptionalVocalChoiceV1::Quiet);
    assert!(d.patch.selected_bundle().unwrap().channels.iter().all(|c|c.channel!=MotorChannel::Vocal));
    assert!(host.world().audible_utterances().is_empty());
    assert!(d.action.joint_log_probability().is_finite());
    assert!(d.action.bundle_log_probability()>=d.action.joint_log_probability()-1e-10);
}
#[cfg(any())]
#[test]
fn joint_optional_archive_kept_legacy_values_gated() {
    let (mut host,_)=fixture(false); host.step(0.9).unwrap(); host.step(0.9).unwrap();
    let r=host.inner.host.residents.values().next().unwrap();
    let archive=r.memory.export_active_bank().unwrap();
    assert_eq!(archive.last_observed_sequence_id_raw,2);
    let joint=r.grouped.as_ref().unwrap().joint_episode.as_ref().unwrap();
    assert_eq!(joint.anchor.last_sequence,2);
    let value=serde_json::to_value(&joint.last.as_ref().unwrap().scores).unwrap();
    for c in value["episodic_context"]["candidates"].as_array().unwrap() {
        assert_eq!(c["family_source_count"],0); assert_eq!(c["target_source_count"],0);
        assert!(c["family_value"].as_array().unwrap().iter().all(|x|x.as_f64()==Some(0.)));
    }
    joint.validate().unwrap();
}
#[cfg(any())]
#[test]
fn joint_optional_outer_inner_and_old_owner_cross_load_rejected() {
    let (mut host,inputs)=fixture(false); host.step(0.9).unwrap();
    let c=host.checkpoint().unwrap();let wire=c.encode().unwrap();
    assert!(CpuGroupedM2HostCheckpointV1::decode(&wire).is_err());
    assert!(CpuOptionalVocalM2HostCheckpointV1::decode(&wire).is_err());
    assert!(CpuOptionalVocalM2HostCheckpointV1::decode(c.payload.inner.as_bytes()).is_err());
    assert!(host.inner.checkpoint_payload::<OptionalVocalPolicy>().is_err());
    let mut bad=c.clone();bad.payload.owner_digest[0]^=1;
    assert!(CpuJointOptionalM2HostCheckpointV2::decode(&bad.encode().unwrap()).is_err());
    let cold=CpuJointOptionalM2HostV2::restore(c,&inputs,MediationModeV1::Full).unwrap();
    assert_eq!(cold.checkpoint().unwrap().encode().unwrap(),wire);
}
#[cfg(any())]
#[test]
fn joint_optional_rejected_transaction_is_atomic() {
    let(mut host,_)=fixture(false);let before=host.checkpoint().unwrap().encode().unwrap();
    assert!(host.step(f32::NAN).is_err());assert_eq!(host.checkpoint().unwrap().encode().unwrap(),before);
}
#[test]
fn graded_registered_two_root_reason_and_self_match_diagnostic() {
    // Two fixed mechanism intervals, NOT sampled witnesses. Acquire, then consume. No body/receipt edits.
    let (game,founder,inputs)=setup(true);
    let (inner,())=CpuGroupedM2HostV1::new_prepared_policy::<ScriptedJointMechanismPolicy,_,String>(
        game,founder,inputs,(SEED^(SEED>>32))as u32,MediationModeV1::Full,mature).unwrap();
    let mut host=CpuJointOptionalM2HostV2{inner};let before=frozen(&host);let counters=event_counters(&host);
    let acquired=host.inner.host.grouped_policy_step_observed::<ScriptedJointMechanismPolicy>(&host.inner.founder,0.9).unwrap();
    assert_eq!(acquired.world_receipts.len(),1);
    let receipt=&acquired.world_receipts[0];let actor=acquired.step.decisions[0].organism_id;
    assert!(receipt.grip_transfers.iter().any(|t|t.kind==GripTransferKind::Acquired
        && t.object==WorldEntityId(2) && t.previous_owner.is_none() && t.new_owner==Some(actor)));
    assert!(!receipt.grip_transfers.iter().any(|t|t.kind==GripTransferKind::Consumed));
    assert!(receipt.channel_receipts.iter().any(|c|c.command.channel==MotorChannel::Manipulation
        && c.phase==ActionPhase::Preparation && c.physical.contact!=PhysicalContactKind::Consumed));
    let (first_episode,first_memory)={
        let resident=host.inner.host.residents.values().next().unwrap();
        let joint=resident.grouped.as_ref().unwrap().joint_episode.as_ref().unwrap();
        let memory=joint.memory().unwrap();assert_eq!(memory.sleep_joint_sources().len(),1);
        let episode=&memory.sleep_joint_sources()[0];assert!(episode.consumed.is_none());
        assert_eq!(episode.channel_receipts,acquired.step.decisions[0].patch.outcome().joint.as_ref().unwrap().channel_outcomes);
        assert_eq!(joint.anchor.generation,1);assert_eq!(joint.anchor.last_sequence,1);
        assert_eq!(resident.memory.export_active_bank().unwrap().last_observed_sequence_id_raw,1);
        (bytes(episode),memory)
    };
    assert_eq!(frozen(&host),before);
    let acquired_counters=event_counters(&host);
    assert_eq!(acquired_counters,(counters.0+1,counters.1+1,counters.2+1,counters.3+1,counters.4+1));
    let held=host.world().entity(WorldEntityId(2)).unwrap();
    assert_eq!(held.carried_by,Some(actor));assert!(!held.consumed);
    // No direct acquisition or ownership preload. The next ordinary registered
    // transaction must keep the carried target reachable and consume it itself.
    let observed=host.inner.host.grouped_policy_step_observed::<ScriptedJointMechanismPolicy>(&host.inner.founder,0.9).unwrap();
    assert_eq!(observed.world_receipts.len(),1);let d=&observed.step.decisions[0];
    assert_eq!(d.patch.decision().selected_action.action_id.raw(),102);
    let r=host.inner.host.residents.values().next().unwrap();let joint=r.grouped.as_ref().unwrap().joint_episode.as_ref().unwrap();
    let memory=joint.memory().unwrap();assert_eq!(memory.sleep_joint_sources().len(),2);
    assert_eq!(bytes(&memory.sleep_joint_sources()[0]),first_episode);
    // Newly authored cold cue witness control, within the same two intervals.
    let(cue_bytes,cue_anchor)=memory.checkpoint().unwrap();
    let restored=crate::cpu::visible_cue_joint::FreshVisibleCueMemoryV1::restore(&cue_bytes,&cue_anchor).unwrap();
    assert_eq!(restored.checkpoint().unwrap().0,cue_bytes);
    assert_eq!(bytes(&restored.sleep_joint_sources()),bytes(&memory.sleep_joint_sources()));
    let mut changed=cue_anchor.clone();changed.generation+=1;
    assert!(crate::cpu::visible_cue_joint::FreshVisibleCueMemoryV1::restore(&cue_bytes,&changed).is_err());
    // Alter only an observed chemistry vector, even recomputing the outer byte
    // checksum: the original exact episode frame commitment must still reject it.
    fn alter_chemical(v:&mut serde_json::Value)->bool {
        match v {
            serde_json::Value::Object(m)=>{
                if let Some(serde_json::Value::Array(a))=m.get_mut("chemical") {
                    if !a.is_empty(){a[0]=serde_json::json!(0.987654);return true;}
                }
                m.values_mut().any(alter_chemical)
            },
            serde_json::Value::Array(a)=>a.iter_mut().any(alter_chemical),_=>false,
        }
    }
    let mut edited:serde_json::Value=serde_json::from_slice(&cue_bytes).unwrap();
    assert!(alter_chemical(&mut edited),"registered cue witness must be retained for this tamper control");
    let edited=serde_json::to_vec(&edited).unwrap();let mut edited_anchor=cue_anchor.clone();
    edited_anchor.digest=*blake3::hash(&edited).as_bytes();
    assert!(crate::cpu::visible_cue_joint::FreshVisibleCueMemoryV1::restore(&edited,&edited_anchor).is_err());
    let original_frame=d.patch.pre_action().perception();
    let original_bundle=d.patch.selected_bundle().unwrap();
    assert!(original_frame.candidates().len()<=32);
    // Same real sealed event, test-only zero cue storage budget. No extra source
    // or physics; this tests the production over-budget fallback branch.
    let mut degraded=first_memory;
    degraded.observe_without_cue_budget(&d.patch,original_frame).unwrap();
    assert_eq!(bytes(&degraded.sleep_joint_sources()),bytes(&memory.sleep_joint_sources()));
    let(db,da)=degraded.checkpoint().unwrap();
    let degraded_cold=crate::cpu::visible_cue_joint::FreshVisibleCueMemoryV1::restore(&db,&da).unwrap();
    assert_eq!(degraded_cold.checkpoint().unwrap().0,db);
    let targets=original_frame.candidates().iter().filter(|c|c.action_id.raw()==210&&c.target.entity==Some(WorldEntityId(5))).collect::<Vec<_>>();
    assert!(targets.len()<=1);
    let transfer=if let Some(candidate)=targets.first(){
        let mut proposed=original_bundle.clone();
        let command=proposed.channels.iter_mut().find(|c|c.channel==MotorChannel::Manipulation).unwrap();
        command.target=Some(candidate.target);command.direction=candidate.target.position.unwrap_or(Vec3f::ZERO);
        let reason_report=memory.diagnose_two_sources(&[(1,acquired.step.decisions[0].patch.pre_action().perception()),(2,original_frame)],original_frame,&proposed).unwrap();
        let graded=memory.expected_graded_joint_value(&proposed,original_frame).unwrap();
        println!("GRADED_CUE_DIAGNOSTIC {}",serde_json::json!({"reason_report":reason_report,"graded_joint_value":graded,"future_consumption":"Unknown"}));
        let exact_result=memory.expected_whole_event(original_frame,&proposed,crate::cpu::visible_cue_joint::LookupModeV1::ExactIdentityControl);
        let exact_error=exact_result.as_ref().err().map(|e|format!("{e:?}"));let exact=exact_result.ok().flatten();
        let cue_result=memory.expected_whole_event(original_frame,&proposed,crate::cpu::visible_cue_joint::LookupModeV1::ExecutorEntityRoutesV2);
        let cue_error=cue_result.as_ref().err().map(|e|format!("{e:?}"));let cue=cue_result.ok().flatten();
        serde_json::json!({"candidate_present":true,"exact_error":exact_error,"cue_error":cue_error,"exact_sequences":exact.as_ref().map(|e|&e.source_sequences),
            "cue_sequences":cue.as_ref().map(|e|&e.source_sequences),"cue_valence":cue.as_ref().map(|e|e.expected_joint_valence),
            "meal_matched":cue.as_ref().is_some_and(|e|e.source_sequences.contains(&2)),"future_consumption":"Unknown"})
    }else{serde_json::json!({"candidate_present":false,"meal_matched":false,"reason":"second root not in actual observed support"})};
    println!("CUE_HISTORICAL_SECOND_TARGET {}",transfer);

    assert_eq!(memory.recall_joint(original_bundle,original_frame).unwrap().len(),
        restored.recall_joint(original_bundle,original_frame).unwrap().len());
    let e=&memory.sleep_joint_sources()[1];
    assert!(observed.world_receipts[0].grip_transfers.iter().any(|t|t.kind==GripTransferKind::Consumed
        && t.object==WorldEntityId(2) && t.previous_owner==Some(actor) && t.new_owner.is_none()));
    assert_eq!(e.consumed.as_ref().unwrap().target,WorldEntityId(2));
    // Pure public-route witness on the EXACT original source draft; no new forward.
    let source_frame=d.patch.pre_action().perception();
    let source_draft=PerceptionFrameDraft::new(source_frame.organism_id(),source_frame.tick(),source_frame.sensor_profile(),
        source_frame.sensory().clone(),source_frame.body(),source_frame.homeostasis().clone(),
        source_frame.candidates().to_vec(),source_frame.profile_provenance(),source_frame.grounded_object_slots().to_vec()).unwrap();
    assert_eq!(source_draft.base_digest(),source_frame.base_digest());
    assert_eq!(source_draft.clone().finalize(source_frame.context().clone()).unwrap(),*source_frame);
    let selected_food=source_frame.candidates().iter().filter(|c|c.action_id.raw()==210
        && c.target.entity==Some(WorldEntityId(2))).collect::<Vec<_>>();
    assert_eq!(selected_food.len(),1);
    let public_query=alife_core::MemoryQueryEncoderV2::encode_candidate(&source_draft,selected_food[0]).unwrap();
    assert_eq!(bytes(&e.consumed.as_ref().unwrap().query),bytes(&public_query));
    assert_eq!(e.consumed.as_ref().unwrap().query,public_query);

    assert!(e.channel_receipts.iter().any(|r|r.channel==MotorChannel::Locomotion
        && r.physical.contact==PhysicalContactKind::Moved && r.physical.target_entity==Some(WorldEntityId(4))));
    assert_eq!(e.channel_receipts,d.patch.outcome().joint.as_ref().unwrap().channel_outcomes);
    let archive=r.memory.export_active_bank().unwrap();assert_eq!(archive.last_observed_sequence_id_raw,2);
    assert_eq!(joint.anchor.generation,2);assert_eq!(joint.anchor.last_sequence,2);assert_eq!(frozen(&host),before);
    let after=event_counters(&host);assert_eq!(after,(counters.0+2,counters.1+2,counters.2+2,counters.3+2,counters.4+2));
    assert!(host.checkpoint().is_err(),"test owner must not export as production");
    assert_eq!(serde_json::to_value(&d.action).unwrap()["selection_rule"],"TEST-ONLY-REGISTERED-WORLD-MECHANISM");
}
