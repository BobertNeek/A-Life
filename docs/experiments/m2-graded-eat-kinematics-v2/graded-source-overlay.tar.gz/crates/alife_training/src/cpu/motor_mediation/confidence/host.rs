//! Host-only continuation of the actual resident source tape. No source banks,
//! dendrites, synaptic parameters, optimizer, or detached owner live here.
use super::*;
use crate::cpu::replay::Tape;

const HOST_SCHEMA: &str = "grouped-m2-host-appendage-v1-confidence-v2-learning-closed";
pub const GROUPED_HOST_WORK_POLICY_V1: &str =
    "source-once;460-native-cells;814-fixed-rows;group-source-effective;native-semantic-work-v1;host-bookkeeping-unpriced";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GroupedMotorStateV1 {
    schema: String,
    source_inputs: PhenotypeCompilerInputs,
    source_hash: PhenotypeHash,
    mode: MediationModeV1,
    m2_recipe: String,
    group_recipe: String,
    work_policy: String,
    generation: u64,
    activations: Vec<f32>,
    ema: Vec<f32>,
    metabolic: Vec<f32>,
    group_activations: [f32; 16],
    group_ema: [f32; 16],
    group_metabolic: [f32; 16],
    pub last_receipt: Option<GroupedMotorReceiptV1>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GroupedMotorReceiptV1 {
    pub tick: Tick,
    pub frame_digest: PerceptionFrameDigest,
    pub native: RecoveryGroupNativeReceiptV2,
    pub raw_memory: Vec<f32>,
    pub raw_cognitive: Vec<f32>,
    pub reservation_q24: u64,
    pub reservation_q16: u32,
    pub available_atp_q16: u32,
    pub applied_body_energy_debit: f32,
}
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GroupedAppendWorkV1 {
    pub neuron_updates: u64,
    pub synapse_products: u64,
    pub other_work: u64,
    pub reservation_q24: u64,
}
impl GroupedMotorStateV1 {
    pub(crate) fn fresh(
        inputs: &PhenotypeCompilerInputs,
        source: &BrainPhenotype,
        mode: MediationModeV1,
    ) -> Result<Self, TrainingError> {
        let state = Self {
            schema: HOST_SCHEMA.into(),
            source_inputs: inputs.clone(),
            source_hash: source.phenotype_hash(),
            mode,
            m2_recipe: M2_RECIPE_SHA256.into(),
            group_recipe: RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256.into(),
            work_policy: GROUPED_HOST_WORK_POLICY_V1.into(),
            generation: 0,
            activations: vec![0.; ADDED],
            ema: vec![0.; ADDED],
            metabolic: vec![0.; ADDED],
            group_activations: [0.; 16],
            group_ema: [0.; 16],
            group_metabolic: [0.; 16],
            last_receipt: None,
        };
        state.validate(source)?;
        Ok(state)
    }
    pub(crate) fn matches(&self, inputs: &PhenotypeCompilerInputs, mode: MediationModeV1) -> bool {
        self.source_inputs == *inputs && self.mode == mode
    }
    pub(crate) fn validate(&self, source: &BrainPhenotype) -> Result<(), TrainingError> {
        let expected = PhenotypeCompiler::compile_validated(
            &self.source_inputs,
            &BrainCapacityClass::n2048_grounded_drive_research(),
        )?;
        if self.schema != HOST_SCHEMA
            || self.work_policy != GROUPED_HOST_WORK_POLICY_V1
            || self.m2_recipe != M2_RECIPE_SHA256
            || self.group_recipe != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
            || self.mode == MediationModeV1::DirectSource
            || expected != *source
            || self.source_hash != source.phenotype_hash()
            || source.neuron_count() != 2048
            || source.synapses().len() != 34048
            || source.foundation_abi().motor_lobe_m0().is_some()
            || !source
                .candidate_decoder()
                .factorized_motor_channels(source)?
                .contains(&MotorChannel::Posture)
        {
            return Err(invalid());
        }
        Lowered::pinned(MANIFEST)?;
        Self::group_recipe()?;
        for (bank, count, bounded) in [
            (self.activations.as_slice(), ADDED, false),
            (self.ema.as_slice(), ADDED, true),
            (self.metabolic.as_slice(), ADDED, true),
            (self.group_activations.as_slice(), 16, false),
            (self.group_ema.as_slice(), 16, true),
            (self.group_metabolic.as_slice(), 16, true),
        ] {
            if bank.len() != count
                || bank
                    .iter()
                    .any(|x| !x.is_finite() || (bounded && !(0. ..=1.).contains(x)))
            {
                return Err(invalid());
            }
        }
        match &self.last_receipt {
            None if self.generation == 0 => (),
            Some(r) if self.generation > 0 => {
                let core = &r.native.core;
                if core.source_hash != self.source_hash
                    || core.mode != self.mode
                    || core.final_generation != self.generation
                    || core.source_generation.checked_add(1) != Some(self.generation)
                    || core.source_execution_count != 1
                    || core.appended_activations != self.activations
                    || r.native.extension_activations != self.group_activations
                    || r.native.schema != HOST_SCHEMA
                    || r.native.recipe != self.group_recipe
                    || core.schema != HOST_SCHEMA
                    || core.recipe != self.m2_recipe
                    || r.raw_memory.len() != core.components.len()
                    || r.raw_cognitive.len() != core.components.len()
                    || core.work != MediationWorkV1::expected()
                    || !r.applied_body_energy_debit.is_finite()
                    || r.applied_body_energy_debit < 0.
                {
                    return Err(invalid());
                }
                finite(&r.raw_memory)?;
                finite(&r.raw_cognitive)?;
                r.native.scores.validate_host_identity(
                    self.source_hash,
                    r.frame_digest,
                    core.source_generation,
                )?;
            }
            _ => return Err(invalid()),
        }
        Ok(())
    }
    fn group_recipe() -> Result<GroupRecipe, TrainingError> {
        if format!("{:x}", Sha256::digest(GROUP_RECIPE.as_bytes()))
            != RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256
        {
            return Err(invalid());
        }
        let recipe: GroupRecipe = serde_json::from_str(GROUP_RECIPE).map_err(|_| invalid())?;
        if recipe.operation_final_readouts != [[8., -8.]; 2]
            || recipe.nodes.len() != 16
            || recipe
                .nodes
                .iter()
                .enumerate()
                .any(|(i, n)| n.id != 2492 + i || n.phase != if i < 10 { 5 } else { 6 })
        {
            return Err(invalid());
        }
        Ok(recipe)
    }
    pub(crate) fn append_work(
        source: &BrainPhenotype,
    ) -> Result<GroupedAppendWorkV1, TrainingError> {
        let common_products = source.synapses().iter().filter(|s| matches!(s.kind(),CompiledSynapseKind::Decoder(d) if d.family()==CandidateActionFamily::Rest && d.head()==DecoderHeadKind::ActionCandidate)).count() as u64;
        // Exact native semantic work, including padded absent candidates and
        // the extra common drive/source readout. Host validation, sampler and
        // serialization overhead remains unpriced as in the ordinary/M1 host;
        // it is not biological neural/dendritic work. No dense decoder Jacobian
        // or synaptic-learning operation is executed in this mode.
        let arithmetic = MediationWorkV1::expected()
            .cost_q24()?
            .checked_add(1016)
            .and_then(|x| x.checked_add(4 * common_products))
            .ok_or_else(invalid)?;
        Ok(GroupedAppendWorkV1 {
            neuron_updates: 460,
            synapse_products: 640 + 1920 + 64 + 44 + 6 + 60 + common_products,
            other_work: 36 + 72 + 460,
            reservation_q24: arithmetic,
        })
    }
    pub(crate) fn work(
        source: &BrainPhenotype,
        base: &BrainWorkCounters,
        dynamic_q24: u64,
        available_q16: u32,
    ) -> Result<(u64, u32, bool), TrainingError> {
        let policy = BrainActivityPolicyV1::for_phenotype(source).cost;
        let total = policy
            .neural_cost_q24(base)?
            .checked_add(dynamic_q24)
            .and_then(|n| n.checked_add(Self::append_work(source).ok()?.reservation_q24))
            .ok_or_else(invalid)?;
        let debit = policy.q24_to_atp_q16_round_half_up(total)?;
        Ok((total, debit, available_q16 >= debit))
    }
    #[allow(clippy::too_many_arguments)]
    pub(in crate::cpu) fn forward(
        &mut self,
        source: &BrainPhenotype,
        weights: &[f32],
        q: &TrainingSequence,
        frame: &PerceptionFrame,
        receptors: &NeuralReceptorFrame,
        effects: &NeuralReceptorEffects,
        effectors: [bool; 6],
        attempt_mask: u32,
    ) -> Result<Tape, TrainingError> {
        self.validate(source)?;
        q.validate_for(source)?;
        receptors.validate_contract()?;
        if q.ticks.len() != 1
            || q.ticks[0].microstep_count == 0
            || *effects
                != NeuralReceptorEffects::from_frame(
                    receptors,
                    &NeuralReceptorPhenotype::compile(source)?,
                )?
            || effects.source_tick != frame.tick()
            || frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1
            || q.initial
                .dendrites
                .branches()
                .iter()
                .any(|b| b.target >= 2048 || b.inputs.iter().any(|i| i.source >= 2048))
            || q.ticks[0].structural_synapses.iter().any(|e| {
                e.source >= 2048
                    || e.target >= 2048
                    || e.route as usize >= source.projections().len()
            })
        {
            return Err(invalid());
        }
        let t = &q.ticks[0];
        if t.candidates.len() != frame.candidates().len() || t.candidates.len() > SLOTS {
            return Err(invalid());
        }
        let binding =
            RecoveryGroupBindingV2::bind(source, frame, attempt_mask, effectors, self.generation)?;
        let rows = t
            .candidates
            .iter()
            .enumerate()
            .map(|(i, c)| {
                let family = source
                    .candidate_decoder()
                    .families()
                    .iter()
                    .find(|f| f.family() == c.family)
                    .ok_or_else(invalid)?;
                if c.innate_bias.to_bits()
                    != family
                        .innate_contribution(
                            frame.homeostasis().drives,
                            frame.candidates()[i].features,
                        )
                        .to_bits()
                {
                    return Err(invalid());
                }
                MediationRowV1::bind(frame, i, c, self.generation, self.source_hash)
            })
            .collect::<Result<Vec<_>, TrainingError>>()?;
        let m = MediationModulationV1 {
            interoceptive_gain: effects.interoceptive_gain,
            regional_gain: effects.regional_excitability,
            projection_gain: effects.projection_gain,
            threshold: effects.local_threshold_shift,
            offset: ((effects.structural_growth_gate
                + effects.sleep_gate
                + effects.consolidation_gate)
                / 3.
                - 0.5)
                * 0.05,
        };
        m.validate()?;
        // THE ONLY source execution. Current recurrent banks, acquired dendrites,
        // frozen structural rows and effective lifetime+alpha*fast are in q.
        let tape = SparseGraph::new(source).forward_mediation_source(source, weights, q)?;
        let mut next = self.clone();
        let mut drives = [0.; 12];
        drives[..11].copy_from_slice(&frame.homeostasis().drives.to_array());
        drives[11] = frame.homeostasis().hormones.to_array()[8];
        let mut components = t
            .candidates
            .iter()
            .enumerate()
            .map(|(i, c)| {
                [
                    tape.mediation_source[0][i],
                    c.innate_bias,
                    tape.memory[0][i].clamp(-q.memory_candidate_gain, q.memory_candidate_gain),
                    tape.cognitive[0][i].clamp(-q.memory_candidate_gain, q.memory_candidate_gain),
                    0.,
                ]
            })
            .collect::<Vec<_>>();
        let recipe = Lowered::pinned(MANIFEST)?;
        let mut core = run_partition_banks(
            &recipe,
            self.mode,
            self.source_hash,
            &mut next.activations,
            &mut next.ema,
            &mut next.metabolic,
            &mut components,
            &t.candidates,
            drives,
            self.source_inputs
                .genome()
                .cognitive_architecture()
                .sleep_trigger_threshold(),
            m,
        )?;
        core.schema = HOST_SCHEMA.into();
        core.recipe = M2_RECIPE_SHA256.into();
        core.source_generation = self.generation;
        core.final_generation = self.generation.checked_add(1).ok_or_else(invalid)?;
        core.rows = rows;
        core.direct_source_logits = tape.evaluation.candidate_logits[0].clone();
        core.upstream_context_slopes = (0..t.candidates.len())
            .map(|i| {
                [
                    clip_slope(tape.memory[0][i], q.memory_candidate_gain),
                    clip_slope(tape.cognitive[0][i], q.memory_candidate_gain),
                ]
            })
            .collect();
        core.output_logits = core.core_logits.clone();
        core.source_execution_count = 1;
        let canonical =
            CandidateFeatureVector::zero().with_intrinsic_action_basis(ActionKind::Rest);
        let mut input = [0.; 54];
        input[..24].copy_from_slice(&canonical.0);
        let family = source
            .candidate_decoder()
            .families()
            .iter()
            .find(|f| f.family() == CandidateActionFamily::Rest)
            .ok_or_else(invalid)?;
        // Common M/C have no producer. Physical M/C above retain the ACTUAL raw
        // tape sums and their clamp slopes, independently for each operation.
        let mut common = [
            family.bias(),
            family.innate_contribution(frame.homeostasis().drives, canonical),
            0.,
            0.,
            0.,
        ];
        let activation = &tape.evaluation.final_activations[0];
        let mut source_products = 0;
        for (j, s) in source.synapses().iter().enumerate() {
            if let CompiledSynapseKind::Decoder(d) = s.kind() {
                if d.family() == CandidateActionFamily::Rest
                    && d.head() == DecoderHeadKind::ActionCandidate
                {
                    common[0] += activation[s.source() as usize]
                        * (input[d.input_lane() as usize]
                            * (weights[j] + t.effective_weight_offsets[j]));
                    source_products += 1;
                }
            }
        }
        let virtual_candidate = TrainingReplayCandidate {
            family: CandidateActionFamily::Rest,
            decoder_inputs: input,
            innate_bias: common[1],
        };
        for r in &recipe.manifest.drive_proposal_readouts {
            common[4] += core.appended_activations[r.source - START]
                * (cue(r, &virtual_candidate) * r.weight);
        }
        let (group, group_jac, operations, op_jac, pressure_jac) = extension_forward_banks(
            &Self::group_recipe()?,
            &mut next.group_activations,
            &mut next.group_ema,
            &mut next.group_metabolic,
            &core,
            &binding,
            common,
            m,
        )?;
        let scores = RecoveryGroupScoresV2 {
            binding,
            ordinary: core.core_logits.iter().map(|&x| f64::from(x)).collect(),
            group: f64::from(group),
            operations: operations.map(f64::from),
        };
        scores.validate()?;
        next.generation = core.final_generation;
        next.last_receipt = Some(GroupedMotorReceiptV1 {
            tick: frame.tick(),
            frame_digest: frame.frame_digest(),
            native: RecoveryGroupNativeReceiptV2 {
                schema: HOST_SCHEMA.into(),
                recipe: RECOVERY_GROUP_CONFIDENCE_RECIPE_SHA256.into(),
                core,
                group_components: common,
                group_jacobian: group_jac,
                operation_context_jacobians: op_jac,
                operation_pressure_jacobians: pressure_jac,
                extension_activations: next.group_activations,
                extension_source_products: source_products,
                extension_arithmetic_q24: 1016 + 4 * source_products,
                scores,
            },
            raw_memory: tape.memory[0].clone(),
            raw_cognitive: tape.cognitive[0].clone(),
            reservation_q24: 0,
            reservation_q16: 0,
            available_atp_q16: 0,
            applied_body_energy_debit: 0.,
        });
        *self = next;
        Ok(tape)
    }
}

#[cfg(any())]
mod tests;
