//! Distinct joint episodic policy over the qualified Optional-Quiet support.
//! Original optional RNG evaluator remains literal and cannot accept these actions.
use super::*;
use alife_core::{EpisodicRetrievalContextV1, MotorCommandBundle, MotorChannel, ExperienceSequenceId, UtteranceSourceKind, factorized_motor_bundle_for_candidates};
use alife_joint_episode::joint_episode::JointEpisodeAnchorV1;
use crate::cpu::visible_cue_joint::FreshVisibleCueMemoryV1 as JointEpisodeMemoryV1;
pub const JOINT_OPTIONAL_POLICY_V2: &str = "m2-graded-cue-joint-episode-optional-v1;quiet-preserved;full-joint-association;closed;no-gradient";
pub const JOINT_OPTIONAL_SUPPORT_CAP_V2: usize = 65_536;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JointOptionalScoresV2 {
    policy: String,
    base: OptionalVocalScoresV1,
    frame: PerceptionFrame,
    channels: Vec<MotorChannel>,
    sequence: ExperienceSequenceId,
    memory_bytes: Vec<u8>,
    memory_anchor: JointEpisodeAnchorV1,
    episodic_context: EpisodicRetrievalContextV1,
    #[cfg(test)]
    #[serde(default, skip_serializing_if = "Option::is_none")]
    scripted_mechanism: Option<[WorldEntityId;3]>,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JointOptionalActionV2 {
    policy: String,
    selection_rule: String,
    binding: [u8; 32],
    representative: OptionalVocalChoiceV1,
    motors: [OptionalVocalChoiceV1; 6],
    operation: Option<u8>,
    temperature_bits: u64,
    base_log_probability_bits: u64,
    joint_log_probability_bits: u64,
    bundle_log_probability_bits: u64,
    potential_bits: u64,
    support_digest: [u8; 32],
    support_count: usize,
    selected_index: usize,
    seed: u32,
    counter: u32,
}
impl JointOptionalActionV2 {
    pub fn seed(&self) -> u32 { self.seed }
    pub fn counter(&self) -> u32 { self.counter }
    pub fn temperature(&self) -> f64 { f64::from_bits(self.temperature_bits) }
    pub fn operation(&self) -> Option<u8> { self.operation }
    pub fn motors(&self) -> [OptionalVocalChoiceV1; 6] { self.motors }
    pub fn joint_log_probability(&self) -> f64 { f64::from_bits(self.joint_log_probability_bits) }
    pub fn bundle_log_probability(&self) -> f64 { f64::from_bits(self.bundle_log_probability_bits) }
    pub fn base_log_probability(&self) -> f64 { f64::from_bits(self.base_log_probability_bits) }
}
struct Row {
    representative: OptionalVocalChoiceV1,
    motors: [OptionalVocalChoiceV1; 6],
    operation: Option<u8>,
    base: f64,
    potential: f64,
    log_mass: f64,
    bundle: [u64; 4],
}
impl JointOptionalScoresV2 {
    #[allow(clippy::too_many_arguments)]
    pub(in crate::cpu) fn bind(p: &BrainPhenotype, frame: &PerceptionFrame,
        native: &RecoveryGroupScoresV2, source: OptionalVocalSourceV1,
        sequence: ExperienceSequenceId, memory: &JointEpisodeMemoryV1,
        episodic_context: EpisodicRetrievalContextV1) -> Result<Self, TrainingError> {
        let base = OptionalVocalScoresV1::bind(p, frame, native, source)?;
        let (memory_bytes, memory_anchor) = memory.checkpoint()?;
        let result = Self { policy: JOINT_OPTIONAL_POLICY_V2.into(), base,
            frame: frame.clone(), channels: p.candidate_decoder().factorized_motor_channels(p)?,
            sequence, memory_bytes, memory_anchor, episodic_context,
            #[cfg(test)] scripted_mechanism: None };
        result.validate()?;
        // Full Optional-Quiet support, including any actual source payload removal.
        result.support_count(1.)?;
        Ok(result)
    }
    pub(in crate::cpu) fn is_scripted_mechanism(&self) -> bool {
        #[cfg(test)] { return self.scripted_mechanism.is_some(); }
        #[cfg(not(test))] { false }
    }
    #[cfg(test)]
    pub(in crate::cpu) fn with_scripted_mechanism(mut self, targets:[WorldEntityId;3]) -> Result<Self,TrainingError> {
        for t in targets { t.validate()?; }
        self.scripted_mechanism=Some(targets); self.validate()?; Ok(self)
    }
    fn validate(&self) -> Result<(), TrainingError> {
        self.base.validate()?;
        self.frame.validate_contract()?;
        self.sequence.validate()?;
        self.episodic_context.validate_contract()?;
        if self.policy != JOINT_OPTIONAL_POLICY_V2 || self.frame.frame_digest() != self.base.source.frame
            || self.frame.organism_id() != self.memory_anchor.organism
            || self.base.source.source != self.memory_anchor.phenotype
            || self.memory_anchor.last_sequence.checked_add(1) != Some(self.sequence.raw())
            || self.episodic_context.to_perception_context_block()? != *self.frame.context()
            || self.episodic_context.candidates.iter().any(|c| c.family_source_count!=0 || c.target_source_count!=0
                || c.best_family_source.is_some() || c.best_target_source.is_some()
                || c.family_confidence.raw()!=0. || c.target_confidence.raw()!=0.
                || c.family_value.iter().chain(c.target_latent.iter()).any(|x| *x!=0.)) {
            return Err(invalid());
        }
        JointEpisodeMemoryV1::restore(&self.memory_bytes, &self.memory_anchor)?;
        Ok(())
    }
    pub(in crate::cpu) fn validate_source(&self, source: &OptionalVocalSourceV1) -> Result<(), TrainingError> {
        self.validate()?; self.base.validate_source(source)
    }
    pub(in crate::cpu) fn validate_native(&self, native: &RecoveryGroupScoresV2) -> Result<(), TrainingError> {
        self.validate()?; self.base.validate_native(native)
    }
    pub fn source(&self) -> &OptionalVocalSourceV1 { self.base.source() }
    pub(in crate::cpu) fn prior_anchor(&self) -> &JointEpisodeAnchorV1 { &self.memory_anchor }
    pub fn base_probabilities(&self, t: f64) -> Result<OptionalVocalProbabilitiesV1, TrainingError> {
        self.validate()?; self.base.probabilities(t)
    }
    pub fn support_count(&self, t: f64) -> Result<usize, TrainingError> {
        self.validate()?;
        let d = self.base.probabilities(t)?;
        let operations = self.base.native_binding.operation_mask().iter().filter(|x| **x).count();
        let mut count=0usize;
        for rep in &d.representative.outcomes {
            let forced=self.base.forced(*rep);
            let mut total=1usize;
            let mut no_rest=usize::from(*rep!=OptionalVocalChoiceV1::RestGroup);
            for s in 0..6 {
                let choices=if forced==Some(s) { vec![*rep] } else {
                    d.channels[s].as_ref().map_or(vec![OptionalVocalChoiceV1::NoOp],|f|f.outcomes.clone()) };
                total=total.checked_mul(choices.len()).ok_or_else(invalid)?;
                no_rest=no_rest.checked_mul(choices.iter().filter(|c|**c!=OptionalVocalChoiceV1::RestGroup).count()).ok_or_else(invalid)?;
            }
            count=count.checked_add(no_rest).and_then(|n|(total-no_rest).checked_mul(operations).and_then(|m|n.checked_add(m))).ok_or_else(invalid)?;
            if count>JOINT_OPTIONAL_SUPPORT_CAP_V2 { return Err(invalid()); }
        }
        if count==0 { return Err(invalid()); } Ok(count)
    }
    fn resolve(&self, rep: OptionalVocalChoiceV1, motors: [OptionalVocalChoiceV1;6], operation:Option<u8>)
        ->Result<(u16,[Option<u16>;6]),TrainingError> {
        let index=self.base.resolve(rep,operation)?.ok_or_else(invalid)?;
        let mut slots=[None;6];
        for (slot,choice) in slots.iter_mut().zip(motors) { *slot=self.base.resolve(choice,operation)?; }
        Ok((index,slots))
    }
    fn bundle(&self, rep:OptionalVocalChoiceV1, motors:[OptionalVocalChoiceV1;6], operation:Option<u8>)
        ->Result<MotorCommandBundle,TrainingError> {
        let (index,slots)=self.resolve(rep,motors,operation)?;
        let candidate=&self.frame.candidates()[usize::from(index)];
        let confidence=Confidence::new((candidate.sensor_confidence.raw()*65535.).round()/65535.)?;
        let command=candidate.to_command(self.frame.organism_id(),confidence)?;
        let speech=if slots[3].is_some(){self.base.source().speech()?}else{None};
        let prompted=self.frame.sensory().language_context.heard_tokens.iter().flatten()
            .any(|t|t.source_kind==UtteranceSourceKind::Player);
        Ok(factorized_motor_bundle_for_candidates(self.frame.organism_id(),self.sequence,self.frame.tick(),
            &self.frame,slots.map(|i|i.map_or(0,|i|i+1)),&self.channels,&command,index,speech.as_ref(),prompted)?)
    }
    fn rows(&self,t:f64)->Result<Vec<Row>,TrainingError> {
        let expected=self.support_count(t)?;
        let d=self.base.probabilities(t)?;
        let memory=JointEpisodeMemoryV1::restore(&self.memory_bytes,&self.memory_anchor)?;
        let mut rows=Vec::with_capacity(expected);
        for &representative in &d.representative.outcomes {
            let forced=self.base.forced(representative);
            let mut products=vec![[OptionalVocalChoiceV1::NoOp;6]];
            for s in 0..6 {
                let choices=if forced==Some(s){vec![representative]}else{
                    d.channels[s].as_ref().map_or(vec![OptionalVocalChoiceV1::NoOp],|f|f.outcomes.clone())};
                let mut next=Vec::new();
                for row in products {for &c in &choices {let mut n=row;n[s]=c;next.push(n);}}
                products=next;
            }
            for motors in products {
                let rest=representative==OptionalVocalChoiceV1::RestGroup || motors.contains(&OptionalVocalChoiceV1::RestGroup);
                let operations=if rest {self.base.native_binding.operation_mask().iter().enumerate()
                    .filter(|(_,e)|**e).map(|(i,_)|Some(i as u8)).collect::<Vec<_>>()}else{vec![None]};
                for operation in operations {
                    let mut base=d.representative.logp(representative)?;
                    for s in 0..6 {if forced!=Some(s){if let Some(f)=&d.channels[s]{base+=f.logp(motors[s])?;}}}
                    if let Some(o)=operation{base+=d.conditional_log_probability[usize::from(o)].ok_or_else(invalid)?;}
                    let bundle=self.bundle(representative,motors,operation)?;
                    let potential=f64::from(memory.expected_graded_joint_value(&bundle,&self.frame)?.unwrap_or(0.));
                    rows.push(Row{representative,motors,operation,base,potential,log_mass:base+potential,bundle:bundle.canonical_digest()?});
                }
            }
        }
        if rows.len()!=expected || (rows.iter().map(|r|r.base.exp()).sum::<f64>()-1.).abs()>1e-8{return Err(invalid());}
        Ok(rows)
    }
    pub fn sample(&self,seed:u32,counter:u32,t:f64)->Result<JointOptionalActionV2,TrainingError> {
        let rows=self.rows(t)?;
        let max=rows.iter().map(|r|r.log_mass).fold(f64::NEG_INFINITY,f64::max);
        let z=max+rows.iter().map(|r|(r.log_mass-max).exp()).sum::<f64>().ln();
        let mut hash=Sha256::new();hash.update(JOINT_OPTIONAL_POLICY_V2.as_bytes());
        for r in &rows {hash.update(serde_json::to_vec(&(r.representative,r.motors,r.operation,r.base.to_bits(),r.potential.to_bits(),r.bundle)).map_err(|_|invalid())?);}
        let u=optional_draw(seed^0x4a45_5032,counter,0x4a45_5032);
        let mut sum=0.;let mut selected=rows.len()-1;
        for (i,r) in rows.iter().enumerate(){sum+=(r.log_mass-z).exp();if u<sum{selected=i;break;}}
        #[cfg(test)]
        if let Some([food, other, inspected]) = self.scripted_mechanism {
            let matches = |choice:OptionalVocalChoiceV1, primitive:u32, target:WorldEntityId| {
                if let OptionalVocalChoiceV1::Candidate(i)=choice {
                    let c=&self.frame.candidates()[usize::from(i)]; c.action_id.raw()==primitive && c.target.entity==Some(target)
                } else {false}
            };
            let matching=rows.iter().enumerate().filter(|(_,r)|matches(r.representative,102,other)
                && matches(r.motors[0],102,other) && matches(r.motors[2],210,food)
                && matches(r.motors[4],4,inspected) && r.motors[3]==OptionalVocalChoiceV1::Quiet
                && r.operation.is_none()).map(|(i,_)|i).collect::<Vec<_>>();
            if matching.len()!=1 {return Err(invalid());}
            selected=matching[0];
        }
        let r=&rows[selected];
        let bundle_mass=rows.iter().filter(|x|x.bundle==r.bundle).map(|x|(x.log_mass-z).exp()).sum::<f64>();
        if !bundle_mass.is_finite() || bundle_mass<=0. {return Err(invalid());}
        let scripted=self.is_scripted_mechanism();
        Ok(JointOptionalActionV2{policy:JOINT_OPTIONAL_POLICY_V2.into(),
            selection_rule:if scripted {"TEST-ONLY-REGISTERED-WORLD-MECHANISM"}else{"AUTONOMOUS-JOINT-RNG"}.into(),binding:Sha256::digest(serde_json::to_vec(self).map_err(|_|invalid())?).into(),
            representative:r.representative,motors:r.motors,operation:r.operation,temperature_bits:t.to_bits(),
            base_log_probability_bits:r.base.to_bits(),joint_log_probability_bits:(if scripted {0_f64}else{r.log_mass-z}).to_bits(),
            bundle_log_probability_bits:(if scripted {0_f64}else{bundle_mass.ln()}).to_bits(),potential_bits:r.potential.to_bits(),support_digest:hash.finalize().into(),
            support_count:rows.len(),selected_index:selected,seed,counter})
    }
    pub fn validate_sampling_context(&self,a:&JointOptionalActionV2,seed:u32,counter:u32,t:f64)->Result<(),TrainingError>{
        if a.seed!=seed || a.counter!=counter || a.temperature_bits!=t.to_bits() || *a!=self.sample(seed,counter,t)?{return Err(invalid());}Ok(())
    }
    pub fn physical_selection(&self,a:&JointOptionalActionV2)->Result<(u16,[Option<u16>;6]),TrainingError>{
        self.validate_sampling_context(a,a.seed,a.counter,a.temperature())?;
        self.resolve(a.representative,a.motors,a.operation)
    }
}
