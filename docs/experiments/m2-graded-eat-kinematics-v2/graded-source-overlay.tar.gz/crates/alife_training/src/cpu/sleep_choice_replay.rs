//! A distinct, frame-bound 55-lane ABI. The ordinary 54-lane replay wire is untouched.
use super::{finite, invalid};
use crate::{TrainingError, TrainingReplayCandidate};
use alife_core::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SleepChoiceReplayRowV1 {
    schema: u16,
    selector: u16,
    profile: u16,
    frame_digest: PerceptionFrameDigest,
    candidate_index: u32,
    action_id: ActionId,
    operation: Option<RecoveryOperationV1>,
    prefix: TrainingReplayCandidate,
    recovery_sign: f32,
}
impl SleepChoiceReplayRowV1 {
    pub fn bind(
        frame: &PerceptionFrame,
        index: usize,
        prefix: &TrainingReplayCandidate,
    ) -> Result<Self, TrainingError> {
        if frame.sensor_profile() != SensorProfile::GroundedObjectSlotsSleepChoiceV1 {
            return Err(invalid());
        }
        let candidate = frame.candidates().get(index).ok_or_else(invalid)?;
        if prefix.family != candidate.family {
            return Err(invalid());
        }
        finite(&prefix.decoder_inputs)?;
        if !prefix.innate_bias.is_finite() {
            return Err(invalid());
        }
        let operation = RecoveryOperationV1::for_candidate(candidate)?;
        Ok(Self {
            schema: 1,
            selector: 12,
            profile: 5,
            frame_digest: frame.frame_digest(),
            candidate_index: u32::try_from(index).map_err(|_| invalid())?,
            action_id: candidate.action_id,
            operation,
            prefix: prefix.clone(),
            recovery_sign: operation.map_or(0., RecoveryOperationV1::decoder_sign),
        })
    }
    pub fn validate(
        &self,
        frame: &PerceptionFrame,
        index: usize,
        prefix: &TrainingReplayCandidate,
    ) -> Result<(), TrainingError> {
        let expected = Self::bind(frame, index, prefix)?;
        if self.schema != expected.schema
            || self.selector != expected.selector
            || self.profile != expected.profile
            || self.frame_digest != expected.frame_digest
            || self.candidate_index != expected.candidate_index
            || self.action_id != expected.action_id
            || self.operation != expected.operation
            || self.recovery_sign.to_bits() != expected.recovery_sign.to_bits()
            || self.prefix.family != prefix.family
            || self.prefix.innate_bias.to_bits() != prefix.innate_bias.to_bits()
            || self
                .prefix
                .decoder_inputs
                .iter()
                .zip(prefix.decoder_inputs)
                .any(|(a, b)| a.to_bits() != b.to_bits())
        {
            return Err(invalid());
        }
        Ok(())
    }
    pub fn decoder_inputs(&self) -> [f32; 55] {
        let mut row = [0.; 55];
        row[..54].copy_from_slice(&self.prefix.decoder_inputs);
        row[54] = self.recovery_sign;
        row
    }
    pub(super) fn input(&self, lane: usize) -> Result<f32, TrainingError> {
        if lane == 54 {
            Ok(self.recovery_sign)
        } else {
            self.prefix
                .decoder_inputs
                .get(lane)
                .copied()
                .ok_or_else(invalid)
        }
    }
}

#[cfg(any())]
mod tests {
    use super::*;
    fn frame(profile: SensorProfile, tick: u64) -> PerceptionFrame {
        let tick = Tick::new(tick);
        let candidates = [3, 700]
            .into_iter()
            .enumerate()
            .map(|(i, id)| {
                ActionCandidate::new(
                    i as u16,
                    ActionId(id),
                    ActionKind::Rest,
                    CandidateActionFamily::Rest,
                    CandidateObservationRef::None,
                    ActionTarget::NONE,
                    CandidateFeatureVector::zero().with_intrinsic_action_basis(ActionKind::Rest),
                    Confidence::new(1.).unwrap(),
                    NormalizedScalar::new(0.).unwrap(),
                    DurationTicks::new(1),
                    DurationTicks::new(1),
                )
                .unwrap()
            })
            .collect();
        PerceptionFrame::new(
            OrganismId(1),
            tick,
            profile,
            SensorySnapshot::new(
                OrganismId(1),
                tick,
                Vec3f::ZERO,
                SensoryChannels::ZERO,
                Default::default(),
            )
            .unwrap(),
            BodySnapshot {
                pose: Pose::IDENTITY,
                velocity: Velocity::ZERO,
            },
            HomeostaticSnapshot::baseline(tick),
            candidates,
            SensorProfileProvenance::new(profile, SensoryAbiVersion::CURRENT, tick).unwrap(),
            vec![],
        )
        .unwrap()
    }
    fn prefix() -> TrainingReplayCandidate {
        let mut decoder_inputs = std::array::from_fn(|i| i as f32 / 64.);
        decoder_inputs[53] = -0.;
        TrainingReplayCandidate {
            family: CandidateActionFamily::Rest,
            decoder_inputs,
            innate_bias: 0.25,
        }
    }
    #[test]
    fn sleep_choice_row_preserves_54_bit_prefix_and_lane53() {
        let frame = frame(SensorProfile::GroundedObjectSlotsSleepChoiceV1, 4);
        let prefix = prefix();
        for (i, sign) in [(0, 1.), (1, -1.)] {
            let row = SleepChoiceReplayRowV1::bind(&frame, i, &prefix).unwrap();
            let values = row.decoder_inputs();
            assert!(values[..54]
                .iter()
                .zip(prefix.decoder_inputs)
                .all(|(a, b)| a.to_bits() == b.to_bits()));
            assert_eq!(values[54], sign);
            let bytes = serde_json::to_vec(&row).unwrap();
            let restored: SleepChoiceReplayRowV1 = serde_json::from_slice(&bytes).unwrap();
            restored.validate(&frame, i, &prefix).unwrap();
        }
    }
    #[test]
    fn sleep_choice_row_rejects_wrong_frame_operation_prefix_and_tag() {
        let frame = frame(SensorProfile::GroundedObjectSlotsSleepChoiceV1, 4);
        let prefix = prefix();
        let row = SleepChoiceReplayRowV1::bind(&frame, 0, &prefix).unwrap();
        assert!(row.validate(&frame, 1, &prefix).is_err());
        let mut forged = row.clone();
        forged.recovery_sign = -1.;
        assert!(forged.validate(&frame, 0, &prefix).is_err());
        let mut forged = row.clone();
        forged.selector = 11;
        assert!(forged.validate(&frame, 0, &prefix).is_err());
        let mut changed = prefix.clone();
        changed.decoder_inputs[53] = 0.;
        assert!(row.validate(&frame, 0, &changed).is_err());
        let other = self::frame(SensorProfile::GroundedObjectSlotsSleepChoiceV1, 5);
        assert!(row.validate(&other, 0, &prefix).is_err());
        let ordinary = self::frame(SensorProfile::GroundedObjectSlotsV1, 4);
        assert!(SleepChoiceReplayRowV1::bind(&ordinary, 0, &prefix).is_err());
    }
    #[test]
    fn native55_fixed_context_opponent_causality_and_matched_null() {
        use super::super::replay::SparseGraph;
        use crate::{TrainingInitialState, TrainingReplayTick, TrainingSequence};
        let g = BrainGenome::scaffold(
            0x2048_2026,
            BrainCapacityClass::N2048_GROUNDED_DRIVE_RESEARCH_ID,
        );
        let d = DevelopmentState::new(g.id, Tick::ZERO, NormalizedScalar::new(1.).unwrap());
        let (_, source) = PhenotypeCompiler::compile_n2048_grounded_drive_basis(
            g,
            d,
            SensorProfile::GroundedObjectSlotsV1,
        )
        .unwrap();
        let (p, recipe) = PhenotypeCompiler::compile_sleep_choice_m1(&source).unwrap();
        let graph = SparseGraph::new(&p);
        let weights: Vec<_> = p.synapses().iter().map(|s| s.genetic_weight()).collect();
        let frame = frame(SensorProfile::GroundedObjectSlotsSleepChoiceV1, 4);
        let candidates = vec![prefix(), prefix()];
        let rows: Vec<_> = candidates
            .iter()
            .enumerate()
            .map(|(i, c)| SleepChoiceReplayRowV1::bind(&frame, i, c).unwrap())
            .collect();
        let run = |pressure: f32, gain: f32, offset: f32, threshold: f32, swap: bool| {
            let mut encoded = vec![offset; 2144];
            encoded[2140] = (pressure * gain + offset).clamp(-1., 1.);
            encoded[2141] = (recipe.pressure_reference() * gain + offset).clamp(-1., 1.);
            let q = TrainingSequence {
                phenotype_hash: p.phenotype_hash(),
                initial: TrainingInitialState {
                    activations: vec![0.; 2144],
                    activity_ema: vec![0.; 2144],
                    metabolic_load: vec![0.; 2144],
                    dendrites: recipe.fixed_branches().unwrap(),
                },
                ticks: vec![TrainingReplayTick {
                    encoded_inputs: encoded,
                    projection_gain: 0.5,
                    local_threshold_shift: threshold,
                    microstep_count: u32::from(p.microstep_count()),
                    enabled_routes: vec![true; p.projections().len()],
                    effective_weight_offsets: vec![0.; weights.len()],
                    structural_synapses: vec![],
                    candidates: candidates.clone(),
                }],
                burn_in_ticks: 0,
                memory_candidate_gain: 1.,
            };
            let mut w = weights.clone();
            if swap {
                for x in &mut w[34098..] {
                    *x = -*x;
                }
            }
            assert!(graph.forward(&p, &w, &q).is_err());
            // Exactly one actual native frame from zero state, no settling or padding.
            graph
                .forward_sleep_choice(&p, &w, &q, &frame, &rows)
                .unwrap()
        };
        for gain in [0., 0.5, 1., 4.] {
            for offset in [-0.5, 0., 0.5] {
                for threshold in [-0.5, 0., 0.5] {
                    let tape = run(recipe.pressure_reference(), gain, offset, threshold, false);
                    assert_eq!(tape.sleep_pressure_head[0], [0., 0.]);
                    assert_eq!(
                        tape.evaluation.final_activations[0][2142],
                        tape.evaluation.final_activations[0][2143]
                    );
                }
            }
        }
        for pressure in [0., 1.] {
            let full = run(pressure, 1., 0., 0., false);
            let swap = run(pressure, 1., 0., 0., true);
            assert_eq!(
                full.evaluation.final_activations,
                swap.evaluation.final_activations
            );
            assert_eq!(
                full.sleep_pressure_head[0][0],
                -full.sleep_pressure_head[0][1]
            );
            assert_eq!(
                full.sleep_pressure_head[0][0],
                -swap.sleep_pressure_head[0][0]
            );
            if p.microstep_count() >= 2 {
                assert_eq!(
                    full.sleep_pressure_head[0][0].is_sign_positive(),
                    pressure > recipe.pressure_reference()
                );
                assert_ne!(full.sleep_pressure_head[0][0], 0.);
            }
        }
    }
}
