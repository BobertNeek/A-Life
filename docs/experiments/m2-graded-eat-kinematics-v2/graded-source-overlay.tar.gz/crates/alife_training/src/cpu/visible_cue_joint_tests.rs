//! Authored pure observed-cue contract controls, NOT executed or physical meal evidence.
//! Inputs are validated public profile5 frames/queries. No world-kind/owner oracle.
use super::*;
#[derive(Clone)]
struct Input {ids:[u32;3],chemical:[f32;3],shape:[f32;3],color:[f32;3],temperature:f32,terrain:[f32;2],eat_bearing:Option<[f32;2]>,distance:f32,contact:f32,confidence:f32,pain:f32,missing:bool}
impl Default for Input{fn default()->Self{Self{ids:[71,72,73],chemical:[0.2,0.3,0.4],shape:[0.2,0.4,0.5],color:[0.2,0.5,0.7],temperature:0.4,terrain:[0.2,0.3],eat_bearing:None,distance:0.0625,contact:1.,confidence:0.9,pain:0.,missing:false}}}
fn fixture(input:Input)->Result<(PerceptionFrame,MotorCommandBundle),ScaffoldContractError>{
    let owner=OrganismId(811);let tick=Tick::new(10);let mut unique=Vec::new();
    for id in input.ids{if !unique.contains(&id){unique.push(id);}}
    let slots=unique.iter().enumerate().map(|(i,id)|Ok(GroundedObjectSlotV1{
        slot_index:i as u16,tracked_object_id:TrackedObjectId(u64::from(*id)*10),bearing:if i==1{input.eat_bearing.unwrap_or([0.,1.])}else{[0.,1.]},distance:input.distance,
        relative_velocity:[0.;3],color:input.color,material:[0.1,0.3,0.6],shape:input.shape,
        chemical:input.chemical,contact:input.contact,proprioception:[0.;2],temperature:input.temperature,terrain:input.terrain,
        confidence:Confidence::new(input.confidence)?})).collect::<Result<Vec<_>,ScaffoldContractError>>()?;
    let types=[(102,ActionKind::Move,CandidateActionFamily::Avoid,MotorChannel::Locomotion),
        (210,ActionKind::Interact,CandidateActionFamily::Ingest,MotorChannel::Manipulation),
        (4,ActionKind::Inspect,CandidateActionFamily::Inspect,MotorChannel::Posture)];
    let mut candidates=Vec::new();let mut commands=Vec::new();
    for (i,(id,kind,family,channel))in types.into_iter().enumerate(){
        let slot=unique.iter().position(|id|*id==input.ids[i]).unwrap();let target=ActionTarget::new(Some(WorldEntityId(u64::from(input.ids[i]))),Some(Vec3f::new(input.distance*8.,0.,0.)));
        candidates.push(ActionCandidate::new(i as u16,ActionId(id),kind,family,
            if input.missing{CandidateObservationRef::None}else{CandidateObservationRef::ObjectSlot(slot as u16)},target,
            slots[slot].candidate_features()?,Confidence::new(input.confidence)?,NormalizedScalar::new(0.2)?,DurationTicks::new(1),DurationTicks::new(2))?);
        commands.push(ChannelCommand::new(channel,ActionId(id),Some(target),Vec3f::ZERO,Intensity::new(1.)?,DurationTicks::new(1),0.,Confidence::new(0.8)?,0)?);
    }
    let profile=SensorProfile::GroundedObjectSlotsSleepChoiceV1;let mut home=HomeostaticSnapshot::baseline(tick);home.drives.pain=input.pain;
    let draft=PerceptionFrameDraft::new(owner,tick,profile,SensorySnapshot::new(owner,tick,Vec3f::ZERO,SensoryChannels::ZERO,Default::default())?,
        BodySnapshot{pose:Pose::IDENTITY,velocity:Velocity::ZERO},home,candidates,SensorProfileProvenance::new(profile,SensoryAbiVersion::CURRENT,tick)?,slots)?;
    let bank=MemoryBank::new(MemoryBankConfig::new(8,64,4,0.72,Confidence::new(0.)?)?)?;
    let(frame,_)=bank.recall_frame(&draft)?.finalize(draft)?;
    Ok((frame,MotorCommandBundle::new(owner,ExperienceSequenceId::new(1).ok_or(ScaffoldContractError::InvalidId)?,tick,commands)?))
}
fn context(input:Input)->Result<ObservedJoint,ScaffoldContractError>{let(f,b)=fixture(input)?;ObservedJoint::capture(&f,&b)}
fn newer()->Input{Input{ids:[171,172,173],..Input::default()}}
fn cue(a:&ObservedJoint,b:&ObservedJoint)->bool{a.matches(b,LookupModeV1::VisibleCueRoles,Some(MotorChannel::Manipulation))}
#[cfg(any())]
#[test]
fn same_observed_cues_new_entities_match_whole_joint_context(){assert!(cue(&context(Input::default()).unwrap(),&context(newer()).unwrap()));}
#[cfg(any())]
#[test]
fn exact_identity_control_refuses_new_entities(){let a=context(Input::default()).unwrap();let b=context(newer()).unwrap();assert!(!a.matches(&b,LookupModeV1::ExactIdentityControl,Some(MotorChannel::Manipulation)));assert!(a.matches(&a,LookupModeV1::ExactIdentityControl,Some(MotorChannel::Manipulation)));}
#[cfg(any())]
#[test]
fn public_query_target_features_are_the_only_descriptor(){let(f,b)=fixture(Input::default()).unwrap();let c=ObservedJoint::capture(&f,&b).unwrap();for role in c.roles{let q=role.query.unwrap();let candidate=f.candidates().iter().find(|a|a.action_id==role.command.primitive).unwrap();let CandidateObservationRef::ObjectSlot(i)=candidate.observation else{panic!()};assert_eq!(&q.features()[TARGET_START..TARGET_START+24],f.grounded_object_slots()[i as usize].candidate_features().unwrap().0.as_slice());}}
#[cfg(any())]
#[test]
fn appearance_identical_chemical_changed_refuses_transfer(){let mut b=newer();b.chemical[2]+=0.0001;assert!(!cue(&context(Input::default()).unwrap(),&context(b).unwrap()));}
#[cfg(any())]
#[test]
fn shared_target_role_split_and_merge_are_rejected(){let a=context(Input{ids:[71,71,73],..Input::default()}).unwrap();assert!(cue(&a,&context(Input{ids:[171,171,173],..Input::default()}).unwrap()));let split=context(newer()).unwrap();assert!(!cue(&a,&split));assert!(!cue(&split,&a));}
#[cfg(any())]
#[test]
fn action_operation_intensity_and_duration_changes_are_rejected(){let a=context(Input::default()).unwrap();for kind in 0..4{let mut b=context(newer()).unwrap();let c=&mut b.roles[1].command;match kind{0=>c.primitive=ActionId(211),1=>c.payload=BoundedMotorPayload::new(vec![5]).unwrap(),2=>c.intensity=Intensity::new(0.5).unwrap(),_=>c.duration_ticks=DurationTicks::new(2)};assert!(!cue(&a,&b));}}
#[cfg(any())]
#[test]
fn identical_but_out_of_interaction_range_is_not_enough(){let a=context(Input{distance:0.2,..Input::default()}).unwrap();let b=context(Input{distance:0.2,..newer()}).unwrap();assert!(!cue(&a,&b));}
#[cfg(any())]
#[test]
fn absent_contact_cannot_borrow_consumed_event_expectancy(){let a=context(Input{contact:0.,..Input::default()}).unwrap();let b=context(Input{contact:0.,..newer()}).unwrap();assert!(!cue(&a,&b));}
#[cfg(any())]
#[test]
fn missing_observation_or_low_confidence_is_rejected(){assert!(context(Input{missing:true,..Input::default()}).is_err());assert!(context(Input{confidence:0.4,..Input::default()}).is_err());}
#[cfg(any())]
#[test]
fn invalid_observed_geometry_is_rejected(){assert!(context(Input{distance:f32::NAN,..Input::default()}).is_err());}
#[cfg(any())]
#[test]
fn held_and_loose_observation_equivalents_are_indistinguishable(){
    // Physical heldness is deliberately NOT an input. These are paired equal
    // visible observations, not invented ownership labels or a nutrition promise.
    let held_observation=context(Input::default()).unwrap();let loose_observation=context(newer()).unwrap();
    assert!(cue(&held_observation,&loose_observation));
    let(f,b)=fixture(newer()).unwrap();
    let association=expectation(vec![1],vec![0.08],vec![Some(MotorChannel::Manipulation)],LookupModeV1::VisibleCueRoles,f.frame_digest(),b.canonical_digest().unwrap()).unwrap();
    assert_eq!(association.grip,GripEvidenceV1::Unknown);
    assert_eq!(association.future_consumption,FutureConsumptionV1::Unknown);
    assert_eq!(association.expected_joint_valence,0.08);
}
#[cfg(any())]
#[test]
fn one_drive_crossing_threshold_removes_match(){let a=context(Input::default()).unwrap();assert!(cue(&a,&context(Input{pain:0.149,..newer()}).unwrap()));assert!(!cue(&a,&context(Input{pain:0.151,..newer()}).unwrap()));}
#[cfg(any())]
#[test]
fn channel_order_does_not_change_role_graph(){let(f,mut b)=fixture(newer()).unwrap();b.channels.reverse();assert!(cue(&context(Input::default()).unwrap(),&ObservedJoint::capture(&f,&b).unwrap()));}
#[cfg(any())]
#[test]
fn joint_nonreward_and_harm_can_reverse_unscaled_expectation(){
    // Arithmetic contract only. Genuine producer revision remains a later native
    // sealed-event integration case; no synthetic values are labeled measured.
    assert_eq!(bounded_mean(&[0.08]).unwrap(),0.08);
    assert_eq!(bounded_mean(&[0.08,0.]).unwrap(),0.04);
    assert!(bounded_mean(&[0.08,0.,-0.5]).unwrap()<0.);
    assert!(bounded_mean(&[-0.5,0.08,0.8]).unwrap()>0.);
    assert!(bounded_mean(&[f32::NAN]).is_err());assert!(bounded_mean(&[1.1]).is_err());
}
#[cfg(any())]
#[test]
fn target_pose_and_position_presence_must_bind_to_actual_candidate(){
    let(frame,bundle)=fixture(Input::default()).unwrap();
    for missing_position in [false,true]{let mut bad=bundle.clone();let target=bad.channels[1].target.as_mut().unwrap();
        if missing_position{target.position=None;}else{target.position.as_mut().unwrap().x+=0.01;}
        assert!(ObservedJoint::capture(&frame,&bad).is_err());
    }
    assert!(ObservedJoint::capture(&frame,&bundle).is_ok());
    assert!(turn_fixture(604,0.5,ActionTarget::new(None,Some(Vec3f::new(0.5,0.,0.)))).is_err(),
        "profile5 does not admit an unobserved position-only turn target");
}
#[cfg(any())]
#[test]
fn changed_direction_standoff_or_confidence_refuses_cue_transfer(){
    let a=context(Input::default()).unwrap();let(frame,bundle)=fixture(newer()).unwrap();
    let mut directed=bundle.clone();directed.channels[0].direction=Vec3f::new(0.1,0.,0.);
    assert!(!cue(&a,&ObservedJoint::capture(&frame,&directed).unwrap()));
    let mut stand_off=bundle.clone();stand_off.channels[0].stand_off_distance=0.25;
    assert!(!cue(&a,&ObservedJoint::capture(&frame,&stand_off).unwrap()));
    let mut confidence=bundle;confidence.channels[0].confidence=Confidence::new(0.7).unwrap();
    assert!(!cue(&a,&ObservedJoint::capture(&frame,&confidence).unwrap()));
}
fn turn_fixture(action:u32,intensity:f32,target:ActionTarget)->Result<(PerceptionFrame,MotorCommandBundle),ScaffoldContractError>{
    // Intentionally adversarial: ordinary profile5 does not admit unobserved
    // intrinsic Look/Turn candidates. Use public validation, never loosen it.
    let owner=OrganismId(811);let tick=Tick::new(10);let profile=SensorProfile::GroundedObjectSlotsSleepChoiceV1;
    let candidate=ActionCandidate::new(0,ActionId(action),ActionKind::Look,CandidateActionFamily::Inspect,
        CandidateObservationRef::None,target,CandidateFeatureVector::zero(),Confidence::new(0.9)?,
        NormalizedScalar::new(0.2)?,DurationTicks::new(1),DurationTicks::new(2))?;
    let draft=PerceptionFrameDraft::new(owner,tick,profile,SensorySnapshot::new(owner,tick,Vec3f::ZERO,SensoryChannels::ZERO,Default::default())?,
        BodySnapshot{pose:Pose::IDENTITY,velocity:Velocity::ZERO},HomeostaticSnapshot::baseline(tick),vec![candidate],
        SensorProfileProvenance::new(profile,SensoryAbiVersion::CURRENT,tick)?,vec![])?;
    let bank=MemoryBank::new(MemoryBankConfig::new(8,64,4,0.72,Confidence::new(0.)?)?)?;
    let(frame,_)=bank.recall_frame(&draft)?.finalize(draft)?;
    let command=ChannelCommand::new(MotorChannel::Orientation,ActionId(action),if target==ActionTarget::NONE{None}else{Some(target)},Vec3f::ZERO,Intensity::new(intensity)?,DurationTicks::new(1),0.,Confidence::new(0.8)?,0)?;
    let bundle=MotorCommandBundle::new(owner,ExperienceSequenceId::new(1).ok_or(ScaffoldContractError::InvalidId)?,tick,vec![command])?;
    Ok((frame,bundle))
}
#[cfg(any())]
#[test]
fn turn_context_rejects_noncanonical_profile5_and_preserves_turn_operation_keys(){
    // Pinned ABI has no turn_radians scalar. World turn sign is604 versus605;
    // angle magnitude uses intensity. Profile5 rejects these intrinsic proposals.
    for id in [604,605]{assert!(turn_fixture(id,0.5,ActionTarget::NONE).is_err());}
    // Pure comparison-key adversary, NOT a captured/admitted turn frame or action.
    let mut left=context(Input::default()).unwrap();left.roles[0].command.channel=MotorChannel::Orientation;
    left.roles[0].command.primitive=ActionId(604);left.roles[0].command.intensity=Intensity::new(0.5).unwrap();
    let same=left.clone();let mut right=left.clone();right.roles[0].command.primitive=ActionId(605);
    let mut larger=left.clone();larger.roles[0].command.intensity=Intensity::new(0.75).unwrap();
    assert!(left.matches(&same,LookupModeV1::VisibleCueRoles,None));
    assert!(!left.matches(&right,LookupModeV1::VisibleCueRoles,None));
    assert!(!left.matches(&larger,LookupModeV1::VisibleCueRoles,None));
}
fn grouped(input:Input,id:u8,members:Vec<MotorChannel>)->(PerceptionFrame,MotorCommandBundle){
    let(frame,mut bundle)=fixture(input).unwrap();
    for command in &mut bundle.channels{command.coordination_group=if members.contains(&command.channel){id}else{0};}
    bundle=bundle.with_coordination(BoundedCoordinationSummary{groups:vec![CoordinationGroup{group_id:id,channels:members}]}).unwrap();
    (frame,bundle)
}
#[cfg(any())]
#[test]
fn nonempty_coordination_matches_but_changed_group_or_channel_structure_does_not(){
    let members=vec![MotorChannel::Locomotion,MotorChannel::Manipulation,MotorChannel::Posture];
    let(f,a)=grouped(Input::default(),1,members.clone());let a=ObservedJoint::capture(&f,&a).unwrap();
    let(f,same)=grouped(newer(),1,members.clone());assert!(cue(&a,&ObservedJoint::capture(&f,&same).unwrap()));
    let(f,changed_id)=grouped(newer(),2,members);assert!(!cue(&a,&ObservedJoint::capture(&f,&changed_id).unwrap()));
    let(f,changed_members)=grouped(newer(),1,vec![MotorChannel::Locomotion,MotorChannel::Manipulation]);
    assert!(!cue(&a,&ObservedJoint::capture(&f,&changed_members).unwrap()));
}
#[cfg(any())]
#[test]
fn inconsistent_coordination_membership_is_not_observed_evidence(){
    let(f,b)=fixture(Input::default()).unwrap();let mut absent=b.clone();
    absent.coordination=BoundedCoordinationSummary{groups:vec![CoordinationGroup{group_id:0,channels:vec![MotorChannel::Orientation]}]};
    assert!(ObservedJoint::capture(&f,&absent).is_err());
    let mut no_group=b.clone();no_group.channels[1].coordination_group=7;assert!(ObservedJoint::capture(&f,&no_group).is_err());
    let mut duplicate=b;let g=CoordinationGroup{group_id:0,channels:vec![MotorChannel::Manipulation]};
    duplicate.coordination=BoundedCoordinationSummary{groups:vec![g.clone(),g]};assert!(ObservedJoint::capture(&f,&duplicate).is_err());
}

#[cfg(any())]
#[test]
fn proven_entity_routes_normalize_only_unused_command_fields(){
 let a=context(Input::default()).unwrap();let mut b=context(newer()).unwrap();
 for index in [1,2]{b.roles[index].command.direction=Vec3f::new(91.,0.,-82.);b.roles[index].command.stand_off_distance=0.3;b.roles[index].command.confidence=Confidence::new(0.6).unwrap();}
 assert!(a.matches(&b,LookupModeV1::ExecutorEntityRoutesV2,Some(MotorChannel::Manipulation)));
 assert!(!cue(&a,&b));
 b.roles[0].command.direction=Vec3f::new(91.,0.,-82.);
 assert!(!a.matches(&b,LookupModeV1::ExecutorEntityRoutesV2,Some(MotorChannel::Manipulation)));
}
#[cfg(any())]
#[test]
fn semantic_routes_preserve_intensity_operations_and_observation_uncertainty(){
 let a=context(Input::default()).unwrap();let mut b=context(newer()).unwrap();
 b.roles[1].command.intensity=Intensity::new(0.5).unwrap();
 assert!(!a.matches(&b,LookupModeV1::ExecutorEntityRoutesV2,Some(MotorChannel::Manipulation)));
 assert!(context(Input{confidence:0.4,..newer()}).is_err());
 b.roles[1].command.primitive=ActionId(211);
 assert!(!entity_route_equivalent(&a.roles[1].command,&b.roles[1].command,LookupModeV1::ExecutorEntityRoutesV2));
}
#[cfg(any())]
#[test]
fn fresh_cue_wire_roundtrip_and_edited_anchor_rejection(){
 let source=PhenotypeHash([1,2,3,4]);
 let m=FreshVisibleCueMemoryV1::fresh(OrganismId(811),source,[8,7,6,5]).unwrap();
 let(bytes,anchor)=m.checkpoint().unwrap();
 let restored=FreshVisibleCueMemoryV1::restore(&bytes,&anchor).unwrap();assert_eq!(restored.checkpoint().unwrap().0,bytes);
 let mut bad=anchor.clone();bad.generation+=1;assert!(FreshVisibleCueMemoryV1::restore(&bytes,&bad).is_err());
 let mut edited=bytes.clone();edited[0]^=1;assert!(FreshVisibleCueMemoryV1::restore(&edited,&anchor).is_err());
 let old=JointEpisodeMemoryV1::fresh(OrganismId(811),source,[8,7,6,5],64).unwrap().checkpoint().unwrap();
 assert!(FreshVisibleCueMemoryV1::restore(&old.0,&old.1).is_err());
 assert!(JointEpisodeMemoryV1::restore(&bytes,&anchor).is_err());
}

// Regression: production semantic lookup must never bypass observed evidence.
fn semantic_inputs(a:Input,b:Input)->Result<bool,ScaffoldContractError>{
    Ok(context(a)?.matches(&context(b)?,LookupModeV1::ExecutorEntityRoutesV2,Some(MotorChannel::Manipulation)))
}
#[cfg(any())]
#[test]
fn executor_semantic_mode_rejects_chemical_change(){
    let mut b=newer();b.chemical[2]+=0.0001;
    assert!(!semantic_inputs(Input::default(),b).unwrap());
}
#[cfg(any())]
#[test]
fn executor_semantic_mode_rejects_shape_change(){
    let mut b=newer();b.shape[1]+=0.0001;
    assert!(!semantic_inputs(Input::default(),b).unwrap());
}
#[cfg(any())]
#[test]
fn executor_semantic_mode_rejects_equal_out_of_reach_cues(){
    assert!(!semantic_inputs(Input{distance:0.2,..Input::default()},Input{distance:0.2,..newer()}).unwrap());
}
#[cfg(any())]
#[test]
fn executor_semantic_mode_rejects_equal_absent_contact_cues(){
    assert!(!semantic_inputs(Input{contact:0.,..Input::default()},Input{contact:0.,..newer()}).unwrap());
}
#[cfg(any())]
#[test]
fn executor_semantic_mode_rejects_low_or_missing_observed_evidence(){
    assert!(semantic_inputs(Input::default(),Input{confidence:0.4,..newer()}).is_err());
    assert!(semantic_inputs(Input::default(),Input{missing:true,..newer()}).is_err());
}
#[cfg(any())]
#[test]
fn executor_semantic_mode_rejects_invalid_observed_geometry(){
    assert!(semantic_inputs(Input::default(),Input{distance:f32::NAN,..newer()}).is_err());
}
#[cfg(any())]
#[test]
fn graded_same_cue_has_unit_weight_and_new_identity_control_stays_exact(){
 let a=context(Input::default()).unwrap();let b=context(newer()).unwrap();
 assert_eq!(a.graded_weight(&b,Some(MotorChannel::Manipulation)),Some(1.));
 assert!(!a.matches(&b,LookupModeV1::ExactIdentityControl,Some(MotorChannel::Manipulation)));
}
#[cfg(any())]
#[test]
fn graded_appearance_distance_is_monotonic_without_gain(){
 let a=context(Input::default()).unwrap();let near=context(Input{color:[0.3,0.5,0.7],..newer()}).unwrap();let far=context(Input{color:[0.6,0.5,0.7],..newer()}).unwrap();
 let n=a.graded_weight(&near,Some(MotorChannel::Manipulation)).unwrap();let f=a.graded_weight(&far,Some(MotorChannel::Manipulation)).unwrap();
 assert!(0.<f&&f<n&&n<1.);assert!(attenuated_signed_mean(&[(0.8,f)]).unwrap().unwrap()<0.8);
}
#[cfg(any())]
#[test]
fn graded_chemical_difference_is_strictly_incompatible(){
 let a=context(Input::default()).unwrap();let b=context(Input{chemical:[0.2,0.3,0.4001],..newer()}).unwrap();assert_eq!(a.graded_weight(&b,Some(MotorChannel::Manipulation)),None);
}
#[cfg(any())]
#[test]
fn graded_operation_and_role_graph_changes_reject(){
 let a=context(Input::default()).unwrap();let mut b=context(newer()).unwrap();b.roles[1].command.payload=BoundedMotorPayload::new(vec![1]).unwrap();assert!(a.graded_weight(&b,Some(MotorChannel::Manipulation)).is_none());
 let shared=context(Input{ids:[171,171,173],..newer()}).unwrap();assert!(a.graded_weight(&shared,Some(MotorChannel::Manipulation)).is_none());
}
#[cfg(any())]
#[test]
fn graded_unobserved_low_confidence_and_unsupported_route_reject(){
 assert!(context(Input{missing:true,..newer()}).is_err());assert!(context(Input{confidence:0.4,..newer()}).is_err());
 let a=context(Input::default()).unwrap();let mut b=context(newer()).unwrap();b.roles[1].command.primitive=ActionId(211);assert!(a.graded_weight(&b,Some(MotorChannel::Manipulation)).is_none());
}
#[cfg(any())]
#[test]
fn graded_entity_eat_bearing_is_not_an_operation_but_reach_contact_remain(){
 let a=context(Input::default()).unwrap();let b=context(Input{eat_bearing:Some([1.,0.]),..newer()}).unwrap();
 assert_eq!(a.graded_weight(&b,Some(MotorChannel::Manipulation)),Some(1.));
 assert!(!a.matches(&b,LookupModeV1::ExecutorEntityRoutesV2,Some(MotorChannel::Manipulation)));
 let far=context(Input{distance:0.2,..newer()}).unwrap();assert!(a.graded_weight(&far,Some(MotorChannel::Manipulation)).is_none());
 let none=context(Input{contact:0.,..newer()}).unwrap();assert!(a.graded_weight(&none,Some(MotorChannel::Manipulation)).is_none());
}
#[cfg(any())]
#[test]
fn graded_temperature_and_terrain_extremes_are_not_erased(){
 let cold=context(Input{temperature:-1.,terrain:[0.,0.],..Input::default()}).unwrap();let hot=context(Input{temperature:1.,terrain:[1.,1.],..newer()}).unwrap();
 let w=cold.graded_weight(&hot,Some(MotorChannel::Manipulation)).unwrap();assert!(w>0.&&w<0.001);
}
#[cfg(any())]
#[test]
fn graded_signed_contradictions_reverse_and_nonreward_dilutes(){
 assert_eq!(attenuated_signed_mean(&[(0.5,1.),(0.,1.)]).unwrap(),Some(0.25));
 assert!(attenuated_signed_mean(&[(0.2,1.),(-0.8,1.)]).unwrap().unwrap()<0.);
 assert_eq!(attenuated_signed_mean(&[(-0.8,0.5)]).unwrap(),Some(-0.4));
}
#[cfg(any())]
#[test]
fn graded_drive_change_and_movement_fallback_remain_context(){
 let a=context(Input::default()).unwrap();let b=context(Input{pain:0.151,..newer()}).unwrap();assert!(a.graded_weight(&b,Some(MotorChannel::Manipulation)).is_none());
 let mut b=context(newer()).unwrap();b.roles[0].command.direction=Vec3f::new(1.,0.,0.);assert!(a.graded_weight(&b,Some(MotorChannel::Manipulation)).is_none());
}
