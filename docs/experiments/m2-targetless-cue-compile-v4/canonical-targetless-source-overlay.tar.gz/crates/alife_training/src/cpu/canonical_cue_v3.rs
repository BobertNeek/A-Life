//! V3 canonical targetless joint-role association. Fresh-only owner.
//! No object observation, grip, ownership or future consumption is manufactured.
use super::*;
pub(crate) const CANONICAL_CUE_OWNER_V3:&str="fresh-canonical-targetless-joint-v3/profile5/exact-role-registry/no-migration";
#[derive(Debug,Clone)]
pub(crate) struct FreshCanonicalCueMemoryV3{legacy:FreshMealCueMemoryV2,canonical_sequences:Vec<u64>}
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
struct CanonicalCueWireV3{schema:u16,owner:String,storage:MealCueWireV2}
fn targetless_spec_v3(c:&ChannelCommand)->Option<(ActionKind,CandidateActionFamily,f32)>{
    match(c.channel,c.primitive.raw()){
        (MotorChannel::Posture,1)=>Some((ActionKind::Idle,CandidateActionFamily::Idle,0.)),
        (MotorChannel::Locomotion,103)=>Some((ActionKind::Move,CandidateActionFamily::Approach,0.)),
        (MotorChannel::Manipulation,212)=>Some((ActionKind::Interact,CandidateActionFamily::Contact,0.)),
        (MotorChannel::Posture,104)=>Some((ActionKind::Hold,CandidateActionFamily::Other,0.)),
        (MotorChannel::Posture,3)=>Some((ActionKind::Rest,CandidateActionFamily::Rest,0.05)),
        (MotorChannel::Posture,700)=>Some((ActionKind::Rest,CandidateActionFamily::Rest,0.)),_=>None,
    }
}
fn canonical_command_v3(c:&ChannelCommand)->bool{
    targetless_spec_v3(c).is_some()&&c.target.is_none()&&c.payload.values.is_empty()
        &&[c.direction.x,c.direction.y,c.direction.z,c.stand_off_distance].iter().all(|x|x.to_bits()==0_f32.to_bits())
        &&c.intensity.raw().to_bits()==1_f32.to_bits()&&c.confidence.raw().to_bits()==1_f32.to_bits()
        &&c.duration_ticks.raw()==1&&c.coordination_group==0
}
fn capture_canonical_v3(frame:&PerceptionFrame,bundle:&MotorCommandBundle)->Result<ObservedJoint,ScaffoldContractError>{
    let observed=ObservedJoint::capture(frame,bundle)?;
    for role in &observed.roles{
        if role.query.is_some(){continue;}
        let c=&role.command;let(kind,family,effort)=targetless_spec_v3(c).ok_or_else(invalid)?;
        if !canonical_command_v3(c){return Err(invalid());}
        let matches=frame.candidates().iter().enumerate().filter(|(_,a)|a.action_id==c.primitive&&a.target==ActionTarget::NONE).collect::<Vec<_>>();
        if matches.len()!=1{return Err(invalid());}let(index,a)=matches[0];
        let basis=CandidateFeatureVector::zero().with_intrinsic_action_basis(kind);
        if a.kind!=kind||a.family!=family||a.observation!=CandidateObservationRef::None||usize::from(a.candidate_index)!=index
            ||a.features.0.map(f32::to_bits)!=basis.0.map(f32::to_bits)||a.sensor_confidence.raw().to_bits()!=1_f32.to_bits()
            ||a.required_effort.raw().to_bits()!=effort.to_bits()||a.min_duration.raw()!=1||a.max_duration.raw()!=1{return Err(invalid());}
        if matches!(c.primitive.raw(),3|700)&&RecoveryOperationV1::for_candidate(a)?.map(|o|o.action_id())!=Some(c.primitive){return Err(invalid());}
        let action=a.to_command(frame.organism_id(),a.sensor_confidence)?;
        if alife_core::channel_command_for_action(c.channel,&action)?!=*c{return Err(invalid());}
    }
    Ok(observed)
}
impl FreshCanonicalCueMemoryV3{
    fn refresh(&mut self)->Result<(),ScaffoldContractError>{
        self.canonical_sequences.clear();
        for(c,e)in self.legacy.legacy.cues.iter().zip(self.legacy.sleep_joint_sources()){
            if c.sequence!=e.sequence.raw(){return Err(invalid());}
            let Some(f)=c.frame.as_ref()else{continue;};
            let b=MotorCommandBundle::new(f.organism_id(),e.sequence,e.source_tick,e.commands.clone())?.with_coordination(e.coordination.clone())?;
            if c.observed.is_some()&&capture_canonical_v3(f,&b).is_ok(){self.canonical_sequences.push(c.sequence);}
        }Ok(())
    }
    pub(crate) fn fresh(owner:OrganismId,phenotype:PhenotypeHash,lineage:[u64;4])->Result<Self,ScaffoldContractError>{
        if lineage==[0;4]{return Err(invalid());}let mut h=blake3::Hasher::new();h.update(CANONICAL_CUE_OWNER_V3.as_bytes());
        for w in lineage{h.update(&w.to_le_bytes());}let digest=h.finalize();let lineage=std::array::from_fn(|i|u64::from_le_bytes(digest.as_bytes()[i*8..i*8+8].try_into().unwrap()));
        Ok(Self{legacy:FreshMealCueMemoryV2::fresh(owner,phenotype,lineage)?,canonical_sequences:vec![]})
    }
    pub(crate) fn observe(&mut self,p:&ExperiencePatch,f:&PerceptionFrame)->Result<(),ScaffoldContractError>{
        let mut staged=self.clone();staged.legacy.observe(p,f)?;staged.refresh()?;*self=staged;Ok(())
    }
    pub(crate) fn checkpoint(&self)->Result<(Vec<u8>,JointEpisodeAnchorV1),ScaffoldContractError>{
        let(inner,mut anchor)=self.legacy.checkpoint()?;let storage:MealCueWireV2=serde_json::from_slice(&inner).map_err(|_|invalid())?;
        let bytes=serde_json::to_vec(&CanonicalCueWireV3{schema:3,owner:CANONICAL_CUE_OWNER_V3.into(),storage}).map_err(|_|invalid())?;
        if bytes.len()>MAX_CUE_WIRE_BYTES{return Err(invalid());}anchor.policy=CANONICAL_CUE_OWNER_V3.into();anchor.digest=*blake3::hash(&bytes).as_bytes();Ok((bytes,anchor))
    }
    pub(crate) fn restore(bytes:&[u8],anchor:&JointEpisodeAnchorV1)->Result<Self,ScaffoldContractError>{
        if bytes.len()>MAX_CUE_WIRE_BYTES||anchor.policy!=CANONICAL_CUE_OWNER_V3||*blake3::hash(bytes).as_bytes()!=anchor.digest{return Err(invalid());}
        let wire:CanonicalCueWireV3=serde_json::from_slice(bytes).map_err(|_|invalid())?;
        if wire.schema!=3||wire.owner!=CANONICAL_CUE_OWNER_V3||wire.storage.owner!=MEAL_CUE_OWNER_V2{return Err(invalid());}
        let inner=serde_json::to_vec(&wire.storage).map_err(|_|invalid())?;let mut prior=anchor.clone();prior.policy=MEAL_CUE_OWNER_V2.into();prior.digest=*blake3::hash(&inner).as_bytes();
        let mut result=Self{legacy:FreshMealCueMemoryV2::restore(&inner,&prior)?,canonical_sequences:vec![]};result.refresh()?;
        if result.checkpoint()?.1!=*anchor{return Err(invalid());}Ok(result)
    }
    pub(crate) fn sleep_joint_sources(&self)->&[JointEpisodeV1]{self.legacy.sleep_joint_sources()}
    pub(crate) fn expected_whole_event(&self,f:&PerceptionFrame,b:&MotorCommandBundle,m:LookupModeV1)->Result<Option<WholeEventExpectationV1>,ScaffoldContractError>{self.legacy.expected_whole_event(f,b,m)}
    pub(crate) fn expected_graded_joint_value(&self,b:&MotorCommandBundle,f:&PerceptionFrame)->Result<Option<f32>,ScaffoldContractError>{self.legacy.expected_graded_joint_value(b,f)}
    pub(crate) fn expected_meal_joint_value_v2(&self,b:&MotorCommandBundle,f:&PerceptionFrame)->Result<Option<f32>,ScaffoldContractError>{self.legacy.expected_meal_joint_value_v2(b,f)}
    pub(crate) fn recall_joint(&self,b:&MotorCommandBundle,f:&PerceptionFrame)->Result<Vec<&JointEpisodeV1>,ScaffoldContractError>{self.legacy.recall_joint(b,f)}
    pub(crate) fn expected_canonical_joint_value_v3(&self,b:&MotorCommandBundle,f:&PerceptionFrame)->Result<Option<f32>,ScaffoldContractError>{
        let Ok(query)=capture_canonical_v3(f,b)else{return Ok(None);};let mut values=vec![];
        for(c,e)in self.legacy.legacy.cues.iter().zip(self.sleep_joint_sources()){
            if c.sequence!=e.sequence.raw(){return Err(invalid());}
            if !self.canonical_sequences.contains(&c.sequence){continue;}
            if let Some(w)=c.observed.as_ref().and_then(|s|s.canonical_weight_v3(&query,c.consumed_channel)){values.push((e.joint_experienced_valence.raw(),w));}
        }attenuated_signed_mean(&values)
    }
    #[cfg(test)]
    pub(crate) fn observe_without_cue_budget(&mut self,p:&ExperiencePatch,f:&PerceptionFrame)->Result<(),ScaffoldContractError>{let mut s=self.clone();s.legacy.observe_without_cue_budget(p,f)?;s.refresh()?;*self=s;Ok(())}
    #[cfg(test)]
    pub(crate) fn diagnose_two_sources(&self,s:&[(u64,&PerceptionFrame)],f:&PerceptionFrame,b:&MotorCommandBundle)->Result<serde_json::Value,ScaffoldContractError>{self.legacy.diagnose_two_sources(s,f,b)}
    #[cfg(test)]
    pub(crate) fn matched_readouts_v2(&self,f:&PerceptionFrame,b:&MotorCommandBundle)->Result<serde_json::Value,ScaffoldContractError>{self.legacy.matched_readouts_v2(f,b)}
    #[cfg(test)]
    pub(crate) fn source_readouts_v3(&self,f:&PerceptionFrame,b:&MotorCommandBundle)->Result<serde_json::Value,ScaffoldContractError>{
        if self.sleep_joint_sources().len()>3{return Err(invalid());}let query=capture_canonical_v3(f,b).ok();let mut rows=vec![];
        for(c,e)in self.legacy.legacy.cues.iter().zip(self.sleep_joint_sources()){
            if c.sequence!=e.sequence.raw(){return Err(invalid());}
            rows.push(serde_json::json!({"sequence":c.sequence,"source_consumed":e.consumed.is_some(),"signed_joint_valence":e.joint_experienced_valence.raw(),
                "canonical_source":self.canonical_sequences.contains(&c.sequence),"v3_weight":c.observed.as_ref().zip(query.as_ref()).filter(|_|self.canonical_sequences.contains(&c.sequence)).and_then(|(s,q)|s.canonical_weight_v3(q,c.consumed_channel))}));
        }
        let(bytes,anchor)=self.checkpoint()?;let restored=Self::restore(&bytes,&anchor)?;
        let(v2_bytes,v2_anchor)=self.legacy.checkpoint()?;
        if FreshMealCueMemoryV2::restore(&bytes,&anchor).is_ok()||Self::restore(&v2_bytes,&v2_anchor).is_ok()
            ||restored.checkpoint()?.0!=bytes||restored.sleep_joint_sources()!=self.sleep_joint_sources()
            ||restored.canonical_sequences!=self.canonical_sequences
            ||restored.expected_canonical_joint_value_v3(b,f)?!=self.expected_canonical_joint_value_v3(b,f)?{return Err(invalid());}
        Ok(serde_json::json!({"schema":"canonical-targetless-source-readouts-v3","query_capture_success":query.is_some(),"sources":rows,"v3_joint_value":self.expected_canonical_joint_value_v3(b,f)?,"cold_equal":true,"cross_load_rejected":true,"future_grip":"Unknown","future_consumption":"Unknown"}))
    }
}
impl ObservedJoint {
    fn canonical_weight_v3(&self,b:&Self,consumed:Option<MotorChannel>)->Option<f32>{
        if self.owner!=b.owner||self.roles.len()!=b.roles.len()||self.coordination!=b.coordination
            ||self.drives.iter().zip(b.drives).any(|(x,y)|(x-y).abs()>0.15){return None;}
        let mut distance=0f64;
        for a in &self.roles {
            let z=b.roles.iter().find(|z|z.command.channel==a.command.channel)?;
            let x=&a.command;let y=&z.command;
            match(&a.query,&z.query){
                (None,None)=>{if !canonical_command_v3(x)||!canonical_command_v3(y)||x!=y{return None;}continue;},
                (Some(_),Some(_))=>{},_=>return None,
            }
            let route=graded_route(x)?;graded_route(y)?;
            if x.primitive!=y.primitive||x.payload!=y.payload||x.intensity!=y.intensity||x.duration_ticks!=y.duration_ticks||x.coordination_group!=y.coordination_group{return None;}
            if !entity_route_equivalent(x,y,LookupModeV1::ExecutorEntityRoutesV2)
                &&(x.direction!=y.direction||x.stand_off_distance!=y.stand_off_distance||x.confidence!=y.confidence){return None;}
            let af=&a.query.as_ref()?.features()[TARGET_START..TARGET_START+24];let bf=&z.query.as_ref()?.features()[TARGET_START..TARGET_START+24];
            // Strict chemical boundary; even subtle changed chemistry is not
            // generalized from a positive event without separate evidence.
            if (15..18).any(|i|af[i].to_bits()!=bf[i].to_bits()){return None;}
            let velocity_differs=(3..6).any(|i|(af[i]-bf[i]).abs()>0.02);
            if (19..21).any(|i|(af[i]-bf[i]).abs()>0.05){return None;}
            match route {
                GradedRoute::EntityEat=>{
                    // Actual entity-target ingestion resolves world position;
                    // bearing/fallback point is not its command operation.
                    // Reach and observed contact still constrain transfer.
                    if af[2]>MAX_INTERACTION_DISTANCE||bf[2]>MAX_INTERACTION_DISTANCE||af[18].to_bits()!=bf[18].to_bits(){return None;}
                    if consumed==Some(x.channel)&&(af[18]!=1.||bf[18]!=1.){return None;}
                    // Only reached AND contacted EntityEat ignores relative velocity.
                    // The raw witness is retained; this is association, not feasibility.
                    if (af[18]!=1.||bf[18]!=1.)&&velocity_differs{return None;}
                },
                GradedRoute::EntityMove|GradedRoute::EntityInspect=>{
                    if velocity_differs{return None;}
                    if (0..3).any(|i|(af[i]-bf[i]).abs()>if i<2{0.05}else{0.02})||af[18].to_bits()!=bf[18].to_bits(){return None;}
                }
            }
            for range in [6..9,9..12,12..15]{distance+=range.map(|i|(f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/3.;}
            // Full observed temperature range is[-1,1]; terrain range[0,1].
            // Keep both as nonzero, stronger context penalties, not nuisance
            // channels erased globally. Scales fixed before any evaluation.
            distance+=2.*((f64::from(af[21])-f64::from(bf[21]))/2.).powi(2);
            distance+=2.*(22..24).map(|i|(f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/2.;
        }
        for a in &self.roles{for other in &self.roles{
            let z=b.roles.iter().find(|z|z.command.channel==a.command.channel)?;
            let zo=b.roles.iter().find(|z|z.command.channel==other.command.channel)?;
            let target=|r:&ObservedRole|r.command.target.and_then(|t|t.entity);
            if(target(a)==target(other))!=(target(z)==target(zo)){return None;}
        }}
        Some((-distance).exp()as f32)
    }
}


#[cfg(test)]
#[path="canonical_cue_v3_contracts.rs"]
mod contracts;
#[cfg(test)]
pub(crate) fn assert_pure_contracts_v3(){contracts::run();}
