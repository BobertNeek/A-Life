//! Public-frame pure contracts. No world, source forward or sealed experience.
use super::*;
fn fixture(id:u32,channel:MotorChannel)->Result<(PerceptionFrame,MotorCommandBundle),ScaffoldContractError>{
    let owner=OrganismId(811);let tick=Tick::new(10);
    let stub=ChannelCommand::new(channel,ActionId(id),None,Vec3f::ZERO,Intensity::new(1.)?,DurationTicks::new(1),0.,Confidence::new(1.)?,0)?;
    let(kind,family,effort)=targetless_spec_v3(&stub).ok_or_else(invalid)?;
    let a=ActionCandidate::new(0,ActionId(id),kind,family,CandidateObservationRef::None,ActionTarget::NONE,
        CandidateFeatureVector::zero().with_intrinsic_action_basis(kind),Confidence::new(1.)?,NormalizedScalar::new(effort)?,DurationTicks::new(1),DurationTicks::new(1))?;
    let profile=SensorProfile::GroundedObjectSlotsSleepChoiceV1;
    let draft=PerceptionFrameDraft::new(owner,tick,profile,SensorySnapshot::new(owner,tick,Vec3f::ZERO,SensoryChannels::ZERO,Default::default())?,
        BodySnapshot{pose:Pose::IDENTITY,velocity:Velocity::ZERO},HomeostaticSnapshot::baseline(tick),vec![a],SensorProfileProvenance::new(profile,SensoryAbiVersion::CURRENT,tick)?,vec![])?;
    let bank=MemoryBank::new(MemoryBankConfig::new(8,64,4,0.72,Confidence::new(0.)?)?)?;
    let(frame,_)=bank.recall_frame(&draft)?.finalize(draft)?;
    Ok((frame,MotorCommandBundle::new(owner,ExperienceSequenceId(1),tick,vec![stub])?))
}
fn mixed(ids:[u32;2],velocity:[[f32;3];2],chemical:[f32;3],distance:f32,contact:f32,missing:bool)->Result<ObservedJoint,ScaffoldContractError>{
    let(f,mut bundle)=fixture(104,MotorChannel::Posture)?;let mut slots=vec![];let mut candidates=vec![];let mut unique=vec![];
    for id in ids{if !unique.contains(&id){unique.push(id);}}
    for(i,id)in unique.iter().enumerate(){slots.push(GroundedObjectSlotV1{slot_index:i as u16,tracked_object_id:TrackedObjectId(u64::from(*id)*10),
        bearing:[0.,1.],distance,relative_velocity:velocity[i],color:[0.2,0.4,0.5],material:[0.2,0.4,0.5],shape:[0.2,0.4,0.5],
        chemical,contact,proprioception:[0.;2],temperature:0.,terrain:[0.;2],confidence:Confidence::new(1.)?});}
    for(i,(primitive,kind,family,channel))in [(102,ActionKind::Move,CandidateActionFamily::Avoid,MotorChannel::Locomotion),(210,ActionKind::Interact,CandidateActionFamily::Ingest,MotorChannel::Manipulation)].into_iter().enumerate(){
        let slot=unique.iter().position(|x|*x==ids[i]).unwrap();let target=ActionTarget::new(Some(WorldEntityId(u64::from(ids[i]))),Some(Vec3f::new(distance*8.,0.,0.)));
        candidates.push(ActionCandidate::new(i as u16,ActionId(primitive),kind,family,if missing{CandidateObservationRef::None}else{CandidateObservationRef::ObjectSlot(slot as u16)},target,
            slots[slot].candidate_features()?,Confidence::new(1.)?,NormalizedScalar::new(0.2)?,DurationTicks::new(1),DurationTicks::new(2))?);
        bundle.channels.push(ChannelCommand::new(channel,ActionId(primitive),Some(target),Vec3f::ZERO,Intensity::new(1.)?,DurationTicks::new(1),0.,Confidence::new(1.)?,0)?);
    }
    let mut noop=f.candidates()[0].clone();noop.candidate_index=2;candidates.push(noop);
    let draft=PerceptionFrameDraft::new(f.organism_id(),f.tick(),f.sensor_profile(),f.sensory().clone(),f.body(),*f.homeostasis(),candidates,f.profile_provenance(),slots)?;
    let bank=MemoryBank::new(MemoryBankConfig::new(8,64,4,0.72,Confidence::new(0.)?)?)?;
    let(frame,_)=bank.recall_frame(&draft)?.finalize(draft)?;capture_canonical_v3(&frame,&bundle)
}
pub(super) fn run(){
    for(id,ch)in [(1,MotorChannel::Posture),(104,MotorChannel::Posture),(103,MotorChannel::Locomotion),(212,MotorChannel::Manipulation),(3,MotorChannel::Posture),(700,MotorChannel::Posture)]{
        let(f,b)=fixture(id,ch).unwrap();let a=capture_canonical_v3(&f,&b).unwrap();
        assert!(a.roles[0].query.is_none());assert_eq!(a.canonical_weight_v3(&a,None),Some(1.));assert!(a.meal_weight_v2(&a,None).is_none());
        for mutation in 0..10{let mut bad=b.clone();let c=&mut bad.channels[0];match mutation{
            0=>c.primitive=ActionId(999),1=>c.target=Some(ActionTarget::NONE),2=>c.target=Some(ActionTarget::new(None,Some(Vec3f::ZERO))),
            3=>c.direction=Vec3f::new(0.1,0.,0.),4=>c.intensity=Intensity::new(0.5).unwrap(),5=>c.duration_ticks=DurationTicks::new(2),
            6=>c.payload=BoundedMotorPayload::new(vec![1]).unwrap(),7=>c.confidence=Confidence::new(0.9).unwrap(),8=>c.stand_off_distance=0.1,_=>c.coordination_group=1};
            assert!(capture_canonical_v3(&f,&bad).is_err());}
    }
    let(f,a)=fixture(3,MotorChannel::Posture).unwrap();let sleep=capture_canonical_v3(&f,&a).unwrap();
    let(f,b)=fixture(700,MotorChannel::Posture).unwrap();let awake=capture_canonical_v3(&f,&b).unwrap();assert!(sleep.canonical_weight_v3(&awake,None).is_none());
    let(f,b)=fixture(104,MotorChannel::Posture).unwrap();let noop=capture_canonical_v3(&f,&b).unwrap();assert!(sleep.canonical_weight_v3(&noop,None).is_none());
    let mut wrong=noop.clone();wrong.roles[0].command.channel=MotorChannel::Manipulation;assert!(noop.canonical_weight_v3(&wrong,None).is_none());
    let mut changed=noop.clone();changed.owner=OrganismId(812);assert!(noop.canonical_weight_v3(&changed,None).is_none());
    changed=noop.clone();changed.drives[0]+=0.151;assert!(noop.canonical_weight_v3(&changed,None).is_none());
    changed=noop.clone();changed.coordination.groups.push(CoordinationGroup{group_id:0,channels:vec![MotorChannel::Posture]});assert!(noop.canonical_weight_v3(&changed,None).is_none());
    let chemical=[0.2,0.3,0.4];let zero=[[0.;3];2];let consumed=Some(MotorChannel::Manipulation);
    let source=mixed([71,72],zero,chemical,0.0625,1.,false).unwrap();
    let query=mixed([171,172],[[0.;3],[0.31,-0.27,0.19]],chemical,0.0625,1.,false).unwrap();
    assert_eq!(source.canonical_weight_v3(&query,consumed),Some(1.));assert!(source.meal_weight_v2(&query,consumed).is_none());
    for v in [mixed([171,172],[[0.1,0.,0.],[0.;3]],chemical,0.0625,1.,false),
        mixed([171,172],zero,[0.2,0.3,0.4001],0.0625,1.,false),mixed([171,172],zero,chemical,0.2,1.,false),
        mixed([171,172],zero,chemical,0.0625,0.,false),mixed([171,171],zero,chemical,0.0625,1.,false)]{
        assert!(source.canonical_weight_v3(&v.unwrap(),consumed).is_none());}
    assert!(mixed([171,172],zero,chemical,0.0625,1.,true).is_err());
    let mut missing=query.clone();missing.roles.iter_mut().find(|r|r.command.channel==MotorChannel::Manipulation).unwrap().query=None;
    assert!(source.canonical_weight_v3(&missing,consumed).is_none());
    let m=FreshCanonicalCueMemoryV3::fresh(OrganismId(811),PhenotypeHash([1,2,3,4]),[8,7,6,5]).unwrap();
    let(bytes,anchor)=m.checkpoint().unwrap();assert_eq!(FreshCanonicalCueMemoryV3::restore(&bytes,&anchor).unwrap().checkpoint().unwrap().0,bytes);
    assert!(FreshMealCueMemoryV2::restore(&bytes,&anchor).is_err());let(v2,a2)=m.legacy.checkpoint().unwrap();assert!(FreshCanonicalCueMemoryV3::restore(&v2,&a2).is_err());
    assert_eq!(attenuated_signed_mean(&[(-0.8,0.5)]).unwrap(),Some(-0.4));assert_eq!(attenuated_signed_mean(&[(0.8,0.5),(0.,1.)]).unwrap(),Some(0.2));
}
