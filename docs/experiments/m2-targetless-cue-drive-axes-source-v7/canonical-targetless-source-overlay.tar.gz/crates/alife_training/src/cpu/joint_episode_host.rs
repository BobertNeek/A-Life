//! Fresh joint policy retaining the qualified Optional-Quiet source producer.
use super::*;
use crate::cpu::{JointOptionalActionV2, JointOptionalScoresV2, OptionalVocalSourceV1, JOINT_OPTIONAL_POLICY_V2};
use alife_joint_episode::joint_episode::JointEpisodeAnchorV1;
use crate::cpu::visible_cue_joint::meal_cue_v2::canonical_cue_v3::FreshCanonicalCueMemoryV3 as JointEpisodeMemoryV1;
const OUTER_MAGIC:&[u8]=b"ALIFE-CANONICAL-TARGETLESS-CUE-V3-JOINT-OPTIONAL-OUTER\0V2\0QUIET-PRESERVED\0";
const INNER_MAGIC:&[u8]=b"ALIFE-CANONICAL-TARGETLESS-CUE-V3-JOINT-OPTIONAL-OWNED-INNER\0V2\0";
const INNER_LINEAGE:&str="fresh-canonical-targetless-cue-v3-joint-optional-inner-v2/proof-owner-bound";
const NORMALIZED_MAGIC:&[u8]=b"ALIFE-CANONICAL-TARGETLESS-CUE-V3-JOINT-OPTIONAL-PRIVATE-TOKEN\0V2\0";
const LINEAGE:&str="fresh-canonical-targetless-cue-v3-joint-optional-v2/no-old-import/neutral-candidate-memory";
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub(in crate::cpu::host) struct JointResidentV2 {
    bytes:Vec<u8>, anchor:JointEpisodeAnchorV1,
    #[cfg(test)]
    #[serde(default,skip_serializing_if="Option::is_none")]
    mechanism_targets:Option<[WorldEntityId;3]>,
    pub(super) last:Option<JointSelectionV2>,
}
#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct JointSelectionV2 {pub(super) scores:JointOptionalScoresV2,pub(super) action:JointOptionalActionV2}
impl JointResidentV2 {
    pub(super) fn fresh(owner:OrganismId,phenotype:PhenotypeHash,lineage:[u64;4],scripted:bool)->Result<Self,CpuHostError>{
        #[cfg(not(test))] if scripted {return Err(CpuHostError::State("scripted owner not compiled"));}
        let (bytes,anchor)=JointEpisodeMemoryV1::fresh(owner,phenotype,lineage)?.checkpoint()?;
        Ok(Self{bytes,anchor,last:None,
            #[cfg(test)] mechanism_targets:scripted.then_some([WorldEntityId(2),WorldEntityId(4),WorldEntityId(3)])})
    }
    pub(super) fn is_scripted(&self)->bool {
        #[cfg(test)] {return self.mechanism_targets.is_some();}
        #[cfg(not(test))] {false}
    }
    fn memory(&self)->Result<JointEpisodeMemoryV1,CpuHostError>{Ok(JointEpisodeMemoryV1::restore(&self.bytes,&self.anchor)?)}
    pub(super) fn validate(&self)->Result<(),CpuHostError>{
        self.memory()?;
        match &self.last {
            None if self.anchor.generation==0=>Ok(()),
            Some(last)=>{
                if last.scores.is_scripted_mechanism()!=(self.is_scripted()&&self.anchor.last_sequence<=2){return Err(CpuHostError::State("scripted/source owner mismatch"));}
                let prior=last.scores.prior_anchor();
                if prior.organism!=self.anchor.organism || prior.phenotype!=self.anchor.phenotype
                    || prior.lineage!=self.anchor.lineage || prior.generation.checked_add(1)!=Some(self.anchor.generation)
                    || prior.last_sequence.checked_add(1)!=Some(self.anchor.last_sequence){
                    return Err(CpuHostError::State("joint source/episode boundary mismatch"));}
                last.scores.physical_selection(&last.action)?;Ok(())
            },
            _=>Err(CpuHostError::State("joint incomplete selection")),
        }
    }
    pub(super) fn validate_source(&self,state:&GroupedResidentV1,f:&CpuFoundationTrainer,n:&CpuOrganismState)->Result<(),CpuHostError>{
        self.validate()?;
        let Some(last)=&self.last else{return Ok(());};
        let m=state.motor.last_receipt.as_ref().ok_or(CpuHostError::State("missing joint native receipt"))?;
        let checkpoint=n.checkpoint()?;let offsets=n.effective_offsets(f.phenotype())?;
        let actual=OptionalVocalSourceV1::from_forward(checkpoint.organism_id,m.tick,f.phenotype().phenotype_hash(),
            m.frame_digest,checkpoint.dispatch_generation,checkpoint.active_activation_side,&checkpoint.neural.activations,
            &offsets,decode_cpu_speech(f,&checkpoint.neural.activations,&offsets)?)?;
        last.scores.validate_source(&actual)?;last.scores.validate_native(&m.native.scores)?;
        if checkpoint.dispatch_generation!=self.anchor.last_sequence{return Err(CpuHostError::State("joint dispatch mismatch"));}Ok(())
    }
}
pub(in crate::cpu::host) struct JointOptionalPolicyV2;
impl GroupedPolicyStrategy for JointOptionalPolicyV2 {
    type Action=JointOptionalActionV2;
    const OPTIONAL:bool=true;const JOINT:bool=true;
    const MAGIC:&'static[u8]=NORMALIZED_MAGIC;
    const LINEAGE:&'static str=LINEAGE;
    const POLICY:&'static str=JOINT_OPTIONAL_POLICY_V2;
    fn select(f:&CpuFoundationTrainer,r:&mut Resident,frame:&PerceptionFrame,_output:&CpuDecisionOutput,
        seed:u32,counter:u32,t:f64,recall:&FinalizedMemoryRecall)->Result<(Self::Action,u16,[Option<u16>;6],Option<SpeechMotorPayload>),CpuHostError>{
        let source=r.neural.optional_vocal_source()?.clone();
        let sequence=ExperienceSequenceId(r.next_sequence);
        let state=r.grouped.as_mut().ok_or(CpuHostError::State("missing joint grouped owner"))?;
        let joint=state.joint_episode.as_mut().ok_or(CpuHostError::State("missing joint episode owner"))?;
        let native=&state.motor.last_receipt.as_ref().ok_or(CpuHostError::State("missing joint source"))?.native.scores;
        let scores=JointOptionalScoresV2::bind(f.phenotype(),frame,native,source,sequence,&joint.memory()?,recall.context().clone())?;
        #[cfg(test)]
        let scores=if let Some(targets)=joint.mechanism_targets.filter(|_|joint.anchor.last_sequence<2) {scores.with_scripted_mechanism(targets)?}else{scores};
        let action=scores.sample(seed,counter,t)?;let(index,motors)=scores.physical_selection(&action)?;
        let speech=if motors[3].is_some(){scores.source().speech()?}else{None};
        joint.last=Some(JointSelectionV2{scores,action:action.clone()});Ok((action,index,motors,speech))
    }
    fn stage(r:&mut Resident,p:&BrainPhenotype,a:&Self::Action,b:CpuDecisionBinding)->Result<(),CpuHostError>{
        let state=r.grouped.as_ref().ok_or(CpuHostError::State("missing joint owner"))?;
        let last=state.joint_episode.as_ref().and_then(|s|s.last.as_ref()).ok_or(CpuHostError::State("missing joint selection"))?;
        if last.action!=*a{return Err(CpuHostError::State("joint staged sample mismatch"));}
        last.scores.validate_native(&state.motor.last_receipt.as_ref().unwrap().native.scores)?;
        Ok(r.neural.stage_joint_optional_closed_selection(p,a,&last.scores,b)?)
    }
    fn close(n:&mut CpuOrganismState,f:&CpuFoundationTrainer,p:&ExperiencePatch,r:&NeuralReceptorFrame)->Result<(),CpuHostError>{
        // Same Optional source producer and exactly one original sealed biology credit.
        Ok(n.close_optional_vocal_outcome(f,p,r)?)
    }
    fn observe(r:&mut Resident,patch:&ExperiencePatch,frame:&PerceptionFrame)->Result<(),CpuHostError>{
        let joint=r.grouped.as_mut().and_then(|s|s.joint_episode.as_mut()).ok_or(CpuHostError::State("missing joint write owner"))?;
        let mut memory=joint.memory()?;memory.observe(patch,frame)?;
        (joint.bytes,joint.anchor)=memory.checkpoint()?;joint.validate()
    }
}

#[derive(Debug,Clone,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
struct OuterV2 {schema:u16,lineage:String,policy:String,inner:String,owner_digest:[u64;4]}
pub struct CpuJointOptionalM2HostV2 {inner:CpuGroupedM2HostV1}
#[derive(Debug,Clone)]
pub struct CpuJointOptionalM2HostCheckpointV2 {payload:OuterV2}
fn owners(payload:&GroupedPayloadV1)->Result<[u64;4],CpuHostError>{
    json_digest(b"ALIFE-CANONICAL-TARGETLESS-CUE-V3-JOINT-OPTIONAL-OWNERS-V2",&payload.controllers.iter().map(|(&id,s)|(id,&s.joint_episode)).collect::<Vec<_>>())
}
fn encode_inner(mut p:GroupedPayloadV1)->Result<OuterV2,CpuHostError>{
    let owner_digest=owners(&p)?;
    p.schema_version=3;p.source_lineage=INNER_LINEAGE.into();p.policy=serde_json::to_string(&(JOINT_OPTIONAL_POLICY_V2,owner_digest))?;
    let mut bytes=INNER_MAGIC.to_vec();bytes.extend(serde_json::to_vec(&p)?);
    Ok(OuterV2{schema:2,lineage:LINEAGE.into(),policy:JOINT_OPTIONAL_POLICY_V2.into(),inner:String::from_utf8(bytes)
        .map_err(|_|CpuHostError::State("joint inner nonUTF8"))?,owner_digest})
}
fn decode_inner(o:&OuterV2)->Result<GroupedPayloadV1,CpuHostError>{
    if o.schema!=2||o.lineage!=LINEAGE||o.policy!=JOINT_OPTIONAL_POLICY_V2{return Err(CpuHostError::State("joint outer owner mismatch"));}
    let body=o.inner.as_bytes().strip_prefix(INNER_MAGIC).ok_or(CpuHostError::State("joint inner magic mismatch"))?;
    let metadata:serde_json::Value=serde_json::from_slice(body)?;
    if metadata["schema_version"]!=3||metadata["source_lineage"]!=INNER_LINEAGE
        ||metadata["policy"]!=serde_json::to_string(&(JOINT_OPTIONAL_POLICY_V2,o.owner_digest))? {
        return Err(CpuHostError::State("joint inner binding mismatch"));}
    let mut p:GroupedPayloadV1=serde_json::from_value(metadata.clone())?;p.restore_sampler_bits()?;
    if owners(&p)?!=o.owner_digest||serde_json::from_slice::<serde_json::Value>(&serde_json::to_vec(&p)?)?!=metadata{return Err(CpuHostError::State("joint noncanonical owner state"));}
    for s in p.controllers.values(){s.validate_policy::<JointOptionalPolicyV2>()?;}
    p.schema_version=1;p.source_lineage=LINEAGE.into();p.policy=JOINT_OPTIONAL_POLICY_V2.into();Ok(p)
}
impl CpuJointOptionalM2HostCheckpointV2 {
    pub fn encode(&self)->Result<Vec<u8>,CpuHostError>{let mut bytes=OUTER_MAGIC.to_vec();bytes.extend(serde_json::to_vec(&self.payload)?);Ok(bytes)}
    pub fn decode(bytes:&[u8])->Result<Self,CpuHostError>{
        let body=bytes.strip_prefix(OUTER_MAGIC).ok_or(CpuHostError::State("not joint optional host"))?;
        let payload:OuterV2=serde_json::from_slice(body)?;decode_inner(&payload)?;
        let result=Self{payload};if result.encode()?!=bytes{return Err(CpuHostError::State("joint outer canonical mismatch"));}Ok(result)
    }
}
impl CpuJointOptionalM2HostV2 {
    pub fn new_prepared<T,E:std::fmt::Display>(game:CanonicalNewGame,founder:CpuFoundationTrainer,inputs:PhenotypeCompilerInputs,
        seed:u32,mode:MediationModeV1,prepare:impl FnOnce(&mut HeadlessWorld)->Result<T,E>)->Result<(Self,T),CpuHostError>{
        let(inner,result)=CpuGroupedM2HostV1::new_prepared_policy::<JointOptionalPolicyV2,T,E>(game,founder,inputs,seed,mode,prepare)?;
        Ok((Self{inner},result))
    }
    pub fn checkpoint(&self)->Result<CpuJointOptionalM2HostCheckpointV2,CpuHostError>{
        Ok(CpuJointOptionalM2HostCheckpointV2{payload:encode_inner(self.inner.checkpoint_payload::<JointOptionalPolicyV2>()?)?})
    }
    pub fn restore(c:CpuJointOptionalM2HostCheckpointV2,inputs:&PhenotypeCompilerInputs,mode:MediationModeV1)->Result<Self,CpuHostError>{
        let wire=c.encode()?;let c=CpuJointOptionalM2HostCheckpointV2::decode(&wire)?;let p=decode_inner(&c.payload)?;
        let mut normalized=NORMALIZED_MAGIC.to_vec();normalized.extend(serde_json::to_vec(&p)?);
        let inner=CpuGroupedM2HostV1::restore_payload::<JointOptionalPolicyV2>(p,inputs,mode,normalized)?;
        let result=Self{inner};if result.checkpoint()?.encode()?!=wire{return Err(CpuHostError::State("joint cold rewrite"));}Ok(result)
    }
    pub fn world(&self)->&HeadlessWorld{self.inner.world()}
    pub fn step(&mut self,t:f32)->Result<CpuGroupedM2HostStepV1<JointOptionalActionV2>,CpuHostError>{
        self.inner.host.grouped_policy_step::<JointOptionalPolicyV2>(&self.inner.founder,t)
    }
    pub fn step_research_observed(&mut self,t:f32)->Result<CpuGroupedM2ResearchStepV1<JointOptionalActionV2>,CpuHostError>{
        self.inner.host.grouped_policy_step_observed::<JointOptionalPolicyV2>(&self.inner.founder,t)
    }
    pub fn actor_optimization(&mut self)->Result<(),CpuHostError>{Err(CpuHostError::State("joint policy optimizer closed"))}
    pub fn waking_synaptic_plasticity(&mut self)->Result<(),CpuHostError>{Err(CpuHostError::State("joint policy synapses closed"))}
    pub fn synaptic_sleep_consolidation(&mut self)->Result<(),CpuHostError>{Err(CpuHostError::State("joint policy synaptic sleep closed"))}
}

// Explicit separate test owner. Production builds contain neither this strategy
// nor a source of scripted-mechanism action evidence. No sampler witness is forged.
#[cfg(test)]
struct ScriptedJointMechanismPolicy;
#[cfg(test)]
impl GroupedPolicyStrategy for ScriptedJointMechanismPolicy {
    type Action=JointOptionalActionV2;
    const OPTIONAL:bool=true;const JOINT:bool=true;const SCRIPTED:bool=true;
    const MAGIC:&'static[u8]=b"TEST-ONLY-JOINT-MECHANISM";
    const LINEAGE:&'static str="test-only-registered-joint-mechanism";
    const POLICY:&'static str="scripted-intervention-not-sampled-policy";
    fn select(f:&CpuFoundationTrainer,r:&mut Resident,frame:&PerceptionFrame,o:&CpuDecisionOutput,seed:u32,counter:u32,t:f64,recall:&FinalizedMemoryRecall)
        ->Result<(Self::Action,u16,[Option<u16>;6],Option<SpeechMotorPayload>),CpuHostError>{JointOptionalPolicyV2::select(f,r,frame,o,seed,counter,t,recall)}
    fn stage(r:&mut Resident,p:&BrainPhenotype,a:&Self::Action,b:CpuDecisionBinding)->Result<(),CpuHostError>{JointOptionalPolicyV2::stage(r,p,a,b)}
    fn close(n:&mut CpuOrganismState,f:&CpuFoundationTrainer,p:&ExperiencePatch,r:&NeuralReceptorFrame)->Result<(),CpuHostError>{JointOptionalPolicyV2::close(n,f,p,r)}
    fn observe(r:&mut Resident,p:&ExperiencePatch,f:&PerceptionFrame)->Result<(),CpuHostError>{JointOptionalPolicyV2::observe(r,p,f)}
}

#[cfg(test)]
#[path="joint_episode_host_tests.rs"]
mod tests;
