//! Fresh V2 meal association over immutable V1 sealed source storage.
//! No V1 import/migration API. Future grip and consumption remain Unknown.
//! Admitted contacted Eat sources may be acquisition or other non-consumption
//! events. Only each sealed source consumed fact establishes actual ingestion.
use super::*;
pub(crate) const MEAL_CUE_OWNER_V2:&str="fresh-meal-kinematic-cue-joint-v2/contacted-eat/observed-kernel/profile5/grip-unknown/no-migration";
#[derive(Debug,Clone)]
pub(crate) struct FreshMealCueMemoryV2 { legacy:FreshVisibleCueMemoryV1 }
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
struct MealCueWireV2 {schema:u16,owner:String,storage:CueWire}
impl FreshMealCueMemoryV2 {
    pub(crate) fn fresh(owner:OrganismId,phenotype:PhenotypeHash,fresh_lineage:[u64;4])->Result<Self,ScaffoldContractError>{
        if fresh_lineage==[0;4]{return Err(invalid());}
        let mut h=blake3::Hasher::new();h.update(MEAL_CUE_OWNER_V2.as_bytes());
        for word in fresh_lineage{h.update(&word.to_le_bytes());}
        let digest=h.finalize();let lineage=std::array::from_fn(|i|u64::from_le_bytes(digest.as_bytes()[i*8..i*8+8].try_into().unwrap()));
        Ok(Self{legacy:FreshVisibleCueMemoryV1::fresh(owner,phenotype,lineage)?})
    }
    pub(crate) fn observe(&mut self,patch:&ExperiencePatch,frame:&PerceptionFrame)->Result<(),ScaffoldContractError>{
        self.legacy.observe(patch,frame)
    }
    pub(crate) fn checkpoint(&self)->Result<(Vec<u8>,JointEpisodeAnchorV1),ScaffoldContractError>{
        let(legacy_bytes,mut anchor)=self.legacy.checkpoint()?;
        let storage:CueWire=serde_json::from_slice(&legacy_bytes).map_err(|_|invalid())?;
        let bytes=serde_json::to_vec(&MealCueWireV2{schema:2,owner:MEAL_CUE_OWNER_V2.into(),storage}).map_err(|_|invalid())?;
        if bytes.len()>MAX_CUE_WIRE_BYTES{return Err(invalid());}
        anchor.policy=MEAL_CUE_OWNER_V2.into();anchor.digest=*blake3::hash(&bytes).as_bytes();Ok((bytes,anchor))
    }
    pub(crate) fn restore(bytes:&[u8],anchor:&JointEpisodeAnchorV1)->Result<Self,ScaffoldContractError>{
        if bytes.len()>MAX_CUE_WIRE_BYTES||anchor.policy!=MEAL_CUE_OWNER_V2||*blake3::hash(bytes).as_bytes()!=anchor.digest{return Err(invalid());}
        let wire:MealCueWireV2=serde_json::from_slice(bytes).map_err(|_|invalid())?;
        if wire.schema!=2||wire.owner!=MEAL_CUE_OWNER_V2||wire.storage.owner!=VISIBLE_CUE_JOINT_OWNER_V1{return Err(invalid());}
        // V1's original frame/source/sequence/owner validation is reused, not bypassed.
        // This internal encoding is never accepted as a V2 input on its own.
        let legacy_bytes=serde_json::to_vec(&wire.storage).map_err(|_|invalid())?;
        let mut legacy_anchor=anchor.clone();legacy_anchor.policy=VISIBLE_CUE_JOINT_OWNER_V1.into();
        legacy_anchor.digest=*blake3::hash(&legacy_bytes).as_bytes();
        let result=Self{legacy:FreshVisibleCueMemoryV1::restore(&legacy_bytes,&legacy_anchor)?};
        if result.checkpoint()?.1!=*anchor{return Err(invalid());}Ok(result)
    }
    pub(crate) fn sleep_joint_sources(&self)->&[JointEpisodeV1]{self.legacy.sleep_joint_sources()}
    // Frozen V1 controls. These never call the V2 matcher.
    pub(crate) fn expected_whole_event(&self,frame:&PerceptionFrame,bundle:&MotorCommandBundle,mode:LookupModeV1)->Result<Option<WholeEventExpectationV1>,ScaffoldContractError>{
        self.legacy.expected_whole_event(frame,bundle,mode)
    }
    pub(crate) fn expected_graded_joint_value(&self,bundle:&MotorCommandBundle,frame:&PerceptionFrame)->Result<Option<f32>,ScaffoldContractError>{
        self.legacy.expected_graded_joint_value(bundle,frame)
    }
    pub(crate) fn recall_joint(&self,bundle:&MotorCommandBundle,frame:&PerceptionFrame)->Result<Vec<&JointEpisodeV1>,ScaffoldContractError>{self.legacy.recall_joint(bundle,frame)}
    pub(crate) fn expected_meal_joint_value_v2(&self,bundle:&MotorCommandBundle,frame:&PerceptionFrame)->Result<Option<f32>,ScaffoldContractError>{
        if self.legacy.owner_domain!=VISIBLE_CUE_JOINT_OWNER_V1{return Err(invalid());}
        let Ok(query)=ObservedJoint::capture(frame,bundle)else{return Ok(None);};
        let mut values=Vec::new();
        for(record,e)in self.legacy.cues.iter().zip(self.legacy.exact.sleep_joint_sources()){
            if record.sequence!=e.sequence.raw(){return Err(invalid());}
            if let Some(w)=record.observed.as_ref().and_then(|s|s.meal_weight_v2(&query,record.consumed_channel)){
                values.push((e.joint_experienced_valence.raw(),w));
            }
        }
        attenuated_signed_mean(&values)
    }
    #[cfg(test)]
    pub(crate) fn observe_without_cue_budget(&mut self,patch:&ExperiencePatch,frame:&PerceptionFrame)->Result<(),ScaffoldContractError>{self.legacy.observe_without_cue_budget(patch,frame)}
    #[cfg(test)]
    pub(crate) fn diagnose_two_sources(&self,sources:&[(u64,&PerceptionFrame)],frame:&PerceptionFrame,bundle:&MotorCommandBundle)->Result<serde_json::Value,ScaffoldContractError>{self.legacy.diagnose_two_sources(sources,frame,bundle)}
    #[cfg(test)]
    pub(crate) fn matched_readouts_v2(&self,frame:&PerceptionFrame,bundle:&MotorCommandBundle)->Result<serde_json::Value,ScaffoldContractError>{
        if self.legacy.cues.len()>2{return Err(invalid());}
        let query=ObservedJoint::capture(frame,bundle)?;
        let mut rows=Vec::new();
        for(record,e)in self.legacy.cues.iter().zip(self.sleep_joint_sources()){
            if record.sequence!=e.sequence.raw(){return Err(invalid());}
            rows.push(serde_json::json!({"sequence":record.sequence,"source_consumed":e.consumed.is_some(),
                "signed_joint_valence":e.joint_experienced_valence.raw(),
                "v1_graded_weight":record.observed.as_ref().and_then(|s|s.graded_weight(&query,record.consumed_channel)),
                "v2_meal_weight":record.observed.as_ref().and_then(|s|s.meal_weight_v2(&query,record.consumed_channel))}));
        }
        let(v2_bytes,v2_anchor)=self.checkpoint()?;let(v1_bytes,v1_anchor)=self.legacy.checkpoint()?;
        if FreshVisibleCueMemoryV1::restore(&v2_bytes,&v2_anchor).is_ok()||Self::restore(&v1_bytes,&v1_anchor).is_ok(){return Err(invalid());}
        let restored=Self::restore(&v2_bytes,&v2_anchor)?;
        let v1=self.expected_graded_joint_value(bundle,frame)?;let v2=self.expected_meal_joint_value_v2(bundle,frame)?;
        if restored.checkpoint()?.0!=v2_bytes||restored.sleep_joint_sources()!=self.sleep_joint_sources()
            ||restored.expected_graded_joint_value(bundle,frame)?!=v1||restored.expected_meal_joint_value_v2(bundle,frame)?!=v2{return Err(invalid());}
        let report=serde_json::json!({"schema":"meal-kinematic-matched-readouts-v2","comparison":"matched-engineering-regression-not-held-out",
            "sources":rows,"v1_graded_joint_value":v1,"v2_meal_joint_value":v2,"v1_v2_cross_load_rejected":true,
            "cold_readouts_equal":true,"future_grip":"Unknown","future_consumption":"Unknown"});
        if serde_json::to_vec(&report).map_err(|_|invalid())?.len()>32*1024{return Err(invalid());}Ok(report)
    }
}
impl ObservedJoint {
    fn meal_weight_v2(&self,b:&Self,consumed:Option<MotorChannel>)->Option<f32>{
        if self.owner!=b.owner||self.roles.len()!=b.roles.len()||self.coordination!=b.coordination
            ||self.drives.iter().zip(b.drives).any(|(x,y)|(x-y).abs()>0.15){return None;}
        let mut distance=0f64;
        for a in &self.roles {
            let z=b.roles.iter().find(|z|z.command.channel==a.command.channel)?;
            let x=&a.command;let y=&z.command;let route=graded_route(x)?;graded_route(y)?;
            if x.primitive!=y.primitive||x.payload!=y.payload||x.intensity!=y.intensity||x.duration_ticks!=y.duration_ticks||x.coordination_group!=y.coordination_group{return None;}
            if !entity_route_equivalent(x,y,LookupModeV1::ExecutorEntityRoutesV2)
                &&(x.direction!=y.direction||x.stand_off_distance!=y.stand_off_distance||x.confidence!=y.confidence){return None;}
            let af=&a.query.as_ref()?.features()[TARGET_START..TARGET_START+24];let bf=&z.query.as_ref()?.features()[TARGET_START..TARGET_START+24];
            // Strict chemical boundary; even subtle changed chemistry is not
            // generalized from a positive event without separate evidence.
            if (15..18).any(|i|af[i].to_bits()!=bf[i].to_bits()){return None;}
            let velocity_differs=(3..6).any(|i|(af[i]-bf[i]).abs()>0.02);
            if (19..21).any(|i|(af[i]-bf[i]).abs()>0.05){return None;}
            match route {
                GradedRoute::EntityEat=>{
                    // Actual entity-target ingestion resolves world position;
                    // bearing/fallback point is not its command operation.
                    // Reach and observed contact still constrain transfer.
                    if af[2]>MAX_INTERACTION_DISTANCE||bf[2]>MAX_INTERACTION_DISTANCE||af[18].to_bits()!=bf[18].to_bits(){return None;}
                    if consumed==Some(x.channel)&&(af[18]!=1.||bf[18]!=1.){return None;}
                    // Only reached AND contacted EntityEat ignores relative velocity.
                    // The raw witness is retained; this is association, not feasibility.
                    if (af[18]!=1.||bf[18]!=1.)&&velocity_differs{return None;}
                },
                GradedRoute::EntityMove|GradedRoute::EntityInspect=>{
                    if velocity_differs{return None;}
                    if (0..3).any(|i|(af[i]-bf[i]).abs()>if i<2{0.05}else{0.02})||af[18].to_bits()!=bf[18].to_bits(){return None;}
                }
            }
            for range in [6..9,9..12,12..15]{distance+=range.map(|i|(f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/3.;}
            // Full observed temperature range is[-1,1]; terrain range[0,1].
            // Keep both as nonzero, stronger context penalties, not nuisance
            // channels erased globally. Scales fixed before any evaluation.
            distance+=2.*((f64::from(af[21])-f64::from(bf[21]))/2.).powi(2);
            distance+=2.*(22..24).map(|i|(f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/2.;
        }
        for a in &self.roles{for other in &self.roles{
            let z=b.roles.iter().find(|z|z.command.channel==a.command.channel)?;
            let zo=b.roles.iter().find(|z|z.command.channel==other.command.channel)?;
            let target=|r:&ObservedRole|r.command.target.and_then(|t|t.entity);
            if(target(a)==target(other))!=(target(z)==target(zo)){return None;}
        }}
        Some((-distance).exp()as f32)
    }
}

#[cfg(test)]
#[path="meal_cue_v2_contracts.rs"]
mod contracts;
#[cfg(test)]
pub(crate) fn assert_pure_contracts_v2(){contracts::run();}

#[path="canonical_cue_v3.rs"]
pub(crate) mod canonical_cue_v3;
