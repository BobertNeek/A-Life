//! Read-only first-rejection diagnostics for the unchanged V3 matcher.
#![cfg(test)]
use super::*;

pub(crate) const FIRST_REJECTION_REASONS_V5: &[&str] = &[
    "QueryCaptureRejected", "SourceNotCanonical", "MissingSourceObservation", "Matched",
    "Owner", "RoleCount", "Coordination", "Drives", "MissingRole",
    "CanonicalSourceCommand", "CanonicalQueryCommand", "CanonicalCommandMismatch",
    "ObservationPresence", "SourceRoute", "QueryRoute", "OperationFields",
    "PhysicalCommandFields", "SourceObservation", "QueryObservation", "Chemistry",
    "Proprioception", "InteractionRange", "Contact", "ConsumedContact", "EatVelocity",
    "MoveInspectVelocity", "MoveInspectSpatialContact", "TopologyRole",
    "TopologyOtherRole", "TargetTopology",
];

fn role_v5(channel: MotorChannel) -> u16 {
    match channel {
        MotorChannel::Locomotion => 0,
        MotorChannel::Orientation => 1,
        MotorChannel::Manipulation => 2,
        MotorChannel::Vocal => 3,
        MotorChannel::Posture => 4,
        MotorChannel::SpeciesSpecific(id) => 256 + u16::from(id),
    }
}

fn equal_weight_bits_v5(a: Option<f32>, b: Option<f32>) -> bool {
    a.map(f32::to_bits) == b.map(f32::to_bits)
}

// Preserve production guard order, arithmetic order, and role iteration order.
// Compound guards keep one reason when a finer split would add no useful evidence.
fn first_rejection_v5(
    source: &ObservedJoint,
    b: &ObservedJoint,
    consumed: Option<MotorChannel>,
) -> (Option<f32>, Option<u16>, &'static str) {
    macro_rules! reject {
        ($role:expr, $reason:literal) => {
            return (None, $role, $reason)
        };
    }
    if source.owner != b.owner { reject!(None, "Owner"); }
    if source.roles.len() != b.roles.len() { reject!(None, "RoleCount"); }
    if source.coordination != b.coordination { reject!(None, "Coordination"); }
    if source.drives.iter().zip(b.drives).any(|(x, y)| (x-y).abs() > 0.15) {
        reject!(None, "Drives");
    }
    let mut distance = 0f64;
    for a in &source.roles {
        let role = Some(role_v5(a.command.channel));
        let Some(z) = b.roles.iter().find(|z| z.command.channel == a.command.channel) else {
            reject!(role, "MissingRole");
        };
        let x = &a.command;
        let y = &z.command;
        match (&a.query, &z.query) {
            (None, None) => {
                if !canonical_command_v3(x) { reject!(role, "CanonicalSourceCommand"); }
                if !canonical_command_v3(y) { reject!(role, "CanonicalQueryCommand"); }
                if x != y { reject!(role, "CanonicalCommandMismatch"); }
                continue;
            },
            (Some(_), Some(_)) => {},
            _ => reject!(role, "ObservationPresence"),
        }
        let Some(route) = graded_route(x) else { reject!(role, "SourceRoute"); };
        if graded_route(y).is_none() { reject!(role, "QueryRoute"); }
        if x.primitive != y.primitive || x.payload != y.payload || x.intensity != y.intensity
            || x.duration_ticks != y.duration_ticks || x.coordination_group != y.coordination_group {
            reject!(role, "OperationFields");
        }
        if !entity_route_equivalent(x, y, LookupModeV1::ExecutorEntityRoutesV2)
            && (x.direction != y.direction || x.stand_off_distance != y.stand_off_distance || x.confidence != y.confidence) {
            reject!(role, "PhysicalCommandFields");
        }
        let Some(aq) = a.query.as_ref() else { reject!(role, "SourceObservation"); };
        let af = &aq.features()[TARGET_START..TARGET_START+24];
        let Some(bq) = z.query.as_ref() else { reject!(role, "QueryObservation"); };
        let bf = &bq.features()[TARGET_START..TARGET_START+24];
        if (15..18).any(|i| af[i].to_bits() != bf[i].to_bits()) { reject!(role, "Chemistry"); }
        let velocity_differs = (3..6).any(|i| (af[i]-bf[i]).abs() > 0.02);
        if (19..21).any(|i| (af[i]-bf[i]).abs() > 0.05) { reject!(role, "Proprioception"); }
        match route {
            GradedRoute::EntityEat => {
                if af[2] > MAX_INTERACTION_DISTANCE || bf[2] > MAX_INTERACTION_DISTANCE {
                    reject!(role, "InteractionRange");
                }
                if af[18].to_bits() != bf[18].to_bits() { reject!(role, "Contact"); }
                if consumed == Some(x.channel) && (af[18] != 1. || bf[18] != 1.) {
                    reject!(role, "ConsumedContact");
                }
                if (af[18] != 1. || bf[18] != 1.) && velocity_differs { reject!(role, "EatVelocity"); }
            },
            GradedRoute::EntityMove | GradedRoute::EntityInspect => {
                if velocity_differs { reject!(role, "MoveInspectVelocity"); }
                if (0..3).any(|i| (af[i]-bf[i]).abs() > if i < 2 { 0.05 } else { 0.02 })
                    || af[18].to_bits() != bf[18].to_bits() {
                    reject!(role, "MoveInspectSpatialContact");
                }
            },
        }
        for range in [6..9, 9..12, 12..15] {
            distance += range.map(|i| (f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>() / 3.;
        }
        distance += 2.*((f64::from(af[21])-f64::from(bf[21]))/2.).powi(2);
        distance += 2.*(22..24).map(|i| (f64::from(af[i])-f64::from(bf[i])).powi(2)).sum::<f64>()/2.;
    }
    for a in &source.roles {
        for other in &source.roles {
            let role = Some(role_v5(a.command.channel));
            let Some(z) = b.roles.iter().find(|z| z.command.channel == a.command.channel) else {
                reject!(role, "TopologyRole");
            };
            let Some(zo) = b.roles.iter().find(|z| z.command.channel == other.command.channel) else {
                reject!(role, "TopologyOtherRole");
            };
            let target = |r: &ObservedRole| r.command.target.and_then(|t| t.entity);
            if (target(a) == target(other)) != (target(z) == target(zo)) {
                reject!(role, "TargetTopology");
            }
        }
    }
    (Some((-distance).exp() as f32), None, "Matched")
}

impl FreshCanonicalCueMemoryV3 {
    pub(crate) fn diagnostic_first_rejections_v5(
        &self,
        f: &PerceptionFrame,
        b: &MotorCommandBundle,
    ) -> Result<serde_json::Value, ScaffoldContractError> {
        // Diagnose the two literal retained sources, never reconstructed observations.
        if self.legacy.legacy.cues.len() != 2 || self.sleep_joint_sources().len() != 2 {
            return Err(invalid());
        }
        let query = capture_canonical_v3(f, b).ok();
        let mut rows = vec![];
        let mut values = vec![];
        for (c, e) in self.legacy.legacy.cues.iter().zip(self.sleep_joint_sources()) {
            if c.sequence != e.sequence.raw() { return Err(invalid()); }
            let canonical_source = self.canonical_sequences.contains(&c.sequence);
            let (weight, first_role, first_reason) = match query.as_ref() {
                None => (None, None, "QueryCaptureRejected"),
                Some(_) if !canonical_source => (None, None, "SourceNotCanonical"),
                Some(q) => match c.observed.as_ref() {
                    None => (None, None, "MissingSourceObservation"),
                    Some(s) => {
                        let diagnostic = first_rejection_v5(s, q, c.consumed_channel);
                        let production = s.canonical_weight_v3(q, c.consumed_channel);
                        if !equal_weight_bits_v5(diagnostic.0, production) { return Err(invalid()); }
                        diagnostic
                    },
                },
            };
            if !FIRST_REJECTION_REASONS_V5.contains(&first_reason) { return Err(invalid()); }
            if let Some(w) = weight { values.push((e.joint_experienced_valence.raw(), w)); }
            rows.push(serde_json::json!({
                "sequence": c.sequence,
                "source_consumed": e.consumed.is_some(),
                "signed_joint_valence": e.joint_experienced_valence.raw(),
                "canonical_source": canonical_source,
                "v3_weight": weight,
                "first_role": first_role,
                "first_reason": first_reason,
            }));
        }
        let joint_value = attenuated_signed_mean(&values)?;
        let production_joint_value = self.expected_canonical_joint_value_v3(b, f)?;
        if !equal_weight_bits_v5(joint_value, production_joint_value) { return Err(invalid()); }
        Ok(serde_json::json!({
            "query_capture_success": query.is_some(),
            "sources": rows,
            "v3_joint_value": joint_value,
        }))
    }
}
