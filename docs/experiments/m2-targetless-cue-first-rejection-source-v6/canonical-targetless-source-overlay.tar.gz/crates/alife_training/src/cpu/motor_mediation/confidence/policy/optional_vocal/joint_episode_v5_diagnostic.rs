//! Read-only full-support diagnostics. No new source forward or world branch.
use super::*;
use std::collections::BTreeMap;

fn value_v5(v: &serde_json::Value) -> Result<Option<f64>, TrainingError> {
    if v.is_null() { return Ok(None); }
    let x = v.as_f64().ok_or_else(invalid)?;
    if !x.is_finite() || !(-1.0..=1.0).contains(&x) { return Err(invalid()); }
    Ok(Some(x))
}
fn count_v5(v: &serde_json::Value) -> Result<u64, TrainingError> {
    v.as_u64().ok_or_else(invalid)
}

impl JointOptionalScoresV2 {
    pub(crate) fn diagnose_full_support_v5(
        &self,
        actual: &JointOptionalActionV2,
    ) -> Result<serde_json::Value, TrainingError> {
        if self.is_scripted_mechanism()
            || self.memory_anchor.last_sequence != 2
            || self.sequence.raw() != 3
            || self.base.source.dispatch_generation != 3
        { return Err(invalid()); }
        // These are two additional administrative enumerations of the same support.
        let on = self.rows(actual.temperature())?;
        let off = self.rows_with_reader(actual.temperature(), CueReaderV3::Off)?;
        let n = on.len();
        if n != 1330 || off.len() != n
            || on.iter().zip(&off).any(|(a,b)| a.bundle != b.bundle || a.base.to_bits() != b.base.to_bits()
                || a.representative != b.representative || a.motors != b.motors || a.operation != b.operation)
        { return Err(invalid()); }
        let (selected_on, z_on, support_digest) = self.choose_rows_v3(&on, actual.seed, actual.counter)?;
        let (_, z_off, _) = self.choose_rows_v3(&off, actual.seed, actual.counter)?;
        let selected_row = &on[selected_on];
        let selected_bundle_mass = on.iter().filter(|r|r.bundle == selected_row.bundle)
            .map(|r|(r.log_mass-z_on).exp()).sum::<f64>();
        let binding: [u8;32] = Sha256::digest(serde_json::to_vec(self).map_err(|_|invalid())?).into();
        if selected_on != actual.selected_index || actual.support_count != n
            || actual.policy != JOINT_OPTIONAL_POLICY_V2 || actual.binding != binding
            || !selected_bundle_mass.is_finite() || selected_bundle_mass <= 0.0
            || actual.bundle_log_probability_bits != selected_bundle_mass.ln().to_bits()
            || support_digest != actual.support_digest || actual.selection_rule != "AUTONOMOUS-JOINT-RNG"
            || actual.representative != selected_row.representative || actual.motors != selected_row.motors
            || actual.operation != selected_row.operation
            || actual.potential_bits != selected_row.potential.to_bits()
            || actual.base_log_probability_bits != selected_row.base.to_bits()
            || actual.joint_log_probability_bits != (selected_row.log_mass-z_on).to_bits()
        { return Err(invalid()); }
        let memory = JointEpisodeMemoryV1::restore(&self.memory_bytes, &self.memory_anchor)?;
        let sources = memory.sleep_joint_sources();
        if sources.len() != 2 { return Err(invalid()); }
        let mut histograms: [BTreeMap<(Option<u16>, String), usize>; 2] = std::array::from_fn(|_| BTreeMap::new());
        let mut source_counts = [[0_usize; 5]; 2];
        // Overall values: None, negative, exactly zero, positive.
        let mut values = [0_usize; 4];
        let mut capture_successes = 0_usize;
        let mut mirror_checks = 0_usize;
        let mut eat_rows = 0_usize;
        let mut eat_matching = 0_usize;
        let mut eat_nonzero = 0_usize;
        let mut max_row_delta = 0_f64;
        let mut kl = 0_f64;
        let mut sum_on = 0_f64;
        let mut sum_off = 0_f64;
        let mut on_underflows = 0_usize;
        let mut off_underflows = 0_usize;
        let mut bundle_mass: BTreeMap<[u64;4], (f64,f64)> = BTreeMap::new();
        for (a,b) in on.iter().zip(&off) {
            let bundle = self.bundle(a.representative, a.motors, a.operation)?;
            let eat = bundle.channels.iter().any(|c| c.channel == MotorChannel::Manipulation
                && c.primitive.raw() == 210 && c.target.and_then(|t|t.entity) == Some(WorldEntityId(5)));
            if eat { eat_rows += 1; }
            // Each call checks the mirror against the literal production matcher.
            let report = memory.diagnostic_first_rejections_v5(&self.frame, &bundle)?;
            let capture = report["query_capture_success"].as_bool().ok_or_else(invalid)?;
            if capture { capture_successes += 1; }
            let value = value_v5(&report["v3_joint_value"])?;
            if value.unwrap_or(0.0).to_bits() != a.potential.to_bits() { return Err(invalid()); }
            let bucket = match value { None => 0, Some(x) if x < 0.0 => 1, Some(x) if x > 0.0 => 3, Some(_) => 2 };
            values[bucket] += 1;
            if eat && value.is_some() { eat_matching += 1; }
            if eat && value.is_some_and(|v|v != 0.0) { eat_nonzero += 1; }
            let source_rows = report["sources"].as_array().ok_or_else(invalid)?;
            if source_rows.len() != 2 { return Err(invalid()); }
            for (i,row) in source_rows.iter().enumerate() {
                if count_v5(&row["sequence"])? != sources[i].sequence.raw()
                    || row["source_consumed"].as_bool() != Some(sources[i].consumed.is_some())
                    || row["signed_joint_valence"].as_f64() != Some(f64::from(sources[i].joint_experienced_valence.raw()))
                { return Err(invalid()); }
                let role = if row["first_role"].is_null() { None } else {
                    Some(u16::try_from(count_v5(&row["first_role"])?).map_err(|_|invalid())?)
                };
                let reason = row["first_reason"].as_str().ok_or_else(invalid)?;
                let weight = value_v5(&row["v3_weight"])?;
                if !matches!(reason, "QueryCaptureRejected" | "SourceNotCanonical" | "MissingSourceObservation") {
                    mirror_checks += 1;
                }
                if weight.is_some() != (reason == "Matched") || (weight.is_some() && role.is_some())
                { return Err(invalid()); }
                *histograms[i].entry((role, reason.to_owned())).or_insert(0) += 1;
                if let Some(w) = weight {
                    if w < 0.0 { return Err(invalid()); }
                    source_counts[i][0] += 1;
                    let contribution = f64::from(sources[i].joint_experienced_valence.raw()) * w;
                    source_counts[i][if contribution < 0.0 {1} else if contribution > 0.0 {3} else {2}] += 1;
                    if eat { source_counts[i][4] += 1; }
                }
            }
            let log_on = a.log_mass-z_on;
            let log_off = b.log_mass-z_off;
            if !log_on.is_finite() || !log_off.is_finite() { return Err(invalid()); }
            let p_on = log_on.exp();
            let p_off = log_off.exp();
            if p_on == 0.0 { on_underflows += 1; }
            if p_off == 0.0 { off_underflows += 1; }
            sum_on += p_on; sum_off += p_off;
            max_row_delta = max_row_delta.max((p_on-p_off).abs());
            kl += p_on * (log_on-log_off);
            let mass = bundle_mass.entry(a.bundle).or_insert((0.0,0.0));
            mass.0 += p_on; mass.1 += p_off;
        }
        if (sum_on-1.0).abs() > 1e-8 || (sum_off-1.0).abs() > 1e-8
            || !kl.is_finite() || kl < -1e-9 || values.iter().sum::<usize>() != n
        { return Err(invalid()); }
        let max_bundle_delta = bundle_mass.values().map(|(a,b)|(a-b).abs()).fold(0_f64,f64::max);
        let mut source_summaries = vec![];
        for i in 0..2 {
            if histograms[i].values().sum::<usize>() != n || histograms[i].len() > 128
                || source_counts[i][1..4].iter().sum::<usize>() != source_counts[i][0]
            { return Err(invalid()); }
            let first_rejections = histograms[i].iter().map(|((role,reason),count)|
                serde_json::json!({"role":role,"reason":reason,"count":count})).collect::<Vec<_>>();
            source_summaries.push(serde_json::json!({"sequence":sources[i].sequence.raw(),
                "source_consumed":sources[i].consumed.is_some(),"signed_joint_valence":sources[i].joint_experienced_valence.raw(),
                "matched_rows":source_counts[i][0],"negative_rows":source_counts[i][1],"zero_rows":source_counts[i][2],
                "positive_rows":source_counts[i][3],"second_root_eat_matched_rows":source_counts[i][4],
                "first_rejections":first_rejections}));
        }
        let (after_bytes, after_anchor) = memory.checkpoint()?;
        if after_bytes != self.memory_bytes || after_anchor != self.memory_anchor { return Err(invalid()); }
        let report = serde_json::json!({"schema":"canonical-targetless-full-support-first-rejection-v5",
            "support_kind":"production-rows-including-physical-bundle-aliases","support_count":n,
            "unique_bundle_count":bundle_mass.len(),"original_source_count":2,
            "query_capture_success_count":capture_successes,
            "value_counts":{"none":values[0],"negative":values[1],"zero":values[2],"positive":values[3]},
            "second_root_eat_rows":eat_rows,"second_root_eat_matching_rows":eat_matching,
            "second_root_eat_nonzero_rows":eat_nonzero,"sources":source_summaries,
            "probabilities":{"max_abs_row_on_off":max_row_delta,"max_abs_bundle_on_off":max_bundle_delta,
                "nominal_kl_on_off":kl,"kl_roundoff_tolerance":1e-9,"sum_on":sum_on,"sum_off":sum_off,
                "on_probability_underflow_rows":on_underflows,"off_probability_underflow_rows":off_underflows},
            "administrative_dose":{"additional_support_enumerations":2,"bundle_queries":n,
                "paired_source_admission_queries":2*n,"mirror_weight_equality_checks":mirror_checks,
                "diagnostic_production_weight_evaluations":2*mirror_checks,
                "production_value_equality_checks":n,"row_potential_equality_checks":n,
                "extra_native_forwards":0,"extra_world_intervals":0,"alternate_committed_paths":0},
            "source_dispatch_generation":self.base.source.dispatch_generation,"memory_last_sequence":self.memory_anchor.last_sequence,
            "decision_sequence":self.sequence.raw(),"frame_tick":self.frame.tick().raw(),"seed":actual.seed,"counter":actual.counter,
            "source_archive_unchanged":true,"future_grip":"Unknown","future_consumption":"Unknown"});
        if serde_json::to_vec(&report).map_err(|_|invalid())?.len() > 16*1024 { return Err(invalid()); }
        Ok(report)
    }
}
