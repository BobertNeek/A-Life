// Grouped M2 durable transport only. Checkpoint and science bytes remain opaque.
// Adapted from the qualified recovery-sleep V3 publication/recovery core.
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::Path,
};
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
pub const MAGIC: &[u8; 8] = b"ALGM2J01";
pub const MAX_PACKET: u64 = 8 * 1024 * 1024;
pub const MAX_TRACE_BYTES: u64 = 512 * 1024 * 1024;
pub const MAX_ARM_BYTES: u64 = 11 * 1024 * 1024 * 1024;
pub const MIN_FREE_BYTES: u64 = 4 * 1024 * 1024 * 1024;
pub const METADATA_RESERVE: u64 = 64 * 1024;
const MAX_METADATA: u64 = 16 * 1024;
fn hash(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Binding {
    pub schema: String,
    pub study_id: String,
    pub arm: usize,
    pub mode: String,
    pub seed: u64,
    pub sampling_seed: u32,
    pub initial_tick: u64,
    pub horizon: u64,
    pub temperature_bits: u32,
    pub host_source_commit: String,
    pub host_source_tree: String,
    pub driver_source_commit: String,
    pub driver_source_sha256: String,
    pub executable_sha256: String,
    pub protocol_sha256: String,
    pub qualification_sha256: String,
    pub preparation_sha256: String,
    pub source_manifest_sha256: String,
    pub inputs_sha256: String,
    pub initial_sha256: String,
    pub initial_matched_sha256: String,
    pub closure_sha256: String,
    pub source_headers: BTreeMap<String, String>,
    pub max_packet_bytes: u64,
    pub max_arm_bytes: u64,
    pub min_free_bytes: u64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Header {
    pub binding: Binding,
    pub offset: u64,
    pub tick_before: u64,
    pub tick_after: u64,
    pub previous_commit_sha256: String,
    pub checkpoint_sha256: String,
    pub trace_sha256: String,
    pub checkpoint_bytes: u64,
    pub trace_bytes: u64,
}
pub struct Packet {
    pub header: Header,
    pub checkpoint: Vec<u8>,
    pub trace: Vec<u8>,
    pub digest: String,
}
pub struct Recovery {
    pub next: u64,
    pub previous: String,
    pub checkpoint: Vec<u8>,
    pub trace: Vec<u8>,
    pub trace_bytes: u64,
    pub storage_bytes: u64,
    pub ignored_temps: usize,
}
pub fn unique() -> Result<String> {
    Ok(format!(
        "{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)?
            .as_nanos()
    ))
}
pub fn sync_dir(dir: &Path) -> Result<()> {
    File::open(dir)?.sync_all()?;
    Ok(())
}
pub fn publish(dir: &Path, name: &str, wire: &[u8]) -> Result<()> {
    publish_with_fault(dir, name, wire, 0)
}
pub fn publish_with_fault(dir: &Path, name: &str, wire: &[u8], fault: u8) -> Result<()> {
    regular_dir(dir)?;
    if !allowed_name(name)
        || name.starts_with(".tmp-")
        || wire.len() as u64
            > if packet_name(name) {
                MAX_PACKET
            } else {
                MAX_METADATA
            }
    {
        return Err("invalid publication name or oversized payload".into());
    }
    publish_atomic(dir, name, wire, fault)
}
/// Publish a caller-bounded preparation or export artifact outside the journal.
/// This does not relax the journal's recovery allowlist.
pub fn publish_artifact(dir: &Path, name: &str, bytes: &[u8], limit: u64) -> Result<()> {
    let mut parts = Path::new(name).components();
    let normal =
        matches!(parts.next(), Some(std::path::Component::Normal(_))) && parts.next().is_none();
    if !normal
        || name.contains('/')
        || name.contains('\\')
        || name.contains('\0')
        || name.starts_with(".tmp-")
        || name == "LOCK"
        || limit > MAX_ARM_BYTES
        || bytes.len() as u64 > limit
    {
        return Err("invalid artifact filename or payload bound".into());
    }
    publish_atomic(dir, name, bytes, 0)
}
fn publish_atomic(dir: &Path, name: &str, wire: &[u8], fault: u8) -> Result<()> {
    regular_dir(dir)?;
    // hard_link is an atomic CREATE-NEW publication: unlike POSIX rename it
    // cannot replace an existing committed packet, even after a racing check.
    // The same-directory temporary is synced first. Directory sync is checked.
    // Keep temps as evidence, including successful aliases (no extra data blocks).
    let tmp = dir.join(format!(".tmp-{}", unique()?));
    let mut f = OpenOptions::new().create_new(true).write(true).open(&tmp)?;
    f.write_all(wire)?;
    f.sync_all()?;
    if fault == 1 {
        return Err("fixed test: failure before publication".into());
    }
    fs::hard_link(&tmp, dir.join(name))?;
    if fault == 2 {
        return Err("fixed test: failure after publication before directory sync".into());
    }
    sync_dir(dir)?;
    Ok(())
}
pub fn bounded_read(path: &Path, limit: u64) -> Result<Vec<u8>> {
    if !fs::symlink_metadata(path)?.file_type().is_file() || fs::metadata(path)?.len() > limit {
        return Err(format!("not a bounded regular file: {}", path.display()).into());
    }
    let mut out = Vec::new();
    File::open(path)?
        .take(limit.checked_add(1).ok_or("read limit overflow")?)
        .read_to_end(&mut out)?;
    if out.len() as u64 > limit {
        return Err("file exceeds bounded read".into());
    }
    Ok(out)
}
pub fn make_packet(
    binding: &Binding,
    offset: u64,
    previous: &str,
    cp: &[u8],
    trace: &[u8],
) -> Result<Vec<u8>> {
    validate_binding(binding)?;
    if offset >= binding.horizon {
        return Err("interval outside horizon".into());
    }
    let tick_before = binding
        .initial_tick
        .checked_add(offset)
        .ok_or("tick overflow")?;
    let header = Header {
        binding: binding.clone(),
        offset,
        tick_before,
        tick_after: tick_before.checked_add(1).ok_or("tick overflow")?,
        previous_commit_sha256: previous.into(),
        checkpoint_sha256: hash(cp),
        trace_sha256: hash(trace),
        checkpoint_bytes: cp.len() as u64,
        trace_bytes: trace.len() as u64,
    };
    validate_trace(trace, &header)?;
    encode_packet(&header, cp, trace)
}
fn encode_packet(h: &Header, cp: &[u8], trace: &[u8]) -> Result<Vec<u8>> {
    validate_binding(&h.binding)?;
    let meta = serde_json::to_vec(h)?;
    let total = [meta.len(), cp.len(), trace.len()]
        .into_iter()
        .try_fold(32_usize, |sum, n| sum.checked_add(n))
        .ok_or("packet length overflow")?;
    if total as u64 > h.binding.max_packet_bytes || meta.len() > 16 * 1024 {
        return Err("packet size ceiling exceeded; interval unpublished".into());
    }
    let mut out = Vec::with_capacity(total);
    out.extend_from_slice(MAGIC);
    for n in [meta.len(), cp.len(), trace.len()] {
        out.extend_from_slice(&(n as u64).to_le_bytes());
    }
    out.extend_from_slice(&meta);
    out.extend_from_slice(cp);
    out.extend_from_slice(trace);
    if out.len() as u64 > h.binding.max_packet_bytes {
        return Err("packet size ceiling exceeded; interval unpublished".into());
    }
    Ok(out)
}
pub fn decode_packet(
    wire: &[u8],
    binding: &Binding,
    offset: u64,
    previous: &str,
) -> Result<Packet> {
    validate_binding(binding)?;
    let tick_before = binding
        .initial_tick
        .checked_add(offset)
        .ok_or("tick overflow")?;
    let tick_after = tick_before.checked_add(1).ok_or("tick overflow")?;
    if wire.len() < 32 || wire.len() as u64 > binding.max_packet_bytes || &wire[..8] != MAGIC {
        return Err("invalid packet prefix or size".into());
    }
    let lengths = [8, 16, 24].map(|p| u64::from_le_bytes(wire[p..p + 8].try_into().unwrap()));
    let sum = lengths
        .iter()
        .try_fold(32_u64, |a, b| a.checked_add(*b))
        .ok_or("packet length overflow")?;
    if sum != wire.len() as u64 || lengths[0] > 16 * 1024 {
        return Err("packet lengths differ".into());
    }
    let a = 32 + lengths[0] as usize;
    let b = a + lengths[1] as usize;
    let h: Header = serde_json::from_slice(&wire[32..a])?;
    if serde_json::to_vec(&h)? != wire[32..a]
        || &h.binding != binding
        || h.offset != offset
        || h.previous_commit_sha256 != previous
        || h.tick_before != tick_before
        || h.tick_after != tick_after
        || offset >= binding.horizon
        || h.checkpoint_bytes != lengths[1]
        || h.trace_bytes != lengths[2]
        || h.checkpoint_sha256 != hash(&wire[a..b])
        || h.trace_sha256 != hash(&wire[b..])
    {
        return Err("packet identity, order, hash or length mismatch".into());
    }
    validate_trace(&wire[b..], &h)?;
    Ok(Packet {
        header: h,
        checkpoint: wire[a..b].to_vec(),
        trace: wire[b..].to_vec(),
        digest: hash(wire),
    })
}
fn validate_trace(trace: &[u8], h: &Header) -> Result<()> {
    let rows = trace.split(|c| *c == b'\n').collect::<Vec<_>>();
    if rows.len() != 3 || !rows[2].is_empty() {
        return Err("packet needs both complete scientific rows".into());
    }
    let commit: Value = serde_json::from_slice(rows[0])?;
    let observation: Value = serde_json::from_slice(rows[1])?;
    if commit["schema"] != "grouped-m2-commit-v1"
        || observation["schema"] != "grouped-m2-observation-v1"
        || commit["checkpoint_sha256"] != h.checkpoint_sha256
        || commit["status"] != "committed"
        || observation["status"] != "observed"
        || commit["offset"] != h.offset
        || observation["offset"] != h.offset
        || commit["tick_before"] != h.tick_before
        || commit["tick_after"] != h.tick_after
        || observation["before"]["tick"] != h.tick_before
        || observation["after"]["tick"] != h.tick_after
        || !commit["decisions"].is_array()
        || !commit["consolidations"].is_u64()
    {
        return Err("scientific row identity or completeness mismatch".into());
    }
    Ok(())
}
/// Recover exact raw science for bounded qualification/export consumers.
pub fn recover(
    dir: &Path,
    binding: &Binding,
    initial: &[u8],
    validate_cp: impl Fn(&[u8], u64) -> Result<()>,
) -> Result<Recovery> {
    recover_impl(dir, binding, initial, validate_cp, true)
}
/// Validate every packet and scientific row, retaining only the latest checkpoint.
/// The returned trace is empty; trace_bytes still accounts for the entire prefix
/// and enforces its export ceiling. This is the bounded-memory primary resume path.
pub fn recover_without_trace(
    dir: &Path,
    binding: &Binding,
    initial: &[u8],
    validate_cp: impl Fn(&[u8], u64) -> Result<()>,
) -> Result<Recovery> {
    recover_impl(dir, binding, initial, validate_cp, false)
}
fn recover_impl(
    dir: &Path,
    binding: &Binding,
    initial: &[u8],
    validate_cp: impl Fn(&[u8], u64) -> Result<()>,
    retain_trace: bool,
) -> Result<Recovery> {
    regular_dir(dir)?;
    validate_binding(binding)?;
    if initial.len() as u64 > binding.max_packet_bytes || hash(initial) != binding.initial_sha256 {
        return Err("initial checkpoint changed".into());
    }
    let expected_manifest = serde_json::to_vec(binding)?;
    if bounded_read(&dir.join("MANIFEST.json"), 16 * 1024)? != expected_manifest {
        return Err("journal manifest changed".into());
    }
    if bounded_read(&dir.join("CLAIM.json"), MAX_METADATA)? != expected_manifest {
        return Err("fresh grouped-M2 guard claim differs from manifest".into());
    }
    validate_cp(initial, binding.initial_tick)?;
    let mut names = Vec::new();
    let mut entry_count = 0_u64;
    let mut storage_bytes = 0_u64;
    let mut ignored_temps = 0;
    // Charge every directory entry conservatively, even retained hardlink aliases.
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        entry_count += 1;
        if entry_count > binding.horizon.saturating_mul(2).saturating_add(128) {
            return Err("journal entry count exceeds bounded horizon allowance".into());
        }
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| "non-UTF8 journal name")?;
        let meta = fs::symlink_metadata(entry.path())?;
        if !meta.is_file() || meta.file_type().is_symlink() {
            return Err("journal contains nonregular entry".into());
        }
        if !allowed_name(&name)
            || meta.len()
                > if packet_name(&name) || name.starts_with(".tmp-") {
                    binding.max_packet_bytes
                } else {
                    MAX_METADATA
                }
        {
            return Err(format!("unknown or oversized journal entry: {name}").into());
        }
        storage_bytes = storage_bytes
            .checked_add(meta.len())
            .ok_or("storage overflow")?;
        if name.starts_with(".tmp-") {
            ignored_temps += 1;
            continue;
        }
        if name.ends_with(".packet") {
            names.push(name);
        } else if name != "CLAIM.json"
            && name != "MANIFEST.json"
            && name != "LOCK"
            && name != "BLOCKED-PUBLICATION"
            && !name.starts_with("PROCESS-")
            && name != "TERMINAL.json"
        {
            return Err(format!("unknown journal entry: {name}").into());
        }
    }
    if storage_bytes > binding.max_arm_bytes {
        return Err("journal exceeds storage ceiling".into());
    }
    bounded_read(&dir.join("LOCK"), 0)?;
    names.sort();
    let mut r = Recovery {
        next: 0,
        previous: hash(initial),
        checkpoint: initial.to_vec(),
        trace: Vec::new(),
        trace_bytes: 0,
        storage_bytes,
        ignored_temps,
    };
    for name in names {
        if name != format!("{:06}.packet", r.next) {
            return Err("duplicate, omitted or out-of-order committed packet".into());
        }
        let wire = bounded_read(&dir.join(name), binding.max_packet_bytes)?;
        let p = decode_packet(&wire, binding, r.next, &r.previous)?;
        validate_cp(&p.checkpoint, p.header.tick_after)?;
        // Every valid prefix must remain exportable, including no-trace resume.
        r.trace_bytes = checked_trace_len(r.trace_bytes, p.trace.len() as u64)?;
        r.next += 1;
        r.previous = p.digest;
        r.checkpoint = p.checkpoint;
        if retain_trace {
            append_trace(&mut r.trace, &p.trace)?;
        }
    }
    if dir.join("TERMINAL.json").exists() {
        let t: Value =
            serde_json::from_slice(&bounded_read(&dir.join("TERMINAL.json"), 16 * 1024)?)?;
        if t["schema"] != "grouped-m2-terminal-v1"
            || t["binding"] != serde_json::to_value(binding)?
            || t["committed_intervals"] != r.next
            || t["last_commit_sha256"] != r.previous
            || t["final_checkpoint_sha256"] != hash(&r.checkpoint)
            || t["tick"] != binding.initial_tick + r.next
            || !t["stop"].is_string()
        {
            return Err("terminal record differs from complete committed prefix".into());
        }
    }
    Ok(r)
}
pub fn lock(dir: &Path) -> Result<File> {
    regular_dir(dir)?;
    bounded_read(&dir.join("LOCK"), 0)?;
    let f = OpenOptions::new()
        .read(true)
        .write(true)
        .open(dir.join("LOCK"))?;
    f.try_lock()
        .map_err(|e| format!("journal already has an active writer: {e}"))?;
    Ok(f)
}
pub fn free_bytes(dir: &Path) -> Result<u64> {
    // POSIX df reports available blocks for this exact filesystem. Fail closed
    // on missing utility or unexpected output; no fragile ABI-specific statvfs.
    let out = std::process::Command::new("df")
        .args(["-Pk", "--"])
        .arg(dir)
        .env("LC_ALL", "C")
        .output()?;
    if !out.status.success() {
        return Err("free-space inspection failed".into());
    }
    let text = String::from_utf8(out.stdout)?;
    let row = text
        .lines()
        .last()
        .ok_or("missing df output")?
        .split_whitespace()
        .collect::<Vec<_>>();
    if row.len() < 6 {
        return Err("invalid df output".into());
    }
    Ok(row[3]
        .parse::<u64>()?
        .checked_mul(1024)
        .ok_or("df overflow")?)
}
pub fn resource_stop(b: &Binding, used: u64, free: u64) -> bool {
    validate_binding(b).is_err()
        || b.max_packet_bytes
            .checked_mul(2)
            .and_then(|n| n.checked_add(METADATA_RESERVE))
            .and_then(|n| used.checked_add(n))
            .is_none_or(|n| n > b.max_arm_bytes)
        || b.min_free_bytes
            .checked_add(b.max_packet_bytes)
            .is_none_or(|n| free < n)
}
pub fn terminal(dir: &Path, b: &Binding, r: &Recovery, reason: &str) -> Result<()> {
    validate_binding(b)?;
    if r.next > b.horizon {
        return Err("terminal exceeds horizon".into());
    }
    publish(
        dir,
        "TERMINAL.json",
        &serde_json::to_vec(
            &json!({"schema":"grouped-m2-terminal-v1","binding":b,"stop":reason,"committed_intervals":r.next,"last_commit_sha256":r.previous,"final_checkpoint_sha256":hash(&r.checkpoint),"tick":b.initial_tick+r.next}),
        )?,
    )
}
pub fn stop_after_failure(dir: &Path, b: &Binding, r: &Recovery, reason: &str) {
    if let Err(stop_error) = terminal(dir, b, r, reason) {
        let blocker = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(dir.join("BLOCKED-PUBLICATION"));
        if let Ok(f) = blocker {
            let _ = f.sync_all();
            let _ = sync_dir(dir);
        }
        eprintln!("STOP RECORD FAILURE: {stop_error}. Do not resume automatically; storage may be unable to persist the blocker. {reason}");
    }
}
pub fn record_publication_failure(
    dir: &Path,
    b: &Binding,
    r: &mut Recovery,
    cp: &[u8],
    packet: &[u8],
    reason: &str,
) -> Result<()> {
    let decoded = match decode_packet(packet, b, r.next, &r.previous) {
        Ok(p) if p.checkpoint == cp => p,
        _ => {
            stop_after_failure(
                dir,
                b,
                r,
                "invalid failed-publication packet; journal blocked",
            );
            return Err("invalid failed-publication packet".into());
        }
    };
    let mut trace_failure = None;
    let published = dir.join(format!("{:06}.packet", r.next));
    match fs::symlink_metadata(&published) {
        Ok(_) => {
            match bounded_read(&published, b.max_packet_bytes) {
                Ok(actual) if actual == packet => {}
                _ => {
                    stop_after_failure(
                        dir,
                        b,
                        r,
                        "conflicting publication destination; journal invalid",
                    );
                    return Err("publication destination conflicts or cannot be read".into());
                }
            }
            // A successful link is committed even when its directory sync failed.
            // Reconcile before emitting any terminal status; never replay it.
            r.next += 1;
            r.previous = decoded.digest;
            r.checkpoint = decoded.checkpoint;
            // Update durable prefix identity first. Aggregate memory exhaustion
            // must never erase a known-visible commit or cause its replay.
            match r.trace_bytes.checked_add(decoded.trace.len() as u64) {
                Some(total) => {
                    // Preserve the exact visible byte count even if an invalid
                    // caller allowed a publication beyond the export ceiling.
                    r.trace_bytes = total;
                    if total > MAX_TRACE_BYTES {
                        trace_failure =
                            Some("raw science exceeds 512 MiB aggregate memory cap".into());
                    }
                }
                None => trace_failure = Some("raw science length overflow".into()),
            }
            if trace_failure.is_none() {
                if let Err(error) = append_trace(&mut r.trace, &decoded.trace) {
                    trace_failure = Some(error.to_string());
                }
            }
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => {
            stop_after_failure(
                dir,
                b,
                r,
                "publication outcome cannot be inspected; journal blocked",
            );
            return Err(e.into());
        }
    }
    let stop_reason = match &trace_failure {
        Some(error) => format!("{reason}; raw science aggregation stopped: {error}"),
        None => reason.to_owned(),
    };
    stop_after_failure(dir, b, r, &stop_reason);
    // Count what actually exists, including a prelink temporary, a successful
    // link's retained alias, and all terminal/blocker publication evidence.
    // Do not assume a failed write produced zero bytes or exactly one temp.
    let (storage_bytes, ignored_temps) = storage_snapshot(dir, b)?;
    r.storage_bytes = storage_bytes;
    r.ignored_temps = ignored_temps;
    if let Some(error) = trace_failure {
        return Err(error.into());
    }
    Ok(())
}

fn checked_trace_len(current: u64, additional: u64) -> Result<u64> {
    let total = current
        .checked_add(additional)
        .ok_or("raw science length overflow")?;
    if total > MAX_TRACE_BYTES {
        return Err("raw science exceeds 512 MiB aggregate memory cap".into());
    }
    Ok(total)
}
fn append_trace(trace: &mut Vec<u8>, incoming: &[u8]) -> Result<()> {
    checked_trace_len(trace.len() as u64, incoming.len() as u64)?;
    // Bound before requesting allocation; avoid Vec's speculative growth factor.
    trace.try_reserve_exact(incoming.len())?;
    trace.extend_from_slice(incoming);
    Ok(())
}

fn storage_snapshot(dir: &Path, b: &Binding) -> Result<(u64, usize)> {
    regular_dir(dir)?;
    let mut storage_bytes = 0_u64;
    let mut ignored_temps = 0;
    for (index, entry) in fs::read_dir(dir)?.enumerate() {
        if index as u64 >= b.horizon.saturating_mul(2).saturating_add(128) {
            return Err("journal entry count exceeds bounded horizon allowance".into());
        }
        let entry = entry?;
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| "non-UTF8 journal name")?;
        let meta = fs::symlink_metadata(entry.path())?;
        if !meta.file_type().is_file() || !allowed_name(&name) {
            return Err("cannot account for nonregular or unknown journal entry".into());
        }
        let limit = if packet_name(&name) || name.starts_with(".tmp-") {
            b.max_packet_bytes
        } else {
            MAX_METADATA
        };
        if meta.len() > limit {
            return Err("oversized journal entry".into());
        }
        storage_bytes = storage_bytes
            .checked_add(meta.len())
            .ok_or("storage overflow")?;
        if name.starts_with(".tmp-") {
            ignored_temps += 1;
        }
    }
    Ok((storage_bytes, ignored_temps))
}

fn regular_dir(dir: &Path) -> Result<()> {
    if !fs::symlink_metadata(dir)?.file_type().is_dir() {
        return Err("journal path is not a real directory".into());
    }
    Ok(())
}
fn packet_name(name: &str) -> bool {
    name.len() == 13
        && name.ends_with(".packet")
        && name.as_bytes()[..6].iter().all(u8::is_ascii_digit)
}
fn allowed_name(name: &str) -> bool {
    if name.contains('/') || name.contains('\\') || name.len() > 128 {
        return false;
    }
    matches!(
        name,
        "MANIFEST.json" | "LOCK" | "CLAIM.json" | "BLOCKED-PUBLICATION" | "TERMINAL.json"
    ) || packet_name(name)
        || (name.starts_with("PROCESS-") && name.len() > 8)
        || (name.starts_with(".tmp-") && name.len() > 5)
}
fn validate_binding(b: &Binding) -> Result<()> {
    if b.schema != "grouped-m2-durable-v1"
        || b.study_id.is_empty()
        || b.horizon == 0
        || b.horizon > 1_000_000
        || b.initial_tick.checked_add(b.horizon).is_none()
        || b.max_packet_bytes == 0
        || b.max_packet_bytes > MAX_PACKET
        || b.max_arm_bytes == 0
        || b.max_arm_bytes > MAX_ARM_BYTES
        || b.min_free_bytes < MIN_FREE_BYTES
        || serde_json::to_vec(b)?.len() as u64 > MAX_METADATA
    {
        return Err("invalid grouped-M2 binding or resource bounds".into());
    }
    Ok(())
}
/// Fresh directory only. The claim is guard-only identity: it does not establish
/// a process start, a scientific decision, or an executed world interval.
/// Interrupted initialization is intentionally not repaired during resume.
pub fn init_journal(dir: &Path, b: &Binding) -> Result<()> {
    validate_binding(b)?;
    let manifest = serde_json::to_vec(b)?;
    fs::create_dir(dir)?;
    sync_dir(dir.parent().ok_or("journal parent missing")?)?;
    let f = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(dir.join("LOCK"))?;
    f.sync_all()?;
    publish(dir, "MANIFEST.json", &manifest)?;
    // CREATE-NEW hardlink preserves any unknown conflicting claim unchanged.
    fs::hard_link(dir.join("MANIFEST.json"), dir.join("CLAIM.json"))?;
    sync_dir(dir)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn binding() -> Binding {
        Binding {
            schema: "grouped-m2-durable-v1".into(),
            study_id: "transport-unit".into(),
            arm: 0,
            mode: "transport-only".into(),
            seed: 7,
            sampling_seed: 8,
            initial_tick: 10,
            horizon: 4,
            temperature_bits: 1.0_f32.to_bits(),
            host_source_commit: "host".into(),
            host_source_tree: "tree".into(),
            driver_source_commit: "driver".into(),
            driver_source_sha256: "source".into(),
            executable_sha256: "executable".into(),
            protocol_sha256: "protocol".into(),
            qualification_sha256: "qualification".into(),
            preparation_sha256: "preparation".into(),
            source_manifest_sha256: "manifest".into(),
            inputs_sha256: "inputs".into(),
            initial_sha256: hash(b"initial"),
            initial_matched_sha256: "matched".into(),
            closure_sha256: "closure".into(),
            source_headers: BTreeMap::new(),
            max_packet_bytes: MAX_PACKET,
            max_arm_bytes: MAX_ARM_BYTES,
            min_free_bytes: MIN_FREE_BYTES,
        }
    }
    fn science(cp: &[u8]) -> Vec<u8> {
        // Deliberately noncanonical whitespace and number spelling prove that
        // scientific payload bytes are preserved rather than re-serialized.
        format!("{{ \"schema\":\"grouped-m2-commit-v1\",\"status\":\"committed\",\"offset\":0,\"tick_before\":10,\"tick_after\":11,\"decisions\":[],\"consolidations\":0,\"checkpoint_sha256\":\"{}\",\"extra\":1.00}}\n{{\"schema\":\"grouped-m2-observation-v1\",\"status\":\"observed\",\"offset\":0,\"before\":{{\"tick\":10}},\"after\":{{\"tick\":11}}}}\n",hash(cp)).into_bytes()
    }
    struct Scratch(std::path::PathBuf);
    impl Scratch {
        fn new() -> Self {
            Self(
                std::env::temp_dir().join(format!("grouped-m2-journal-test-{}", unique().unwrap())),
            )
        }
    }
    impl Drop for Scratch {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }
    #[test]
    fn trace_cap_is_checked_without_large_allocations() {
        assert_eq!(
            checked_trace_len(MAX_TRACE_BYTES - 1, 1).unwrap(),
            MAX_TRACE_BYTES
        );
        assert!(checked_trace_len(MAX_TRACE_BYTES, 1).is_err());
        assert!(checked_trace_len(u64::MAX, 1).is_err());
        let mut raw = b"raw".to_vec();
        append_trace(&mut raw, b" bytes").unwrap();
        assert_eq!(raw, b"raw bytes");
    }
    #[test]
    fn no_trace_recovery_validates_and_preserves_latest_checkpoint() {
        let d = Scratch::new();
        let b = binding();
        init_journal(&d.0, &b).unwrap();
        let cp = b"opaque checkpoint";
        let wire = make_packet(&b, 0, &b.initial_sha256, cp, &science(cp)).unwrap();
        publish(&d.0, "000000.packet", &wire).unwrap();
        let seen = std::cell::Cell::new(0);
        let r = recover_without_trace(&d.0, &b, b"initial", |_, _| {
            seen.set(seen.get() + 1);
            Ok(())
        })
        .unwrap();
        assert_eq!(seen.get(), 2);
        assert_eq!(r.next, 1);
        assert_eq!(r.checkpoint, cp);
        assert!(r.trace.is_empty());
        assert_eq!(r.trace_bytes, science(cp).len() as u64);
        assert!(recover_without_trace(&d.0, &b, b"initial", |_, tick| {
            if tick == 11 {
                Err("invalid checkpoint".into())
            } else {
                Ok(())
            }
        })
        .is_err());
        let mut corrupt = wire;
        *corrupt.last_mut().unwrap() ^= 1;
        fs::write(d.0.join("000000.packet"), corrupt).unwrap();
        assert!(recover_without_trace(&d.0, &b, b"initial", |_, _| Ok(())).is_err());
    }
    #[test]
    fn raw_packet_roundtrip_and_negatives() {
        let b = binding();
        let cp = b"opaque checkpoint";
        let trace = science(cp);
        let wire = make_packet(&b, 0, &b.initial_sha256, cp, &trace).unwrap();
        let p = decode_packet(&wire, &b, 0, &b.initial_sha256).unwrap();
        assert_eq!(p.checkpoint, cp);
        assert_eq!(p.trace, trace);
        assert!(decode_packet(&wire, &b, 1, &b.initial_sha256).is_err());
        assert!(decode_packet(&wire, &b, 0, "wrong predecessor").is_err());
        let mut corrupt = wire.clone();
        *corrupt.last_mut().unwrap() ^= 1;
        assert!(decode_packet(&corrupt, &b, 0, &b.initial_sha256).is_err());
        assert!(make_packet(&b, 0, &b.initial_sha256, cp, b"{}\n{}\n").is_err());
        assert!(make_packet(&b, b.horizon, &b.initial_sha256, cp, &trace).is_err());
    }
    #[test]
    fn lock_claim_and_recovery_do_not_initialize() {
        let d = Scratch::new();
        let b = binding();
        assert!(lock(&d.0).is_err());
        assert!(recover(&d.0, &b, b"initial", |_, _| Ok(())).is_err());
        assert!(!d.0.exists());
        init_journal(&d.0, &b).unwrap();
        assert!(init_journal(&d.0, &b).is_err());
        let guard = lock(&d.0).unwrap();
        assert!(lock(&d.0).is_err());
        drop(guard);
        assert_eq!(
            bounded_read(&d.0.join("CLAIM.json"), MAX_METADATA).unwrap(),
            serde_json::to_vec(&b).unwrap()
        );
        fs::write(d.0.join("CLAIM.json"), b"unknown conflicting claim").unwrap();
        assert!(recover(&d.0, &b, b"initial", |_, _| Ok(())).is_err());
    }
    #[test]
    fn prelink_and_postlink_failure_reconcile_without_replay() {
        for fault in [1, 2] {
            let d = Scratch::new();
            let b = binding();
            init_journal(&d.0, &b).unwrap();
            let _guard = lock(&d.0).unwrap();
            let mut r = recover(&d.0, &b, b"initial", |_, _| Ok(())).unwrap();
            let cp = b"opaque checkpoint";
            let trace = science(cp);
            let wire = make_packet(&b, 0, &r.previous, cp, &trace).unwrap();
            assert!(publish_with_fault(&d.0, "000000.packet", &wire, fault).is_err());
            record_publication_failure(&d.0, &b, &mut r, cp, &wire, "injected failure").unwrap();
            let replay = recover(&d.0, &b, b"initial", |_, _| Ok(())).unwrap();
            assert_eq!(r.trace_bytes, replay.trace_bytes);
            assert_eq!(r.storage_bytes, replay.storage_bytes);
            assert_eq!(r.ignored_temps, replay.ignored_temps);
            assert_eq!(replay.next, if fault == 2 { 1 } else { 0 });
            assert_eq!(replay.trace, if fault == 2 { trace } else { Vec::new() });
            assert!(d.0.join("TERMINAL.json").is_file());
            assert!(replay.storage_bytes >= wire.len() as u64 * u64::from(fault));
            assert!(publish(&d.0, "TERMINAL.json", b"replace").is_err());
        }
    }
    #[test]
    fn visible_commit_survives_trace_cap_failure() {
        let d = Scratch::new();
        let b = binding();
        init_journal(&d.0, &b).unwrap();
        let mut r = recover_without_trace(&d.0, &b, b"initial", |_, _| Ok(())).unwrap();
        let cp = b"opaque checkpoint";
        let trace = science(cp);
        let wire = make_packet(&b, 0, &r.previous, cp, &trace).unwrap();
        assert!(publish_with_fault(&d.0, "000000.packet", &wire, 2).is_err());
        // Inject a bad caller's accounting without allocating 512 MiB.
        r.trace_bytes = MAX_TRACE_BYTES;
        assert!(
            record_publication_failure(&d.0, &b, &mut r, cp, &wire, "injected failure").is_err()
        );
        assert_eq!(r.next, 1);
        assert_eq!(r.checkpoint, cp);
        assert_eq!(r.trace_bytes, MAX_TRACE_BYTES + trace.len() as u64);
        assert!(r.trace.is_empty());
        assert!(d.0.join("TERMINAL.json").is_file());
        let terminal: Value = serde_json::from_slice(
            &bounded_read(&d.0.join("TERMINAL.json"), MAX_METADATA).unwrap(),
        )
        .unwrap();
        assert_eq!(terminal["committed_intervals"], 1);
        assert_eq!(terminal["final_checkpoint_sha256"], hash(cp));
    }
    #[test]
    fn artifact_publication_is_bounded_create_new_and_not_journal_permission() {
        let d = Scratch::new();
        fs::create_dir(&d.0).unwrap();
        let bytes = vec![b'x'; MAX_METADATA as usize + 1];
        publish_artifact(&d.0, "initial.private.m2", &bytes, MAX_PACKET).unwrap();
        assert_eq!(
            bounded_read(&d.0.join("initial.private.m2"), MAX_PACKET).unwrap(),
            bytes
        );
        assert!(publish_artifact(&d.0, "initial.private.m2", b"replace", MAX_PACKET).is_err());
        assert!(publish(&d.0, "initial.private.m2", b"x").is_err());
        for name in [
            "",
            ".",
            "..",
            "../outside",
            "a/b",
            "a\\b",
            ".tmp-reserved",
            "LOCK",
        ] {
            assert!(publish_artifact(&d.0, name, b"x", MAX_PACKET).is_err());
        }
        assert!(publish_artifact(&d.0, "SOURCE.json", b"xx", 1).is_err());
        assert!(publish_artifact(&d.0, "SOURCE.json", b"x", MAX_ARM_BYTES + 1).is_err());
    }
    #[test]
    fn unknown_names_and_resource_limits_fail_closed() {
        let d = Scratch::new();
        let b = binding();
        init_journal(&d.0, &b).unwrap();
        assert!(publish(&d.0, "../escape", b"x").is_err());
        fs::write(d.0.join("not-allowed"), b"x").unwrap();
        assert!(recover(&d.0, &b, b"initial", |_, _| Ok(())).is_err());
        assert!(resource_stop(&b, u64::MAX, u64::MAX));
        assert!(resource_stop(&b, 0, MIN_FREE_BYTES));
        assert!(!resource_stop(&b, 0, MIN_FREE_BYTES + MAX_PACKET));
    }
}
