//! One declared disposable fixture, not a primary-seed rehearsal or seed search.
use super::*;
use std::{io::Write, time::Instant};
const INTERVALS: u64 = 12;
const BODY_PREPARATION: u64 = 1200;
const INTERRUPTS: [u64; 1] = [6];
const FIXTURE_TEMPERATURE: f32 = 0.73;
fn fixture_binding(arm: usize, initial: &[u8], r: &recipe::Recipe) -> Result<journal::Binding> {
    Ok(journal::Binding {
        schema: "grouped-m2-durable-v1".into(),
        study_id: "grouped-m2-fixed-driver-qualification-v1".into(),
        arm,
        mode: mode_name(arm)?.into(),
        seed: FIXTURE_SEED,
        sampling_seed: sampling_seed(FIXTURE_SEED),
        initial_tick: BODY_PREPARATION,
        horizon: INTERVALS,
        temperature_bits: FIXTURE_TEMPERATURE.to_bits(),
        host_source_commit: HOST_COMMIT.into(),
        host_source_tree: HOST_TREE.into(),
        driver_source_commit: DRIVER_COMMIT.into(),
        driver_source_sha256: code_hash(),
        executable_sha256: executable_hash()?,
        protocol_sha256: hash(PROTOCOL),
        qualification_sha256: "fixed-disposable-qualification-not-primary".into(),
        preparation_sha256: hash(b"one fresh 1200-world-only template; two modes; no primary seed"),
        source_manifest_sha256: hash(&serde_json::to_vec(&r.metadata)?),
        inputs_sha256: hash(&serde_json::to_vec(&r.inputs)?),
        initial_sha256: hash(initial),
        initial_matched_sha256: hash(&raw::matched_initial(initial, mode_name(arm)?)?),
        closure_sha256: closure_hash(initial)?,
        source_headers: raw::source_headers(initial)?,
        max_packet_bytes: journal::MAX_PACKET,
        max_arm_bytes: journal::MAX_ARM_BYTES,
        min_free_bytes: journal::MIN_FREE_BYTES,
    })
}
fn rewire(h: &journal::Header, cp: &[u8], trace: &[u8]) -> Result<Vec<u8>> {
    let meta = serde_json::to_vec(h)?;
    let mut wire = journal::MAGIC.to_vec();
    for n in [meta.len(), cp.len(), trace.len()] {
        wire.extend_from_slice(&(n as u64).to_le_bytes());
    }
    wire.extend(meta);
    wire.extend(cp);
    wire.extend(trace);
    Ok(wire)
}
fn packet_cases(out: &Path, b: &journal::Binding, initial: &[u8], first: &[u8]) -> Result<Value> {
    fs::create_dir(out)?;
    let p = journal::decode_packet(first, b, 0, &hash(initial))?;
    let mut cases = Vec::new();
    for key in [
        "schema",
        "host_commit",
        "host_tree",
        "driver_commit",
        "source_code",
        "executable",
        "protocol",
        "qualification",
        "preparation",
        "source_manifest",
        "inputs",
        "initial",
        "matched",
        "closure",
        "headers",
        "arm",
        "mode",
        "seed",
        "sampler",
        "temperature",
        "horizon",
        "offset",
        "tick",
        "previous",
        "cp_hash",
        "science_hash",
        "cp_length",
        "science_length",
    ] {
        let mut h = p.header.clone();
        match key {
            "schema" => h.binding.schema = "wrong".into(),
            "host_commit" => h.binding.host_source_commit = "wrong".into(),
            "host_tree" => h.binding.host_source_tree = "wrong".into(),
            "driver_commit" => h.binding.driver_source_commit = "wrong".into(),
            "source_code" => h.binding.driver_source_sha256 = "wrong".into(),
            "executable" => h.binding.executable_sha256 = "wrong".into(),
            "protocol" => h.binding.protocol_sha256 = "wrong".into(),
            "qualification" => h.binding.qualification_sha256 = "wrong".into(),
            "preparation" => h.binding.preparation_sha256 = "wrong".into(),
            "source_manifest" => h.binding.source_manifest_sha256 = "wrong".into(),
            "inputs" => h.binding.inputs_sha256 = "wrong".into(),
            "initial" => h.binding.initial_sha256 = "wrong".into(),
            "matched" => h.binding.initial_matched_sha256 = "wrong".into(),
            "closure" => h.binding.closure_sha256 = "wrong".into(),
            "headers" => {
                h.binding
                    .source_headers
                    .insert("extra".into(), "wrong".into());
            }
            "arm" => h.binding.arm = 7,
            "mode" => h.binding.mode = "PressureSham".into(),
            "seed" => h.binding.seed += 1,
            "sampler" => h.binding.sampling_seed += 1,
            "temperature" => h.binding.temperature_bits ^= 1,
            "horizon" => h.binding.horizon += 1,
            "offset" => h.offset += 1,
            "tick" => h.tick_after += 1,
            "previous" => h.previous_commit_sha256 = "wrong".into(),
            "cp_hash" => h.checkpoint_sha256 = "wrong".into(),
            "science_hash" => h.trace_sha256 = "wrong".into(),
            "cp_length" => h.checkpoint_bytes += 1,
            "science_length" => h.trace_bytes += 1,
            _ => unreachable!(),
        }
        if journal::decode_packet(&rewire(&h, &p.checkpoint, &p.trace)?, b, 0, &hash(initial))
            .is_ok()
        {
            return Err(format!("negative accepted: {key}").into());
        }
        cases.push(key);
    }
    for label in [
        "magic",
        "truncated",
        "trailing",
        "length_overflow",
        "payload_corruption",
    ] {
        let mut wire = first.to_vec();
        match label {
            "magic" => wire[0] ^= 1,
            "truncated" => {
                wire.pop();
            }
            "trailing" => wire.push(0),
            "length_overflow" => wire[8..16].copy_from_slice(&u64::MAX.to_le_bytes()),
            "payload_corruption" => {
                let n = wire.len();
                wire[n - 2] ^= 1;
            }
            _ => unreachable!(),
        }
        if journal::decode_packet(&wire, b, 0, &hash(initial)).is_ok() {
            return Err(format!("negative accepted: {label}").into());
        }
        cases.push(label);
    }
    if journal::make_packet(b, 0, &hash(initial), &p.checkpoint, b"{}\n").is_ok() {
        return Err("missing row accepted".into());
    }
    for (index, name) in ["000001.packet", "000000-copy.packet"]
        .into_iter()
        .enumerate()
    {
        let d = out.join(format!("gap-{index}"));
        journal::init_journal(&d, b)?;
        fs::write(d.join(name), first)?;
        if journal::recover(&d, b, initial, |_, _| Ok(())).is_ok() {
            return Err("gap/name accepted".into());
        }
    }
    for fault in [1, 2] {
        let d = out.join(format!("publish-{fault}"));
        journal::init_journal(&d, b)?;
        let _guard = journal::lock(&d)?;
        let mut state = journal::recover(&d, b, initial, |_, _| Ok(()))?;
        if journal::publish_with_fault(&d, "000000.packet", first, fault).is_ok() {
            return Err("publication fault not injected".into());
        }
        journal::record_publication_failure(
            &d,
            b,
            &mut state,
            &p.checkpoint,
            first,
            "fixed publication fault",
        )?;
        let recovered = journal::recover(&d, b, initial, |_, _| Ok(()))?;
        if recovered.next != u64::from(fault == 2) || !d.join("TERMINAL.json").is_file() {
            return Err("publication outcome reconciliation differs".into());
        }
    }
    let fallback = out.join("terminal-fallback");
    journal::init_journal(&fallback, b)?;
    let r = journal::recover(&fallback, b, initial, |_, _| Ok(()))?;
    fs::create_dir(fallback.join("TERMINAL.json"))?;
    journal::stop_after_failure(&fallback, b, &r, "fixed terminal write refusal");
    if !fallback.join("BLOCKED-PUBLICATION").is_file() {
        return Err("failure blocker absent".into());
    }
    let d = out.join("exclusive-lock");
    journal::init_journal(&d, b)?;
    let guard = journal::lock(&d)?;
    let child = std::process::Command::new(std::env::current_exe()?)
        .arg("--lock-child")
        .arg(&d)
        .status()?;
    if child.code() != Some(7) {
        return Err("real child overlapped journal lock".into());
    }
    drop(guard);
    let child = std::process::Command::new(std::env::current_exe()?)
        .arg("--lock-child")
        .arg(&d)
        .status()?;
    if !child.success() {
        return Err("child lock did not release after exit".into());
    }
    let _guard = journal::lock(&d)?;
    journal::publish(&d, "000000.packet", first)?;
    if journal::publish(&d, "000000.packet", first).is_ok() {
        return Err("duplicate publication accepted".into());
    }
    for order in [0, 1] {
        let d = out.join(format!("claim-order-{order}"));
        if order == 0 {
            journal::init_journal(&d, b)?;
            if fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(d.join("CLAIM.json"))
                .is_ok()
            {
                return Err("second claim acquired".into());
            }
        } else {
            fs::create_dir(&d)?;
            fs::write(d.join("CLAIM.json"), b"other-driver").map_err(|e| e.to_string())?;
            if journal::init_journal(&d, b).is_ok() {
                return Err("existing claim replaced".into());
            }
            if fs::read(d.join("CLAIM.json"))? != b"other-driver" {
                return Err("prior claim altered".into());
            }
        }
    }
    if !journal::resource_stop(b, b.max_arm_bytes - b.max_packet_bytes, u64::MAX)
        || !journal::resource_stop(b, 0, b.min_free_bytes)
        || journal::resource_stop(b, 0, b.min_free_bytes + b.max_packet_bytes)
    {
        return Err("pre-step guard differs".into());
    }
    #[cfg(unix)]
    {
        let d = out.join("symlink");
        journal::init_journal(&d, b)?;
        std::os::unix::fs::symlink(out.join("absent"), d.join("000000.packet"))?;
        if journal::recover(&d, b, initial, |_, _| Ok(())).is_ok() {
            return Err("symlink accepted".into());
        }
    }
    let result = json!({"negative_cases":cases,"raw_cp_and_science_preserved":true,"missing_row_rejected":true,"gap_order_duplicate_rejected":true,"fresh_claim_both_orders":true,"real_child_lock_and_exit_release":true,"before_and_after_link_failure_reconciled":true,"terminal_fallback":true,"pre_step_resource_guard":true});
    write_new(out, "RESULT.json", &result)?;
    Ok(result)
}
const REFERENCE_COMMIT: &str = "2e14a6d4cc0a0086cf88c27c40de30d9c957c200";
const REFERENCE_CODE: &str = "ddab50b2c11bf69b349e9344c3b39e68a31a152a91c32d1f093282947098ba4c";
const REFERENCE_EXE: &str = "f246955d823e77b95c11651e83ee69e70d6ef721ab03ecd922646fb265f82e3b";
const REFERENCE_PROTOCOL: &str = "8bcded9e7a7649ec187bae352695080dfb26c6c797f8962a569cbd1d3ce8d972";
fn reference_receipt(root: &Path) -> Result<(Value, Vec<u8>)> {
    let (q, bytes): (Value, _) =
        read_typed(&root.join("QUALIFICATION_COMPLETE.json"), 1024 * 1024)?;
    if q["complete"] != true
        || q["schema"] != "grouped-m2-driver-qualification-v1"
        || q["driver_commit"] != REFERENCE_COMMIT
        || q["driver_code_sha256"] != REFERENCE_CODE
        || q["executable_sha256"] != REFERENCE_EXE
        || q["protocol_sha256"] != REFERENCE_PROTOCOL
        || q["host_runtime_commit"] != HOST_COMMIT
        || q["host_runtime_tree"] != HOST_TREE
        || q["fixture_seed"] != FIXTURE_SEED
        || q["primary_seed_executed"] != false
        || q["actual_preparation_intervals"] != BODY_PREPARATION
        || q["actual_native_calls"] != 136
        || q["arms"].as_array().is_none_or(|a| a.len() != 2)
    {
        return Err("reference qualification identity or dose differs".into());
    }
    Ok((q, bytes))
}
pub fn qualify(reference: &Path, out: &Path) -> Result<()> {
    let (reference_q, reference_bytes) = reference_receipt(reference)?;
    fs::create_dir(out)?;
    if journal::free_bytes(out)? < journal::MIN_FREE_BYTES + 512 * 1024 * 1024 {
        return Err("fixture storage guard before preparation".into());
    }
    let started = Instant::now();
    let mut actual_preparation = 0_u64;
    let mut actual_native = 0_u64;
    write_new(
        out,
        "FIXTURE_PLAN.json",
        &json!({"schema":"grouped-m2-fixed-fixture-plan-v1","seed":FIXTURE_SEED,"seed_hex":"0x03475250484F5354","seed_origin":"explicit reuse of existing host unit fixture, not primary","modes":["Full","DriveSham"],"source_templates":1,"actual_preparation_intervals":BODY_PREPARATION,"intervals_per_mode":INTERVALS,"warm_and_cold_native_calls":2*2*INTERVALS,"unpublished_interruption_offsets":INTERRUPTS,"maximum_native_calls":2*(2*INTERVALS+INTERRUPTS.len() as u64),"composite_reference_sha256":hash(&reference_bytes),"reference_native_calls_not_this_executable":136,"temperature_bits":FIXTURE_TEMPERATURE.to_bits(),"founder_optimizer_sentinel":23,"source_synaptic_nonzero_sentinel_coverage":"already-qualified frozen host tests; driver does not forge an M2 envelope","primary_seed_executed":false}),
    )?;
    let result = (|| -> Result<()> {
        journal::publish_artifact(out, "not-the-authoritative-reservation.json", b"{}", 1024)?;
        if canonical_reservation(&out.join("not-the-authoritative-reservation.json")).is_ok() {
            return Err("copyable reservation claim admitted".into());
        }
        journal::publish_artifact(
            out,
            "REFERENCE_QUALIFICATION.json",
            &reference_bytes,
            1024 * 1024,
        )?;
        let recipe = recipe::build(FIXTURE_SEED, true)?;
        let inputs = serde_json::to_vec(&recipe.inputs)?;
        let source = serde_json::to_vec(&recipe.metadata)?;
        let source_bound = serde_json::to_vec(&json!({
            "schema":"grouped-m2-fixture-source-before-preparation-v1",
            "source_manifest_sha256":hash(&source),"inputs_sha256":hash(&inputs),
            "genotype_sha256":recipe.metadata["genotype_sha256"],"asset":recipe.metadata["target_asset"],
            "driver_code_sha256":code_hash(),"actual_preparation_intervals":0,"native_calls":0
        }))?;
        if inputs
            != journal::bounded_read(&reference.join("INPUTS.private.json"), journal::MAX_PACKET)?
        {
            return Err("source inputs differ from unchanged reference fixture".into());
        }
        let hosts = bind_then_prepare(out, &source, &inputs, &source_bound, || {
            fresh_pair(&recipe, BODY_PREPARATION, true, &mut actual_preparation)
        })?;
        let pressure = recipe
            .phenotype
            .cognitive_architecture()
            .sleep_trigger_threshold();
        let mut audits = Vec::new();
        // Retain the longer original run's measured maxima rather than lowering bounds to this shorter repair test.
        let ref_number = |key: &str| -> Result<u64> {
            reference_q[key]
                .as_u64()
                .ok_or_else(|| format!("reference measurement absent: {key}").into())
        };
        let mut global_max = ref_number("maximum_packet_bytes")?;
        let mut max_growth = ref_number("observed_packet_growth_bytes")?;
        let mut initial_max = ref_number("maximum_initial_checkpoint_bytes")?;
        let mut maximum_science_row_pair_bytes = ref_number("maximum_science_row_pair_bytes")?;
        for (arm, mut warm) in hosts.into_iter().enumerate() {
            let arm_start = Instant::now();
            let dir = out.join(format!("arm-{arm}"));
            fs::create_dir(&dir)?;
            let initial = cp(&warm)?;
            initial_max = initial_max.max(initial.len() as u64);
            journal::publish_artifact(&dir, "initial.private.m2", &initial, journal::MAX_PACKET)?;
            let b = fixture_binding(arm, &initial, &recipe)?;
            let reference_arm = reference.join(format!("arm-{arm}"));
            let old_initial = journal::bounded_read(
                &reference_arm.join("initial.private.m2"),
                journal::MAX_PACKET,
            )?;
            if initial != old_initial {
                return Err(
                    "native initial source/genotype/sampler/body bytes differ from reference"
                        .into(),
                );
            }
            let (old_binding, _): (journal::Binding, _) =
                read_typed(&reference_arm.join("warm/MANIFEST.json"), 16 * 1024)?;
            if old_binding.driver_source_commit != REFERENCE_COMMIT
                || old_binding.driver_source_sha256 != REFERENCE_CODE
                || old_binding.executable_sha256 != REFERENCE_EXE
                || old_binding.protocol_sha256 != REFERENCE_PROTOCOL
                || old_binding.arm != arm
                || old_binding.mode != mode_name(arm)?
                || old_binding.host_source_commit != HOST_COMMIT
                || old_binding.host_source_tree != HOST_TREE
                || old_binding.sampling_seed != sampling_seed(FIXTURE_SEED)
                || old_binding.initial_tick != BODY_PREPARATION
                || old_binding.seed != FIXTURE_SEED
                || old_binding.initial_sha256 != hash(&old_initial)
                || old_binding.closure_sha256 != b.closure_sha256
                || old_binding.source_headers != b.source_headers
                || old_binding.horizon != 32
                || old_binding.temperature_bits != FIXTURE_TEMPERATURE.to_bits()
            {
                return Err("reference journal binding differs".into());
            }
            let mut reference_previous = hash(&old_initial);
            if raw::payload(&initial)?
                .path(&["founder", "optimizer_step"])?
                .value::<u64>()?
                != 23
            {
                return Err("founder optimizer sentinel absent".into());
            }
            if CpuGroupedM2HostV1::restore(
                CpuGroupedM2HostCheckpointV1::decode(&initial)?,
                &recipe.inputs,
                mode(1 - arm)?,
            )
            .is_ok()
            {
                return Err("wrong native mode accepted".into());
            }
            let mut wrong_magic = initial.clone();
            wrong_magic[0] ^= 1;
            if CpuGroupedM2HostCheckpointV1::decode(&wrong_magic).is_ok() {
                return Err("wrong native envelope magic accepted".into());
            }
            let mut expected_trace = Vec::new();
            let mut previous = hash(&initial);
            let mut maximum = 0_u64;
            let mut first_size = 0_u64;
            let mut last_size = 0_u64;
            let warm_dir = dir.join("warm");
            journal::init_journal(&warm_dir, &b)?;
            let _warm_guard = journal::lock(&warm_dir)?;
            let mut body_sleep = false;
            let mut waking = false;
            let mut resumed = false;
            let mut consolidations = 0;
            let mut decisions = 0;
            let mut max_memory = 0;
            let mut packet_one = None;
            for offset in 0..INTERVALS {
                if journal::resource_stop(&b, 2 * maximum * offset, journal::free_bytes(&warm_dir)?)
                {
                    return Err("warm fixture resource guard".into());
                }
                let before = observe(&warm)?;
                let step = counted_call(&mut actual_native, || warm.step(FIXTURE_TEMPERATURE))?;
                let after = observe(&warm)?;
                if waking && !step.decisions.is_empty() {
                    resumed = true;
                }
                waking |= after.phase == SleepPhase::Waking;
                body_sleep |= step
                    .decisions
                    .iter()
                    .any(|d| d.physical.successful_stationary_body_sleep);
                consolidations += step.sleep_consolidations;
                decisions += step.decisions.len();
                let bytes = cp(&warm)?;
                validate_cp(&bytes, BODY_PREPARATION + offset + 1, &b.closure_sha256)?;
                let memory = raw::payload(&bytes)?
                    .path(&["canonical", "residents"])?
                    .one()?
                    .field("memory")?;
                max_memory = max_memory.max(memory.0.len());
                let rows = science(
                    &before,
                    &after,
                    &step,
                    offset,
                    &bytes,
                    &b.closure_sha256,
                    pressure,
                )?;
                maximum_science_row_pair_bytes =
                    maximum_science_row_pair_bytes.max(rows.len() as u64);
                let packet = journal::make_packet(&b, offset, &previous, &bytes, &rows)?;
                let old_wire = journal::bounded_read(
                    &reference_arm.join(format!("warm/{offset:06}.packet")),
                    journal::MAX_PACKET,
                )?;
                let old_packet =
                    journal::decode_packet(&old_wire, &old_binding, offset, &reference_previous)?;
                if old_packet.checkpoint != bytes || old_packet.trace != rows {
                    return Err(format!("unchanged runtime checkpoint/scientific bytes differ from reference arm {arm} interval {offset}").into());
                }
                reference_previous = hash(&old_wire);
                if offset == 0 {
                    first_size = packet.len() as u64;
                    packet_one = Some(packet.clone());
                }
                last_size = packet.len() as u64;
                maximum = maximum.max(last_size);
                previous = hash(&packet);
                expected_trace.extend(rows);
                journal::publish(&warm_dir, &format!("{offset:06}.packet"), &packet)?;
            }
            let warm_r = journal::recover(&warm_dir, &b, &initial, |bytes, tick| {
                validate_cp(bytes, tick, &b.closure_sha256)
            })?;
            journal::terminal(&warm_dir, &b, &warm_r, "fixture horizon")?;
            if warm_r.trace != expected_trace || warm_r.checkpoint != cp(&warm)? {
                return Err("warm journal projection differs".into());
            }
            if arm == 0 && (!body_sleep || consolidations == 0 || !waking || !resumed) {
                return Err("fixed Full fixture failed to observe actual complete sleep and resumed decision".into());
            }
            let cold_dir = dir.join("cold");
            journal::init_journal(&cold_dir, &b)?;
            let _cold_guard = journal::lock(&cold_dir)?;
            let mut previous = hash(&initial);
            for offset in 0..INTERVALS {
                if journal::resource_stop(
                    &b,
                    2 * maximum * offset + 4 * maximum,
                    journal::free_bytes(&cold_dir)?,
                ) {
                    return Err("cold fixture resource guard".into());
                }
                let disk_cp = if offset == 0 {
                    journal::bounded_read(&dir.join("initial.private.m2"), journal::MAX_PACKET)?
                } else {
                    let packet = journal::bounded_read(
                        &cold_dir.join(format!("{:06}.packet", offset - 1)),
                        journal::MAX_PACKET,
                    )?;
                    let meta_len = u64::from_le_bytes(packet[8..16].try_into()?);
                    let header: journal::Header =
                        serde_json::from_slice(&packet[32..32 + meta_len as usize])?;
                    journal::decode_packet(&packet, &b, offset - 1, &header.previous_commit_sha256)?
                        .checkpoint
                };
                if INTERRUPTS.contains(&offset) {
                    let mut lost = restore(
                        &disk_cp,
                        &recipe.inputs,
                        arm,
                        BODY_PREPARATION + offset,
                        &b.closure_sha256,
                    )?;
                    let before = observe(&lost)?;
                    let step = counted_call(&mut actual_native, || lost.step(FIXTURE_TEMPERATURE))?;
                    let bytes = cp(&lost)?;
                    let rows = science(
                        &before,
                        &observe(&lost)?,
                        &step,
                        offset,
                        &bytes,
                        &b.closure_sha256,
                        pressure,
                    )?;
                    maximum_science_row_pair_bytes =
                        maximum_science_row_pair_bytes.max(rows.len() as u64);
                    let packet = journal::make_packet(&b, offset, &previous, &bytes, &rows)?;
                    let mut f = fs::OpenOptions::new()
                        .write(true)
                        .create_new(true)
                        .open(cold_dir.join(format!(".tmp-fixed-unpublished-{offset}")))?;
                    f.write_all(&packet[..packet.len() / 2])?;
                    f.sync_all()?;
                    drop(lost);
                    let r = journal::recover(&cold_dir, &b, &initial, |bytes, tick| {
                        validate_cp(bytes, tick, &b.closure_sha256)
                    })?;
                    if r.next != offset || r.checkpoint != disk_cp || r.previous != previous {
                        return Err("unpublished interruption changed prefix".into());
                    }
                }
                let mut cold = restore(
                    &disk_cp,
                    &recipe.inputs,
                    arm,
                    BODY_PREPARATION + offset,
                    &b.closure_sha256,
                )?;
                let before = observe(&cold)?;
                let step = counted_call(&mut actual_native, || cold.step(FIXTURE_TEMPERATURE))?;
                let bytes = cp(&cold)?;
                let rows = science(
                    &before,
                    &observe(&cold)?,
                    &step,
                    offset,
                    &bytes,
                    &b.closure_sha256,
                    pressure,
                )?;
                maximum_science_row_pair_bytes =
                    maximum_science_row_pair_bytes.max(rows.len() as u64);
                let packet = journal::make_packet(&b, offset, &previous, &bytes, &rows)?;
                let expected = journal::bounded_read(
                    &warm_dir.join(format!("{offset:06}.packet")),
                    journal::MAX_PACKET,
                )?;
                if packet != expected {
                    return Err(format!("cold native checkpoint/scientific bytes differ arm {arm} interval {offset}").into());
                }
                journal::publish(&cold_dir, &format!("{offset:06}.packet"), &packet)?;
                previous = hash(&packet);
            }
            let cold_r = journal::recover(&cold_dir, &b, &initial, |bytes, tick| {
                validate_cp(bytes, tick, &b.closure_sha256)
            })?;
            if cold_r.trace != warm_r.trace
                || cold_r.checkpoint != warm_r.checkpoint
                || cold_r.previous != warm_r.previous
            {
                return Err("cold full projection differs".into());
            }
            journal::terminal(&cold_dir, &b, &cold_r, "fixture horizon")?;
            if arm == 0 {
                packet_cases(
                    &out.join("packet-cases"),
                    &b,
                    &initial,
                    packet_one.as_deref().ok_or("first packet absent")?,
                )?;
            }
            let final_host = restore(
                &cold_r.checkpoint,
                &recipe.inputs,
                arm,
                BODY_PREPARATION + INTERVALS,
                &b.closure_sha256,
            )?;
            let summary = summarize(
                &cold_r.trace,
                &observe(&final_host)?,
                INTERVALS,
                None,
                &cold_r.previous,
            )?;
            if arm == 0
                && summary["fully_observed_complete_cycles"]
                    .as_array()
                    .is_none_or(|cycles| cycles.is_empty())
            {
                return Err(
                    "Full fixture lacks a fully observed same-ID complete sleep cycle".into(),
                );
            }
            write_new(&dir, "RESULT.json", &summary)?;
            let audit = json!({"arm":arm,"mode":mode_name(arm)?,"committed_fixture_intervals":INTERVALS,"decisions":decisions,"actual_body_sleep":body_sleep,"closed_memory_consolidations":consolidations,"waking_observed":waking,"resumed_decision":resumed,"every_checkpoint_and_raw_scientific_row_byte_exact":true,"cold_from_disk_every_interval":true,"same_initial_and_each_warm_native_cp_and_raw_science_as_reference":true,"reference_matching_intervals":INTERVALS,"unpublished_interruptions":INTERRUPTS,"source_and_optimizer_closure":true,"founder_optimizer_step_sentinel":23,"maximum_memory_serialized_bytes":max_memory,"first_packet_bytes":first_size,"last_packet_bytes":last_size,"maximum_packet_bytes":maximum,"charged_cold_journal_bytes":cold_r.storage_bytes,"wall_seconds":arm_start.elapsed().as_secs_f64(),"raw_trace_sha256":hash(&cold_r.trace),"final_checkpoint_sha256":hash(&cold_r.checkpoint)});
            write_new(&dir, "QUALIFICATION.json", &audit)?;
            audits.push(audit);
            global_max = global_max.max(maximum);
            max_growth = max_growth.max(last_size.saturating_sub(first_size));
            println!(
                "qualified fixed arm {arm}: {INTERVALS} exact cold intervals, max packet {maximum}"
            );
        }
        if actual_preparation != BODY_PREPARATION
            || actual_native != 2 * (2 * INTERVALS + INTERRUPTS.len() as u64)
        {
            return Err("fixture dose differs from prospective cap".into());
        }
        let margin = max_growth.max(256 * 1024);
        let projected_packet = global_max
            .checked_add(margin)
            .ok_or("projection overflow")?;
        let projected_pair = projected_packet
            .checked_mul(2 * HORIZON)
            .ok_or("projection overflow")?;
        let metadata_export_headroom = 2 * maximum_science_row_pair_bytes * HORIZON
            + 2 * initial_max
            + 2 * projected_packet
            + 64 * 1024 * 1024_u64;
        let free = journal::free_bytes(out)?;
        let projected_trace_bytes = maximum_science_row_pair_bytes
            .checked_mul(HORIZON)
            .ok_or("trace projection overflow")?;
        let budget_ok = projected_trace_bytes < journal::MAX_TRACE_BYTES
            && projected_packet <= journal::MAX_PACKET
            && projected_packet * 2 * HORIZON + journal::METADATA_RESERVE <= journal::MAX_ARM_BYTES
            && projected_pair + metadata_export_headroom + journal::MIN_FREE_BYTES < free;
        let result = json!({"schema":"grouped-m2-driver-qualification-v1","complete":budget_ok,"driver_commit":DRIVER_COMMIT,"driver_code_sha256":code_hash(),"executable_sha256":executable_hash()?,"protocol_sha256":hash(PROTOCOL),"host_runtime_commit":HOST_COMMIT,"host_runtime_tree":HOST_TREE,"fixture_seed":FIXTURE_SEED,"primary_seed_executed":false,"actual_preparation_intervals":actual_preparation,"actual_native_calls":actual_native,"composite_proof":true,"reference_driver_commit":REFERENCE_COMMIT,"reference_qualification_sha256":hash(&reference_bytes),"reference_native_calls_not_this_executable":136,"measurement_bounds_include_longer_reference":true,"arms":audits,"maximum_packet_bytes":global_max,"maximum_initial_checkpoint_bytes":initial_max,"maximum_science_row_pair_bytes":maximum_science_row_pair_bytes,"projected_trace_bytes_per_arm":projected_trace_bytes,"aggregate_trace_memory_cap":journal::MAX_TRACE_BYTES,"observed_packet_growth_bytes":max_growth,"projection_margin_bytes":margin,"projected_packet_bytes":projected_packet,"projected_pair_physical_bytes":projected_pair,"metadata_initial_export_headroom":metadata_export_headroom,"free_bytes_at_qualification":free,"resource_projection_adequate":budget_ok,"projection_is_not_a_growth_guarantee":true,"power_loss_durability_claim":false,"long_prefix_restart_latency_claim":false,"wall_seconds":started.elapsed().as_secs_f64(),"native_core_nonzero_source_sentinel_scope":"host qualification only; this driver independently carries exact founder optimizer sentinels and checks all initial synaptic banks unchanged"});
        write_new(
            out,
            if budget_ok {
                "QUALIFICATION_COMPLETE.json"
            } else {
                "QUALIFICATION_RESOURCE_BLOCKED.json"
            },
            &result,
        )?;
        if !budget_ok {
            return Err(
                "measured M2 packet/space projection inadequate; no primary activation".into(),
            );
        }
        Ok(())
    })();
    if let Err(e) = &result {
        let _ = write_new(
            out,
            "QUALIFICATION_FAILED.json",
            &json!({"error":e.to_string(),"actual_preparation_intervals":actual_preparation,"actual_native_calls":actual_native,"primary_seed_executed":false,"preserve_failure":true}),
        );
    }
    result
}

// The admission-only delta does not rerun or import the prior native fixture.
const ADMISSION_REFERENCE_SHA256: &str =
    "5e2c13072debd852e32f902af8ad689cadf7560efe8f7432736d208a34ca492f";
const ADMISSION_REFERENCE_COMMIT: &str = "93ff181050a9f7274a0535f2fba6b248f6e52734";
const ADMISSION_REFERENCE_CODE: &str =
    "1f82b8219176ef4765515e62df4964c423e9b9bfca11d840a85704c76c83ff58";
const ADMISSION_REFERENCE_EXE: &str =
    "eaeafbbc77fc6759afcdeadcfac6a42b5b298496ddafaf9721c247c6d0396780";
const ADMISSION_RUNTIME_FINGERPRINT: &str =
    "e9b892da7c8ad72b22231df8c67e333fa1ec40148c9ee28f17a952999f84f970";
fn unchanged_host_helper_fingerprint() -> String {
    let mut h = Sha256::new();
    for bytes in [
        include_bytes!("../../src/cpu/grouped_host_envelope.rs").as_slice(),
        include_bytes!("../../src/cpu/grouped_host_fixture.rs").as_slice(),
        include_bytes!("../../src/cpu/grouped_host_food_tests.rs").as_slice(),
        include_bytes!("../../src/cpu/grouped_host_loop.rs").as_slice(),
        include_bytes!("../../src/cpu/grouped_host_tests.rs").as_slice(),
        include_bytes!("../../src/cpu/host.rs").as_slice(),
        include_bytes!("../../src/cpu/motor_mediation.rs").as_slice(),
        include_bytes!("../../src/cpu/motor_mediation/confidence.rs").as_slice(),
        include_bytes!("../../src/cpu/motor_mediation/confidence/host.rs").as_slice(),
        include_bytes!("../../src/cpu/motor_mediation/confidence/host/tests.rs").as_slice(),
        include_bytes!("../../src/cpu/motor_mediation/confidence/policy.rs").as_slice(),
        include_bytes!("../../src/cpu/motor_mediation/confidence/tests.rs").as_slice(),
        include_bytes!("../../src/cpu/organism.rs").as_slice(),
        include_bytes!("recovery_sleep_recipe_v1.rs").as_slice(),
        include_bytes!("grounded_r0_dedicated_fatigue.rs").as_slice(),
        include_bytes!("multidrive_frozen.rs").as_slice(),
        include_bytes!("grounded_r0_motor_operating_point.rs").as_slice(),
    ] {
        h.update((bytes.len() as u64).to_le_bytes());
        h.update(bytes);
    }
    format!("{:x}", h.finalize())
}
pub fn qualify_admission(reference: &Path, out: &Path) -> Result<()> {
    let (prior, prior_bytes): (Value, _) =
        read_typed(&reference.join("QUALIFICATION_COMPLETE.json"), 1024 * 1024)?;
    if hash(&prior_bytes) != ADMISSION_REFERENCE_SHA256
        || prior["driver_commit"] != ADMISSION_REFERENCE_COMMIT
        || prior["driver_code_sha256"] != ADMISSION_REFERENCE_CODE
        || prior["executable_sha256"] != ADMISSION_REFERENCE_EXE
        || prior["complete"] != true
        || prior["actual_native_calls"] != 50
        || prior["actual_preparation_intervals"] != 1200
        || prior["primary_seed_executed"] != false
        || unchanged_host_helper_fingerprint() != ADMISSION_RUNTIME_FINGERPRINT
    {
        return Err("admission-only reference/runtime proof differs".into());
    }
    let max = (u64::MAX - 1) / 16;
    if seed_admission_preflight(max, 1)? != 0xFFFF_FFFF_FFFF_FFF1
        || seed_admission_preflight(max, 8)? != 0xFFFF_FFFF_FFFF_FFF8
        || seed_admission_preflight(max + 1, 1).is_ok()
        || seed_admission_preflight(u64::MAX, 1).is_ok()
        || seed_admission_preflight(0, 1).is_ok()
        || seed_admission_preflight(1, 0).is_ok()
        || seed_admission_preflight(1, 9).is_ok()
        || seed_admission_preflight(0x4D32_424C_0009_0001, 1).is_ok()
        || seed_admission_preflight(SEED, 1)? != 0x34D3_2424_C000_9011
    {
        return Err("fixed pre-claim admission guard case differs".into());
    }
    fs::create_dir(out)?;
    journal::publish_artifact(
        out,
        "REUSED_RUNTIME_QUALIFICATION.json",
        &prior_bytes,
        1024 * 1024,
    )?;
    write_new(
        out,
        "ADMISSION_GUARDS.json",
        &json!({
            "schema":"grouped-m2-pre-claim-seed-domain-proof-v1",
            "new_seed":SEED,"new_seed_hex":"0x034D32424C000901","sampling_seed":sampling_seed(SEED),
            "first_founder_seed":seed_admission_preflight(SEED, 1)?,
            "maximum_seed_one_founder":max,"maximum_seed_accepted":true,"next_seed_rejected":true,
            "u64_max_rejected":true,"zero_and_invalid_founder_count_rejected":true,
            "failed_original_seed_rejected":true,"host_helper_fingerprint":ADMISSION_RUNTIME_FINGERPRINT,
            "source_constructions":0,"world_constructions":0,"body_preparation_intervals":0,"native_calls":0,
            "unit_tests_required_separately":"root identity, source publication ordering/failure, attempted-call accounting and ordered cycle tests"
        }),
    )?;
    let mut q = prior.clone();
    let arms = q
        .as_object_mut()
        .ok_or("reference receipt is not an object")?
        .remove("arms")
        .ok_or("reference arms absent")?;
    q["reused_runtime_arms_not_this_executable"] = arms;
    q["qualification_scope"] =
        json!("admission-only; unchanged native runtime via exact prior proof");
    q["reused_runtime_qualification_sha256"] = json!(ADMISSION_REFERENCE_SHA256);
    q["reused_runtime_driver_commit"] = json!(ADMISSION_REFERENCE_COMMIT);
    q["reused_runtime_native_calls_not_this_executable"] = json!(50);
    q["reused_runtime_preparation_intervals_not_this_executable"] = json!(1200);
    q["host_helper_fingerprint"] = json!(ADMISSION_RUNTIME_FINGERPRINT);
    q["driver_commit"] = json!(DRIVER_COMMIT);
    q["driver_code_sha256"] = json!(code_hash());
    q["executable_sha256"] = json!(executable_hash()?);
    q["protocol_sha256"] = json!(hash(PROTOCOL));
    q["actual_native_calls"] = json!(0);
    q["actual_preparation_intervals"] = json!(0);
    q["source_constructions"] = json!(0);
    q["wall_seconds"] = Value::Null;
    let free = journal::free_bytes(out)?;
    q["free_bytes_at_qualification"] = json!(free);
    let required = q["projected_pair_physical_bytes"]
        .as_u64()
        .ok_or("projection absent")?
        .checked_add(
            q["metadata_initial_export_headroom"]
                .as_u64()
                .ok_or("headroom absent")?,
        )
        .and_then(|n| n.checked_add(journal::MIN_FREE_BYTES))
        .ok_or("resource overflow")?;
    let adequate = free > required;
    q["complete"] = json!(adequate);
    q["resource_projection_adequate"] = json!(adequate);
    write_new(
        out,
        if adequate {
            "QUALIFICATION_COMPLETE.json"
        } else {
            "QUALIFICATION_RESOURCE_BLOCKED.json"
        },
        &q,
    )?;
    if !adequate {
        return Err("admission-qualified source below measured resource guard".into());
    }
    Ok(())
}
