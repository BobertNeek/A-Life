//! Read-only raw JSON slicing. Never deserialize/re-emit authoritative M2 bytes.
use super::{hash, Result};
use std::collections::BTreeMap;

pub const MAGIC: &[u8] =
    b"ALIFE-GROUPED-M2-HOST\0V1\0CONFIDENCE-V2\0SYNAPTIC-CLOSED\0PROFILE5\0SAMPLER-BITS1\0";
#[derive(Clone, Copy)]
pub struct Raw<'a>(pub &'a [u8]);
impl<'a> Raw<'a> {
    pub fn object(self) -> Result<BTreeMap<String, Self>> {
        let bytes = self.0;
        if bytes.first() != Some(&b'{') {
            return Err("raw object expected".into());
        }
        let mut pos = 1;
        let mut out = BTreeMap::new();
        loop {
            ws(bytes, &mut pos);
            if bytes.get(pos) == Some(&b'}') {
                pos += 1;
                break;
            }
            let (key, end) = read::<String>(&bytes[pos..])?;
            pos += end;
            ws(bytes, &mut pos);
            if bytes.get(pos) != Some(&b':') {
                return Err("raw colon expected".into());
            }
            pos += 1;
            ws(bytes, &mut pos);
            let start = pos;
            let (_, len) = read::<serde::de::IgnoredAny>(&bytes[pos..])?;
            pos += len;
            if out.insert(key, Raw(&bytes[start..pos])).is_some() {
                return Err("duplicate raw key".into());
            }
            ws(bytes, &mut pos);
            match bytes.get(pos) {
                Some(b',') => pos += 1,
                Some(b'}') => {
                    pos += 1;
                    break;
                }
                _ => return Err("raw object delimiter".into()),
            }
        }
        ws(bytes, &mut pos);
        if pos != bytes.len() {
            return Err("raw object trailing bytes".into());
        }
        Ok(out)
    }
    pub fn array(self) -> Result<Vec<Self>> {
        let bytes = self.0;
        if bytes.first() != Some(&b'[') {
            return Err("raw array expected".into());
        }
        let mut pos = 1;
        let mut out = Vec::new();
        loop {
            ws(bytes, &mut pos);
            if bytes.get(pos) == Some(&b']') {
                pos += 1;
                break;
            }
            let start = pos;
            let (_, len) = read::<serde::de::IgnoredAny>(&bytes[pos..])?;
            pos += len;
            out.push(Raw(&bytes[start..pos]));
            ws(bytes, &mut pos);
            match bytes.get(pos) {
                Some(b',') => pos += 1,
                Some(b']') => {
                    pos += 1;
                    break;
                }
                _ => return Err("raw array delimiter".into()),
            }
        }
        ws(bytes, &mut pos);
        if pos != bytes.len() {
            return Err("raw array trailing bytes".into());
        }
        Ok(out)
    }
    pub fn field(self, name: &str) -> Result<Self> {
        self.object()?
            .remove(name)
            .ok_or_else(|| format!("missing raw field {name}").into())
    }
    pub fn path(self, path: &[&str]) -> Result<Self> {
        path.iter().try_fold(self, |v, key| v.field(key))
    }
    pub fn one(self) -> Result<Self> {
        let values = self.array()?;
        if values.len() != 1 {
            return Err("exactly one raw resident expected".into());
        }
        Ok(values[0])
    }
    pub fn value<T: serde::de::DeserializeOwned>(self) -> Result<T> {
        Ok(serde_json::from_slice(self.0)?)
    }
}
fn ws(bytes: &[u8], pos: &mut usize) {
    while bytes.get(*pos).is_some_and(u8::is_ascii_whitespace) {
        *pos += 1;
    }
}
fn read<T: serde::de::DeserializeOwned>(bytes: &[u8]) -> Result<(T, usize)> {
    let mut stream = serde_json::Deserializer::from_slice(bytes).into_iter::<T>();
    let value = stream.next().ok_or("missing raw JSON value")??;
    Ok((value, stream.byte_offset()))
}
pub fn payload(cp: &[u8]) -> Result<Raw<'_>> {
    Ok(Raw(cp.strip_prefix(MAGIC).ok_or("not M2 raw wire")?))
}

/// The only allowed initial-pair differences are mode and mode-derived brain
/// authority digests. All other original bytes, including f64 IEEE seals, match.
pub fn matched_initial(cp: &[u8], expected_mode: &str) -> Result<Vec<u8>> {
    let p = payload(cp)?;
    let mut excluded = vec![p.field("mode")?];
    if excluded[0].value::<String>()? != expected_mode {
        return Err("wrong initial mode".into());
    }
    let controllers = p.field("controllers")?.object()?;
    if controllers.len() != 1 {
        return Err("initial controller roster differs".into());
    }
    for c in controllers.values() {
        let mode = c.path(&["motor", "mode"])?;
        if mode.value::<String>()? != expected_mode {
            return Err("wrong initial append mode".into());
        }
        excluded.push(mode);
    }
    let record = p
        .path(&["canonical", "world", "world", "organism_records"])?
        .one()?;
    excluded.push(record.path(&["state_graph", "brain", "content_digest"])?);
    let mut spans = excluded
        .iter()
        .map(|raw| {
            let start = raw.0.as_ptr() as usize - cp.as_ptr() as usize;
            (start, start + raw.0.len())
        })
        .collect::<Vec<_>>();
    spans.sort_unstable();
    let mut result = Vec::new();
    let mut cursor = 0;
    for (start, end) in spans {
        if start < cursor || end > cp.len() {
            return Err("overlapping initial mask".into());
        }
        result.extend_from_slice(&cp[cursor..start]);
        result.extend_from_slice(b"null");
        cursor = end;
    }
    result.extend_from_slice(&cp[cursor..]);
    Ok(result)
}
/// Exact hashes of every prohibited write bank and immutable source field.
/// Dynamic activation, memory/predictor, sleep and biology are deliberately not frozen.
pub fn closure(cp: &[u8]) -> Result<BTreeMap<String, String>> {
    let p = payload(cp)?;
    let mut out = BTreeMap::new();
    for key in [
        "schema_version",
        "source_lineage",
        "policy",
        "runtime_profile_raw",
        "selector_tag",
        "decoder_stride",
        "mode",
        "source_inputs",
        "recipe_digest",
        "source_asset",
        "founder",
    ] {
        out.insert(key.into(), hash(p.field(key)?.0));
    }
    let resident = p.path(&["canonical", "residents"])?.one()?;
    let neural = resident.field("neural")?;
    for key in [
        "schema_version",
        "organism_id",
        "phenotype_hash",
        "fast",
        "lifetime",
        "eligibility",
        "weight_generation",
    ] {
        out.insert(format!("resident.neural.{key}"), hash(neural.field(key)?.0));
    }
    out.insert(
        "resident.neural.dendrites".into(),
        hash(neural.path(&["neural", "dendrites"])?.0),
    );
    out.insert(
        "resident.neural_topology".into(),
        hash(resident.field("neural_topology")?.0),
    );
    let record = p
        .path(&["canonical", "world", "world", "organism_records"])?
        .one()?;
    for key in [
        "genome",
        "phenotype",
        "birth_tick",
        "organism_id",
        "world_entity_id",
    ] {
        out.insert(format!("record.{key}"), hash(record.field(key)?.0));
    }
    for (owner, c) in p.field("controllers")?.object()? {
        let motor = c.field("motor")?;
        for key in [
            "schema",
            "source_inputs",
            "source_hash",
            "mode",
            "m2_recipe",
            "group_recipe",
            "work_policy",
        ] {
            out.insert(
                format!("controller.{owner}.{key}"),
                hash(motor.field(key)?.0),
            );
        }
    }
    Ok(out)
}
pub fn source_headers(cp: &[u8]) -> Result<BTreeMap<String, String>> {
    let p = payload(cp)?;
    let mut result = BTreeMap::new();
    for key in [
        "source_lineage",
        "policy",
        "runtime_profile_raw",
        "selector_tag",
        "decoder_stride",
        "recipe_digest",
        "source_inputs",
        "source_asset",
        "founder",
    ] {
        result.insert(key.into(), hash(p.field(key)?.0));
    }
    for (owner, c) in p.field("controllers")?.object()? {
        for key in ["schema", "m2_recipe", "group_recipe", "work_policy"] {
            result.insert(
                format!("controller.{owner}.{key}"),
                hash(c.path(&["motor", key])?.0),
            );
        }
    }
    let record = p
        .path(&["canonical", "world", "world", "organism_records"])?
        .one()?;
    // The record genotype is checked by the native restore and the complete
    // prepared-pair comparison; source_inputs/source_asset seal its compiled source.
    result.insert("initial_record_sha256".into(), hash(record.0));
    Ok(result)
}
pub fn fresh(cp: &[u8], preparation: u64, sampler: u32) -> Result<()> {
    let p = payload(cp)?;
    let canonical = p.field("canonical")?;
    if canonical.field("sampling_seed")?.value::<u32>()? != sampler
        || canonical.field("sampling_counter")?.value::<u32>()? != 0
    {
        return Err("fresh sampler differs".into());
    }
    let r = canonical.field("residents")?.one()?;
    let n = r.field("neural")?;
    if r.field("next_sequence")?.value::<u64>()? != 1
        || !r.field("replay")?.array()?.is_empty()
        || n.field("last_decision_tick")?.0 != b"null"
        || n.field("last_outcome_tick")?.0 != b"null"
        || n.field("dispatch_generation")?.value::<u64>()? != 0
    {
        return Err("fresh neural history differs".into());
    }
    for key in ["fast", "lifetime", "eligibility"] {
        if n.field(key)?
            .value::<Vec<f32>>()?
            .iter()
            .any(|v| v.to_bits() != 0)
        {
            return Err("fresh acquired bank is nonzero".into());
        }
    }
    if canonical
        .path(&["world", "world", "tick"])?
        .value::<u64>()?
        != preparation
    {
        return Err("fresh prepared tick differs".into());
    }
    Ok(())
}
