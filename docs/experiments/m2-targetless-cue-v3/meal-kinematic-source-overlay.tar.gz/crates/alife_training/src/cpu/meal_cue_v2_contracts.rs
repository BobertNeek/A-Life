//! Authored pure observed-cue contract controls, NOT executed or physical meal evidence.
//! Inputs are validated public profile5 frames/queries. No world-kind/owner oracle.
use super::*;
#[derive(Clone)]
struct Input {ids:[u32;3],chemical:[f32;3],shape:[f32;3],color:[f32;3],temperature:f32,terrain:[f32;2],eat_bearing:Option<[f32;2]>,distance:f32,contact:f32,confidence:f32,pain:f32,missing:bool,velocity:[[f32;3];3],proprioception:[f32;2]}
impl Default for Input{fn default()->Self{Self{ids:[71,72,73],chemical:[0.2,0.3,0.4],shape:[0.2,0.4,0.5],color:[0.2,0.5,0.7],temperature:0.4,terrain:[0.2,0.3],eat_bearing:None,distance:0.0625,contact:1.,confidence:0.9,pain:0.,missing:false,velocity:[[0.;3];3],proprioception:[0.;2]}}}
fn fixture(input:Input)->Result<(PerceptionFrame,MotorCommandBundle),ScaffoldContractError>{
    let owner=OrganismId(811);let tick=Tick::new(10);let mut unique=Vec::new();
    for id in input.ids{if !unique.contains(&id){unique.push(id);}}
    let slots=unique.iter().enumerate().map(|(i,id)|Ok(GroundedObjectSlotV1{
        slot_index:i as u16,tracked_object_id:TrackedObjectId(u64::from(*id)*10),bearing:if i==1{input.eat_bearing.unwrap_or([0.,1.])}else{[0.,1.]},distance:input.distance,
        relative_velocity:input.velocity[i],color:input.color,material:[0.1,0.3,0.6],shape:input.shape,
        chemical:input.chemical,contact:input.contact,proprioception:input.proprioception,temperature:input.temperature,terrain:input.terrain,
        confidence:Confidence::new(input.confidence)?})).collect::<Result<Vec<_>,ScaffoldContractError>>()?;
    let types=[(102,ActionKind::Move,CandidateActionFamily::Avoid,MotorChannel::Locomotion),
        (210,ActionKind::Interact,CandidateActionFamily::Ingest,MotorChannel::Manipulation),
        (4,ActionKind::Inspect,CandidateActionFamily::Inspect,MotorChannel::Posture)];
    let mut candidates=Vec::new();let mut commands=Vec::new();
    for (i,(id,kind,family,channel))in types.into_iter().enumerate(){
        let slot=unique.iter().position(|id|*id==input.ids[i]).unwrap();let target=ActionTarget::new(Some(WorldEntityId(u64::from(input.ids[i]))),Some(Vec3f::new(input.distance*8.,0.,0.)));
        candidates.push(ActionCandidate::new(i as u16,ActionId(id),kind,family,
            if input.missing{CandidateObservationRef::None}else{CandidateObservationRef::ObjectSlot(slot as u16)},target,
            slots[slot].candidate_features()?,Confidence::new(input.confidence)?,NormalizedScalar::new(0.2)?,DurationTicks::new(1),DurationTicks::new(2))?);
        commands.push(ChannelCommand::new(channel,ActionId(id),Some(target),Vec3f::ZERO,Intensity::new(1.)?,DurationTicks::new(1),0.,Confidence::new(0.8)?,0)?);
    }
    let profile=SensorProfile::GroundedObjectSlotsSleepChoiceV1;let mut home=HomeostaticSnapshot::baseline(tick);home.drives.pain=input.pain;
    let draft=PerceptionFrameDraft::new(owner,tick,profile,SensorySnapshot::new(owner,tick,Vec3f::ZERO,SensoryChannels::ZERO,Default::default())?,
        BodySnapshot{pose:Pose::IDENTITY,velocity:Velocity::ZERO},home,candidates,SensorProfileProvenance::new(profile,SensoryAbiVersion::CURRENT,tick)?,slots)?;
    let bank=MemoryBank::new(MemoryBankConfig::new(8,64,4,0.72,Confidence::new(0.)?)?)?;
    let(frame,_)=bank.recall_frame(&draft)?.finalize(draft)?;
    Ok((frame,MotorCommandBundle::new(owner,ExperienceSequenceId::new(1).ok_or(ScaffoldContractError::InvalidId)?,tick,commands)?))
}
fn context(input:Input)->Result<ObservedJoint,ScaffoldContractError>{let(f,b)=fixture(input)?;ObservedJoint::capture(&f,&b)}
fn newer()->Input{Input{ids:[171,172,173],..Input::default()}}

// One host fixture calls these pure contracts before creating its single world.
// No sealed experience is fabricated and no contract advances biology.
pub(super) fn run(){
    let consumed=Some(MotorChannel::Manipulation);
    let a=context(Input::default()).unwrap();
    let eat_velocity=[[0.;3],[0.31,-0.27,0.19],[0.;3]];
    let b=context(Input{velocity:eat_velocity,..newer()}).unwrap();
    assert_eq!(a.meal_weight_v2(&b,consumed),Some(1.));
    assert!(a.graded_weight(&b,consumed).is_none());
    assert!(!a.matches(&b,LookupModeV1::ExecutorEntityRoutesV2,consumed));
    assert!(!a.matches(&b,LookupModeV1::ExactIdentityControl,consumed));
    // Every velocity axis and sign is exempted only for contacted/reached Eat.
    for axis in 0..3{for velocity in [-1.,-0.021,0.021,1.]{
        let mut v=[[0.;3];3];v[1][axis]=velocity;
        assert_eq!(a.meal_weight_v2(&context(Input{velocity:v,..newer()}).unwrap(),consumed),Some(1.));
        for role in [0,2]{let mut other=[[0.;3];3];other[role][axis]=velocity;
            assert!(a.meal_weight_v2(&context(Input{velocity:other,..newer()}).unwrap(),consumed).is_none());}
    }}
    // Source and query must both be in range, with matching observed contact.
    let far=context(Input{distance:0.2,velocity:eat_velocity,..newer()}).unwrap();
    assert!(a.meal_weight_v2(&far,consumed).is_none());assert!(far.meal_weight_v2(&a,consumed).is_none());
    let no_contact=context(Input{contact:0.,velocity:eat_velocity,..newer()}).unwrap();
    assert!(a.meal_weight_v2(&no_contact,consumed).is_none());
    let source_no_contact=context(Input{contact:0.,..Input::default()}).unwrap();
    assert!(source_no_contact.meal_weight_v2(&no_contact,None).is_none(),"uncontacted Eat retains V1 velocity gate");
    let chemistry=context(Input{chemical:[0.2,0.3,0.4001],velocity:eat_velocity,..newer()}).unwrap();
    assert!(a.meal_weight_v2(&chemistry,consumed).is_none());
    let same=context(newer()).unwrap();assert_eq!(a.graded_weight(&same,consumed),a.meal_weight_v2(&same,consumed));
    let shared=context(Input{ids:[171,171,173],..newer()}).unwrap();
    assert!(a.meal_weight_v2(&shared,consumed).is_none());assert!(shared.meal_weight_v2(&a,consumed).is_none());
    let mut reordered=b.clone();reordered.roles.reverse();assert_eq!(a.meal_weight_v2(&reordered,consumed),Some(1.));
    for kind in 0..4{let mut edited=b.clone();let c=&mut edited.roles[1].command;match kind{
        0=>c.primitive=ActionId(211),1=>c.payload=BoundedMotorPayload::new(vec![1]).unwrap(),
        2=>c.intensity=Intensity::new(0.5).unwrap(),_=>c.duration_ticks=DurationTicks::new(2)};
        assert!(a.meal_weight_v2(&edited,consumed).is_none());}
    let mut other_owner=b.clone();other_owner.owner=OrganismId(812);assert!(a.meal_weight_v2(&other_owner,consumed).is_none());
    assert!(a.meal_weight_v2(&context(Input{pain:0.151,velocity:eat_velocity,..newer()}).unwrap(),consumed).is_none());
    assert!(a.meal_weight_v2(&context(Input{proprioception:[0.051,0.],velocity:eat_velocity,..newer()}).unwrap(),consumed).is_none());
    assert!(context(Input{confidence:0.4,..newer()}).is_err());assert!(context(Input{missing:true,..newer()}).is_err());
    assert!(context(Input{velocity:[[0.;3],[f32::NAN,0.,0.],[0.;3]],..newer()}).is_err());
    let distant=context(Input{color:[0.8,0.1,0.2],temperature:-1.,terrain:[1.,1.],velocity:eat_velocity,..newer()}).unwrap();
    let weight=a.meal_weight_v2(&distant,consumed).unwrap();assert!(weight>0.&&weight<1.);
    let positive=attenuated_signed_mean(&[(0.8,weight)]).unwrap().unwrap();
    let negative=attenuated_signed_mean(&[(-0.8,weight)]).unwrap().unwrap();
    assert!(0.<positive&&positive<0.8);assert!(-0.8<negative&&negative<0.);assert_eq!(negative,-positive);
    assert_eq!(attenuated_signed_mean(&[(0.8,weight),(0.,1.)]).unwrap(),Some(positive/2.));
    assert!(attenuated_signed_mean(&[(0.2,1.),(-0.8,1.)]).unwrap().unwrap()<0.);
    let(f,bundle)=fixture(newer()).unwrap();
    let expected=expectation(vec![1],vec![0.08],vec![consumed],LookupModeV1::VisibleCueRoles,f.frame_digest(),bundle.canonical_digest().unwrap()).unwrap();
    assert_eq!(expected.grip,GripEvidenceV1::Unknown);assert_eq!(expected.future_consumption,FutureConsumptionV1::Unknown);
    let m=FreshMealCueMemoryV2::fresh(OrganismId(811),PhenotypeHash([1,2,3,4]),[8,7,6,5]).unwrap();
    let(bytes,anchor)=m.checkpoint().unwrap();assert_eq!(FreshMealCueMemoryV2::restore(&bytes,&anchor).unwrap().checkpoint().unwrap().0,bytes);
    let(v1_bytes,v1_anchor)=m.legacy.checkpoint().unwrap();
    assert!(FreshVisibleCueMemoryV1::restore(&bytes,&anchor).is_err());assert!(FreshMealCueMemoryV2::restore(&v1_bytes,&v1_anchor).is_err());
    let mut stale=anchor.clone();stale.generation+=1;assert!(FreshMealCueMemoryV2::restore(&bytes,&stale).is_err());
}
