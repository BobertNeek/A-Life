//! SOURCE-ONLY fresh research owner. No checkpoint import, migration or host dispatch.
//! Every expectation belongs to the whole joint event. Future consumption is unknown.
use alife_core::*;
use alife_joint_episode::joint_episode::JointEpisodeMemoryV1;

pub const VISIBLE_CUE_JOINT_OWNER_V1:&str="fresh-graded-cue-joint-v1/observed-kernel/profile5/grip-unknown/no-migration";
const CAPACITY:usize=64;
const TARGET_START:usize=MEMORY_TARGET_RANGE.start; // Existing MemoryQueryV2 target-feature block, not new lanes.
const MAX_INTERACTION_DISTANCE:f32=1.25/8.0; // Verified profile5 normalizer/range contract.
fn invalid()->ScaffoldContractError{ScaffoldContractError::InvalidMemoryQuery}
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub enum LookupModeV1 { ExactIdentityControl, VisibleCueRoles, ExecutorEntityRoutesV2 }
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub enum GripEvidenceV1 { Unknown }
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub enum FutureConsumptionV1 { Unknown }
#[derive(Debug,Clone)]
pub struct WholeEventExpectationV1 {
    pub queried_frame:PerceptionFrameDigest,
    pub queried_bundle:[u64;4],
    pub source_sequences:Vec<u64>,
    pub original_joint_valences:Vec<f32>,
    /// Unscaled arithmetic mean of actual whole-event valences, never a family value.
    pub expected_joint_valence:f32,
    /// Source-record role witnesses only; NOT facts about the current targets.
    pub consumed_source_channels:Vec<Option<MotorChannel>>,
    pub grip:GripEvidenceV1,
    pub future_consumption:FutureConsumptionV1,
    pub mode:LookupModeV1,
}
#[derive(Debug,Clone)]
struct ObservedRole {command:ChannelCommand,query:Option<CandidateMemoryQueryV2>}
#[derive(Debug,Clone)]
struct ObservedJoint {
    owner:OrganismId,drives:[f32;DriveSnapshot::CHANNEL_COUNT],roles:Vec<ObservedRole>,coordination:BoundedCoordinationSummary,
}
impl ObservedJoint {
    fn capture(frame:&PerceptionFrame,bundle:&MotorCommandBundle)->Result<Self,ScaffoldContractError>{
        frame.validate_contract()?;bundle.validate_contract()?;
        if frame.profile_provenance().identity().profile_id.raw()!=5
            || frame.organism_id()!=bundle.organism_id || frame.tick()!=bundle.tick{return Err(invalid());}
        let draft=PerceptionFrameDraft::new(frame.organism_id(),frame.tick(),frame.sensor_profile(),
            frame.sensory().clone(),frame.body(),*frame.homeostasis(),frame.candidates().to_vec(),
            frame.profile_provenance(),frame.grounded_object_slots().to_vec())?;
        if draft.base_digest()!=frame.base_digest() || draft.clone().finalize(frame.context().clone())?!=*frame{return Err(invalid());}
        // Additional cue-admission consistency only. The genuine sealed writer
        // remains authoritative even when this stricter readout key is unavailable.
        for (index,group) in bundle.coordination.groups.iter().enumerate(){
            if bundle.coordination.groups[..index].iter().any(|g|g.group_id==group.group_id){return Err(invalid());}
            for channel in &group.channels {
                let command=bundle.channels.iter().find(|c|c.channel==*channel).ok_or_else(invalid)?;
                if command.coordination_group!=group.group_id{return Err(invalid());}
            }
        }
        for command in &bundle.channels {
            if command.coordination_group!=0 && bundle.coordination.groups.iter().filter(|g|
                g.group_id==command.coordination_group&&g.channels.contains(&command.channel)).count()!=1{return Err(invalid());}
        }
        let mut roles=Vec::new();
        for command in &bundle.channels {
            let normalized_target=command.target.unwrap_or(ActionTarget::NONE);
            let target=normalized_target.entity;
            let candidates=frame.candidates().iter().filter(|c|c.action_id==command.primitive
                && c.target==normalized_target).collect::<Vec<_>>();
            if candidates.len()!=1{return Err(invalid());}let candidate=candidates[0];
            let query=if target.is_some(){
                let CandidateObservationRef::ObjectSlot(i)=candidate.observation else{return Err(invalid());};
                let slot=frame.grounded_object_slots().get(i as usize).ok_or_else(invalid)?;
                if slot.confidence.raw()<0.5||candidate.sensor_confidence.raw()<0.5{return Err(invalid());}
                let q=MemoryQueryEncoderV2::encode_candidate(&draft,candidate)?;
                q.validate_against_frame(frame,candidate)?;
                if q.tracked_object_id()!=Some(slot.tracked_object_id){return Err(invalid());}
                let target_features=&q.features()[TARGET_START..TARGET_START+24];
                if target_features!=slot.candidate_features()?.0.as_slice(){return Err(invalid());}
                // Insufficient discriminating cue evidence, not an assertion that
                // a measured zero channel means a missing chemical/hidden category.
                if target_features[6..18].iter().all(|x|*x==0.){return Err(invalid());}
                Some(q)
            }else{
                // A position-only target has no visible slot/role evidence. Do
                // not silently treat two different absolute points as one None role.
                if normalized_target!=ActionTarget::NONE || candidate.observation!=CandidateObservationRef::None{return Err(invalid());}None
            };
            roles.push(ObservedRole{command:command.clone(),query});
        }
        Ok(Self{owner:frame.organism_id(),drives:frame.homeostasis().drives.to_array(),roles,coordination:bundle.coordination.clone()})
    }
    fn matches(&self,other:&Self,mode:LookupModeV1,consumed_channel:Option<MotorChannel>)->bool{
        if self.owner!=other.owner || self.roles.len()!=other.roles.len() || self.coordination!=other.coordination
            || self.drives.iter().zip(other.drives).any(|(a,b)|(a-b).abs()>0.15){return false;}
        let mut aligned=Vec::new();
        for a in &self.roles {
            let Some(b)=other.roles.iter().find(|b|b.command.channel==a.command.channel)else{return false;};
            let ac=&a.command;let bc=&b.command;
            if ac.primitive!=bc.primitive || ac.payload!=bc.payload || ac.coordination_group!=bc.coordination_group
                || ac.intensity!=bc.intensity || ac.duration_ticks!=bc.duration_ticks
                || (!entity_route_equivalent(ac,bc,mode) && (ac.direction!=bc.direction
                    || ac.stand_off_distance!=bc.stand_off_distance || ac.confidence!=bc.confidence)){return false;}
            let at=ac.target.and_then(|t|t.entity);let bt=bc.target.and_then(|t|t.entity);
            if at.is_some()!=bt.is_some() || (mode==LookupModeV1::ExactIdentityControl&&at!=bt){return false;}
            // Every cross-instance mode shares ALL observed cue guards. The
            // semantic variant changes only proven-unused command fields above.
            if matches!(mode,LookupModeV1::VisibleCueRoles|LookupModeV1::ExecutorEntityRoutesV2) {
                match (&a.query,&b.query){
                    (Some(aq),Some(bq))=>{
                        let af=&aq.features()[TARGET_START..TARGET_START+24];let bf=&bq.features()[TARGET_START..TARGET_START+24];
                        // Reuse the existing observed descriptor lanes. Any change
                        // in chemical, shape, material, color, temperature or terrain
                        // rejects transfer. No WorldObjectKind/FoodVariety lookup.
                        for i in (6..18).chain(21..24){if af[i].to_bits()!=bf[i].to_bits(){return false;}}
                        for i in 0..6 {let limit=if i<2{0.05}else{0.02};if (af[i]-bf[i]).abs()>limit{return false;}}
                        for i in 19..21 {if (af[i]-bf[i]).abs()>0.05{return false;}}
                        if af[18].to_bits()!=bf[18].to_bits(){return false;}
                        if ac.channel==MotorChannel::Manipulation {
                            if af[2]>MAX_INTERACTION_DISTANCE||bf[2]>MAX_INTERACTION_DISTANCE{return false;}
                            // Contact is necessary for a consumed-event cue transfer,
                            // but never interpreted as ownership or immediate ingestion.
                            if consumed_channel==Some(ac.channel)&&(af[18]!=1.||bf[18]!=1.){return false;}
                        }
                    },(None,None)=>{},_=>return false,
                }
            }
            aligned.push(b);
        }
        // Preserve the complete target equality graph (including shared targets).
        // A per-role bijection cannot merge/split two originally equal targets.
        for i in 0..self.roles.len(){for j in 0..self.roles.len(){
            let a=self.roles[i].command.target.and_then(|t|t.entity);
            let b=self.roles[j].command.target.and_then(|t|t.entity);
            let c=aligned[i].command.target.and_then(|t|t.entity);
            let d=aligned[j].command.target.and_then(|t|t.entity);
            if (a==b)!=(c==d){return false;}
        }}
        true
    }
}
// The raw commands remain in ObservedRole and sealed exact episodes. Only these
// proven entity-only routes normalize unused fallback fields at lookup. Flee,
// Approach, absolute movement and orientation retain their raw distinctions.
fn entity_route_equivalent(a:&ChannelCommand,b:&ChannelCommand,mode:LookupModeV1)->bool {
    mode==LookupModeV1::ExecutorEntityRoutesV2
        && a.target.and_then(|t|t.entity).is_some() && b.target.and_then(|t|t.entity).is_some()
        && ((a.channel==MotorChannel::Manipulation && a.primitive==ActionId(210))
            || (a.channel==MotorChannel::Posture && a.primitive==ActionId(4)))
        && a.channel==b.channel && a.primitive==b.primitive
}
#[derive(Debug,Clone)]
struct CueRecord {sequence:u64,observed:Option<ObservedJoint>,consumed_channel:Option<MotorChannel>,frame:Option<PerceptionFrame>}
#[derive(Debug,Clone)]
pub struct FreshVisibleCueMemoryV1 {
    owner_domain:String,exact:JointEpisodeMemoryV1,cues:Vec<CueRecord>,
}
impl FreshVisibleCueMemoryV1 {
    pub fn fresh(owner:OrganismId,phenotype:PhenotypeHash,fresh_lineage:[u64;4])->Result<Self,ScaffoldContractError>{
        if fresh_lineage==[0;4]{return Err(invalid());}
        let mut h=blake3::Hasher::new();h.update(VISIBLE_CUE_JOINT_OWNER_V1.as_bytes());
        for word in fresh_lineage{h.update(&word.to_le_bytes());}
        let bytes=h.finalize();let lineage=std::array::from_fn(|i|u64::from_le_bytes(bytes.as_bytes()[i*8..i*8+8].try_into().unwrap()));
        Ok(Self{owner_domain:VISIBLE_CUE_JOINT_OWNER_V1.into(),exact:JointEpisodeMemoryV1::fresh(owner,phenotype,lineage,CAPACITY)?,cues:vec![]})
    }
    /// Only new sealed events may enter this owner. No old-record/import/restore API.
    pub fn observe(&mut self,patch:&ExperiencePatch,frame:&PerceptionFrame)->Result<(),ScaffoldContractError>{
        self.observe_bounded(patch,frame,MAX_FRAME_BYTES)
    }
    #[cfg(test)]
    pub(crate) fn observe_without_cue_budget(&mut self,patch:&ExperiencePatch,frame:&PerceptionFrame)->Result<(),ScaffoldContractError>{
        self.observe_bounded(patch,frame,0)
    }
    fn observe_bounded(&mut self,patch:&ExperiencePatch,frame:&PerceptionFrame,frame_budget:usize)->Result<(),ScaffoldContractError>{
        if self.owner_domain!=VISIBLE_CUE_JOINT_OWNER_V1{return Err(invalid());}
        let bundle=patch.selected_bundle().ok_or_else(invalid)?;
        // Missing/insufficient cue evidence must not erase a genuine episode or
        // turn a successful registered transaction into a memory-write failure.
        // The exact sealed writer below still rejects every invalid source.
        let observed=ObservedJoint::capture(frame,bundle).ok();
        let mut staged=self.clone();staged.exact.observe(patch,frame)?;
        let episode=staged.exact.sleep_joint_sources().last().ok_or_else(invalid)?;
        let consumed_channel=if let Some(fact)=&episode.consumed{
            let commands=bundle.channels.iter().filter(|c|c.channel==MotorChannel::Manipulation
                &&c.target.and_then(|t|t.entity)==Some(fact.target)).collect::<Vec<_>>();
            if commands.len()!=1{return Err(invalid());}Some(commands[0].channel)
        }else{None};
        let frame_bytes=serde_json::to_vec(frame).map_err(|_|invalid())?;
        let witness=(frame_bytes.len()<=frame_budget).then(||frame.clone());
        staged.cues.push(CueRecord{sequence:episode.sequence.raw(),observed:if witness.is_some(){observed}else{None},consumed_channel,frame:witness});
        staged.cues.retain(|r|staged.exact.sleep_joint_sources().iter().any(|e|e.sequence.raw()==r.sequence));
        *self=staged;Ok(())
    }
    pub fn expected_whole_event(&self,frame:&PerceptionFrame,bundle:&MotorCommandBundle,mode:LookupModeV1)
        ->Result<Option<WholeEventExpectationV1>,ScaffoldContractError>{
        if self.owner_domain!=VISIBLE_CUE_JOINT_OWNER_V1{return Err(invalid());}
        let observed=ObservedJoint::capture(frame,bundle)?;
        let mut sequences=Vec::new();let mut valences=Vec::new();let mut consumed=Vec::new();
        for record in &self.cues {
            let Some(source)=&record.observed else{continue;};
            if !source.matches(&observed,mode,record.consumed_channel){continue;}
            let e=self.exact.sleep_joint_sources().iter().find(|e|e.sequence.raw()==record.sequence).ok_or_else(invalid)?;
            sequences.push(record.sequence);valences.push(e.joint_experienced_valence.raw());consumed.push(record.consumed_channel);
        }
        if valences.is_empty(){return Ok(None);}
        Ok(Some(expectation(sequences,valences,consumed,mode,frame.frame_digest(),bundle.canonical_digest()?)?))
    }
}
fn expectation(sequences:Vec<u64>,valences:Vec<f32>,consumed:Vec<Option<MotorChannel>>,mode:LookupModeV1,queried_frame:PerceptionFrameDigest,queried_bundle:[u64;4])
    ->Result<WholeEventExpectationV1,ScaffoldContractError>{
    if sequences.len()!=valences.len()||sequences.len()!=consumed.len(){return Err(invalid());}
    let mean=bounded_mean(&valences)?;
    Ok(WholeEventExpectationV1{queried_frame,queried_bundle,source_sequences:sequences,original_joint_valences:valences,
        expected_joint_valence:mean,consumed_source_channels:consumed,grip:GripEvidenceV1::Unknown,
        future_consumption:FutureConsumptionV1::Unknown,mode})
}
fn bounded_mean(values:&[f32])->Result<f32,ScaffoldContractError>{
    if values.is_empty()||values.iter().any(|v|!v.is_finite()||!(-1.0..=1.0).contains(v)){return Err(invalid());}
    Ok((values.iter().map(|v|f64::from(*v)).sum::<f64>()/values.len()as f64)as f32)
}
#[cfg(test)]
#[path="visible_cue_joint_tests.rs"]
mod tests;
include!("cue_wire.rs");

include!("graded_lookup.rs");
#[cfg(test)]
include!("cue_diagnostic.rs");

// Separate fresh owner. V1 storage and readers above remain literal controls.
#[path="meal_cue_v2.rs"]
pub(crate) mod meal_cue_v2;
