# World-only hand-swap comparison

Native CPU development evidence only. Two paired seeds are not generalization.
One unchanged v12 foundation, ordinary sleep only. Atomic replacement and item grounding are one bundled world factor.
Physical meals, exact Ingest episode coverage and exact-key recall are separate. Historical forced-sleep runs are not causal controls.

- s1_old_world: 256 ticks, H/S meals 1/10, stop tick_budget.
- s1_new_world: 256 ticks, H/S meals 1/14, stop tick_budget.
- s2_new_world: 256 ticks, H/S meals 1/13, stop tick_budget.
- s2_old_world: 256 ticks, H/S meals 1/7, stop tick_budget.

Validated 4; rejected 0; unknown 0; unstarted 0.
If no natural held-H/selected-S opportunity occurs, the proposed obstruction remains untested. An opportunity or generic failure does not establish hold-caused obstruction. No contact is not proof of avoidance. A swap is not proof of learned aversion.
